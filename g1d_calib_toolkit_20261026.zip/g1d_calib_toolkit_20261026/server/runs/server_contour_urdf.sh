#!/bin/bash
# URDF = dual_trans URDF + shoulder mount deltas from contour_fit.py; projected overlays on the held-out 1209 session
# (left) and the training sessions: nominal (red) / dual_trans (green) / contour (orange)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data/20261019/sessions
V=$R/scratch/urdf_variants_20261020
DT=$R/scratch/urdf_variants_20261019/dual_trans
cd /dev/shm/isaac_work
$PY - <<'EOF'
import json
r = json.load(open("contour_out/contour_fit_both.json"))
vals = {}
for side, d in r["sides"].items():
    vals.update(d["params"])
doc = {"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": False,
       "description": "shoulder_pitch frame deltas ON TOP OF the dual_trans URDF, fitted to the arm outline in the "
                      "head images (contour_fit.py); apply with --nominal <dual_trans dir>",
       "convention": "q_model = q_encoder + zero (radians)", "values": vals}
json.dump(doc, open("contour_out/params_contour_mount_1020.json", "w"), indent=2)
print(json.dumps(vals, indent=1))
EOF
rm -rf $V/contour
cd $R && $PY apply_calibration.py /dev/shm/isaac_work/contour_out/params_contour_mount_1020.json $V/contour --nominal $DT
ln -s $R/assembled_calib_20261016/meshes $V/contour/meshes
cd /dev/shm/isaac_work
I=$R/real_data/20261016/intrinsics/camera_intrinsics_head_left.json
C=$R/assembled_calib_20261016/camera_contract_v5.json
NOM=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf
CT=$V/contour/g1_d_upper_dex1_v4.urdf
for SS in "calib_20261019_1209_B_wrist_table_board_left left ov_contour_1209" \
          "calib_20261019_1509_B_wrist_table_board_left left ov_contour_1509" \
          "calib_20261019_1533_B_wrist_table_board_right right ov_contour_1533"; do
  set -- $SS
  $PY overlay_projected.py $3 $S/$1 $I $C $2 3 nominal=$NOM=0,0,255 dual_trans=$DT/g1_d_upper_dex1_v4.urdf=0,200,0 \
    contour=$CT=0,140,255 2>&1 | grep -v realcam
done
