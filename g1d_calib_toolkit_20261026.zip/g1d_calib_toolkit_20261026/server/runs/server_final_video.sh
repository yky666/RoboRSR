#!/bin/bash
# IsaacSim acceptance render on the HELD-OUT 1209 session: nominal vs contour-fitted URDF, overlays + comparison video
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
OUT=/dev/shm/isaac_work/render_cmp_1209
I=$R/real_data/20261016/intrinsics/camera_intrinsics_head_left.json
cd /dev/shm/isaac_work
tr -d '\r' < run_render_compare.sh > rrc.sh
VARIANTS="nominal=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf,contour=$R/scratch/urdf_variants_20261020/contour/g1_d_upper_dex1_v4.urdf" \
  SESSION=$R/real_data/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left EVERY=2 GPU=4 OUT=$OUT bash rrc.sh
grep -E '\[pose\]|EXIT' $OUT.log
$PY compare_overlay.py $OUT $I | tail -1
$PY make_compare_video.py $OUT $I $OUT/compare_1209_nominal_vs_contour_zoom.mp4 --zoom --right=contour | tail -1
$PY make_compare_video.py $OUT $I $OUT/compare_1209_nominal_vs_contour.mp4 --right=contour | tail -1
echo FINAL_VIDEO_DONE
