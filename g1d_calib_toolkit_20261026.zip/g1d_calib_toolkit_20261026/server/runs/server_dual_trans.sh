#!/bin/bash
# dual-arm identification with joint-origin translations added (3 mm prior), compare with preset-only
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
S=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019/sessions
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== dual + joint translations (prior 3 mm)"
$PY identify.py $S/meas_B_left_1209.json $S/meas_B_left_1509_pm.json $S/meas_B_right_1533_pm.json --preset auto --refine-intrinsics \
  --estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' \
  --loss soft_l1 --f-scale 1.0 --folds 5 --out $S/identify_dual_trans_1019.json --params-out $S/params_dual_trans_1019.json 2>&1 \
  | grep -v realcam | tail -45
echo TRANS_DONE
