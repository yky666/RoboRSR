#!/bin/bash
# dual-arm identification: left 1509 + right 1533 share ONE board pose (robot not moved between them);
# left 1209 has its own board. Shared board ties both arms -> right shoulder frame relative to left is identifiable.
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
S=$R/sessions
cd /dev/shm/isaac_work
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1509_B_wrist_table_board_left --header $R/poses_v2/scene_header_B.json \
  --board-name table_pm --out $S/meas_B_left_1509_pm.json | head -1
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1533_B_wrist_table_board_right --header $R/poses_v2/scene_header_B.json \
  --board-name table_pm --out $S/meas_B_right_1533_pm.json | head -1
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== identify dual-arm (1209 left + shared-board 1509 left / 1533 right)"
$PY identify.py $S/meas_B_left_1209.json $S/meas_B_left_1509_pm.json $S/meas_B_right_1533_pm.json --preset auto --refine-intrinsics \
  --loss soft_l1 --f-scale 1.0 --folds 5 --out $S/identify_dual_1019.json --params-out $S/params_dual_1019.json 2>&1 | grep -v realcam | tail -40
echo DUAL_DONE
