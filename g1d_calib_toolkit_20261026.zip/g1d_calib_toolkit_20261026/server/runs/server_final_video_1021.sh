#!/bin/bash
# IsaacSim acceptance render with the FINAL asset on today's held-out right-arm session (10-21): nominal vs final
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
OUT=/dev/shm/isaac_work/render_cmp_1021r
I=$R/real_data/20261016/intrinsics/camera_intrinsics_head_left.json
cd /dev/shm/isaac_work
tr -d '\r' < run_render_compare.sh > rrc.sh
ARM_SIDE=right \
VARIANTS="nominal=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf,final=$R/assembled_calib_20261021/g1_d_upper_dex1_v4.urdf" \
  SESSION=$R/real_data/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right EVERY=3 GPU=4 OUT=$OUT bash rrc.sh
grep -E '\[pose\]|EXIT' $OUT.log
$PY compare_overlay.py $OUT $I | tail -1
$PY make_compare_video.py $OUT $I $OUT/compare_1021_right_nominal_vs_final_zoom.mp4 --zoom --right=final --arm=right | tail -1
$PY make_compare_video.py $OUT $I $OUT/compare_1021_right_nominal_vs_final.mp4 --right=final --arm=right | tail -1
echo FINAL_VIDEO_DONE
