#!/bin/bash
# doc 07 regression checks for assembled_calib_20261021
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
A=$R/assembled_calib_20261021
cd $R
echo "===== unit tests"
$PY test_apply_calibration.py 2>&1 | tail -n 4
echo "===== usd_fk_validation"; head -c 700 $A/usd_fk_validation.json; echo
echo "===== usd_compare_vs_nominal"; head -c 1500 $A/usd_compare_vs_nominal.json; echo
echo "===== source_validation"; head -c 500 $A/source_validation.json; echo
echo "===== camera contract calibration section"
$PY - <<EOF
import json
c = json.load(open("$A/camera_contract_v5.json"))
cal = c.get("calibration", {})
print(json.dumps({k: (v if not isinstance(v, dict) else {kk: round(vv, 6) if isinstance(vv, float) else vv
                                                       for kk, vv in list(v.items())[:12]}) for k, v in cal.items()},
                 indent=1)[:1800])
EOF
