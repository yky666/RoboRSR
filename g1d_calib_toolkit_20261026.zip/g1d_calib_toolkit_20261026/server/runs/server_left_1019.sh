#!/bin/bash
# export + identify the 2026-10-19 left-arm sessions (1209: 25 samples, board fixed; 1509: 47 samples)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
S=$R/sessions
mkdir -p $S
cd $S && tar -xzf /dev/shm/isaac_work/left1509.tgz && tar -xzf /dev/shm/isaac_work/left1209.tgz
for d in calib_20261019_1209_B_wrist_table_board_left calib_20261019_1509_B_wrist_table_board_left; do
  echo "$d: $(wc -l < $S/$d/samples.jsonl) samples"
done
cd /dev/shm/isaac_work
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1209_B_wrist_table_board_left --header $R/poses/scene_header_B.json \
  --board-name table_1209 --out $S/meas_B_left_1209.json | head -1
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1509_B_wrist_table_board_left --header $R/poses_v2/scene_header_B.json \
  --board-name table_1509 --out $S/meas_B_left_1509.json | head -1
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== identify left (1209 + 1509)"
$PY identify.py $S/meas_B_left_1209.json $S/meas_B_left_1509.json --preset auto --refine-intrinsics --loss soft_l1 --f-scale 1.0 \
  --folds ${FOLDS:-5} --out $S/identify_left_1019.json --params-out $S/params_left_1019.json 2>&1 | grep -v realcam | tail -45
