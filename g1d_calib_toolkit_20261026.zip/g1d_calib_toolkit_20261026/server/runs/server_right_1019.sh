#!/bin/bash
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
S=$R/sessions
cd $S && tar -xzf /dev/shm/isaac_work/right1533.tgz
echo "right session: $(wc -l < $S/calib_20261019_1533_B_wrist_table_board_right/samples.jsonl) samples"
cd /dev/shm/isaac_work
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1533_B_wrist_table_board_right --header $R/poses_v2/scene_header_B.json \
  --board-name table_1533 --out $S/meas_B_right_1533.json | head -1
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== identify right (1533)"
$PY identify.py $S/meas_B_right_1533.json --preset auto --refine-intrinsics --loss soft_l1 --f-scale 1.0 --folds 5 \
  --out $S/identify_right_1019.json --params-out $S/params_right_1019.json 2>&1 | grep -v realcam | tail -30
