#!/bin/bash
# standard (nominal) URDF, joint-reading offsets only:
#   1) per image: sim joint angles that align the arm outline vs the encoder reading (is it a constant offset?)
#   2) one common offset per joint fitted on 1509+1533, tested on 1209
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
NOM=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf
cd /dev/shm/isaac_work
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
echo "===== per-image pose alignment $(date '+%T')"
$PY -u contour_fit.py pose contour_out $NOM both 2>&1 | grep -v realcam
echo "===== common joint offsets $(date '+%T')"
$PY -u contour_fit.py fit contour_out $NOM both zeros 2>&1 | grep -v realcam | grep -v ' eval '
echo "JOINT_OFFSETS_DONE $(date '+%T')"
