#!/bin/bash
# regenerate pose tables for the 2026-10-20 layout (torso ~4.7 cm lower than 10-19; board measured by head stereo)
O=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261020/poses
mkdir -p "$O"
cp /dev/shm/isaac_work/board_pose_1020.json "$O/board_pose_measured.json"
cd /dev/shm/isaac_work
(OPENBLAS_NUM_THREADS=8 nohup ${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python gen_poses.py \
  --board-json /dev/shm/isaac_work/board_pose_1020.json \
  --table-z -0.128 --table-edge-x 0.10 --idle-zero --min-clear 0.10 --out "$O" > /dev/shm/isaac_work/gen_1020.log 2>&1 &)
sleep 10
pgrep -af '[g]en_poses.py --board-json' | cut -c1-120
ls -la "$O"
