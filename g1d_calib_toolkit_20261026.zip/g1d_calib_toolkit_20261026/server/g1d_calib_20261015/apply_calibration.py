"""Write calibrated G1-D + Dex1 URDFs from a g1d_calib_params_v1 file.

Only joint <origin> elements change. Joint names, types, axes (child frame) and limits are kept, so the URDF joint
value stays the real encoder value: FK_calibrated(q_encoder) = FK_nominal(q_encoder + zero) for pure zero offsets.
Camera, intrinsics and base deltas are not URDF data; they are carried to the provenance for the camera-contract step.

usage: apply_calibration.py PARAMS.json OUT_DIR [--nominal DIR]
"""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from scipy.spatial.transform import Rotation
from calib_model import NOMINAL, Robot, load_params

VARIANTS = ['g1_d_upper_dex1_v4.urdf', 'g1_d_full_dex1_v4.urdf']
LIMIT_POLICY = ('Limits are kept unchanged in encoder values. The real controller enforces limits on encoder readings, and the '
                'URDF joint value is the encoder value, so commanded ranges are identical on both sides. The physical range '
                'expressed in the nominal geometry becomes [lower + zero, upper + zero]; it is reported, not written.')

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
fmt = lambda v: ' '.join(repr(float(x)) for x in v)


def split(values):
    joints, other = {}, {}
    for name, v in values.items():
        head, key = name.split('/')
        if ':' in head:
            other[name] = float(v)
        else:
            joints.setdefault(head, {})[key] = float(v)
    return joints, other


def apply(params, out_dir, nominal=NOMINAL):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    joints, other = split(params['values'])
    report = {'variants': {}, 'joints': {}}
    seen = set()
    for name in VARIANTS:
        src = Path(nominal) / name
        robot, xml = Robot(src), ET.parse(src)
        changed = []
        for joint, keys in joints.items():
            e = xml.getroot().find(f"joint[@name='{joint}']")
            if e is None:
                continue
            seen.add(joint)
            bad = set(keys) - set(robot.param_keys(joint))
            if bad:
                raise ValueError(f'{joint}: parameters {sorted(bad)} not valid for a {robot.joints[joint]["type"]} joint')
            T = robot.origin(joint, {f'{joint}/{k}': v for k, v in keys.items()})
            o = e.find('origin')
            if o is None:
                o = ET.SubElement(e, 'origin')
            before = dict(o.attrib)
            o.set('xyz', fmt(T[:3, 3]))
            o.set('rpy', fmt(Rotation.from_matrix(T[:3, :3]).as_euler('xyz')))
            changed.append(joint)
            j = robot.joints[joint]
            rec = report['joints'].setdefault(joint, {'type': j['type'], 'parameters': keys, 'origin_nominal': before,
                                                     'origin_calibrated': dict(o.attrib), 'axis_child_frame': j['axis'].tolist()})
            if 'zero' in keys and j['type'] != 'fixed':
                rec['limits_encoder_unchanged'] = [j['lower'], j['upper']]
                rec['physical_range_in_nominal_geometry'] = [j['lower'] + keys['zero'], j['upper'] + keys['zero']]
                rec['zero_deg'] = float(np.degrees(keys['zero'])) if j['type'] != 'prismatic' else None
        ET.indent(xml)
        xml.write(out_dir / name, encoding='unicode', xml_declaration=True)
        report['variants'][name] = {'nominal': str(src), 'nominal_sha256': sha(src), 'calibrated': str(out_dir / name),
                                    'calibrated_sha256': sha(out_dir / name), 'changed_joints': changed}
    missing = set(joints) - seen
    if missing:
        raise KeyError(f'joints not in any nominal URDF: {sorted(missing)}')
    report.update(status=params.get('status'), sign_verified=params.get('sign_verified'),
                  description=params.get('description'), convention='q_model = q_encoder + zero; rot_u/rot_v/rx..rz act in the '
                  'joint frame before the joint motion; dx/dy/dz in the parent-link frame',
                  limit_policy=LIMIT_POLICY,
                  camera_and_intrinsics_deltas={k: v for k, v in other.items() if k.startswith(('camera:', 'intrinsics:'))},
                  scene_root_deltas={k: v for k, v in other.items() if k.startswith('base:')},
                  created=datetime.now().isoformat(timespec='seconds'))
    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('params')
    ap.add_argument('out_dir')
    ap.add_argument('--nominal', default=str(NOMINAL))
    a = ap.parse_args()
    params = load_params(a.params)
    report = apply(params, a.out_dir, a.nominal)
    report['params_file'] = str(Path(a.params).resolve())
    report['params_sha256'] = sha(a.params)
    (Path(a.out_dir) / 'calibration_provenance.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({k: v['changed_joints'] for k, v in report['variants'].items()}))


if __name__ == '__main__':
    main()
