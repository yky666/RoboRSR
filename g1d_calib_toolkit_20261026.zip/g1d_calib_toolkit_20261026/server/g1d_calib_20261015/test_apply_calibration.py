"""Unit tests of apply_calibration.py against the project FK (scene3_pour_pack/motion/kinematics.py)."""
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from calib_model import NOMINAL, ROOT, Robot, arm_joints
from apply_calibration import VARIANTS, apply

sys.path.insert(0, str(ROOT / 'scene3_pour_pack/motion'))
from kinematics import G1Kinematics

ARMS = arm_joints('left') + arm_joints('right')
HAND_BASIS = {0: ([0, 1, 0], [0, 0, 1]), 1: ([0, 0, 1], [1, 0, 0]), 2: ([1, 0, 0], [0, 1, 0])}
TOL = 1e-9


def params(values):
    return {'format': 'g1d_calib_params_v1', 'status': 'TEST', 'values': values}


def random_q(kin, rng, names):
    return {n: rng.uniform(kin.by_name[n]['lower'], kin.by_name[n]['upper']) for n in names}


def max_diff(a, b):
    return max(np.abs(a[k] - b[k]).max() for k in a)


def hand_basis(kin, frames, joint, R0):
    """u along the previous arm joint axis projected orthogonal to the axis (joint frame), else the fixed basis."""
    j, k = kin.by_name[joint], ARMS.index(joint)
    a = np.asarray(j['axis'], float)
    if k % 7:
        p = kin.by_name[ARMS[k - 1]]
        e = (frames[j['parent']][:3, :3] @ R0).T @ frames[p['child']][:3, :3] @ np.asarray(p['axis'], float)
        if np.linalg.norm(np.cross(a, e)) > 0.2:
            u = e - a * (e @ a)
            u /= np.linalg.norm(u)
            return u, np.cross(a, u)
    return (np.array(x, float) for x in HAND_BASIS[int(np.argmax(np.abs(a)))])


def canonical_without_origins(path, joints):
    root = ET.parse(path).getroot()
    for e in root.findall('joint'):
        if e.get('name') in joints:
            e.remove(e.find('origin'))
    return ET.tostring(root)


class ApplyCalibration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.rng = np.random.default_rng(20261015)
        cls.nominal = {v: G1Kinematics(NOMINAL / v) for v in VARIANTS}

    def build(self, values, tag):
        out = Path(self.tmp.name) / tag
        report = apply(params(values), out)
        return out, report

    def test_empty_params_byte_identical(self):
        out, _ = self.build({}, 'empty')
        for v in VARIANTS:
            self.assertEqual((out / v).read_bytes(), (NOMINAL / v).read_bytes(), v)

    def test_zero_offsets_equal_shifted_encoder_values(self):
        offsets = {j: self.rng.uniform(-np.radians(3), np.radians(3)) for j in ARMS + ['torso_Joint', 'Yaw_Joint']}
        offsets['LZ_it_Joint'] = 0.004
        out, report = self.build({f'{j}/zero': d for j, d in offsets.items()}, 'zero')
        for v in VARIANTS:
            cal, nom = G1Kinematics(out / v), self.nominal[v]
            movable = [n for n in offsets if n in cal.by_name] + ['LZ_mt_Joint']
            movable = [n for n in movable if n in cal.by_name]
            for _ in range(50):
                q = random_q(nom, self.rng, movable)
                shifted = {n: x + offsets.get(n, 0.) for n, x in q.items()}
                self.assertLess(max_diff(cal.fk(q), nom.fk(shifted)), TOL)
            for n in movable:
                for key in ['lower', 'upper', 'effort', 'velocity']:
                    self.assertEqual(cal.by_name[n][key], nom.by_name[n][key])
                np.testing.assert_array_equal(cal.by_name[n]['axis'], nom.by_name[n]['axis'])
            changed = [n for n in offsets if n in cal.by_name]
            self.assertEqual(canonical_without_origins(out / v, changed), canonical_without_origins(NOMINAL / v, changed))
        self.assertIn('physical_range_in_nominal_geometry', report['joints']['left_shoulder_roll_joint'])

    def test_mounting_rotation_and_translation_hand_computed(self):
        for joint in ARMS:
            nom = self.nominal[VARIANTS[0]]
            j = nom.by_name[joint]
            ru, rv = self.rng.uniform(-0.02, 0.02, 2)
            d = self.rng.uniform(-0.002, 0.002, 3)
            out, _ = self.build({f'{joint}/rot_u': ru, f'{joint}/rot_v': rv, f'{joint}/dx': d[0], f'{joint}/dy': d[1],
                                 f'{joint}/dz': d[2]}, 'mount_' + joint)
            cal = G1Kinematics(out / VARIANTS[0])
            e = ET.parse(NOMINAL / VARIANTS[0]).getroot().find(f"joint[@name='{joint}']/origin")
            xyz = np.array([float(x) for x in e.get('xyz').split()]) + d
            R0 = Rotation.from_euler('xyz', [float(x) for x in e.get('rpy').split()]).as_matrix()
            for _ in range(10):
                q = random_q(nom, self.rng, ARMS)
                Fn, Fc = nom.fk(q), cal.fk(q)
                u, v = hand_basis(nom, Fn, joint, R0)
                T = np.eye(4)
                T[:3, :3] = R0 @ Rotation.from_rotvec(ru * u + rv * v).as_matrix() @ \
                    Rotation.from_rotvec(j['axis'] * q[joint]).as_matrix()
                T[:3, 3] = xyz
                child = Fn[j['parent']] @ T
                self.assertLess(np.abs(Fc[j['child']] - child).max(), TOL, joint)
                link = joint.split('_')[0] + '_dex1_base_link'
                expected = child @ np.linalg.inv(Fn[j['child']]) @ Fn[link]
                self.assertLess(np.abs(Fc[link] - expected).max(), TOL, joint)

    def test_fixed_joint_rotation(self):
        out, _ = self.build({'left_dex1_base_joint/rz': 0.01, 'left_dex1_base_joint/dz': 0.001}, 'fixed')
        nom, cal = self.nominal[VARIANTS[0]], G1Kinematics(out / VARIANTS[0])
        q = random_q(nom, self.rng, ARMS)
        expected = nom.fk(q)['left_wrist_yaw_link'] @ np.array([[np.cos(.01), -np.sin(.01), 0, .0415],
                                                                [np.sin(.01), np.cos(.01), 0, 0], [0, 0, 1, .001], [0, 0, 0, 1]])
        self.assertLess(np.abs(cal.fk(q)['left_dex1_base_link'] - expected).max(), TOL)

    def test_invalid_parameter_rejected(self):
        with self.assertRaises(ValueError):
            self.build({'left_dex1_base_joint/zero': 0.01}, 'bad1')
        with self.assertRaises(KeyError):
            self.build({'no_such_joint/zero': 0.01}, 'bad2')

    def test_calib_model_matches_project_fk(self):
        values = {f'{j}/{k}': self.rng.normal(0, 0.01) for j in ARMS for k in ['zero', 'rot_u', 'rot_v']}
        out, _ = self.build(values, 'model')
        cal, robot = G1Kinematics(out / VARIANTS[0]), Robot(NOMINAL / VARIANTS[0])
        qs = [random_q(cal, self.rng, ARMS) for _ in range(20)]
        batch = {n: np.array([q[n] for q in qs]) for n in ARMS}
        for side in ['left', 'right']:
            T = robot.fk(f'{side}_dex1_base_link', batch, values)
            for i, q in enumerate(qs):
                self.assertLess(np.abs(T[i] - cal.fk(q)[f'{side}_dex1_base_link']).max(), TOL)


if __name__ == '__main__':
    unittest.main(verbosity=2)
