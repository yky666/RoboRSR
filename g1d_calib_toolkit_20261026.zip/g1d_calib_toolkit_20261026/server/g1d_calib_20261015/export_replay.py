"""Export the arm trajectory of a verified sim pour (trace.jsonl) as a replay file for the real robot.

usage: export_replay.py RUN_DIR OUT.json [--source command|state] [--params params.json]
Joint values keep the URDF / encoder convention of the model the run used. Gripper values stay in sim units (the real
gripper mapping is to be measured). Check poses (end of close / lift / tilt / pour_hold) carry the predicted TCP pose.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from calib_model import NOMINAL, Robot, arm_joints, load_params

ARMS = arm_joints('left') + arm_joints('right')
CHECK_PHASES = ('close', 'lift', 'tilt', 'pour_hold')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('run_dir')
    ap.add_argument('out')
    ap.add_argument('--source', choices=['command', 'state'], default='command')
    ap.add_argument('--params')
    a = ap.parse_args()
    path = Path(a.run_dir) / 'trace.jsonl'
    rows = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
    key_names, key_values = ('command_names', 'position_command16') if a.source == 'command' else ('joint_names', 'joint_positions')
    names = rows[0][key_names]
    arm = [n for n in names if n in ARMS]
    other = [n for n in names if n not in ARMS]
    t = np.array([r['time_s'] for r in rows])
    Q = np.array([[dict(zip(r[key_names], r[key_values]))[n] for n in arm] for r in rows])
    G = np.array([[dict(zip(r[key_names], r[key_values]))[n] for n in other] for r in rows])
    v = np.gradient(Q, t, axis=0)
    acc = np.gradient(v, t, axis=0)
    phases = []
    for i, r in enumerate(rows):
        if not phases or phases[-1]['name'] != r['phase']:
            phases.append({'name': r['phase'], 'i_start': i, 't_start': float(t[i])})
        phases[-1].update(i_end=i, t_end=float(t[i]))
    robot = Robot(NOMINAL / 'g1_d_upper_dex1_v4.urdf')
    p = load_params(a.params)['values'] if a.params else {}
    checks = []
    for ph in phases:
        if ph['name'] in CHECK_PHASES:
            i = ph['i_end']
            q = {n: np.array([Q[i, k]]) for k, n in enumerate(arm)}
            rec = {'phase': ph['name'], 'index': i, 't': float(t[i]), 'q': dict(zip(arm, Q[i].round(6).tolist()))}
            for side in ['left', 'right']:
                if any(n.startswith(side) for n in arm):
                    rec[f'{side}_tcp_in_torso_nominal'] = robot.tcp(side, q, {}, n=1)[0].round(6).tolist()
                    if p:
                        rec[f'{side}_tcp_in_torso_calibrated'] = robot.tcp(side, q, p, n=1)[0].round(6).tolist()
            checks.append(rec)
    doc = {'format': 'g1d_replay_trajectory_v1', 'source_run': str(Path(a.run_dir).resolve()),
           'trace_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'source': key_values,
           'model': str(NOMINAL / 'g1_d_upper_dex1_v4.urdf'), 'params': a.params,
           'joint_names': arm, 't': t.round(6).tolist(), 'q': Q.round(6).tolist(),
           'gripper': {'names': other, 'values_sim_units': G.round(6).tolist(), 'real_mapping': 'TO BE MEASURED'},
           'phases': phases, 'check_poses': checks,
           'limits_observed': {'max_abs_velocity_rad_s': dict(zip(arm, np.abs(v).max(0).round(4).tolist())),
                               'max_abs_acceleration_rad_s2': dict(zip(arm, np.abs(acc).max(0).round(3).tolist())),
                               'q_min': dict(zip(arm, Q.min(0).round(5).tolist())), 'q_max': dict(zip(arm, Q.max(0).round(5).tolist()))}}
    Path(a.out).write_text(json.dumps(doc))
    print(json.dumps({'frames': len(t), 'duration_s': float(t[-1] - t[0]), 'arm_joints': len(arm), 'gripper': other,
                      'phases': [ph['name'] for ph in phases], 'max_v': doc['limits_observed']['max_abs_velocity_rad_s']}, indent=1))


if __name__ == '__main__':
    main()
