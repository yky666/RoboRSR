# 07 服务器端：参数写回 URDF、重建仿真资产与回归检查

## 1. 参数文件 `g1d_calib_params_v1`

由 `identify.py --params-out` 生成，或手写（占位测试）：

```json
{
  "format": "g1d_calib_params_v1",
  "status": "IDENTIFIED",
  "sign_verified": false,
  "convention": "q_model = q_encoder + zero (radians)",
  "values": {"left_shoulder_roll_joint/zero": 0.0454, "left_elbow_joint/rot_v": -0.0012, "camera:head_left/rx": 0.003},
  "std": {"left_shoulder_roll_joint/zero": 0.0001},
  "values_deg_for_reading": {"left_shoulder_roll_joint/zero": 2.6},
  "measurements": {"<测量文件绝对路径>": "<sha256>"},
  "created": "..."
}
```

- 关节参数写进 URDF；`camera:*` 增量写进相机合同；`intrinsics:*` 只记录（见 §4）；`board:*` 是测量夹具参数，不进入资产。
- 写回前检查：`status`、来源测量文件哈希、各参数 std（<0.05°）、`sign_verified`（`04` 方向检查通过后人工改为 `true`）。
- `params_test_left_shoulder_roll_2p6.json` 是占位文件（`status: PLACEHOLDER`），只用于打通流程。

## 2. 步骤

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=$ISAAC_ENV/bin/python   # unitree_sim_env 的 python（GPU 服务器上）
P=real_data/<日期>/params_identified.json
TAG=calib_<日期>

# 2.1 只写 URDF（几秒，CPU）：检查改动的关节和数值
$PY apply_calibration.py $P out_urdf_$TAG
cat out_urdf_$TAG/calibration_provenance.json     # changed_joints、origin 前后、physical_range_in_nominal_geometry

# 2.2 预估影响：零位/E036 抓取位形/整条轨迹的 TCP 和腕相机位移
$PY tcp_effect.py $P tcp_effect_$TAG.json

# 2.3 完整资产（需要 GPU 做 URDF→USD 转换，几分钟）：先 nvidia-smi 选空闲卡
nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv
nohup $PY build_assembly.py $P assembled_$TAG --gpu <N> > logs/build_$TAG.log 2>&1 &
```

`build_assembly.py` 的流水线：`apply_calibration`（upper + full URDF）→ 拷贝网格、写 `assemble.json` → 来源校验 → UrdfConverter 生成 USD → 共享的 prepare（物理设置，与名义资产相同）→ flat USD → 相机合同（名义 `T_parent_camera` 右乘 `camera:*` 增量）→ USD 与名义资产的对比 → USD-FK 校验 → `sha256.json`。输出目录不能已存在。只重跑校验时用 `--revalidate`。

参考样例：`assembled_test_lsr2p6/`（占位参数 2.6° 左肩 roll）。

## 3. 回归检查（全部通过才可启用）

| 检查 | 命令 / 文件 | 通过标准 |
|---|---|---|
| 单元测试 | `$PY test_apply_calibration.py` | 6 项 OK（空参数逐字节一致、零位等价于编码器平移、安装旋转/平移手算一致、固定关节、非法参数拒绝、与项目 FK `scene3_pour_pack/motion/kinematics.py` 一致）|
| USD-FK | `assembled_$TAG/usd_fk_validation.json` | 标定 USD 关节坐标系与标定 URDF FK 的最大差 <1e-6 m / 1e-6 rad（样例为 1e-8 量级）|
| 与名义资产对比 | `usd_compare_vs_nominal.json` | 只有预期关节的 origin 改变；物理、碰撞过滤、驱动设置与名义一致 |
| 来源校验 | `source_validation.json` | 网格与官方来源哈希一致 |
| 相机合同 | `camera_contract_v5.json` 中的 `calibration` 段 | 增量与参数文件一致；未从参考位置重算（否则会抵消腕部标定）|
| 测量残差 | `$PY compare_sim_real.py <真机测量> --params $P --out check_$TAG.json` | 标定残差接近噪声（≤1 px）|
| Scene3 倒水复跑 | 使用标定资产重新求解并运行一次 Scene3 倒水（需用户授权，按项目 `AGENTS.md` 的运行规则）| 成功率与名义资产相当；IK 解在新模型下收敛 |

## 4. 相机内参

仿真相机的内参由 `camera_contract_v5.json` 中的视场角得到（960×720，无畸变）。若希望仿真图像与真机图像几何一致：
- 分辨率和 K 改用 `01` 的实测值；
- Isaac 的针孔相机不渲染镜头畸变，可以对真机图像去畸变后再对比，或在仿真图像上加畸变后处理；
- 这些改动属于相机合同/运行器层面，需要用户确认后再做。`build_assembly.py` 目前只把 `intrinsics:*` 记录在 `camera_contract_v5.json` 的 `calibration.intrinsics_deltas` 中。

## 5. 切换仿真运行器到标定资产（待用户确认）

- 不覆盖共享资产 `codex_pour/g1d_probe/assembled_v4_coupled/` 和 `real2sim_g1d_20261015/assembled/`；标定资产放在 `real2sim_calib_20261015/assembled_<TAG>/`。
- 运行器（`run_ik_fourview_v5.py` 依赖链）如何指定资产目录、相机合同路径，需由负责运行器的人确认：建议增加显式的资产目录参数，而不是改默认路径。
- IK/控制使用的 `scene3_pour_pack/motion/kinematics.py` 的 `G1Kinematics(urdf)` 必须加载标定后的 URDF（与 USD 同一份），否则仿真中求得的关节轨迹仍是名义模型的结果。
- 切换后，仿真中求解的关节值就是真机编码器值，可直接用于 `06` 回放。
- 参数文件、资产目录、`sha256.json` 一起归档；运行记录中写明使用的资产目录和参数哈希。

## 6. 检查清单

- [ ] 参数文件 `sign_verified: true`、std 达标、测量哈希可追溯
- [ ] `apply_calibration.py` 输出的改动关节符合预期
- [ ] GPU 空闲后再构建；构建日志无错误
- [ ] 回归检查全部通过
- [ ] 运行器切换方式已确认，未改共享资产
- [ ] Scene3 复跑（经授权）通过后再做 `06` 带水回放
