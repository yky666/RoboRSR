# 04 可复现的 sim-vs-real 对比检查

## 目的

在真机和仿真中使用同一个关节向量，比较标定板的观测：真机图像中检测到的角点，对比模型（名义或标定后）预测的角点。用途：
1. 采集前检查关节映射的正方向、相机名、板描述是否正确（防止辨识跑在错误约定上）；
2. 对单个明显偏差（如左肩 roll 约几度）做可复现的快速粗估；
3. 标定后的验收：残差应降到接近噪声。

之前比较仿真和真机数据得到的 2.6° 只当作占位，本流程会给出可复现、带不确定度的数值。

## 1. 原理

对每个样本，`compare_sim_real.py` 先重新估计相机外参和板安装位姿（各 6 自由度，内参固定为 `01` 的值），使它们不混入比较，再报告：
- `nominal`：名义 URDF 下的逐样本、逐相机角点 RMS 和平均残差向量（du, dv）；
- `calibrated`（给 `--params` 时）：同上，关节参数取参数文件中的值；
- `quick_fit`（给 `--fit` 时）：额外估计指定参数（如 `left_shoulder_roll_joint/zero`），报告数值、std、条件数。

仿真端不需要启动 Isaac Sim：预测用 `calib_model.py` 的 FK 和投影完成，与 USD 的一致性由 `07` 的 USD-FK 校验保证（误差 1e-8 m 量级）。若要做图像叠加，`--overlay-dir` 会在真机图像上画出：绿色 = 检测角点，红色 = 名义预测，蓝色 = 标定预测，连线 = 残差。

## 2. 检查位姿与采集

- 使用 `poses_<side>.json` 中的 10–20 个位姿即可，同时包含 B（腕相机看桌面板）和 A（头部相机看夹爪板）。
- 粗估某一关节零位时，加一组"单关节扫描"：从一个板清晰可见的位姿出发，只改变目标关节 −0.3、−0.15、0、+0.15、+0.3 rad（不超过限位余量，并先在仿真中用 `board_setups.py` 检查碰撞和可见性），其余关节保持不变。
- 采集方法、文件格式同 `02`/`03`，导出为一个测量文件。

```bash
$PY compare_sim_real.py check.json --out check_nominal.json --overlay-dir overlays --images-root <会话目录>
$PY compare_sim_real.py check.json --fit 'left_shoulder_roll_joint/zero' --out quick_roll.json
```

## 3. 方向与符号约定检查（采集正式数据前必须做）

关节方向（每个关节一次）
1. 选一个板可见的参考位姿 q0，在服务器上预测每个关节 +0.05 rad 时板中心的像素位移方向：

```python
from board_setups import nominal_scene, visible_corners
from calib_model import Robot, NOMINAL
# 对 q0 和 q0 + 0.05·e_j 分别计算 visible_corners(...)[0] 的均值，差即预测位移向量 d_sim
```

2. 真机上同样从 q0 出发，令该关节 +0.05 rad，测得角点位移 d_real。
3. `cos(d_sim, d_real)` >0.9 说明方向一致；<−0.9 说明符号相反，要改 `joint_mapping.json` 的 `sign`，不要用 URDF 的零位去补。夹角接近 90° 说明关节映射错位（序号错误）。
4. 在 `joint_mapping.json` 的 `verified_by` 中记录日期和结论。

零位偏差的符号
- 约定 `q_model = q_encoder + zero`。同一个编码器读数下，如果真机的实际关节角比仿真多 δ（沿该关节正方向），则 `zero = +δ`。
- 例：在名义 URDF 中，左肩 roll 正方向使左臂外展（远离躯干）。如果相同读数下真机左臂比仿真更外展约 2.6°，则 `left_shoulder_roll_joint/zero ≈ +2.6°`。这个正方向结论应在服务器上用 FK 复核一次（对 `left_shoulder_roll_joint` 加 +0.05 rad，看 `left_dex1_base_link` 的 y 是否增大）。
- `--fit` 的输出直接采用这个约定，可以与图像叠加中的残差方向互相印证。

## 4. 区分不同来源的偏差

| 现象（重新估计相机/板之后的残差） | 可能来源 | 处理 |
|---|---|---|
| 残差随目标关节角不变化，但随下游位形呈系统性变化 | 该关节零位偏差 | `--fit '<关节>/zero'` |
| 残差随上游关节（如 shoulder_pitch）变化、与目标关节无关 | 关节安装倾斜（`rot_v`），例如肩部安装 roll 倾斜 | 双臂共享头部相机做完整辨识（单臂时与相机外参等价，见 `error_model_zh.md`）|
| 所有位姿上残差在图像中一致平移/旋转 | 相机外参（已被重新估计吸收），不是关节问题 | 无需处理 |
| 残差随距离/视场位置变化 | 内参或畸变 | 回到 `01` |
| 残差随负载或姿态的重力力矩变化 | 柔性 / 重力下垂 | 纳入 `05`，几何标定时尽量用低力矩位姿 |

合成数据上的定量示例（服务器 `examples/identify_demo/`）：
- 完整辨识后逐样本 RMS 0.86 px，名义模型 9.3 px（`compare_sim_real_B_left.json`）；
- 只估计 roll 零位、其余关节用名义值时，roll 估计 2.90°（真值 2.6°，另有其他关节误差），剩余残差 3.2 px（`quick_roll_nominal_B_left.json`）。

也就是说，快速粗估会被未建模的其他误差带偏，只能用于判断符号和量级。

## 5. 与完整辨识的关系

- 快速检查只估计 1–2 个关节参数，适合判断符号、发现映射错误、给出粗略量级；
- 最终参数一律以 `identify.py --preset auto` 的完整辨识为准（50+ 位姿、多个设置、留出验证）；
- 标定后用同一个检查文件、加 `--params` 复跑：`calibrated` 的 RMS 应接近像素噪声（≤1 px），且平均残差向量不再随关节角呈系统变化。这是 `07`/`06` 的前置验收。

## 6. 输出 `check_*.json`（由 `compare_sim_real.py` 生成）

```json
{
  "measurements": ["check.json"],
  "estimated_nuisance": ["camera:head_left/rx", "...", "board:gripper_left/dz"],
  "models": {
    "nominal":    {"rms_px_mean_over_views": 9.3, "rms_px_max_view": 22.2,
                   "per_sample": {"B_left_007": {"left_wrist": {"board": "table", "n": 35, "rms_px": 7.1, "mean_residual_px": [3.2, -5.9]}}},
                   "nuisance": {"camera:left_wrist/rx": 0.004}},
    "calibrated": {"...": "..."}
  },
  "quick_fit": {"parameters": {"left_shoulder_roll_joint/zero": {"value_deg_or_m": 2.90, "std_deg_or_m": 0.018}},
                "rms_px_mean_over_views": 3.2, "condition_number": 35.2, "flags": {}}
}
```

## 7. 检查清单

- [ ] 每个关节的方向检查已完成并记录
- [ ] 相机名与图像流对应正确（左右头部相机没有交换）
- [ ] 板 `points_m` 与实际打印一致（检测到的角点与预测在名义模型下就应该大致重合，偏差几十像素以上先查约定）
- [ ] 快速粗估的符号与图像叠加方向一致
- [ ] 标定后复跑，残差接近噪声
