"""Identify kinematic calibration parameters from board-pixel (and optional 6D pose) measurements.

usage examples
  identify.py meas.json --preset auto --out result.json --params-out params_identified.json
  identify.py meas.json --estimate 'left_*_joint/zero' 'camera:head_left/*' 'board:gripper_left/*' --loss soft_l1
  identify.py a.json b.json --preset auto --refine-intrinsics --fix left_shoulder_pitch_joint/zero=0 --folds 5

--preset auto: zero offsets of shoulder_roll..wrist_pitch and the axis twist rot_v of shoulder_roll..wrist_yaw of every
observed arm, every observed camera extrinsic and board pose; with both arms tied to a shared torso-fixed camera or
board, also the shoulder_pitch frame (zero, rot_u, rot_v) of the non-reference arm. Left out: exact gauge freedoms of
board setups (shoulder_pitch frame of a single arm, wrist_yaw zero) and rot_u, a rotation about the previous joint axis
that duplicates the previous zero offset up to a small translation; see docs/error_model_zh.md.
"""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from calib_model import NOMINAL, Problem, Robot, arm_joints, expand

UNIT = {'zero': 1e-3, 'rot_u': 1e-3, 'rot_v': 1e-3, 'rx': 1e-3, 'ry': 1e-3, 'rz': 1e-3, 'dx': 1e-3, 'dy': 1e-3, 'dz': 1e-3,
        'fx': 1., 'fy': 1., 'cx': 1., 'cy': 1., 'k1': 1e-2, 'k2': 1e-2, 'k3': 1e-2, 'k4': 1e-2, 'p1': 1e-3, 'p2': 1e-3}
TORSO_FIXED = {'torso_link', 'head_link', 'logo_link'}


def unit(name):
    return UNIT[name.split('/')[-1]]


def load_measurements(paths):
    docs = [json.loads(Path(p).read_text()) for p in paths]
    meas = dict(docs[0])
    meas['samples'] = []
    for d in docs:
        assert d.get('format') == 'g1d_calib_measurements_v1'
        for key in ['cameras', 'boards', 'targets', 'bases']:
            for k, v in d.get(key, {}).items():
                if k in meas.get(key, {}) and meas[key][k] != v:
                    raise ValueError(f'{key}/{k} differs between measurement files')
                meas.setdefault(key, {})[k] = v
        meas['samples'] += d['samples']
    return meas


def subset(meas, idx):
    out = dict(meas)
    out['samples'] = [meas['samples'][i] for i in idx]
    return out


def observed(meas):
    cams, boards = set(), set()
    for s in meas['samples']:
        for o in s.get('observations', []):
            if o['type'] == 'board_pixels':
                cams.add(o['camera'])
                boards.add(o['board'])
    return cams, boards


def preset_names(meas, reference='right', refine_intrinsics=False):
    cams, boards = observed(meas)
    parents = {meas['cameras'][c]['parent'] for c in cams} | {meas['boards'][b]['parent'] for b in boards}
    sides = [s for s in ['left', 'right'] if any(p.startswith(s + '_') for p in parents)]
    names = []
    for s in sides:
        j = arm_joints(s)
        names += [f'{n}/zero' for n in j[1:6]] + [f'{n}/rot_v' for n in j[1:]]
    if len(sides) == 2 and parents & (TORSO_FIXED | {meas.get('root_link', 'torso_link')}):
        other = 'left' if reference == 'right' else 'right'
        names += [f'{other}_shoulder_pitch_joint/{k}' for k in ['zero', 'rot_u', 'rot_v']]
    names += [f'camera:{c}/{k}' for c in sorted(cams) for k in ['rx', 'ry', 'rz', 'dx', 'dy', 'dz']]
    names += [f'board:{b}/{k}' for b in sorted(boards) for k in ['rx', 'ry', 'rz', 'dx', 'dy', 'dz']]
    priors = {}
    if refine_intrinsics:
        for c in sorted(cams):
            sig = meas['cameras'][c].get('intrinsics_sigma', {})
            for k, v in sig.items():
                names.append(f'intrinsics:{c}/{k}')
                priors[f'intrinsics:{c}/{k}'] = (0., v)
    return names, priors


def fit(problem, x0=None, loss='linear', f_scale=1.0, max_nfev=200):
    x0 = np.zeros(len(problem.names)) if x0 is None else np.asarray(x0, float)
    scale = np.array([unit(n) for n in problem.names])
    r = least_squares(problem.residual, x0, loss=loss, f_scale=f_scale, x_scale=scale, method='trf',
                      max_nfev=max_nfev, ftol=1e-10, xtol=1e-10, gtol=1e-10)
    return r


def jacobian(problem, x, data_only=True):
    scale = np.array([unit(n) for n in problem.names])
    f = (lambda v: np.concatenate([b for k, b in problem.residual_blocks(v).items() if k != 'prior'])) if data_only else problem.residual
    cols = []
    for i, h in enumerate(1e-3 * scale):
        e = np.zeros_like(x)
        e[i] = h
        cols.append((f(x + e) - f(x - e)) / (2 * h))
    return np.stack(cols, 1)


def analyze(problem, x, null_tol=1e-7, weak_tol=1e-3, corr_tol=0.95):
    """SVD identifiability of the column-scaled data Jacobian and posterior covariance (units of each parameter)."""
    names = problem.names
    scale = np.array([unit(n) for n in names])
    Jd = jacobian(problem, x) * scale
    U, s, Vt = np.linalg.svd(Jd, full_matrices=False)
    rel = s / s[0]
    directions = []
    for i in np.flatnonzero(rel < weak_tol):
        v = Vt[i]
        top = np.argsort(-np.abs(v))[:6]
        directions.append({'relative_singular_value': float(rel[i]), 'kind': 'null' if rel[i] < null_tol else 'weak',
                           'components': {names[k]: round(float(v[k]), 3) for k in top if abs(v[k]) > 0.1}})
    blocks = problem.residual_blocks(x)
    data = np.concatenate([b for k, b in blocks.items() if k != 'prior'])
    dof = max(len(data) - len(names), 1)
    s2 = float(data @ data / dof)
    Jf = jacobian(problem, x, data_only=False) * scale
    H = Jf.T @ Jf
    w, V = np.linalg.eigh(H)
    keep = w > w.max() * 1e-14
    cov = s2 * (V[:, keep] / w[keep]) @ V[:, keep].T
    cov = cov * np.outer(scale, scale)
    std = np.sqrt(np.clip(np.diag(cov), 0, None))
    corr = cov / np.outer(std, std).clip(1e-300)
    pairs = [(names[i], names[j], float(corr[i, j])) for i in range(len(names)) for j in range(i + 1, len(names))
             if abs(corr[i, j]) > 0.9]
    pairs.sort(key=lambda t: -abs(t[2]))
    flags = {}
    for d in directions:
        for n, c in d['components'].items():
            if abs(c) > 0.3:
                flags[n] = 'unidentifiable' if d['kind'] == 'null' else flags.get(n, 'weak')
    for a, b, c in pairs:
        if abs(c) > corr_tol:
            for n in (a, b):
                flags.setdefault(n, 'strongly_correlated')
    return {'n_parameters': len(names), 'n_residuals': int(len(data)), 'sigma2_posterior_factor': s2,
            'singular_values_scaled': s.tolist(), 'condition_number': float(s[0] / s[-1]) if s[-1] > 0 else float('inf'),
            'weak_directions': directions, 'std': dict(zip(names, std.tolist())), 'correlated_pairs_abs_gt_0p9': pairs[:40],
            'flags': flags, 'covariance': cov.tolist()}


def errors(problem, x):
    p = problem.params(x)
    frames = problem.link_poses(p, problem.needed_links())
    out = {}
    for (c, b), g in problem.groups.items():
        uv, _ = problem.predict_pixels(p, c, b, frames, g['k'], g['pts'])
        out[f'pixels:{c}:{b}'] = np.linalg.norm(uv - g['uv'], axis=1)
    if problem.poses:
        blocks = problem.residual_blocks(x)['pose6d'].reshape(-1, 6)
        out['pose6d_mm'] = 1000 * np.linalg.norm(blocks[:, :3] * [o['sm'] for o in problem.poses][0], axis=1)
        out['pose6d_deg'] = np.degrees(np.linalg.norm(blocks[:, 3:] * [o['sr'] for o in problem.poses][0], axis=1))
    return out


def summarize(err):
    return {k: {'rms': float(np.sqrt(np.mean(v ** 2))), 'median': float(np.median(v)), 'p95': float(np.percentile(v, 95)),
                'n': int(len(v))} for k, v in err.items() if len(v)}


def kfold(robot, meas, names, priors, fixed, folds=5, loss='linear', f_scale=1.0, seed=0):
    n = len(meas['samples'])
    order = np.random.default_rng(seed).permutation(n)
    nuisance = [k for k in names if ':' in k.split('/')[0]]
    out = []
    for f in range(folds):
        test = order[f::folds]
        train = np.setdiff1d(order, test)
        tr, te = subset(meas, train), subset(meas, test)
        rec = {}
        for label, est in [('calibrated', names), ('nominal_joints', nuisance)]:
            ptr = Problem(robot, tr, est, fixed, priors)
            r = fit(ptr, loss=loss, f_scale=f_scale)
            pte = Problem(robot, te, est, fixed, priors)
            rec[label] = summarize(errors(pte, r.x))
        out.append(rec)
    agg = {}
    for label in ['calibrated', 'nominal_joints']:
        keys = out[0][label].keys()
        agg[label] = {k: float(np.sqrt(np.mean([o[label][k]['rms'] ** 2 for o in out]))) for k in keys}
    return {'folds': folds, 'heldout_rms_by_block': agg, 'per_fold': out}


def params_document(names, x, std, meas_paths, status='IDENTIFIED'):
    values = {n: float(v) for n, v in zip(names, x) if not n.split('/')[0].startswith(('board:', 'target:', 'base:'))}
    return {'format': 'g1d_calib_params_v1', 'status': status, 'sign_verified': False,
            'description': 'Identified by identify.py; joint values keep encoder semantics (q_model = q_encoder + zero).',
            'convention': 'q_model = q_encoder + zero (radians)', 'values': values,
            'std': {n: std[n] for n in values}, 'values_deg_for_reading': {n: float(np.degrees(v)) for n, v in values.items()
                                                                         if n.split('/')[-1] in ('zero', 'rot_u', 'rot_v', 'rx', 'ry', 'rz')},
            'measurements': {str(Path(p).resolve()): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in meas_paths},
            'created': datetime.now().isoformat(timespec='seconds')}


def parse_pairs(items, cast=float):
    out = {}
    for it in items or []:
        k, v = it.rsplit('=', 1)
        out[k] = cast(v)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('measurements', nargs='+')
    ap.add_argument('--urdf', default=str(NOMINAL / 'g1_d_upper_dex1_v4.urdf'))
    ap.add_argument('--preset', choices=['auto'], default=None)
    ap.add_argument('--reference-arm', default='right')
    ap.add_argument('--refine-intrinsics', action='store_true')
    ap.add_argument('--estimate', nargs='*', default=[], help='fnmatch patterns of parameters to estimate')
    ap.add_argument('--exclude', nargs='*', default=[], help='patterns removed from the estimated set')
    ap.add_argument('--fix', nargs='*', default=[], help='NAME=VALUE fixed parameter values')
    ap.add_argument('--prior', nargs='*', default=[], help='PATTERN=SIGMA zero-mean Gaussian priors (regularization)')
    ap.add_argument('--loss', default='linear', choices=['linear', 'soft_l1', 'huber', 'cauchy', 'arctan'])
    ap.add_argument('--f-scale', type=float, default=1.0)
    ap.add_argument('--folds', type=int, default=5)
    ap.add_argument('--out', required=True)
    ap.add_argument('--params-out')
    a = ap.parse_args()
    meas = load_measurements(a.measurements)
    robot = Robot(a.urdf)
    names, priors = preset_names(meas, a.reference_arm, a.refine_intrinsics) if a.preset else ([], {})
    universe = Problem(robot, meas, []).universe()
    if a.estimate:
        names += [n for n in expand(a.estimate, universe) if n not in names]
    if a.exclude:
        drop = set(expand(a.exclude, names))
        names = [n for n in names if n not in drop]
    for pat, sig in parse_pairs(a.prior).items():
        for n in expand([pat], names):
            priors[n] = (0., sig)
    fixed = parse_pairs(a.fix)
    problem = Problem(robot, meas, names, fixed, priors)
    r = fit(problem, loss=a.loss, f_scale=a.f_scale)
    report = {'measurements': a.measurements, 'urdf': a.urdf, 'estimated': dict(zip(names, r.x.tolist())), 'fixed': fixed,
              'priors': {k: v[1] for k, v in priors.items()}, 'loss': a.loss, 'f_scale': a.f_scale,
              'optimizer': {'status': int(r.status), 'message': r.message, 'nfev': int(r.nfev), 'cost': float(r.cost)},
              'residuals': summarize(errors(problem, r.x))}
    report['identifiability'] = analyze(problem, r.x)
    if a.folds > 1:
        report['validation'] = kfold(robot, meas, names, priors, fixed, a.folds, a.loss, a.f_scale)
    Path(a.out).write_text(json.dumps(report, indent=2))
    if a.params_out:
        Path(a.params_out).write_text(json.dumps(params_document(names, r.x, report['identifiability']['std'], a.measurements), indent=2))
    ident = report['identifiability']
    print(json.dumps({'residuals': report['residuals'], 'condition_number': ident['condition_number'],
                      'flags': ident['flags'], 'validation': report.get('validation', {}).get('heldout_rms_by_block')}, indent=1))


if __name__ == '__main__':
    main()
