"""Create asserted, minimally patched copies of the real2sim_g1d_20261015 tools that take the asset directory as input."""
from pathlib import Path
import hashlib
import json

R2S = Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015')
SRC = R2S / 'tools'
TOOLS = Path(__file__).resolve().parent
NOMINAL = R2S / 'assembled'
log = {}


def patch(name, out_name, pairs):
    src = (SRC / name).read_text()
    text = src
    for a, b in pairs:
        assert text.count(a) == 1, (name, a, text.count(a))
        text = text.replace(a, b)
    (TOOLS / out_name).write_text(text)
    log[out_name] = {'original': str(SRC / name), 'original_sha256': hashlib.sha256(src.encode()).hexdigest(),
                     'replacements': [[a, b] for a, b in pairs]}


patch('convert_prepare_finalize_r2s.py', 'convert_prepare_finalize_calib.py', [
    ("args = parser.parse_args()", "parser.add_argument('--asset-dir', required=True)\nargs = parser.parse_args()"),
    ("directory = Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled')", "directory = Path(args.asset_dir)"),
])
patch('build_camera_contract_v5_r2s.py', 'build_camera_contract_calib.py', [
    ("folder=Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled')\nurdf=folder/'g1_d_full_dex1_v4.urdf'",
     "folder=Path(sys.argv[1])\nurdf=folder/'g1_d_full_dex1_v4.urdf'"),
    ("kin=G1Kinematics(urdf); frames=kin.fk({})",
     "kin=G1Kinematics(%r); frames=kin.fk({})" % str(NOMINAL / 'g1_d_full_dex1_v4.urdf')),
])
patch('compare_usd_r2s.py', 'compare_usd_calib.py', [
    ("args = parser.parse_args()", "parser.add_argument('--asset-dir', required=True); args = parser.parse_args()"),
    ("NEW = Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled')", "NEW = Path(args.asset_dir)"),
    ("OLD = Path('/root/unitree_sim_isaaclab/codex_pour/g1d_probe/assembled_v4_coupled')", "OLD = Path(%r)" % str(NOMINAL)),
    ("(NEW / 'usd_compare_vs_v4.json')", "(NEW / 'usd_compare_vs_nominal.json')"),
])
patch('validate_dex1_v4_sources_r2s.py', 'validate_sources_calib.py', [
    ("out=Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled')", "out=Path(sys.argv[1])"),
    ("assert report['passed']", "assert {k for k, v in checks.items() if not v} <= "
     "{'body/' + j for j in json.loads((out/'calibration_provenance.json').read_text())['joints']}"),
])
(TOOLS / 'patched_copies.json').write_text(json.dumps(log, indent=2))
print(json.dumps({k: len(v['replacements']) for k, v in log.items()}))
