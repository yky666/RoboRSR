"""Attribute-level comparison of new vs v4 flattened USD (physics, geometry, schemas, relationships)."""
import argparse, hashlib, json, os, sys
from pathlib import Path
from isaaclab.app import AppLauncher
parser = argparse.ArgumentParser(); AppLauncher.add_app_launcher_args(parser)
parser.set_defaults(headless=True, device='cpu'); parser.add_argument('--asset-dir', required=True); args = parser.parse_args()
app = AppLauncher(args).app
try:
    from pxr import Usd, UsdPhysics, Sdf
    import numpy as np
    NEW = Path(args.asset_dir)
    OLD = Path('/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled')
    def norm(v, d):
        s = str(v)
        return s.replace(str(d), '<DIR>')
    def dump(d):
        stage = Usd.Stage.Open(str(d / 'g1_d_upper_dex1_v4_flat.usdc'))
        out = {}
        joints = []; masses = {}; approx = {}; drives = {}
        prims = list(Usd.PrimRange.Stage(stage, Usd.TraverseInstanceProxies(Usd.PrimAllPrimsPredicate)))
        # Prototype names (Flattened_Prototype_N) are arbitrary; instance proxies give stable paths.
        for p in prims:
            key = str(p.GetPath())
            if key.startswith('/Flattened_Prototype_'): continue
            rec = {'type': p.GetTypeName(), 'schemas': sorted(p.GetAppliedSchemas())}
            for a in p.GetAttributes():
                v = a.Get()
                if v is None: continue
                if hasattr(v, '__len__') and not isinstance(v, str) and len(v) > 16:
                    v = 'sha256:' + hashlib.sha256(np.asarray(v).tobytes()).hexdigest()
                rec['a:' + a.GetName()] = norm(v, d)
            for r in p.GetRelationships():
                rec['r:' + r.GetName()] = [str(t) for t in r.GetTargets()]
            out[key] = rec
            if p.IsA(UsdPhysics.Joint) and not p.IsA(UsdPhysics.FixedJoint):
                joints.append(p.GetName())
            if p.HasAPI(UsdPhysics.MassAPI):
                m = UsdPhysics.MassAPI(p).GetMassAttr().Get(); masses[p.GetName()] = m
            if p.HasAPI(UsdPhysics.MeshCollisionAPI):
                approx[key] = UsdPhysics.MeshCollisionAPI(p).GetApproximationAttr().Get()
            for kind in ['angular', 'linear']:
                if p.HasAPI(UsdPhysics.DriveAPI, kind):
                    dr = UsdPhysics.DriveAPI.Get(p, kind)
                    drives[p.GetName()] = dict(kind=kind, type=dr.GetTypeAttr().Get(), max_force=dr.GetMaxForceAttr().Get(),
                        stiffness=dr.GetStiffnessAttr().Get(), damping=dr.GetDampingAttr().Get())
        return out, joints, masses, approx, drives
    new, nj, nm, na, nd = dump(NEW); old, oj, om, oa, od = dump(OLD)
    diffs = []
    for k in sorted(set(new) | set(old)):
        if k not in new or k not in old: diffs.append({'prim': k, 'only_in': 'new' if k in new else 'v4'}); continue
        for a in sorted(set(new[k]) | set(old[k])):
            if new[k].get(a) != old[k].get(a): diffs.append({'prim': k, 'attr': a, 'new': new[k].get(a), 'v4': old[k].get(a)})
    report = {'prims_new': len(new), 'prims_v4': len(old), 'n_differences': len(diffs), 'differences': diffs[:200],
              'non_fixed_joint_order_new': nj, 'non_fixed_joint_order_v4': oj, 'joint_order_identical': nj == oj,
              'masses_identical': nm == om, 'total_mass_new': sum(v for v in nm.values() if v), 'n_mass_prims': len(nm),
              'collision_approximation_identical': na == oa, 'collision_approximations': sorted(set(map(str, na.values()))), 'n_collision_meshes': len(na),
              'drives_identical': nd == od, 'drives_new': nd}
    (NEW / 'usd_compare_vs_nominal.json').write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps({k: v for k, v in report.items() if k not in ('differences', 'drives_new')}, indent=1, default=str))
    print(json.dumps(diffs[:20], indent=1, default=str))
except BaseException:
    import traceback; traceback.print_exc(); sys.stdout.flush(); os._exit(1)
sys.stdout.flush(); os._exit(0)
