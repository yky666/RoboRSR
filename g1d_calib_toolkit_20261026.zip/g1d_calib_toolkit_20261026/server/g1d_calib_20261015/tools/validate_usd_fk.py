"""Check that a calibrated USD reproduces the calibrated URDF FK.

Three independent checks against calib_model FK of the calibrated URDF (and the same for the nominal pair as control):
  usd_joint_frames  FK composed from the USD joint prims (localPos/localRot 0/1, axis) at several joint vectors
  usd_link_xforms   authored link prim transforms at zero joints
  physx             PhysX articulation (CPU, no gravity, self-collision off so random vectors are not pushed apart)
                    set to the joint vectors, body poses read back
"""
import argparse
import json
import os
import sys
from pathlib import Path
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
AppLauncher.add_app_launcher_args(parser)
parser.add_argument('--asset-dir', required=True)
parser.set_defaults(headless=True, device='cpu')
args = parser.parse_args()
app = AppLauncher(args).app
try:
    import numpy as np
    import torch
    from pxr import Usd, UsdGeom, UsdPhysics
    from scipy.spatial.transform import Rotation
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from calib_model import NOMINAL, Robot, arm_joints
    from tcp_effect import grasp_row, read_trace
    import isaaclab.sim as sim_utils
    from isaaclab.assets import Articulation, ArticulationCfg
    from isaaclab.actuators import ImplicitActuatorCfg

    asset = Path(args.asset_dir)
    names = arm_joints('left') + arm_joints('right')
    rng = np.random.default_rng(7)
    g = grasp_row(read_trace())
    grasp = dict(zip(g['joint_names'], g['joint_positions']))
    robot_n = Robot(NOMINAL / 'g1_d_upper_dex1_v4.urdf')
    configs = {'zero': {n: 0. for n in names}, 'E036_grasp': {n: grasp[n] for n in names}}
    for i in range(3):
        configs[f'random_{i}'] = {n: rng.uniform(robot_n.joints[n]['lower'] + .2, robot_n.joints[n]['upper'] - .2) for n in names}
    for q in configs.values():
        q.update({f'{s}_dex1_finger_joint_{k}': -0.02 for s in ['left', 'right'] for k in [1, 2]})

    def mat(pos, quat):
        T = np.eye(4)
        T[:3, :3] = Rotation.from_quat([quat.imaginary[0], quat.imaginary[1], quat.imaginary[2], quat.real]).as_matrix()
        T[:3, 3] = [pos[0], pos[1], pos[2]]
        return T

    def usd_joints(stage):
        out = {}
        for prim in stage.Traverse():
            if not prim.IsA(UsdPhysics.Joint):
                continue
            j = UsdPhysics.Joint(prim)
            b0, b1 = j.GetBody0Rel().GetTargets(), j.GetBody1Rel().GetTargets()
            if not b0 or not b1:
                continue
            axis = None
            if prim.IsA(UsdPhysics.RevoluteJoint):
                axis = ('revolute', UsdPhysics.RevoluteJoint(prim).GetAxisAttr().Get())
            elif prim.IsA(UsdPhysics.PrismaticJoint):
                axis = ('prismatic', UsdPhysics.PrismaticJoint(prim).GetAxisAttr().Get())
            out[prim.GetName()] = dict(parent=b0[0].name, child=b1[0].name, axis=axis,
                                       A=mat(j.GetLocalPos0Attr().Get(), j.GetLocalRot0Attr().Get()),
                                       B=mat(j.GetLocalPos1Attr().Get(), j.GetLocalRot1Attr().Get()))
        return out

    def usd_fk(joints, q):
        frames, pending = {'torso_link': np.eye(4)}, dict(joints)
        while pending:
            progress = False
            for name, j in list(pending.items()):
                if j['parent'] not in frames:
                    continue
                M = np.eye(4)
                if j['axis'] is not None:
                    e = np.eye(3)['XYZ'.index(j['axis'][1])]
                    if j['axis'][0] == 'revolute':
                        M[:3, :3] = Rotation.from_rotvec(e * q.get(name, 0.)).as_matrix()
                    else:
                        M[:3, 3] = e * q.get(name, 0.)
                frames[j['child']] = frames[j['parent']] @ j['A'] @ M @ np.linalg.inv(j['B'])
                del pending[name]
                progress = True
            if not progress:
                break
        return frames

    def urdf_fk(robot, q):
        qa = {k: np.array([v]) for k, v in q.items()}
        return {j['child']: robot.fk(j['child'], qa, n=1)[0] for j in robot.joints.values()}

    def compare(A, B):
        common = sorted(set(A) & set(B))
        dt = max(np.linalg.norm(A[l][:3, 3] - B[l][:3, 3]) for l in common)
        dr = max(np.linalg.norm(Rotation.from_matrix(A[l][:3, :3].T @ B[l][:3, :3]).as_rotvec()) for l in common)
        return {'links_compared': len(common), 'max_translation_m': float(dt), 'max_rotation_rad': float(dr)}

    report = {'asset_dir': str(asset), 'nominal_dir': str(NOMINAL), 'configs': list(configs)}
    pairs = {'calibrated': (asset, Robot(asset / 'g1_d_upper_dex1_v4.urdf')), 'nominal': (NOMINAL, robot_n)}
    joint_sign = {}
    for label, (d, robot) in pairs.items():
        stage = Usd.Stage.Open(str(d / 'g1_d_upper_dex1_v4_flat.usdc'))
        joints = usd_joints(stage)
        rec = {'usd_joint_frames': {}, 'n_usd_joints': len(joints)}
        for c, q in configs.items():
            rec['usd_joint_frames'][c] = compare(usd_fk(joints, q), urdf_fk(robot, q))
        root = stage.GetDefaultPrim()
        cache = UsdGeom.XformCache()
        Troot = np.array(cache.GetLocalToWorldTransform(root.GetChild('torso_link'))).T
        xf = {}
        for child in root.GetChildren():
            if child.IsA(UsdGeom.Xformable) and child.GetName() in {j['child'] for j in robot.joints.values()} | {'torso_link'}:
                xf[child.GetName()] = np.linalg.inv(Troot) @ np.array(cache.GetLocalToWorldTransform(child)).T
        rec['usd_link_xforms_zero'] = compare(xf, urdf_fk(robot, {}))
        report[label] = rec

    sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=1 / 240, device='cpu', gravity=(0., 0., 0.)))
    robots = {}
    for i, (label, (d, _)) in enumerate(pairs.items()):
        spawn = sim_utils.UsdFileCfg(usd_path=str(d / 'g1_d_upper_dex1_v4_flat.usdc'),
                                     articulation_props=sim_utils.ArticulationRootPropertiesCfg(enabled_self_collisions=False))
        cfg = ArticulationCfg(prim_path=f'/World/{label}', spawn=spawn,
                              init_state=ArticulationCfg.InitialStateCfg(pos=(0., 2. * i, 0.)),
                              actuators={'all': ImplicitActuatorCfg(joint_names_expr=['.*'], stiffness=1e5, damping=1e3)})
        robots[label] = Articulation(cfg)
    sim.reset()
    for label, art in robots.items():
        report[label]['physx'] = {}
    for c, q in configs.items():
        for label, art in robots.items():
            jp = torch.tensor([[q.get(n, 0.) for n in art.joint_names]], dtype=torch.float32)
            art.write_joint_state_to_sim(jp, torch.zeros_like(jp))
            art.set_joint_position_target(jp)
            art.write_data_to_sim()
        sim.step(render=False)
        for label, art in robots.items():
            art.update(sim.get_physics_dt())
            pose = art.data.body_link_pose_w[0].cpu().numpy().astype(float)
            T = {}
            for n, x in zip(art.body_names, pose):
                M = np.eye(4)
                M[:3, :3] = Rotation.from_quat([x[4], x[5], x[6], x[3]]).as_matrix()
                M[:3, 3] = x[:3]
                T[n] = M
            base = np.linalg.inv(T['torso_link'])
            T = {n: base @ M for n, M in T.items()}
            report[label]['physx'][c] = compare(T, urdf_fk(pairs[label][1], q))
            measured = np.array([art.data.joint_pos[0, art.joint_names.index(n)].item() for n in names])
            report[label]['physx'][c]['max_joint_readback_error_rad'] = float(np.abs(measured - [q[n] for n in names]).max())
    worst = lambda key: max(v['max_translation_m'] for lab in pairs for v in (report[lab][key].values() if key != 'usd_link_xforms_zero' else [report[lab][key]]))
    report['summary'] = {'usd_joint_frames_max_translation_m': worst('usd_joint_frames'),
                         'usd_joint_frames_max_rotation_rad': max(v['max_rotation_rad'] for lab in pairs for v in report[lab]['usd_joint_frames'].values()),
                         'usd_link_xforms_max_translation_m': worst('usd_link_xforms_zero'),
                         'physx_max_translation_m': worst('physx'),
                         'physx_max_rotation_rad': max(v['max_rotation_rad'] for lab in pairs for v in report[lab]['physx'].values())}
    report['passed'] = (report['summary']['usd_joint_frames_max_translation_m'] < 1e-6 and
                        report['summary']['usd_joint_frames_max_rotation_rad'] < 1e-5 and
                        report['summary']['physx_max_translation_m'] < 2e-4 and report['summary']['physx_max_rotation_rad'] < 2e-3)
    (asset / 'usd_fk_validation.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report['summary'], indent=2), report['passed'], flush=True)
except BaseException:
    import traceback
    traceback.print_exc()
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(1)
sys.stdout.flush()
sys.stderr.flush()
os._exit(0)
