# real2sim_calib_20261015：G1-D 真机—仿真运动学标定

目标：标定仿真机器人模型，使仿真中求得的关节轨迹在真机上复现相同位姿。关节名与关节值语义保持为真机编码器值，误差写入 URDF 关节 `<origin>`（约定 `q_model = q_encoder + zero`）。唯一测量设备是标定板 + 机器人自带相机。所有具体偏差数值（含左肩 roll 2.6°）都是占位，需在真机上重新测量。

从 `docs/00_overview_zh.md` 开始阅读。

## 文件

| 文件 | 作用 |
|---|---|
| `calib_model.py` | 误差模型：URDF 解析、带参数 FK、相机投影、板角点、残差问题 |
| `identify.py` | 从测量 JSON 辨识参数：预设参数集、拟合、可辨识性（SVD/协方差/相关）、k 折留出验证、输出参数 JSON |
| `compare_sim_real.py` | sim-vs-real 角点残差（名义/标定）、单参数快速估计、叠加图 |
| `board_setups.py` | 标定设置 A/B 的名义场景、可行位姿采样（限位/自碰撞/桌面/可见/朝向/遮挡）、合成测量 |
| `synthetic_validation.py` | 合成验证 → `synthetic_validation.json`、`synthetic_validation_table.md`、`examples/` |
| `pose_design.py` | D 最优位姿设计 → `poses_left.json`、`poses_right.json`、`pose_design_summary.json` |
| `apply_calibration.py` | 参数 JSON → 标定 URDF（upper + full）+ `calibration_provenance.json` |
| `test_apply_calibration.py` | 单元测试（6 项，日志 `test_apply_calibration.log`）|
| `build_assembly.py`、`tools/` | 标定 URDF → USD / 物理合同 / 相机合同 / 校验（需 GPU）|
| `tcp_effect.py` | 参数集对 TCP / 腕相机位姿的影响 |
| `export_replay.py` | 仿真运行 `trace.jsonl` → 回放轨迹文件 |
| `params_test_left_shoulder_roll_2p6.json` | 占位参数（非标定结果）|
| `assembled_test_lsr2p6/` | 占位参数构建的标定资产样例（含 USD-FK 校验）|
| `tcp_effect_lsr2p6.json` | 占位参数的 TCP 影响 |
| `examples/` | 测量文件样例（含 2 样本小样例）、`identify_demo/`（辨识→参数→URDF→对比的完整演示）、`replay_r2s_E036_left_a1.json`、`replay_r2s_E009_right_a1.json`（回放文件样例）|
| `docs/` | 中文方法文档 00–07 与 `error_model_zh.md` |
| `scratch/` | 诊断脚本（预设参数集比较、误差平台来源、内参影响），日志在 `logs/` |
| `backup_20261015/` | 本轮修改前的服务器版本 |

## 常用命令

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015
PY=$ISAAC_ENV/bin/python   # unitree_sim_env 的 python（GPU 服务器上）
$PY test_apply_calibration.py                                   # 单元测试
$PY synthetic_validation.py --workers 48 [--quick]              # 合成验证（约 1 分钟）
$PY pose_design.py [--n 50] [--scene 真实板与相机头文件.json]      # 位姿表（约 1 分钟）
$PY identify.py meas*.json --preset auto --refine-intrinsics --out r.json --params-out p.json
$PY compare_sim_real.py meas.json [--params p.json] [--fit 'left_shoulder_roll_joint/zero'] --out c.json
$PY apply_calibration.py p.json out_dir
$PY build_assembly.py p.json assembled_<tag> --gpu N            # 需 GPU
$PY export_replay.py <run_dir> replay.json
```

## 文档

| 文档 | 内容 |
|---|---|
| `docs/00_overview_zh.md` | 全流程、服务器 vs 真机分工、真机待实现工具及接口、待实测项汇总 |
| `docs/01_camera_intrinsics_zh.md` | 四个相机的内参/畸变标定与文件格式 |
| `docs/02_data_collection_zh.md` | 标定数据采集工具：位姿遍历、稳定、全关节记录、同步图像、板安装、中止条件 |
| `docs/03_board_detection_export_zh.md` | 角点检测、ID 约定、质量筛选、测量 JSON 格式、辨识命令 |
| `docs/04_sim_real_comparison_zh.md` | 可复现 sim-vs-real 对比、方向/符号检查、快速粗估及其与完整辨识的关系 |
| `docs/05_dynamic_identification_zh.md` | 阶跃/扫频/负载/下垂测试与仿真驱动参数拟合 |
| `docs/06_replay_validation_zh.md` | E009/E036 轨迹真机回放（空载→空杯→带水）与验收阈值 |
| `docs/07_apply_parameters_zh.md` | 参数写回、资产重建、回归检查、切换运行器 |
| `docs/error_model_zh.md` | 参数定义、规范自由度、相关性与破除方法、合成验证结论 |
