"""Synthetic validation of board-based identification (setups A, B, C) against known perturbations of the nominal model.

usage: synthetic_validation.py [--workers 48] [--quick]
writes synthetic_validation.json, synthetic_validation_table.md, examples/measurements_example_*.json
TCP errors are evaluated at the grasp-to-pour joint vectors of the verified sim pours r2s_E009 / r2s_E036 (mirrored to
the other arm) and at random joint vectors, in the frames the measurements can observe (head camera, table board).
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import argparse
import itertools
import json
import multiprocessing as mp
import time
from pathlib import Path
import numpy as np
from board_setups import INTRINSICS_SIGMA, Geometry, nominal_scene, sample_feasible, synthesize
from calib_model import ARM, NOMINAL, SE3_KEYS, TCP_OFFSET, Problem, Robot, arm_joints, inv, pose_error, se3, se3_of, transform
from identify import analyze, errors, fit, preset_names, summarize

HERE = Path(__file__).resolve().parent
DEG = np.pi / 180
G = {}
RUNS = Path('/mnt/data/unitree_sim_isaaclab_runs/real2sim_g1d_20261015/runs')
REFERENCE_RUNS = {'right': 'r2s_E009_right_a1', 'left': 'r2s_E036_left_a1'}
TASK_PHASES = ('close', 'test_lift', 'lift', 'align', 'tilt', 'pour_hold')
MIRROR = {'shoulder_pitch': 1, 'shoulder_roll': -1, 'shoulder_yaw': -1, 'elbow': 1, 'wrist_roll': -1, 'wrist_pitch': 1,
          'wrist_yaw': -1}
FIXTURE_SIGMA = (0.3 * DEG, 5e-4)


def task_poses(per_phase=4):
    """Arm joint vectors of the grasp-to-pour phases of the verified sim pours, mirrored to the other arm."""
    out = {'left': [], 'right': []}
    for side, run in REFERENCE_RUNS.items():
        rows = [json.loads(l) for l in (RUNS / run / 'trace.jsonl').read_text().splitlines() if l.strip()]
        other = 'left' if side == 'right' else 'right'
        for phase in TASK_PHASES:
            sel = [r for r in rows if r['phase'] == phase]
            for r in sel[::max(1, len(sel) // per_phase)][:per_phase]:
                q = dict(zip(r['joint_names'], r['joint_positions']))
                out[side].append([q[n] for n in arm_joints(side)])
                out[other].append([q[f'{side}_{n}_joint'] * MIRROR[n] for n in ARM])
    return {k: np.array(v) for k, v in out.items()}


def truth(seed, realistic=True, alt=False, fixture=False):
    """Ideal: errors inside the estimated model. Realistic: plus rot_u, joint translations (unmodelled) and encoder noise."""
    rng = np.random.default_rng(10_000 + seed)
    p = {}
    for side in ['left', 'right']:
        for j in arm_joints(side):
            p[f'{j}/zero'] = rng.uniform(0.1, 0.5) * DEG * rng.choice([-1, 1])
            p[f'{j}/rot_v'] = rng.normal(0, 0.2 * DEG)
            if realistic or j.endswith('shoulder_pitch_joint'):
                p[f'{j}/rot_u'] = rng.normal(0, 0.2 * DEG)
            if realistic:
                for k in ['dx', 'dy', 'dz']:
                    p[f'{j}/{k}'] = rng.normal(0, 3e-4)
    if alt:
        p['left_shoulder_pitch_joint/rot_v'] = 2.6 * DEG
    else:
        p['left_shoulder_roll_joint/zero'] = 2.6 * DEG
    for cam, (sr, st) in {'head_left': (1, 5e-3), 'head_right': (1, 5e-3), 'left_wrist': (1, 3e-3), 'right_wrist': (1, 3e-3)}.items():
        for k, s in zip(SE3_KEYS, [sr * DEG] * 3 + [st] * 3):
            p[f'camera:{cam}/{k}'] = rng.normal(0, s)
        for k, s in INTRINSICS_SIGMA.items():
            p[f'intrinsics:{cam}/{k}'] = rng.normal(0, s)
    gripper = FIXTURE_SIGMA if fixture else (2 * DEG, 5e-3)
    for board, (sr, st) in {'gripper_left': gripper, 'gripper_right': gripper, 'table': (3 * DEG, 2e-2)}.items():
        for k, s in zip(SE3_KEYS, [sr] * 3 + [st] * 3):
            p[f'board:{board}/{k}'] = rng.normal(0, s)
    return p


def reference(robot, scene, frame, p):
    if frame == 'torso':
        return np.eye(4)
    if frame == 'head_left_camera':
        c = scene['cameras']['head_left']
        return robot.fk(c['parent'], {}, p, n=1)[0] @ np.array(c['T_parent_camera']) @ se3(se3_of(p, 'camera:head_left'))
    if frame == 'table_board':
        return np.array(scene['boards']['table']['T_parent_board']) @ se3(se3_of(p, 'board:table'))
    raise KeyError(frame)


def tcp_errors(robot, scene, p_true, p_est, sides, frames_of, n=300, seed=0):
    """TCP pose error vs truth for calibrated, gauge-fixed (true wrist_yaw zero) and nominal models."""
    rng = np.random.default_rng(seed)
    tool = transform(t=TCP_OFFSET)
    out = {}
    for side in sides:
        names = arm_joints(side)
        lo = np.array([robot.joints[k]['lower'] for k in names]) + 0.15
        hi = np.array([robot.joints[k]['upper'] for k in names]) - 0.15
        models = {'true': p_true, 'calibrated': p_est, 'nominal': {},
                  'gauge_fixed': dict(p_est, **{f'{side}_wrist_yaw_joint/zero': p_true[f'{side}_wrist_yaw_joint/zero']})}
        res = {}
        for label, Q in {'task': G['task'][side], 'random': rng.uniform(lo, hi, (n, 7))}.items():
            q = {k: Q[:, i] for i, k in enumerate(names)}
            T = {m: robot.fk(f'{side}_dex1_base_link', q, pm, n=len(Q)) @ tool for m, pm in models.items()}
            for frame in frames_of:
                ref = {m: reference(robot, scene, frame, pm) for m, pm in models.items()}
                Tt = inv(ref['true']) @ T['true']
                rec = {}
                for m in ['calibrated', 'gauge_fixed', 'nominal']:
                    d, a = pose_error(Tt, inv(ref[m]) @ T[m])
                    rec[f'{m}_mm_rms'] = 1000 * float(np.sqrt(np.mean(d ** 2)))
                    rec[f'{m}_mm_max'] = 1000 * float(d.max())
                    rec[f'{m}_deg_rms'] = float(np.degrees(np.sqrt(np.mean(a ** 2))))
                res[f'{label}:{frame}'] = rec
        out[side] = res
    return out


def experiment(spec):
    robot, scene, pools = G['robot'], G['scene'], G['pools']
    seed = spec['seed']
    rng = np.random.default_rng(seed)
    realistic = spec.get('realistic', True)
    p_true = truth(seed, realistic, spec.get('alt', False), spec.get('fixture', False))
    batches = []
    for setup, side in spec['views']:
        pool = pools[('A_stereo' if setup.startswith('A') else setup, side)]
        idx = rng.choice(len(pool), spec['N'], replace=False)
        batches.append((setup, side, [pool[i] for i in idx]))
    meas = synthesize(scene, robot, batches, p_true, spec['sigma_px'], 0.02 * DEG if realistic else 0., rng)
    names, priors = preset_names(meas, refine_intrinsics=spec['intrinsics'] == 'refine')
    sides = sorted({s for _, s in spec['views']})
    if spec.get('fixture'):
        names += [f'{s}_wrist_yaw_joint/zero' for s in sides]
        for n in names:
            if n.startswith('board:gripper_'):
                priors[n] = (0., FIXTURE_SIGMA[0] if n[-2] == 'r' else FIXTURE_SIGMA[1])
    problem = Problem(robot, meas, names, {}, priors)
    t = time.time()
    r = fit(problem)
    p_est = problem.params(r.x)
    frames = ['torso'] + (['head_left_camera'] if any(v[0].startswith('A') for v in spec['views']) else []) + \
             (['table_board'] if any(v[0] == 'B_wrist' for v in spec['views']) else [])
    out = {'spec': spec, 'n_samples': len(meas['samples']), 'n_parameters': len(names), 'seconds': time.time() - t,
           'optimizer_status': int(r.status), 'final_residuals': summarize(errors(problem, r.x))}
    zero_err, rot_err = {}, {}
    for side in sides:
        for j in arm_joints(side):
            zero_err[f'{j}/zero'] = float(np.degrees(p_est.get(f'{j}/zero', 0.) - p_true[f'{j}/zero']))
            for k in ['rot_u', 'rot_v']:
                rot_err[f'{j}/{k}'] = float(np.degrees(p_est.get(f'{j}/{k}', 0.) - p_true.get(f'{j}/{k}', 0.)))
    out['zero_offset_error_deg'] = zero_err
    out['mount_rotation_error_deg'] = rot_err
    out['estimated_left_shoulder_roll_zero_deg'] = float(np.degrees(p_est.get('left_shoulder_roll_joint/zero', 0.)))
    out['estimates_of_interest_deg'] = {k: float(np.degrees(p_est.get(k, 0.))) for k in
                                        ['left_shoulder_roll_joint/zero', 'left_shoulder_pitch_joint/rot_v',
                                         'camera:head_left/rx', 'camera:head_left/ry', 'camera:head_left/rz']}
    out['tcp'] = tcp_errors(robot, scene, p_true, p_est, sides, frames)
    if spec.get('analyze'):
        a = analyze(problem, r.x)
        out['identifiability'] = {k: a[k] for k in ['condition_number', 'weak_directions', 'flags', 'correlated_pairs_abs_gt_0p9']}
        out['identifiability']['std_deg_or_mm'] = {n: (np.degrees(v) if n.split('/')[-1] in ('zero', 'rot_u', 'rot_v', 'rx', 'ry', 'rz')
                                                     else 1000 * v if n.split('/')[-1] in ('dx', 'dy', 'dz') else v)
                                                   for n, v in a['std'].items()}
    return out


def full_set_study(spec, extra):
    """SVD of the over-parameterized set (all joint rotations, optionally translations) to expose exact null spaces."""
    robot, scene, pools = G['robot'], G['scene'], G['pools']
    rng = np.random.default_rng(spec['seed'])
    batches = []
    for setup, side in spec['views']:
        pool = pools[('A_stereo' if setup.startswith('A') else setup, side)]
        batches.append((setup, side, [pool[i] for i in rng.choice(len(pool), spec['N'], replace=False)]))
    meas = synthesize(scene, robot, batches, {}, 0.5, 0., rng)
    names, _ = preset_names(meas)
    sides = sorted({s for _, s in spec['views']})
    keys = ['zero', 'rot_u', 'rot_v'] + (['dx', 'dy', 'dz'] if extra else [])
    joint_names = [f'{j}/{k}' for s in sides for j in arm_joints(s) for k in keys]
    names = joint_names + [n for n in names if ':' in n.split('/')[0]]
    a = analyze(Problem(robot, meas, names), np.zeros(len(names)))
    return {'views': spec['views'], 'translations': extra, 'n_parameters': len(names), 'rank_deficiency':
            sum(d['kind'] == 'null' for d in a['weak_directions']), 'weak_directions': a['weak_directions'], 'flags': a['flags']}


def obs_frame(frames):
    return next((f for f in frames if not f.endswith(':torso')), frames[0])


def aggregate(results):
    rows = {}
    for r in results:
        s = r['spec']
        key = (s['group'], '+'.join(f'{a}:{b}' for a, b in s['views']), s['N'], s['sigma_px'], s['intrinsics'])
        rows.setdefault(key, []).append(r)
    table = []
    mean = lambda vals: float(np.mean(vals))
    for (group, views, N, sig, intr), rs in sorted(rows.items()):
        for side in sorted(rs[0]['tcp']):
            zeros = [k for k in rs[0]['zero_offset_error_deg'] if k.startswith(side)]
            ident = [k for k in zeros if not k.startswith((f'{side}_shoulder_pitch', f'{side}_wrist_yaw'))]
            roll = f'{side}_shoulder_roll_joint/zero'
            tcp = [r['tcp'][side] for r in rs]
            task = obs_frame([k for k in tcp[0] if k.startswith('task:')])
            rand = 'random:' + task.split(':', 1)[1]
            conds = [r['identifiability']['condition_number'] for r in rs if 'identifiability' in r]
            table.append({'group': group, 'views': views, 'side': side, 'N': N, 'sigma_px': sig, 'intrinsics': intr, 'trials': len(rs),
                          'roll_zero_abs_err_deg_max': float(max(abs(r['zero_offset_error_deg'][roll]) for r in rs)),
                          'identifiable_zero_abs_err_deg_rms': float(np.sqrt(np.mean([r['zero_offset_error_deg'][k] ** 2 for r in rs for k in ident]))),
                          'wrist_yaw_zero_abs_err_deg_rms': float(np.sqrt(np.mean([r['zero_offset_error_deg'][f'{side}_wrist_yaw_joint/zero'] ** 2 for r in rs]))),
                          'observable_frame': task.split(':', 1)[1],
                          'task_mm': mean([t[task]['calibrated_mm_rms'] for t in tcp]), 'task_deg': mean([t[task]['calibrated_deg_rms'] for t in tcp]),
                          'task_mm_max': float(max(t[task]['calibrated_mm_max'] for t in tcp)),
                          'task_gauge_fixed_mm': mean([t[task]['gauge_fixed_mm_rms'] for t in tcp]),
                          'task_gauge_fixed_deg': mean([t[task]['gauge_fixed_deg_rms'] for t in tcp]),
                          'task_nominal_mm': mean([t[task]['nominal_mm_rms'] for t in tcp]), 'task_nominal_deg': mean([t[task]['nominal_deg_rms'] for t in tcp]),
                          'random_mm': mean([t[rand]['calibrated_mm_rms'] for t in tcp]), 'random_deg': mean([t[rand]['calibrated_deg_rms'] for t in tcp]),
                          'condition_number': mean(conds) if conds else None,
                          'est_roll_zero_deg_mean': mean([r['estimated_left_shoulder_roll_zero_deg'] for r in rs]) if side == 'left' else None})
    return table


def markdown(table):
    head = ('| 组 | 设置 | 臂 | N | 噪声 px | 内参 | 试验数 | 2.6° roll 零位最大误差 ° | 可辨识零位 RMS ° | wrist_yaw 零位 RMS °（规范自由度） | '
            '任务位姿 TCP mm / °（可观测系） | 同上，固定规范 mm / ° | 名义模型 mm / ° | 随机位姿 TCP mm / ° | 条件数 |')
    lines = [head, '|' + '---|' * 15]
    for r in table:
        cond = f"{r['condition_number']:.0f}" if r['condition_number'] else '-'
        lines.append(f"| {r['group']} | {r['views']} | {r['side']} | {r['N']} | {r['sigma_px']} | {r['intrinsics']} | {r['trials']} | "
                     f"{r['roll_zero_abs_err_deg_max']:.3f} | {r['identifiable_zero_abs_err_deg_rms']:.3f} | {r['wrist_yaw_zero_abs_err_deg_rms']:.3f} | "
                     f"{r['task_mm']:.2f} / {r['task_deg']:.3f} ({r['observable_frame']}) | {r['task_gauge_fixed_mm']:.2f} / {r['task_gauge_fixed_deg']:.3f} | "
                     f"{r['task_nominal_mm']:.1f} / {r['task_nominal_deg']:.2f} | {r['random_mm']:.2f} / {r['random_deg']:.3f} | {cond} |")
    return '\n'.join(lines)


def specs(quick):
    seeds = range(1 if quick else 3)
    Ns = [20, 50] if quick else [20, 50, 100]
    out = []
    single = {'A_mono': lambda s: [('A_mono', s)], 'A_stereo': lambda s: [('A_stereo', s)], 'B_wrist': lambda s: [('B_wrist', s)],
              'C': lambda s: [('A_stereo', s), ('B_wrist', s)]}
    for (name, views), side, N, intr, seed in itertools.product(single.items(), ['left', 'right'], Ns, ['precal', 'refine'], seeds):
        out.append(dict(group='main', views=views(side), N=N, sigma_px=0.5, intrinsics=intr, seed=seed, analyze=seed == 0))
    both = [('A_stereo', 'left'), ('A_stereo', 'right'), ('B_wrist', 'left'), ('B_wrist', 'right')]
    for N, intr, seed in itertools.product(Ns, ['precal', 'refine'], seeds):
        out.append(dict(group='C2_both_arms', views=both, N=N, sigma_px=0.5, intrinsics=intr, seed=seed, analyze=seed == 0))
    for name, seed in itertools.product(['A_stereo', 'B_wrist', 'C'], seeds):
        out.append(dict(group='ideal_model', views=single[name]('left'), N=50, sigma_px=0.5, intrinsics='refine', seed=seed,
                        realistic=False))
    if quick:
        return out
    for sig, name, seed in itertools.product([0.3, 1.0], ['A_stereo', 'B_wrist', 'C'], seeds):
        out.append(dict(group='noise', views=single[name]('left'), N=50, sigma_px=sig, intrinsics='refine', seed=seed))
    for views, seed in itertools.product([single['A_stereo']('left'), single['C']('left'), both], seeds):
        out.append(dict(group='fixture_board_prior', views=views, N=50, sigma_px=0.5, intrinsics='refine', seed=seed, fixture=True,
                        analyze=seed == 0))
    for views, seed in itertools.product([single['A_stereo']('left'), single['C']('left'), both], seeds):
        out.append(dict(group='alt_truth_pitch_mount_tilt', views=views, N=50, sigma_px=0.5, intrinsics='refine', seed=seed, alt=True))
    return out


def init(pools, task):
    G['robot'] = Robot(NOMINAL / 'g1_d_upper_dex1_v4.urdf')
    G['scene'] = nominal_scene()
    G['pools'] = pools
    G['task'] = task


def tiny_example(scene, robot, pools):
    meas = synthesize(scene, robot, [('A_stereo', 'left', pools[('A_stereo', 'left')][:1]), ('B_wrist', 'left', pools[('B_wrist', 'left')][:1])],
                      {}, 0.5, 0., np.random.default_rng(3))
    for s in meas['samples']:
        for o in s['observations']:
            o['corner_ids'], o['pixels'] = o['corner_ids'][:4], [[round(v, 2) for v in uv] for uv in o['pixels'][:4]]
        s['joints'] = {k: round(v, 6) for k, v in s['joints'].items()}
    meas['boards'] = {k: {kk: v for kk, v in b.items() if kk != 'points_m'} for k, b in meas['boards'].items() if k in ('gripper_left', 'table')}
    return meas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--workers', type=int, default=48)
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--pool-size', type=int, default=300)
    a = ap.parse_args()
    t = time.time()
    scene = nominal_scene()
    geo = Geometry(scene)
    rng = np.random.default_rng(2026)
    pools, pool_stats = {}, {}
    for setup in ['A_stereo', 'B_wrist']:
        for side in ['left', 'right']:
            pools[(setup, side)], pool_stats[f'{setup}:{side}'] = sample_feasible(geo, scene, setup, side, a.pool_size, rng,
                                                                                  draws=300000, max_checks=12000)
            print(setup, side, pool_stats[f'{setup}:{side}'], flush=True)
    task = task_poses()
    init(pools, task)
    jobs = specs(a.quick)
    studies = [dict(views=v, N=50, seed=0) for v in [[('A_mono', 'left')], [('A_stereo', 'left')], [('B_wrist', 'left')],
                                                      [('A_stereo', 'left'), ('B_wrist', 'left')],
                                                      [('A_stereo', 'left'), ('A_stereo', 'right'), ('B_wrist', 'left'), ('B_wrist', 'right')]]]
    print(len(jobs), 'experiments', flush=True)
    with mp.get_context('fork').Pool(a.workers) as pool:
        results = pool.map(experiment, jobs, chunksize=1)
        full = pool.starmap(full_set_study, [(s, x) for s in studies for x in [False, True]])
    table = aggregate(results)
    examples = HERE / 'examples'
    examples.mkdir(exist_ok=True)
    for setup, side in [('A_stereo', 'left'), ('B_wrist', 'left')]:
        meas = synthesize(scene, G['robot'], [(setup, side, pools[(setup, side)][:50])], truth(0), 0.5, 0.02 * DEG, np.random.default_rng(1))
        meas['synthetic_truth_for_testing'] = {k: v for k, v in truth(0).items() if k.startswith(side) or ':' in k}
        (examples / f'measurements_example_{setup}_{side}.json').write_text(json.dumps(meas))
    (examples / 'measurements_tiny_example.json').write_text(json.dumps(tiny_example(scene, G['robot'], pools), indent=1))
    doc = {'description': 'Synthetic validation of board-based kinematic calibration (see docs/error_model_zh.md)', 'seconds': time.time() - t,
           'truth_model': {'left_shoulder_roll_zero_deg': '2.6 (placeholder magnitude)', 'other_zero_offsets_deg': 'uniform 0.1-0.5, random sign',
                           'rot_v_deg_sigma': 0.2, 'realistic_only': {'rot_u_deg_sigma': 0.2, 'joint_translation_mm_sigma': 0.3,
                                                                      'encoder_noise_deg_sigma': 0.02},
                           'camera_extrinsic_sigma': {'head': '1 deg / 5 mm', 'wrist': '1 deg / 3 mm'},
                           'board_pose_sigma': {'gripper': '2 deg / 5 mm (fixture group: 0.3 deg / 0.5 mm with matching prior)', 'table': '3 deg / 20 mm'},
                           'intrinsics_calibration_error_sigma': INTRINSICS_SIGMA,
                           'precal': 'intrinsics fixed at the (erroneous) pre-calibrated values',
                           'refine': 'intrinsics jointly refined with the pre-calibration sigma as prior',
                           'alt_truth': 'left shoulder_pitch frame tilted 2.6 deg about x (rot_v) instead of a roll zero offset',
                           'gauge_fixed': 'calibrated model with the true wrist_yaw zero (unobservable with an unknown board / wrist-camera mount)'},
           'task_poses': {'runs': REFERENCE_RUNS, 'phases': TASK_PHASES, 'count': {k: len(v) for k, v in task.items()}},
           'cameras': {k: {kk: v[kk] for kk in ['K', 'dist', 'resolution']} for k, v in scene['cameras'].items()},
           'boards': {k: {kk: v[kk] for kk in v if kk not in ('points_m',)} for k, v in scene['boards'].items()},
           'pose_pools': pool_stats, 'table': table, 'full_parameter_set_studies': full, 'experiments': results}
    (HERE / 'synthetic_validation.json').write_text(json.dumps(doc, indent=1, default=float))
    (HERE / 'synthetic_validation_table.md').write_text(markdown(table) + '\n')
    print(markdown(table))
    for f in full:
        print(f['views'], 'translations' if f['translations'] else '', 'rank deficiency', f['rank_deficiency'],
              [d['components'] for d in f['weak_directions'] if d['kind'] == 'null'][:8])
    print('seconds', time.time() - t)


if __name__ == '__main__':
    main()
