"""Build a calibrated G1-D + Dex1 assembly the same way as real2sim_g1d_20261015/assembled.

URDF (apply_calibration) -> meshes + assemble.json -> source validation -> UrdfConverter USD -> shared prepare()
-> flat USD -> camera contract (nominal T_parent_camera, then camera deltas) -> USD comparison vs nominal -> USD FK check.

usage: build_assembly.py PARAMS.json OUT_DIR --gpu N
"""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
import numpy as np
from apply_calibration import apply, sha
from calib_model import NOMINAL, SE3_KEYS, load_params, se3

HERE = Path(__file__).resolve().parent
TOOLS = HERE / 'tools'
PY = os.environ.get('ISAAC_PY', '<ISAAC_ENV>/bin/python')


def run(cmd, log, env=None):
    with open(log, 'w') as f:
        code = subprocess.call(cmd, stdout=f, stderr=subprocess.STDOUT, env=env, cwd=str(HERE))
    if code:
        raise RuntimeError(f'{cmd} failed ({code}), see {log}')


def camera_contract(out, deltas):
    path = out / 'camera_contract_v5.json'
    doc = json.loads(path.read_text())
    nominal = {v['name']: v for v in json.loads((NOMINAL / 'camera_contract_v5.json').read_text())['views']}
    applied = {}
    for view in doc['views']:
        assert np.allclose(view['T_parent_camera_world_convention'], nominal[view['name']]['T_parent_camera_world_convention'], atol=1e-12)
        xi = np.array([deltas.get(f"camera:{view['name']}/{k}", 0.) for k in SE3_KEYS])
        if np.any(xi):
            view['T_parent_camera_world_convention'] = (np.array(view['T_parent_camera_world_convention']) @ se3(xi)).tolist()
            applied[view['name']] = xi.tolist()
    doc['calibration'] = {
        'policy': 'T_parent_camera is the nominal mount (cameras are rigidly attached to their parent links, so calibrated link '
                  'frames carry them); identified camera:<name> deltas are right-multiplied. Recomputing T_parent_camera from the '
                  'reference camera positions with the calibrated FK would cancel the link calibration for the wrist cameras.',
        'camera_deltas_rx_ry_rz_dx_dy_dz': applied,
        'intrinsics_deltas': {k: v for k, v in deltas.items() if k.startswith('intrinsics:')}}
    path.write_text(json.dumps(doc, indent=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('params')
    ap.add_argument('out_dir')
    ap.add_argument('--gpu', required=True)
    ap.add_argument('--revalidate', action='store_true', help='rerun only the USD comparison and FK checks of OUT_DIR')
    a = ap.parse_args()
    out = Path(a.out_dir).resolve()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(a.gpu), OMNI_KIT_ACCEPT_EULA='yes')
    if not a.revalidate:
        build(a, out, env)
    run([PY, str(TOOLS / 'compare_usd_calib.py'), '--asset-dir', str(out)], out / 'compare_usd.log', env)
    run([PY, str(TOOLS / 'validate_usd_fk.py'), '--asset-dir', str(out)], out / 'usd_fk_validation.log', env)
    (out / 'sha256.json').write_text(json.dumps({str(p.relative_to(out)): hashlib.sha256(p.read_bytes()).hexdigest()
                                                 for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'sha256.json'}, indent=2))
    print(out)


def build(a, out, env):
    if out.exists():
        raise FileExistsError(out)
    params = load_params(a.params)
    report = apply(params, out)
    report['params_file'] = str(Path(a.params).resolve())
    report['params_sha256'] = sha(a.params)
    (out / 'calibration_provenance.json').write_text(json.dumps(report, indent=2))
    shutil.copytree(NOMINAL / 'meshes', out / 'meshes')
    manifest = json.loads((NOMINAL / 'assemble.json').read_text())
    for variant, name in [('upper', 'g1_d_upper_dex1_v4.urdf'), ('full', 'g1_d_full_dex1_v4.urdf')]:
        manifest['variants'][variant].update(urdf=str(out / name), sha256=sha(out / name))
    manifest['calibration'] = {'params_file': report['params_file'], 'status': params.get('status'),
                               'nominal_assembly': str(NOMINAL), 'changed_joints': sorted(report['joints'])}
    (out / 'assemble.json').write_text(json.dumps(manifest, indent=2))
    run([PY, str(TOOLS / 'validate_sources_calib.py'), str(out)], out / 'source_validation.log')
    run([PY, str(TOOLS / 'convert_prepare_finalize_calib.py'), '--asset-dir', str(out)], out / 'finalize.log', env)
    run([PY, str(TOOLS / 'build_camera_contract_calib.py'), str(out)], out / 'camera_contract.log')
    camera_contract(out, report['camera_and_intrinsics_deltas'])


if __name__ == '__main__':
    main()
