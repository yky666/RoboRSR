"""Calibration pose lists per arm and board setup: greedy D-optimal selection on the stacked pixel Jacobian of the
identified parameters from feasible candidates (joint limits with margin, self/table collision, board visible, facing
the camera and not occluded), ordered to keep joint motion short, with collision-checked transitions.

usage: pose_design.py [--n 50] [--pool 700] [--scene measurements_header.json]
writes poses_left.json, poses_right.json, pose_design_summary.json
--scene: a g1d_calib_measurements_v1 header (cameras, boards) of the real setup; default is the nominal scene.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '4')
import argparse
import json
import time
from pathlib import Path
import numpy as np
from board_setups import Geometry, all_frames, idle_arm, nominal_scene, sample_feasible, setup_views, synthesize, visible_corners
from calib_model import NOMINAL, Problem, Robot, arm_joints
from identify import jacobian, preset_names, unit
from synthetic_validation import task_poses

HERE = Path(__file__).resolve().parent
SETUPS = {'A_head_board_on_gripper': 'A_stereo', 'B_wrist_table_board': 'B_wrist'}
MARGIN = 0.15
V_MAX = 0.35
SETTLE = {'min_wait_s': 1.5, 'velocity_threshold_rad_s': 0.005, 'window_s': 0.5, 'frames_per_pose': 5, 'timeout_s': 6.0}


def candidates(geo, scene, setup, side, n, rng):
    """Half near the grasp-to-pour task poses (perturbed), half uniform within limits; all pass the setup checks."""
    task = task_poses()[side]
    near = task[rng.integers(len(task), size=150000)] + rng.normal(0, 0.35, (150000, 7))
    a, sa = sample_feasible(geo, scene, setup, side, n // 2, rng, margin=MARGIN, candidates=near, max_checks=10000)
    b, sb = sample_feasible(geo, scene, setup, side, n - len(a), rng, margin=MARGIN, draws=300000, max_checks=15000)
    return a + b, ['near_task'] * len(a) + ['uniform'] * len(b), {'near_task': sa, 'uniform': sb}


def information(robot, scene, setup, side, poses):
    """Per-pose information matrices (scaled parameter units), prior information and parameter names."""
    meas = synthesize(scene, robot, [(setup, side, poses)], {}, 0.5, 0., np.random.default_rng(0))
    keep = [int(s['id'].rsplit('_', 1)[1]) for s in meas['samples']]
    names, priors = preset_names(meas, refine_intrinsics=True)
    problem = Problem(robot, meas, names, {}, priors)
    scale = np.array([unit(n) for n in names])
    J = jacobian(problem, np.zeros(len(names))) * scale
    rows = np.concatenate([np.repeat(g['k'], 2) for g in problem.groups.values()])
    H = np.stack([J[rows == k].T @ J[rows == k] for k in range(len(keep))])
    prior = np.diag([(scale[i] / priors[n][1]) ** 2 if n in priors else 1e-6 for i, n in enumerate(names)])
    return H, prior, names, keep


def greedy_d_optimal(H, prior, n):
    M, chosen = prior.copy(), []
    base = np.linalg.slogdet(M)[1]
    for _ in range(min(n, len(H))):
        gains = np.linalg.slogdet(M[None] + H)[1]
        gains[chosen] = -np.inf
        k = int(np.argmax(gains))
        chosen.append(k)
        M = M + H[k]
    return chosen, M, np.linalg.slogdet(M)[1] - base


def design_metrics(M, names):
    cov = np.linalg.inv(M)
    std = np.sqrt(np.diag(cov)) * np.array([unit(n) for n in names])
    joint = [i for i, n in enumerate(names) if ':' not in n.split('/')[0]]
    w = np.linalg.eigvalsh(M[np.ix_(joint, joint)])
    return {'logdet': float(np.linalg.slogdet(M)[1]), 'joint_block_condition': float(np.sqrt(w[-1] / w[0])),
            'predicted_std_deg': {names[i]: float(np.degrees(std[i])) for i in joint},
            'predicted_std_joint_rms_deg': float(np.degrees(np.sqrt(np.mean(std[joint] ** 2))))}


def segment_ok(geo, side, board, qa, qb, other, steps=12):
    names = arm_joints(side)
    for t in np.linspace(0, 1, steps + 1)[1:-1]:
        q = dict(other, **{n: float(a + t * (b - a)) for n, a, b in zip(names, qa, qb)})
        if not geo.collision_free(all_frames(geo.robot, q), side, board, clearance=0.003):
            return False
    return True


def transition(geo, side, board, qa, qb, home, other):
    if segment_ok(geo, side, board, qa, qb, other):
        return 'direct', np.abs(qa - qb).max()
    if segment_ok(geo, side, board, qa, home, other) and segment_ok(geo, side, board, home, qb, other):
        return 'via_home', np.abs(qa - home).max() + np.abs(home - qb).max()
    return 'unverified', np.abs(qa - home).max() + np.abs(home - qb).max()


def order(Q, home):
    """Open tour from home: nearest neighbour then 2-opt on the max joint displacement (time at a common speed)."""
    cost = lambda a, b: np.abs(a - b).max()
    left, path, cur = list(range(len(Q))), [], home
    while left:
        k = min(left, key=lambda i: cost(cur, Q[i]))
        path.append(k)
        left.remove(k)
        cur = Q[k]
    pts = lambda p: [home] + [Q[i] for i in p]
    improved = True
    while improved:
        improved = False
        for i in range(len(path) - 1):
            for j in range(i + 2, len(path) + 1):
                P = pts(path)
                a, b = P[i], P[i + 1]
                c, d = P[j], P[j + 1] if j + 1 < len(P) else None
                old = cost(a, b) + (cost(c, d) if d is not None else 0)
                new = cost(a, c) + (cost(b, d) if d is not None else 0)
                if new < old - 1e-9:
                    path[i:j] = path[i:j][::-1]
                    improved = True
    return path


def pose_record(robot, scene, setup, side, q, other):
    names = arm_joints(side)
    full = dict(other, **dict(zip(names, map(float, q))))
    qa = {k: np.array([v]) for k, v in full.items()}
    out = {}
    for c, b in setup_views(setup, side):
        links = {scene['cameras'][c]['parent'], scene['boards'][b]['parent']}
        frames = {l: robot.fk(l, qa, {}, scene['root_link'], 1) for l in links}
        uv, mask, Tc, Tb, pts = visible_corners(scene, frames, c, b)
        centre = Tb[0, :3, :3] @ pts.mean(0) + Tb[0, :3, 3]
        view = centre - Tc[0, :3, 3]
        ang = np.degrees(np.arccos(np.clip(-Tb[0, :3, 2] @ view / np.linalg.norm(view), -1, 1)))
        out[c] = {'board': b, 'visible_corners': int(mask[0].sum()), 'distance_m': round(float(np.linalg.norm(view)), 3),
                  'board_normal_to_camera_deg': round(float(180 - ang), 1),
                  'board_centre_px': [round(float(v), 1) for v in uv[0, mask[0]].mean(0)] if mask[0].any() else None}
    return out


def design(geo, robot, scene, side, n, pool, rng):
    other_side = 'right' if side == 'left' else 'left'
    other = idle_arm(other_side)
    home = np.array([idle_arm(side)[k] for k in arm_joints(side)])
    out, summary = {}, {}
    for label, setup in SETUPS.items():
        t = time.time()
        poses, origin, stats = candidates(geo, scene, setup, side, pool, rng)
        H, prior, names, keep = information(robot, scene, setup, side, poses)
        poses, origin = [poses[k] for k in keep], [origin[k] for k in keep]
        chosen, M, gain = greedy_d_optimal(H, prior, n)
        rand = [design_metrics(prior + H[rng.choice(len(H), len(chosen), replace=False)].sum(0), names) for _ in range(20)]
        Q = np.array([[poses[k][j] for j in arm_joints(side)] for k in chosen])
        path = order(Q, home)
        board = setup_views(setup, side)[0][1] if setup.startswith('A') else None
        records, prev, total = [], home, 0.
        for i, k in enumerate(path):
            q = Q[k]
            via, move = transition(geo, side, board, prev, q, home, other)
            dur = float(max(1.5, move / V_MAX))
            total += dur + SETTLE['min_wait_s'] + 0.5
            records.append({'index': i, 'id': f'{label[0]}_{side}_{i:03d}', 'joints': {j: round(float(v), 5) for j, v in zip(arm_joints(side), q)},
                            'transition_before': via, 'move_duration_s': round(dur, 2), 'origin': origin[chosen[k]],
                            'expected_nominal': pose_record(robot, scene, setup, side, q, other)})
            prev = q
        back = transition(geo, side, board, prev, home, home, other)[0]
        metrics = design_metrics(M, names)
        summary[label] = {'candidates': len(poses), 'candidate_stats': stats, 'selected': len(chosen),
                          'selected_near_task': sum(origin[k] == 'near_task' for k in chosen), 'logdet_gain': float(gain),
                          'd_optimal': {k: v for k, v in metrics.items() if k != 'predicted_std_deg'},
                          'random_same_size_mean': {'logdet': float(np.mean([r['logdet'] for r in rand])),
                                                    'joint_block_condition': float(np.mean([r['joint_block_condition'] for r in rand])),
                                                    'predicted_std_joint_rms_deg': float(np.mean([r['predicted_std_joint_rms_deg'] for r in rand]))},
                          'transitions': {k: sum(r['transition_before'] == k for r in records) for k in ['direct', 'via_home', 'unverified']},
                          'return_home': back,
                          'estimated_duration_min': round(total / 60, 1), 'seconds': round(time.time() - t, 1)}
        out[label] = {'setup': setup, 'views': [{'camera': c, 'board': b} for c, b in setup_views(setup, side)],
                      'board_spec': {k: v for k, v in scene['boards'][setup_views(setup, side)[0][1]].items() if k != 'points_m'},
                      'parameters_designed_for': names, 'predicted_std_deg': metrics['predicted_std_deg'], 'poses': records}
        print(side, label, json.dumps(summary[label]), flush=True)
    doc = {'format': 'g1d_calib_pose_list_v1', 'side': side, 'robot_model': str(NOMINAL / 'g1_d_upper_dex1_v4.urdf'),
           'units': 'rad, URDF joint convention = encoder value', 'joint_order': arm_joints(side), 'limit_margin_rad': MARGIN,
           'home': {j: float(v) for j, v in zip(arm_joints(side), home)},
           'hold_fixed': {'other_arm': other, 'waist_lift_head': 'hold at the values recorded at session start; abort if they drift'},
           'motion': {'v_max_rad_s': V_MAX, 'profile': 'joint-space quintic / min-jerk, all joints synchronized',
                      'transition_before': 'direct: joint-space segment checked collision-free (nominal model); via_home: go to home first; '
                                           'unverified: no checked path, operator must jog it slowly or skip the pose'},
           'return_home_after_last': 'see pose_design_summary.json; if not direct, retrace the last poses backwards',
           'settle': SETTLE, 'setups': out,
           'notes': ['Collision model: convex hulls of the nominal URDF, table at the board_setups.py height; re-run with --scene '
                     'after the real board mount and camera intrinsics are known.',
                     'expected_nominal values are predictions of the nominal model; differences of a few px / mm on the real robot are expected.']}
    return doc, summary


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--n', type=int, default=50)
    ap.add_argument('--pool', type=int, default=700)
    ap.add_argument('--scene')
    ap.add_argument('--seed', type=int, default=7)
    a = ap.parse_args()
    scene = nominal_scene()
    if a.scene:
        doc = json.loads(Path(a.scene).read_text())
        scene.update({k: doc[k] for k in ['cameras', 'boards', 'root_link'] if k in doc})
    geo = Geometry(scene)
    robot = Robot(NOMINAL / 'g1_d_upper_dex1_v4.urdf')
    rng = np.random.default_rng(a.seed)
    summary = {}
    for side in ['left', 'right']:
        doc, summary[side] = design(geo, robot, scene, side, a.n, a.pool, rng)
        (HERE / f'poses_{side}.json').write_text(json.dumps(doc, indent=1))
    (HERE / 'pose_design_summary.json').write_text(json.dumps(summary, indent=1))


if __name__ == '__main__':
    main()
