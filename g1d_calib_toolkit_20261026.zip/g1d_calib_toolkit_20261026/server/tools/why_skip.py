# why_skip.py -- per-pose skip diagnosis for the generated pose tables (server, /usr/bin/python3)
import json
import sys

DAY = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/poses"
for side in sys.argv[1:] or ["right"]:
    d = json.load(open(f"{DAY}/poses_{side}.json"))
    print(side, "home:", d["home"])
    for p in d["setups"]["B_wrist_table_board"]["poses"]:
        print(f"  {p['id']} designed={p['transition_before']:10s} actual={str(p.get('transition_actual')):9s} "
              f"pose_clear={p['fk_clearance_cm']:6.1f}cm path_clear={p.get('path_clearance_cm')} skip={p['skip']}")
