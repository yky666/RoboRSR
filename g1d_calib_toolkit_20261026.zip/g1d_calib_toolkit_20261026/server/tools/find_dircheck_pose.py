# find_dircheck_pose.py -- search near the ready pose for a safe direction-check pose per arm
# endpoint + all +-0.05 rad jogs: >= 6 cm from the real table (virtual table raised), self-collision free;
# wrist cam sees >= 30 board corners at 0.22-0.40 m; path from ready collision-free vs the real table.
# server, unitree_sim_env python
import json
import sys
from pathlib import Path

import numpy as np

REALCAM = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
sys.path.insert(0, str(REALCAM))
import board_setups as bs  # noqa: E402
from board_setups import all_frames, visible_corners  # noqa: E402
from calib_model import arm_joints  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
hdr = json.loads((DAY / "poses" / "scene_header_B.json").read_text())
TABLE_Z_REAL = -0.022
bs.TABLE_EDGE_X = 0.15


def make_geo(z):
    bs.TABLE_Z = z
    sc = bs.nominal_scene()
    sc["cameras"] = hdr["cameras"]
    sc["boards"]["table"] = hdr["boards"]["table"]
    return bs.Geometry(sc), sc


geo_real, scene = make_geo(TABLE_Z_REAL)
geo_m6, _ = make_geo(TABLE_Z_REAL + 0.06)
robot = geo_real.robot

READY = [0.3280082345, -0.0444015563, -0.0210323147, -0.2193952054, -0.1763718426, -0.3590713441, -0.1322099715,
         0.1631669253, -0.0210245643, 0.1643322706, -0.1186949760, -0.1611172855, -0.2666637003, -0.2119511217]
ready = {"left": np.array(READY[:7]), "right": np.array(READY[7:])}
T_b = np.array(hdr["boards"]["table"]["T_parent_board"])
centre = T_b[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_b[:3, 3]
SPAN = np.array([0.4, 0.15, 0.3, 0.5, 0.4, 0.5, 0.4])


def full(side, q, other_side, other_q):
    d = {n: float(v) for n, v in zip(arm_joints(other_side), other_q)}
    d.update({n: float(v) for n, v in zip(arm_joints(side), q)})
    return d


def ok_static(geo, side, qd):
    return geo.collision_free(all_frames(robot, qd), side, None, clearance=0.003)


def visible(side, qd):
    qa = {k: np.array([v]) for k, v in qd.items()}
    cam = f"{side}_wrist"
    links = {scene["cameras"][cam]["parent"], scene["boards"]["table"]["parent"]}
    fr = {l: robot.fk(l, qa, {}, scene["root_link"], 1) for l in links}
    uv, mask, Tc, Tb, pts = visible_corners(scene, fr, cam, "table")
    dist = float(np.linalg.norm(centre - Tc[0, :3, 3]))
    return int(mask[0].sum()), dist


rng = np.random.default_rng(3)
plan = {}
for side, other in (("left", "right"), ("right", "left")):
    oq = ready[other]
    print(f"[{side}] ready: m6-clear={ok_static(geo_m6, side, full(side, ready[side], other, oq))} "
          f"real-clear={ok_static(geo_real, side, full(side, ready[side], other, oq))} "
          f"visible={visible(side, full(side, ready[side], other, oq))}", flush=True)
    best = None
    for k in range(6000):
        dq = rng.uniform(-1, 1, 7) * SPAN
        q = ready[side] + dq
        cost = float(np.abs(dq).max())
        if best is not None and cost >= best[0]:
            continue
        qd = full(side, q, other, oq)
        n, dist = visible(side, qd)
        if n < 30 or not (0.22 <= dist <= 0.40):
            continue
        if not ok_static(geo_m6, side, qd):
            continue
        jog_ok = True
        for j in range(7):
            for s in (-0.05, 0.05):
                qj = q.copy(); qj[j] += s
                if not ok_static(geo_m6, side, full(side, qj, other, oq)):
                    jog_ok = False; break
            if not jog_ok:
                break
        if not jog_ok:
            continue
        path_ok = all(ok_static(geo_real, side, full(side, ready[side] + t * dq, other, oq))
                      for t in np.linspace(0, 1, 31)[1:])
        if not path_ok:
            continue
        best = (cost, q, n, dist)
    if best is None:
        plan[side] = None
        print(f"[{side}] no pose found", flush=True)
        continue
    plan[side] = {"joints": {n: round(float(v), 5) for n, v in zip(arm_joints(side), best[1])},
                  "max_move_from_ready_rad": round(best[0], 3), "visible_corners": best[2],
                  "cam_to_board_m": round(best[3], 3)}
    print(f"[{side}] dircheck pose: max move {best[0]:.3f} rad, corners {best[2]}, dist {best[3]:.3f} m", flush=True)
    print("   ", plan[side]["joints"], flush=True)

plan["ready"] = {s: {n: float(v) for n, v in zip(arm_joints(s), ready[s])} for s in ready}
(DAY / "poses" / "dircheck_plan.json").write_text(json.dumps(plan, indent=1))
print("[done]")
