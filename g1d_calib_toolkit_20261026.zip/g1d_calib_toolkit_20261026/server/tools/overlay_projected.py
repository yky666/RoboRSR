# overlay_projected.py -- head_left overlays without IsaacSim: rasterize the arm URDF meshes (shoulder_roll..wrist_yaw)
# of each URDF variant with calib_model FK, draw the outlines on the undistorted real head_left frame of a session
# (agrees with the IsaacSim render to IoU ~0.9, see project_mesh_masks.py)
# usage: overlay_projected.py <out_dir> <session_dir> <intrinsics_head_left.json> <contract.json> <side> <every>
#                             tag=urdf[=B,G,R] ...
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402

OUT, SES = Path(sys.argv[1]), Path(sys.argv[2])
intr = json.loads(Path(sys.argv[3]).read_text())
K, dist = np.array(intr["K"], float), np.array(intr["dist"], float)
W, H = [int(x) for x in intr["resolution"]]
cam = {v["name"]: v for v in json.loads(Path(sys.argv[4]).read_text())["views"]}["head_left"]
side, every = sys.argv[5], int(sys.argv[6])
DEFAULT_COL = [(0, 0, 255), (0, 200, 0), (255, 140, 0), (0, 200, 255)]
variants = []
for k, arg in enumerate(sys.argv[7:]):
    parts = arg.split("=")
    col = tuple(int(c) for c in parts[2].split(",")) if len(parts) > 2 else DEFAULT_COL[k % 4]
    variants.append((parts[0], parts[1], col))
ARM_LINKS = [f"{side}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch",
                                          "wrist_yaw")]
ALLJ = arm_joints("left") + arm_joints("right")
OUT.mkdir(parents=True, exist_ok=True)


def stl(path):
    b = Path(path).read_bytes()
    n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
    rec = np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)
    return rec["v"].astype(np.float64)


def meshes(urdf):
    out = {}
    for link in ET.parse(urdf).getroot().findall("link"):
        if link.get("name") in ARM_LINKS:
            for vis in link.findall("visual"):
                out[link.get("name")] = stl(Path(urdf).parent / vis.find("geometry/mesh").get("filename"))
    return out


def arm_mask(robot, mesh, qa):
    Tc = robot.fk(cam["parent"], qa, {}, None, 1)[0] @ np.array(cam["T_parent_camera_world_convention"])
    mask = np.zeros((H, W), np.uint8)
    for ln, tri in mesh.items():
        T = robot.fk(ln, qa, {}, None, 1)[0]
        v = tri.reshape(-1, 3) @ T[:3, :3].T + T[:3, 3]
        pc = (v - Tc[:3, 3]) @ Tc[:3, :3] @ OPTICAL_FROM_CAMERA.T
        ok = (pc[:, 2] > 0.02).reshape(-1, 3).all(1)
        uv = np.stack([K[0, 0] * pc[:, 0] / pc[:, 2] + K[0, 2], K[1, 1] * pc[:, 1] / pc[:, 2] + K[1, 2]], 1)
        cv2.fillPoly(mask, [np.round(t * 8).astype(np.int32) for t in uv.reshape(-1, 3, 2)[ok]], 255, shift=3)
    return mask


models = [(tag, Robot(Path(u)), meshes(u), col) for tag, u, col in variants]
samples = [json.loads(l) for l in open(SES / "samples.jsonl") if l.strip()][::every]
crops = []
for s in samples:
    pid = s["pose_id"]
    f = SES / "images" / pid / "head_stereo.png"
    if not f.exists():
        continue
    st = cv2.imread(str(f))
    und = cv2.undistort(st[:, : st.shape[1] // 2], K, dist, None, K)
    qa = {n: np.array([float(s["joints_before"]["q"].get(n, 0.0))]) for n in ALLJ}
    box = None
    for tag, robot, mesh, col in models:
        m = arm_mask(robot, mesh, qa)
        if m.sum() < 300 * 255:
            continue
        cs, _ = cv2.findContours((m > 127).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        cv2.drawContours(und, cs, -1, col, 1)
        x, y, w, h = cv2.boundingRect((m > 127).astype(np.uint8))
        box = (x, y, x + w, y + h) if box is None else (min(box[0], x), min(box[1], y), max(box[2], x + w),
                                                         max(box[3], y + h))
    for k, (tag, _, _, col) in enumerate(models):
        cv2.putText(und, tag, (8, 18 + 18 * k), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 1)
    cv2.putText(und, pid, (8, H - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.imwrite(str(OUT / f"ov_{pid}.png"), und)
    if box is not None:
        x0, y0, x1, y1 = max(0, box[0] - 25), max(0, box[1] - 25), min(W, box[2] + 25), min(H, box[3] + 25)
        c = und[y0:y1, x0:x1]
        crops.append(cv2.resize(c, (int(c.shape[1] * 240 / c.shape[0]), 240), interpolation=cv2.INTER_CUBIC))
# montage of the arm crops
rows, row, wsum, WM = [], [], 0, 1500
for c in crops:
    if row and wsum + c.shape[1] > WM:
        rows.append(row); row, wsum = [], 0
    row.append(c); wsum += c.shape[1]
if row:
    rows.append(row)
lines = []
for r in rows:
    line = np.hstack(r)[:, :WM]
    lines.append(np.hstack([line, np.zeros((240, WM - line.shape[1], 3), np.uint8)]))
legend = np.zeros((36, WM, 3), np.uint8)
for k, (tag, _, _, col) in enumerate(models):
    cv2.putText(legend, tag, (10 + 360 * k, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, col, 2)
if lines:
    cv2.imwrite(str(OUT / "montage.png"), np.vstack([legend] + lines))
print("written", len(crops), "crops ->", OUT / "montage.png")
