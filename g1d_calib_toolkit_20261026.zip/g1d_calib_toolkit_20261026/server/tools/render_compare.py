# render_compare.py -- head_left view of several URDF variants posed at the recorded joint angles of a real session
# (Isaac Lab, same stack/settings as render_isaaclab.py). Variants are spawned SPACING m apart (overlapping
# articulations interact and fly apart); each is rendered alone, with the camera on its own head, by toggling
# visibility: "full" (everything except the head shell) and "arm" (left arm shoulder_roll..wrist_yaw only, no
# gripper -- the URDF gripper differs from the real one).
# outputs per pose: real_<pid>.png (head_left half, raw), sim_<variant>_<full|arm>_<pid>.png, mask_<variant>_arm_<pid>.png
import argparse
import json
import os

import numpy as np
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--out", required=True)
parser.add_argument("--session", required=True)
parser.add_argument("--variants", required=True, help="tag=urdf,tag=urdf,...")
parser.add_argument("--every", type=int, default=5)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.enable_cameras = True
args.headless = True
app = AppLauncher(args).app

import cv2
import torch
from pxr import Usd, UsdGeom, UsdLux
from scipy.spatial.transform import Rotation

import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import Articulation, ArticulationCfg
from isaaclab.sensors import Camera, CameraCfg
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg

ROOT = "/root/unitree_sim_isaaclab/real2sim_calib_20261015"
CONTRACT = f"{ROOT}/assembled_calib_20261016/camera_contract_v5.json"
INTR = f"{ROOT}/real_data/20261016/intrinsics"
USD_DIR = "/dev/shm/isaac_work/usd_conv_cmp"
CAM = "head_left"
ARM_SIDE = os.environ.get("ARM_SIDE", "left")         # which arm the "arm" render / metric uses
ARM_LINKS = [f"{ARM_SIDE}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch",
                                              "wrist_yaw")]
os.makedirs(args.out, exist_ok=True)
os.makedirs(USD_DIR, exist_ok=True)

variants = [tuple(v.split("=", 1)) for v in args.variants.split(",")]
samples = [json.loads(l) for l in open(f"{args.session}/samples.jsonl") if l.strip()]
samples = [s for s in samples if os.path.exists(f"{args.session}/images/{s['pose_id']}/head_stereo.png")]
samples = samples[::args.every]
print(f"[poses] {[s['pose_id'] for s in samples]}", flush=True)

dt = 1.0 / 120.0
sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=dt, device=args.device, use_fabric=False,
                                                          gravity=(0.0, 0.0, 0.0)))
stage = sim.stage
SPACING = 5.0
robots = {}
for k, (tag, urdf) in enumerate(variants):
    conv = UrdfConverter(UrdfConverterCfg(
        asset_path=urdf, usd_dir=USD_DIR, usd_file_name=f"g1d_{tag}.usd",
        fix_base=True, merge_fixed_joints=False, force_usd_conversion=True, make_instanceable=False,
        joint_drive=UrdfConverterCfg.JointDriveCfg(
            gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
    robots[tag] = Articulation(ArticulationCfg(
        prim_path=f"/World/Robot_{tag}",
        spawn=sim_utils.UsdFileCfg(
            usd_path=conv.usd_path,
            rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
            articulation_props=sim_utils.ArticulationRootPropertiesCfg(enabled_self_collisions=False)),
        init_state=ArticulationCfg.InitialStateCfg(pos=(0.0, SPACING * k, 0.0)),
        actuators={"all": ImplicitActuatorCfg(joint_names_expr=[".*"], stiffness=2000., damping=100.)}))
    print(f"[usd] {tag}: {conv.usd_path}", flush=True)

UsdLux.DomeLight.Define(stage, "/World/Light").CreateIntensityAttr(750.0)
mount = {v["name"]: v for v in json.load(open(CONTRACT))["views"]}[CAM]
doc = json.load(open(f"{INTR}/camera_intrinsics_{CAM}.json"))
K = np.array(doc["K"], dtype=float)
W, H = [int(x) for x in doc["resolution"]]
cam = Camera(CameraCfg(
    prim_path=f"/World/Cam_{CAM}", width=W, height=H, data_types=["rgb", "distance_to_image_plane"],
    update_latest_camera_pose=True,
    spawn=sim_utils.PinholeCameraCfg.from_intrinsic_matrix(intrinsic_matrix=K.flatten().tolist(), width=W, height=H,
                                                           focal_length=24.0, clipping_range=(0.01, 20.0))))
sim.reset()

# principal point via USD aperture offsets (verified with probes in render_isaaclab.py)
prim = stage.GetPrimAtPath(f"/World/Cam_{CAM}")
hap, vap = 24.0 * W / K[0, 0], 24.0 * H / K[1, 1]
prim.GetAttribute("focalLength").Set(24.0)
prim.GetAttribute("horizontalAperture").Set(float(hap))
prim.GetAttribute("verticalAperture").Set(float(vap))
prim.GetAttribute("horizontalApertureOffset").Set(float((W / 2.0 - K[0, 2]) * hap / W))
prim.GetAttribute("verticalApertureOffset").Set(float((K[1, 2] - H / 2.0) * vap / H))

# visuals per robot: head shell always hidden; per-link lists for the arm-only render
vis = {tag: {} for tag in robots}
for tag in robots:
    for p in Usd.PrimRange(stage.GetPrimAtPath(f"/World/Robot_{tag}")):
        if p.GetName() == "visuals":
            vis[tag].setdefault(p.GetParent().GetName(), []).append(p)
    for p in vis[tag].get("head_link", []):
        UsdGeom.Imageable(p).MakeInvisible()


def show(tag_on, mode):
    for tag in robots:
        for link, prims in vis[tag].items():
            on = tag == tag_on and link != "head_link" and (mode == "full" or link in ARM_LINKS)
            for p in prims:
                (UsdGeom.Imageable(p).MakeVisible if on else UsdGeom.Imageable(p).MakeInvisible)()


def pose_T(s):
    s = s.detach().cpu().numpy()
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix()
    T[:3, 3] = s[:3]
    return T


cam_on = [variants[0][0]]


def mount_camera():
    ref = robots[cam_on[0]]
    parent = pose_T(ref.data.body_link_state_w[0, ref.body_names.index(mount["parent"]), :7])
    T = parent @ np.array(mount["T_parent_camera_world_convention"], dtype=float)
    xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
    cam.set_world_poses(torch.tensor([T[:3, 3].tolist()], device=args.device),
                        torch.tensor([xyzw[[3, 0, 1, 2]].tolist()], device=args.device), convention="world")


def run_frames(n, targets):
    for _ in range(n):
        for tag, r in robots.items():
            r.set_joint_position_target(targets[tag])
            r.write_data_to_sim()
        sim.step(render=True)
        for r in robots.values():
            r.update(dt)
        mount_camera()
        cam.update(dt)


report = {"variants": dict(variants), "poses": []}
for s in samples:
    pid = s["pose_id"]
    qd = s["joints_before"]["q"]
    targets = {}
    for tag, r in robots.items():
        q = r.data.default_joint_pos.clone()
        lims = r.data.soft_joint_pos_limits[0].cpu().numpy()
        for i, jn in enumerate(r.joint_names):
            q[0, i] = float(qd[jn]) if jn in qd else float(lims[i, 0])     # grippers at the lower (open) limit
        r.write_joint_state_to_sim(q, torch.zeros_like(q))
        targets[tag] = q
    run_frames(30, targets)
    qerr = max((r.data.joint_pos[0] - targets[t][0]).abs().max().item() for t, r in robots.items())
    if not report["poses"]:
        for tag, r in robots.items():
            err = (r.data.joint_pos[0] - targets[tag][0]).abs().cpu().numpy()
            bad = [(jn, round(float(targets[tag][0, i]), 4), round(float(r.data.joint_pos[0, i]), 4))
                   for i, jn in enumerate(r.joint_names) if err[i] > 1e-3]
            print(f"[joints] {tag}: {len(r.joint_names)} joints; off target: {bad}", flush=True)
    img = cv2.imread(f"{args.session}/images/{pid}/head_stereo.png")
    cv2.imwrite(f"{args.out}/real_{pid}.png", img[:, : img.shape[1] // 2])
    for tag in robots:
        cam_on[0] = tag
        for mode in ("full", "arm"):
            show(tag, mode)
            run_frames(12, targets)
            rgb = cam.data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
            dep = cam.data.output["distance_to_image_plane"][0].cpu().numpy().squeeze()
            mask = np.isfinite(dep) & (dep > 0) & (dep < 5.0)
            cv2.imwrite(f"{args.out}/sim_{tag}_{mode}_{pid}.png", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
            cv2.imwrite(f"{args.out}/mask_{tag}_{mode}_{pid}.png", (mask * 255).astype(np.uint8))
    report["poses"].append({"pose": pid, "q_err_max_rad": qerr})
    print(f"[pose] {pid} q_err {qerr:.1e}", flush=True)

json.dump(report, open(f"{args.out}/render_report.json", "w"), indent=1)
print("[done]", flush=True)
os._exit(0)  # app.close() hangs on shutdown in this env and keeps the GPU busy
