# make_compare_video.py -- side-by-side video: real head_left frame (undistorted) with the IsaacSim render of the
# nominal URDF (left) and the calibrated URDF (right) blended over it; the blend pulses so misalignment is visible
# usage: make_compare_video.py <render_out_dir> <camera_intrinsics_head_left.json> <out.mp4> [--zoom]
#   --zoom: each pose is cropped to the left arm (union of both variants' arm masks + margin, 4:3) and enlarged
import json
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

OUT = Path(sys.argv[1])
intr = json.load(open(sys.argv[2]))
dst = Path(sys.argv[3])
K, dist = np.array(intr["K"], float), np.array(intr["dist"], float)
rep = json.load(open(OUT / "render_report.json"))
metric = {r["pose"]: r for r in json.load(open(OUT / "compare_report.json"))["per_pose"]}
RIGHT = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--right=")), "dual_trans")
ARM = next((a.split("=", 1)[1] for a in sys.argv if a.startswith("--arm=")), "left")
PANELS = (("nominal", "nominal URDF", (0, 0, 255)), (RIGHT, f"calibrated URDF ({RIGHT})", (0, 200, 0)))
FPS, SECONDS, PERIOD, SCALE = 30, 3.0, 1.5, 1.5
ZOOM = "--zoom" in sys.argv


def arm_box(pid, margin=40):
    """4:3 box around both variants' left-arm masks"""
    m = sum((cv2.imread(str(OUT / f"mask_{t}_arm_{pid}.png"), 0) > 127).astype(np.uint8) for t, _, _ in PANELS)
    x, y, w, h = cv2.boundingRect((m > 0).astype(np.uint8))
    cx, cy = x + w / 2, y + h / 2
    w, h = w + 2 * margin, h + 2 * margin
    w, h = max(w, h * 4 / 3), max(h, w * 3 / 4)
    w, h = min(w, 640), min(h, 480)
    x0 = int(np.clip(cx - w / 2, 0, 640 - w)); y0 = int(np.clip(cy - h / 2, 0, 480 - h))
    return x0, y0, int(w), int(h)

poses = [p["pose"] for p in rep["poses"] if all(metric.get(p["pose"], {}).get(t) is not None for t, _, _ in PANELS)]
tmp = dst.with_suffix(".raw.avi")
H0, W0 = 480, 640
Wv, Hv = int(2 * W0 * SCALE), int((H0 + 60) * SCALE)
vw = cv2.VideoWriter(str(tmp), cv2.VideoWriter_fourcc(*"MJPG"), FPS, (Wv, Hv))


def text(img, s, org, col, scale=0.8, th=2):
    cv2.putText(img, s, org, cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), th + 3)
    cv2.putText(img, s, org, cv2.FONT_HERSHEY_SIMPLEX, scale, col, th)


title = np.zeros((Hv, Wv, 3), np.uint8)
for k, (s, c) in enumerate(((f"G1-D {ARM} arm, head_left camera: real image vs IsaacSim render", (255, 255, 255)),
                            ("left: nominal URDF (red)    right: calibrated URDF (green)", (255, 255, 255)),
                            (f"the render pulses on/off; outline = {ARM} arm (gripper excluded, URDF gripper differs)",
                             (200, 200, 200)),
                            ("number = median distance from the arm outline to real image edges (px, lower is better)",
                             (200, 200, 200)))):
    text(title, s, (40, 120 + 70 * k), c, 1.0 if k < 2 else 0.8)
for _ in range(int(2.5 * FPS)):
    vw.write(title)

for pid in poses:
    real = cv2.undistort(cv2.imread(str(OUT / f"real_{pid}.png")), K, dist, None, K).astype(np.float32)
    layers = []
    for tag, name, col in PANELS:
        sim = cv2.imread(str(OUT / f"sim_{tag}_full_{pid}.png")).astype(np.float32)
        full = cv2.imread(str(OUT / f"mask_{tag}_full_{pid}.png"), 0) > 127
        arm = (cv2.imread(str(OUT / f"mask_{tag}_arm_{pid}.png"), 0) > 127).astype(np.uint8)
        tint = 0.55 * sim + 0.45 * np.array(col, np.float32)
        cs, _ = cv2.findContours(arm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        layers.append((tint, full, cs, name, col, metric[pid][tag]))
    box = arm_box(pid) if ZOOM else None
    for f in range(int(SECONDS * FPS)):
        a = 0.7 * (0.5 - 0.5 * np.cos(2 * np.pi * f / (PERIOD * FPS)))
        row = []
        for tint, full, cs, name, col, m in layers:
            p = real.copy()
            p[full] = (1 - a) * real[full] + a * tint[full]
            p = p.astype(np.uint8)
            cv2.drawContours(p, cs, -1, col, 1)
            if ZOOM:
                x0, y0, w, h = box
                p = cv2.resize(p[y0:y0 + h, x0:x0 + w], (W0, H0), interpolation=cv2.INTER_CUBIC)
            hdr = np.zeros((60, W0, 3), np.uint8)
            text(hdr, f"{name}: {m:.1f} px", (10, 40), col, 0.75)
            row.append(np.vstack([hdr, p]))
        frame = np.hstack(row)
        text(frame, pid, (W0 * 2 - 150, H0 + 45), (255, 255, 255), 0.7)
        vw.write(cv2.resize(frame, (Wv, Hv), interpolation=cv2.INTER_LINEAR))
vw.release()

subprocess.check_call(["ffmpeg", "-y", "-loglevel", "error", "-i", str(tmp), "-c:v", "libx264", "-pix_fmt", "yuv420p",
                       "-crf", "20", str(dst)])
gif = dst.with_suffix(".gif")
subprocess.check_call(["ffmpeg", "-y", "-loglevel", "error", "-i", str(tmp), "-vf",
                       "fps=12,scale=960:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse",
                       str(gif)])
tmp.unlink()
print("poses:", poses)
print("written", dst, dst.stat().st_size, "bytes;", gif, gif.stat().st_size, "bytes")
