# estimate_wrist_extrinsic.py -- bootstrap the wrist camera mounting from collected samples:
# T_parent_cam = inv(T_torso_parent(q)) @ T_torso_board(measured) @ inv(T_cam_board(PnP))
# compares with camera_contract_v5 nominal.  usage: estimate_wrist_extrinsic.py <session_dir> [more ...]
# server, /usr/bin/python3
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, OPTICAL_FROM_CAMERA, Robot, inv  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
hdr = json.loads((DAY / "poses" / "scene_header_B.json").read_text())
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
T_tb = np.array(hdr["boards"]["table"]["T_parent_board"])
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
det = cv2.aruco.CharucoDetector(board)
OBJ = board.getChessboardCorners()
C2O = np.eye(4); C2O[:3, :3] = OPTICAL_FROM_CAMERA.T      # optical -> camworld

results = {}
for sd in map(Path, sys.argv[1:]):
    for line in open(sd / "samples.jsonl"):
        r = json.loads(line)
        for cam, frames in r["frames"].items():
            if not cam.endswith("wrist"):
                continue
            c = hdr["cameras"][cam]
            K, dist = np.array(c["K"]), np.array(c["dist"])
            img = cv2.imread(str(sd / frames[0]["file"]), cv2.IMREAD_GRAYSCALE)
            cc, ci, _, _ = det.detectBoard(img)
            if ci is None or len(ci) < 6:
                print(f"{r['id']} {cam}: {0 if ci is None else len(ci)} corners, skip"); continue
            obj = OBJ[ci.ravel()].astype(np.float64); imgp = cc.reshape(-1, 2).astype(np.float64)
            ok, rv, tv = cv2.solvePnP(obj, imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
            ok, rv, tv = cv2.solvePnP(obj, imgp, K, dist, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
            proj, _ = cv2.projectPoints(obj, rv, tv, K, dist)
            rms = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - imgp) ** 2, 1))))
            T_ob = np.eye(4); T_ob[:3, :3] = cv2.Rodrigues(rv)[0]; T_ob[:3, 3] = tv.ravel()   # board -> optical
            T_cb = C2O @ T_ob                                                                 # board -> camworld
            q = {k: np.array([v]) for k, v in r["joints_before"]["q"].items()}
            T_tp = robot.fk(c["parent"], q, {}, None, 1)[0]
            T_pc = inv(T_tp) @ T_tb @ inv(T_cb)
            T_nom = np.array(c["T_parent_camera"])
            dR = Rotation.from_matrix(T_nom[:3, :3].T @ T_pc[:3, :3])
            dt = (T_pc[:3, 3] - T_nom[:3, 3]) * 1000
            results.setdefault(cam, []).append({"id": r["id"], "n": int(len(ci)), "rms": rms,
                                                "rotvec_deg": np.degrees(dR.as_rotvec()).tolist(), "dt_mm": dt.tolist(),
                                                "T_parent_cam": T_pc.tolist()})
            print(f"{r['id']} {cam}: n={len(ci):2d} pnp rms {rms:.2f}px | camera vs nominal: "
                  f"rot {np.degrees(dR.magnitude()):5.1f} deg rotvec(cam axes)={np.round(np.degrees(dR.as_rotvec()), 1).tolist()} "
                  f"dt={np.round(dt, 0).tolist()} mm")
for cam, rows in results.items():
    rv = np.array([x["rotvec_deg"] for x in rows]); dt = np.array([x["dt_mm"] for x in rows])
    print(f"[{cam}] {len(rows)} samples: rotvec mean {np.round(rv.mean(0), 1).tolist()} std {np.round(rv.std(0), 1).tolist()} deg | "
          f"dt mean {np.round(dt.mean(0), 0).tolist()} std {np.round(dt.std(0), 0).tolist()} mm")
json.dump(results, open(DAY / "poses" / "wrist_extrinsic_bootstrap.json", "w"), indent=1)
