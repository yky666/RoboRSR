# compose_params.py -- one g1d_calib_params_v1 file RELATIVE TO THE NOMINAL URDF that reproduces a calibrated URDF built
# in stages (e.g. dual_trans + contour mount deltas): per joint, solve the joint parameters whose origin equals the final
# URDF origin; camera:/intrinsics: deltas are copied from a source params file. Verified by FK on random joint vectors.
# usage: compose_params.py <final_urdf> <camera_params_src.json> <out.json>
# calib_model.py is imported from env G1D_CALIB_PKG (the calibration package dir; on the GPU server
# /root/unitree_sim_isaaclab/real2sim_calib_20261015), default: ../g1d_calib_20261015 next to this tools/ dir.
import json
import os
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

sys.path.insert(0, os.environ.get("G1D_CALIB_PKG", str(Path(__file__).resolve().parent.parent / "g1d_calib_20261015")))
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

final_urdf, src, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
nom, fin = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf"), Robot(final_urdf)
src_doc = json.loads(src.read_text())


def err(T, T_ref):
    return np.concatenate([Rotation.from_matrix(T_ref[:3, :3].T @ T[:3, :3]).as_rotvec(), T[:3, 3] - T_ref[:3, 3]])


values = {}
for j in nom.joints:
    if j not in fin.joints:
        continue
    T_ref, T0 = fin.origin(j, {}), nom.origin(j, {})
    if np.abs(err(T0, T_ref)).max() < 1e-12:
        continue
    keys = list(nom.param_keys(j))
    r = least_squares(lambda x: err(nom.origin(j, {f"{j}/{k}": v for k, v in zip(keys, x)}), T_ref),
                      np.zeros(len(keys)), xtol=1e-15, ftol=1e-15, gtol=1e-15)
    res = np.abs(err(nom.origin(j, {f"{j}/{k}": v for k, v in zip(keys, r.x)}), T_ref)).max()
    assert res < 1e-9, f"{j}: cannot reproduce the final origin ({res:.2e})"
    for k, v in zip(keys, r.x):
        if abs(v) > 1e-12:
            values[f"{j}/{k}"] = float(v)
for k, v in src_doc["values"].items():
    if k.startswith(("camera:", "intrinsics:")):
        values[k] = float(v)

P = {k: v for k, v in values.items() if ":" not in k.split("/")[0]}
ALLJ = arm_joints("left") + arm_joints("right")
rng = np.random.default_rng(0)
worst = 0.0
for _ in range(20):
    qa = {n: np.array([rng.uniform(-1, 1)]) for n in ALLJ}
    for ln in ("left_dex1_base_link", "right_dex1_base_link", "left_elbow_link", "right_elbow_link", "head_link"):
        a, b = nom.fk(ln, qa, P, None, 1)[0], fin.fk(ln, qa, {}, None, 1)[0]
        worst = max(worst, np.abs(a - b).max())
print(f"{len(values)} values; max |FK(nominal + params) - FK(final URDF)| = {worst:.2e}")
assert worst < 1e-9
doc = {"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": True,
       "description": f"Composed relative to the nominal URDF from {final_urdf} (joint origins) and {src.name} (camera / intrinsics deltas).",
       "convention": "q_model = q_encoder + zero (radians)", "values": values,
       "values_deg_for_reading": {k: round(float(np.degrees(v)), 4) for k, v in values.items()
                                  if k.split("/")[-1] in ("zero", "rot_u", "rot_v", "rx", "ry", "rz")},
       "sources": {"final_urdf": str(final_urdf), "camera_params": str(src)}}
out.write_text(json.dumps(doc, indent=2))
print("written", out)
