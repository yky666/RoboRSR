# limits_check.py -- what the sim asset says about joint limits and self-collision
# usage: limits_check.py <asset_dir>
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

A = Path(sys.argv[1])
root = ET.parse(A / "g1_d_upper_dex1_v4.urdf").getroot()
print("root links:", [l.get("name") for l in root.findall("link")][:4], "...")
print("links that are not arm / hand / head:",
      [l.get("name") for l in root.findall("link") if not re.match(r"(left|right)_|head|logo", l.get("name"))])
for j in root.findall("joint"):
    lim = j.find("limit")
    if j.get("type") == "revolute" and lim is not None and re.match(r"(left|right)_(shoulder|elbow|wrist)", j.get("name")):
        lo, hi = float(lim.get("lower")), float(lim.get("upper"))
        print(f"  {j.get('name'):28s} [{lo:+.3f}, {hi:+.3f}] rad = [{lo * 57.2958:+7.1f}, {hi * 57.2958:+7.1f}] deg"
              f"  effort {lim.get('effort')}  velocity {lim.get('velocity')}")
pc = json.loads((A / "physics_contract.json").read_text())


def find(d, path=""):
    if isinstance(d, dict):
        for k, v in d.items():
            p = f"{path}/{k}"
            if re.search(r"self|collision|filter|limit|stiff|damp|drive", k, re.I) and not isinstance(v, (dict, list)):
                print(f"  physics_contract{p} = {v}")
            find(v, p)
    elif isinstance(d, list):
        for i, v in enumerate(d[:3]):
            find(v, f"{path}[{i}]")


find(pc)
