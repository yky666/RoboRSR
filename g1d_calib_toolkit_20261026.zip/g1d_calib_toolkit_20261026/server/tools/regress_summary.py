# regress_summary.py -- summarize usd_compare_vs_nominal.json (attributes that differ) and source_validation.json
# (which checks fail) of a calibrated asset
# usage: regress_summary.py <asset_dir>
import collections
import json
import sys
from pathlib import Path

A = Path(sys.argv[1])
cmp_ = json.loads((A / "usd_compare_vs_nominal.json").read_text())
by_attr = collections.Counter(d["attr"] for d in cmp_["differences"])
print("usd differences by attribute:", dict(by_attr))
inert = [d for d in cmp_["differences"] if d["attr"].endswith("JointEquivalentInertia")]
if inert:
    rel = max(abs(float(d["new"]) - float(d["v4"])) / abs(float(d["v4"])) for d in inert)
    print(f"  JointEquivalentInertia max relative change {rel:.2e} over {len(inert)} joints")
other = [k for k in cmp_ if k not in ("differences",)]
print("compare keys:", {k: cmp_[k] for k in other if not isinstance(cmp_[k], (list, dict))})
src = json.loads((A / "source_validation.json").read_text())
fails = [k for k, v in src["checks"].items() if not v]
print(f"source_validation: {len(fails)} failing checks; all are joints: {all(k.endswith('_joint') for k in fails)}")
print("  failing:", fails)
print("  mesh/link checks all ok:", all(v for k, v in src["checks"].items() if not k.endswith("_joint")))
