# project_mesh_masks.py -- render-free check: rasterize the left-arm URDF meshes (shoulder_roll .. wrist_yaw links)
# with calib_model FK into head_left, and compare with the IsaacSim masks of render_compare.py
# usage: project_mesh_masks.py <render_out_dir> <session_dir> <intrinsics_head_left.json> <contract.json> tag=urdf ...
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402

OUT, SES = Path(sys.argv[1]), Path(sys.argv[2])
intr = json.loads(Path(sys.argv[3]).read_text())
K = np.array(intr["K"], float)
W, H = [int(x) for x in intr["resolution"]]
cam = {v["name"]: v for v in json.loads(Path(sys.argv[4]).read_text())["views"]}["head_left"]
variants = [a.split("=", 1) for a in sys.argv[5:]]
ARM_LINKS = [f"left_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch",
                                         "wrist_yaw")]
ALLJ = arm_joints("left") + arm_joints("right")


def stl(path):
    b = Path(path).read_bytes()
    n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
    rec = np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)
    return rec["v"].astype(np.float64)                    # (n, 3, 3)


def meshes(urdf):
    root = ET.parse(urdf).getroot()
    out = {}
    for link in root.findall("link"):
        if link.get("name") not in ARM_LINKS:
            continue
        for vis in link.findall("visual"):
            m = vis.find("geometry/mesh")
            o = vis.find("origin")
            assert o is None or (o.get("xyz", "0 0 0").split() == ["0", "0", "0"] or
                                 np.allclose([float(x) for x in o.get("xyz").split()], 0)), "visual origin not zero"
            out[link.get("name")] = stl(Path(urdf).parent / m.get("filename"))
    return out


samples = {json.loads(l)["pose_id"]: json.loads(l) for l in open(SES / "samples.jsonl") if l.strip()}
rep = json.loads((OUT / "render_report.json").read_text())
for tag, urdf in variants:
    robot, mesh = Robot(Path(urdf)), meshes(urdf)
    res = []
    for p in rep["poses"]:
        pid = p["pose"]
        qa = {n: np.array([float(samples[pid]["joints_before"]["q"].get(n, 0.0))]) for n in ALLJ}
        Tc = robot.fk(cam["parent"], qa, {}, None, 1)[0] @ np.array(cam["T_parent_camera_world_convention"])
        mask = np.zeros((H, W), np.uint8)
        for ln, tri in mesh.items():
            T = robot.fk(ln, qa, {}, None, 1)[0]
            v = tri.reshape(-1, 3) @ T[:3, :3].T + T[:3, 3]
            pc = (v - Tc[:3, 3]) @ Tc[:3, :3] @ OPTICAL_FROM_CAMERA.T
            ok = pc[:, 2] > 0.02
            uv = np.stack([K[0, 0] * pc[:, 0] / pc[:, 2] + K[0, 2], K[1, 1] * pc[:, 1] / pc[:, 2] + K[1, 2]], 1)
            uv, ok = uv.reshape(-1, 3, 2), ok.reshape(-1, 3).all(1)
            cv2.fillPoly(mask, [np.round(t * 8).astype(np.int32) for t in uv[ok]], 255, shift=3)
        cv2.imwrite(str(OUT / f"proj_{tag}_arm_{pid}.png"), mask)
        r = cv2.imread(str(OUT / f"mask_{tag}_arm_{pid}.png"), 0) > 127
        m = mask > 127
        iou = (r & m).sum() / max(1, (r | m).sum())
        dx = dy = None
        if r.sum() > 300 and m.sum() > 300:
            ry, rx = np.nonzero(r); my, mx = np.nonzero(m)
            dx, dy = mx.mean() - rx.mean(), my.mean() - ry.mean()
        res.append(iou)
        print(f"{tag:12s} {pid}: IoU(projected, IsaacSim) {iou:.3f}  centroid diff "
              f"{None if dx is None else (round(dx, 1), round(dy, 1))} px  (pixels {m.sum()} vs {r.sum()})")
    print(f"{tag}: median IoU {np.median(res):.3f}")
