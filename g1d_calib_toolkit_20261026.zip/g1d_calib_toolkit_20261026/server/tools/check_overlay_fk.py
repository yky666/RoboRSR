# check_overlay_fk.py -- independent check of the render overlays: project arm joint centres with calib_model FK
# (nominal vs calibrated params) into the undistorted head_left image and compare with the rendered masks
# usage: check_overlay_fk.py <render_out_dir> <session_dir> <params.json> <intrinsics_head_left.json> <contract.json>
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402

OUT, SES = Path(sys.argv[1]), Path(sys.argv[2])
P_CAL = {k: float(v) for k, v in json.loads(Path(sys.argv[3]).read_text())["values"].items()
         if "/" in k and ":" not in k.split("/")[0]}
intr = json.loads(Path(sys.argv[4]).read_text())
K, dist = np.array(intr["K"], float), np.array(intr["dist"], float)
cam = {v["name"]: v for v in json.loads(Path(sys.argv[5]).read_text())["views"]}["head_left"]
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
ALLJ = arm_joints("left") + arm_joints("right")
LINKS = ["left_elbow_link", "left_wrist_roll_link", "left_wrist_pitch_link", "left_wrist_yaw_link",
         "left_dex1_base_link"]
COL = {"nominal": (0, 0, 255), "calibrated": (0, 200, 0)}
samples = {json.loads(l)["pose_id"]: json.loads(l) for l in open(SES / "samples.jsonl") if l.strip()}
rep = json.loads((OUT / "render_report.json").read_text())
print(f"head_left fx {K[0, 0]:.1f} fy {K[1, 1]:.1f} cx {K[0, 2]:.1f} cy {K[1, 2]:.1f}")


def project(qd, params):
    qa = {n: np.array([float(qd.get(n, 0.0))]) for n in ALLJ}
    Tc = robot.fk(cam["parent"], qa, params, None, 1)[0] @ np.array(cam["T_parent_camera_world_convention"])
    pts = {}
    for ln in LINKS:
        p = robot.fk(ln, qa, params, None, 1)[0][:3, 3]
        pc = OPTICAL_FROM_CAMERA @ (Tc[:3, :3].T @ (p - Tc[:3, 3]))
        pts[ln] = (K[0, 0] * pc[0] / pc[2] + K[0, 2], K[1, 1] * pc[1] / pc[2] + K[1, 2], pc[2])
    return pts


def centroid(f):
    m = cv2.imread(str(f), 0) > 127
    ys, xs = np.nonzero(m)
    return (xs.mean(), ys.mean()) if len(xs) > 300 else None


rows = []
for p in rep["poses"]:
    pid = p["pose"]
    qd = samples[pid]["joints_before"]["q"]
    a, b = project(qd, {}), project(qd, P_CAL)
    fk_shift = {ln: (b[ln][0] - a[ln][0], b[ln][1] - a[ln][1]) for ln in LINKS}
    ca, cb = centroid(OUT / f"mask_nominal_arm_{pid}.png"), centroid(OUT / f"mask_dual_trans_arm_{pid}.png")
    mshift = None if ca is None or cb is None else (cb[0] - ca[0], cb[1] - ca[1])
    rows.append({"pose": pid, "fk_shift_px": {k: [round(v[0], 1), round(v[1], 1)] for k, v in fk_shift.items()},
                 "mask_centroid_shift_px": None if mshift is None else [round(mshift[0], 1), round(mshift[1], 1)],
                 "depth_m": {k: round(v[2], 3) for k, v in a.items()}})
    fs = np.array([fk_shift[ln] for ln in LINKS[:4]]).mean(axis=0)
    print(f"{pid}: FK shift (forearm/wrist mean) {fs.round(1).tolist()} px | rendered mask centroid shift "
          f"{None if mshift is None else np.round(mshift, 1).tolist()} px | wrist depth {a['left_wrist_pitch_link'][2]:.2f} m")
    # draw the projected joint centres on the overlay used before
    ov = OUT / f"overlay_{pid}.png"
    if ov.exists():
        img = cv2.imread(str(ov))
        for tag, pts in (("nominal", a), ("calibrated", b)):
            for ln, (u, v, _) in pts.items():
                cv2.drawMarker(img, (int(round(u)), int(round(v))), COL[tag], cv2.MARKER_CROSS, 10, 1)
        cv2.imwrite(str(OUT / f"fkcheck_{pid}.png"), img)
json.dump(rows, open(OUT / "fk_check.json", "w"), indent=1)
