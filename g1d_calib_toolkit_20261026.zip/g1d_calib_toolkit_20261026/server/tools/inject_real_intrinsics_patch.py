# inject_real_intrinsics_patch.py — 在服务器上运行：复制标定包并把真实内参注入 board_setups.py
# 用法: python inject_real_intrinsics_patch.py <pkg_dir> <intrinsics_dir> <out_dir>
import json
import shutil
import sys
from pathlib import Path

pkg, intr_dir, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
if out.exists():
    shutil.rmtree(out)
shutil.copytree(pkg, out, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

bs = out / 'board_setups.py'
text = bs.read_text()

A1 = "import json\nimport xml.etree.ElementTree as ET"
B1 = "import json\nimport os\nfrom pathlib import Path\nimport xml.etree.ElementTree as ET"
assert text.count(A1) == 1, f"anchor1 x{text.count(A1)}"
text = text.replace(A1, B1)

A2 = "INTRINSICS_SIGMA = dict(fx=0.5, fy=0.5, cx=0.5, cy=0.5, k1=0.003, k2=0.002, p1=2e-4, p2=2e-4, k3=5e-4)"
B2 = A2 + """

REAL_INTRINSICS_DIR = Path(os.environ.get('G1D_REAL_INTRINSICS', '/nonexistent'))


def _load_real_intrinsics():
    out_ = {}
    for f in sorted(REAL_INTRINSICS_DIR.glob('camera_intrinsics_*.json')):
        d = json.loads(f.read_text())
        out_[d['camera']] = d
    print(f'[realcam] loaded real intrinsics for: {sorted(out_)}', flush=True)
    return out_


REAL_INTRINSICS = _load_real_intrinsics()"""
assert text.count(A2) == 1, f"anchor2 x{text.count(A2)}"
text = text.replace(A2, B2)

A3 = """        c = CAMERA_SPECS[kind]
        cams[name] = dict(parent=contract[name]['parent'], T_parent_camera=contract[name]['T_parent_camera_world_convention'],
                          model=c['model'], K=[[c['fx'], 0, RESOLUTION[0] / 2], [0, c['fx'], RESOLUTION[1] / 2], [0, 0, 1]],
                          dist=list(c['dist']), resolution=list(RESOLUTION), intrinsics_sigma=dict(INTRINSICS_SIGMA))"""
B3 = """        c = CAMERA_SPECS[kind]
        K = [[c['fx'], 0, RESOLUTION[0] / 2], [0, c['fx'], RESOLUTION[1] / 2], [0, 0, 1]]
        dist, isig = list(c['dist']), dict(INTRINSICS_SIGMA)
        real = REAL_INTRINSICS.get(name)
        if real is not None:
            K = [list(row) for row in real['K']]
            dist, isig = list(real['dist']), dict(real['intrinsics_sigma'])
        cams[name] = dict(parent=contract[name]['parent'], T_parent_camera=contract[name]['T_parent_camera_world_convention'],
                          model=c['model'], K=K, dist=dist, resolution=list(RESOLUTION), intrinsics_sigma=isig)"""
assert text.count(A3) == 1, f"anchor3 x{text.count(A3)}"
text = text.replace(A3, B3)

bs.write_text(text)
print(f'[realcam] patched {bs}')
