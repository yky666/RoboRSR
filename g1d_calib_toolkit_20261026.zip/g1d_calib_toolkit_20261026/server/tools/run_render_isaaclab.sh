#!/bin/bash
# run render_isaaclab.py with the unitree_sim_env (same env/flags as codex_pour/g1d_probe)
# usage: GRIP_MODE=upper|lower|default OUT=/dev/shm/isaac_work/render_lab_x bash r.sh
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
GPU=${GPU:-4}
OUT=${OUT:-/dev/shm/isaac_work/render_lab}
rm -rf "$OUT"
mkdir -p "$OUT" /dev/shm/tmp
export CUDA_VISIBLE_DEVICES=$GPU
export OMNI_KIT_ACCEPT_EULA=YES
export PYTHONUNBUFFERED=1
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6
export TMPDIR=/dev/shm/tmp
export GRIP_MODE
cd /dev/shm/isaac_work
timeout --signal=TERM --kill-after=20s 900s $ENV/bin/python -u render_isaaclab.py \
  --out "$OUT" --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$GPU --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" \
  > "$OUT.log" 2>&1
echo "EXIT=$?" >> "$OUT.log"
echo RUN_FINISHED >> "$OUT.log"
