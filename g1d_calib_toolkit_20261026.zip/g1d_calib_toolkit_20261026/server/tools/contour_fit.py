# contour_fit.py -- arm placement relative to the head cameras from the arm OUTLINE in head images (no markers):
# orientation-aware chamfer between the projected URDF arm silhouette (shoulder_roll..wrist_yaw, gripper excluded:
# the URDF gripper differs) and real image edges, both head eyes, truncated quadratic cost.
#   eval : contour_fit.py eval <out_dir> tag=urdf ...                      (score URDF variants)
#   fit  : contour_fit.py fit <out_dir> <urdf> <left|right|both> [mount|zeros|mountzeros]
#          mount: shoulder_pitch frame deltas (6 per arm); zeros: the 7 joint offsets of the arm with the URDF
#          untouched (sim joint angle = encoder reading + offset); mountzeros: mount (6) + zero offsets of
#          shoulder_roll..wrist_pitch (5; wrist_yaw barely changes the outline once the gripper is excluded)
#   pose : contour_fit.py pose <out_dir> <urdf> <left|right|both>
#          per image (both eyes): the joint offsets that align the moving arm's outline on THAT image alone ->
#          per-joint spread across images shows whether a constant reading offset explains the data
# sessions / cameras are configured below
import json
import multiprocessing as mp
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
from scipy.ndimage import map_coordinates
from scipy.optimize import minimize

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402

R = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015")
INT = R / "real_data/20261016/intrinsics"
CONTRACT = R / "assembled_calib_20261016/camera_contract_v5.json"
SES = R / "real_data/20261019/sessions"
SESSIONS = {"1209": SES / "calib_20261019_1209_B_wrist_table_board_left",
            "1509": SES / "calib_20261019_1509_B_wrist_table_board_left",
            "1533": SES / "calib_20261019_1533_B_wrist_table_board_right"}
# extra held-out sessions from other days: key=path in env CONTOUR_EXTRA (comma separated)
import os  # noqa: E402
for _kv in filter(None, os.environ.get("CONTOUR_EXTRA", "").split(",")):
    _k, _p = _kv.split("=", 1)
    SESSIONS[_k] = Path(_p)
TRAIN, TEST = ("1509", "1533"), ("1209",)
EXTRA = tuple(k for k in SESSIONS if k not in ("1209", "1509", "1533"))
EYES = ("head_left", "head_right")
W, H, UP = 640, 480, 2
NBIN, TRUNC, STEP = 8, 5.0, 2
ALLJ = arm_joints("left") + arm_joints("right")
ARM = {s: [f"{s}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch",
                                      "wrist_yaw")] for s in ("left", "right")}
MOUNT = ["zero", "rot_u", "rot_v", "dx", "dy", "dz"]
XSCALE = np.array([0.01, 0.01, 0.01, 0.005, 0.005, 0.005])        # optimizer units: 0.57 deg, 5 mm

cams = {}
contract = {v["name"]: v for v in json.loads(CONTRACT.read_text())["views"]}
for e in EYES:
    d = json.loads((INT / f"camera_intrinsics_{e}.json").read_text())
    cams[e] = dict(K=np.array(d["K"], float), dist=np.array(d["dist"], float), parent=contract[e]["parent"],
                   T=np.array(contract[e]["T_parent_camera_world_convention"]))


def stl(path):
    b = Path(path).read_bytes()
    n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
    rec = np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)
    return rec["v"].astype(np.float64).reshape(-1, 3)


def load_meshes(urdf):
    out = {}
    for link in ET.parse(urdf).getroot().findall("link"):
        vis = link.find("visual/geometry/mesh")
        if vis is not None:
            out[link.get("name")] = stl(Path(urdf).parent / vis.get("filename"))
    return out


def edge_dts(gray):
    """distance transforms of Canny edges split into NBIN gradient-orientation bins (each with +-1 bin tolerance)"""
    g = cv2.GaussianBlur(gray, (5, 5), 0)
    e = cv2.Canny(g, 30, 90) > 0
    ang = np.arctan2(cv2.Sobel(g, cv2.CV_32F, 0, 1), cv2.Sobel(g, cv2.CV_32F, 1, 0)) % np.pi
    b = np.floor(ang / np.pi * NBIN + 0.5).astype(int) % NBIN
    dts = []
    for k in range(NBIN):
        sel = e & ((b == k) | (b == (k + 1) % NBIN) | (b == (k - 1) % NBIN))
        dts.append(np.minimum(cv2.distanceTransform((~sel).astype(np.uint8), cv2.DIST_L2, 5), 20).astype(np.float32))
    return dts


# ---------------- data (module level so forked workers share it) ----------------
VIEWS = []          # (session, pid, eye, q dict, dts, moving side)
for name, sdir in SESSIONS.items():
    moving = json.loads((sdir / "session.json").read_text())["side"]
    for line in open(sdir / "samples.jsonl"):
        s = json.loads(line)
        f = sdir / "images" / s["pose_id"] / "head_stereo.png"
        if not f.exists():
            continue
        st = cv2.imread(str(f), cv2.IMREAD_GRAYSCALE)
        for k, e in enumerate(EYES):
            und = cv2.undistort(st[:, k * W:(k + 1) * W], cams[e]["K"], cams[e]["dist"], None, cams[e]["K"])
            q = {n: float(s["joints_before"]["q"].get(n, 0.0)) for n in ALLJ}
            VIEWS.append((name, s["pose_id"], e, q, edge_dts(und), moving))
MODEL = {}


def set_model(urdf):
    MODEL["robot"] = Robot(Path(urdf))
    meshes = load_meshes(urdf)
    MODEL["arm"] = {s: {ln: meshes[ln] for ln in ARM[s] if ln in meshes} for s in ("left", "right")}
    # coarse meshes (every k-th triangle) for the masks that only BLOCK contour points (dilated afterwards anyway)
    thin = lambda v, k: v.reshape(-1, 3, 3)[::k].reshape(-1, 3)                     # noqa: E731
    MODEL["arm_coarse"] = {s: {ln: thin(v, 4) for ln, v in MODEL["arm"][s].items()} for s in ("left", "right")}
    MODEL["grip"] = {s: {ln: thin(m, 8) for ln, m in meshes.items() if ln.startswith(f"{s}_dex1")}
                     for s in ("left", "right")}


def raster(robot, links, qa, params, Tc, K):
    m = np.zeros((H * UP, W * UP), np.uint8)
    for ln, v in links.items():
        T = robot.fk(ln, qa, params, None, 1)[0]
        pc = ((v @ T[:3, :3].T + T[:3, 3]) - Tc[:3, 3]) @ Tc[:3, :3] @ OPTICAL_FROM_CAMERA.T
        ok = (pc[:, 2] > 0.02).reshape(-1, 3).all(1)
        uv = np.stack([K[0, 0] * pc[:, 0] / pc[:, 2] + K[0, 2], K[1, 1] * pc[:, 1] / pc[:, 2] + K[1, 2]], 1)
        uv = ((uv + 0.5) * UP - 0.5) * 8
        cv2.fillPoly(m, list(np.round(uv.reshape(-1, 3, 2)[ok]).astype(np.int32)), 255, shift=3)
    return m


def view_cost(args):
    """sum of truncated squared chamfer distances and point count for one view and one arm"""
    vi, side, params = args
    name, pid, eye, q, dts, moving = VIEWS[vi]
    robot, c = MODEL["robot"], cams[eye]
    qa = {n: np.array([v]) for n, v in q.items()}
    Tc = robot.fk(c["parent"], qa, params, None, 1)[0] @ c["T"]
    arm = raster(robot, MODEL["arm"][side], qa, params, Tc, c["K"])
    if np.count_nonzero(arm) < 400 * UP * UP:
        return 0.0, 0, []
    other = raster(robot, MODEL["arm_coarse"]["right" if side == "left" else "left"], qa, params, Tc, c["K"])
    grip = raster(robot, MODEL["grip"]["left"], qa, params, Tc, c["K"]) | \
        raster(robot, MODEL["grip"]["right"], qa, params, Tc, c["K"])
    block = cv2.dilate(other | grip, np.ones((8 * UP + 1, 8 * UP + 1), np.uint8))
    cs, _ = cv2.findContours(arm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    pts, nrm = [], []
    for ct in cs:
        p = ct.reshape(-1, 2).astype(np.float64)
        if len(p) < 20:
            continue
        t = np.roll(p, -3, 0) - np.roll(p, 3, 0)
        keep = ~(block[p[:, 1].astype(int), p[:, 0].astype(int)] > 0)
        pts.append(p[keep][::STEP * UP]); nrm.append(t[keep][::STEP * UP])
    if not pts:
        return 0.0, 0, []
    p = (np.concatenate(pts) + 0.5) / UP - 0.5
    t = np.concatenate(nrm)
    inside = (p[:, 0] > 8) & (p[:, 0] < W - 9) & (p[:, 1] > 8) & (p[:, 1] < H - 9)
    p, t = p[inside], t[inside]
    ang = np.arctan2(t[:, 0], -t[:, 1]) % np.pi                       # normal direction (tangent rotated 90 deg)
    b = np.floor(ang / np.pi * NBIN + 0.5).astype(int) % NBIN
    d = np.empty(len(p))
    for k in range(NBIN):
        sel = b == k
        if sel.any():
            d[sel] = map_coordinates(dts[k], [p[sel, 1], p[sel, 0]], order=1)
    return float(np.sum(np.minimum(d, TRUNC) ** 2)), len(d), d


def evaluate(pool, idx, side, params, keep_d=False):
    res = pool.map(view_cost, [(i, side, params) for i in idx], chunksize=4)
    s, n = sum(r[0] for r in res), sum(r[1] for r in res)
    if keep_d:
        return s / max(n, 1), np.concatenate([r[2] for r in res if len(r[2])]) if n else np.array([])
    return s / max(n, 1)


def views_of(sessions, side):
    return [i for i, v in enumerate(VIEWS) if v[0] in sessions]


JSCALE = 0.01                                                     # optimizer unit for joint offsets: 0.57 deg


def pose_fit(args):
    """one image (both eyes): joint offsets that align the outline of the MOVING arm in this image"""
    vis, side = args
    names = [f"{j}/zero" for j in arm_joints(side)]

    def f(x):
        s = n = 0
        for vi in vis:
            a, b, _ = view_cost((vi, side, dict(zip(names, x * JSCALE))))
            s += a; n += b
        return s / max(n, 1)
    c0 = f(np.zeros(7))
    r = minimize(f, np.zeros(7), method="Powell", options={"xtol": 0.05, "ftol": 1e-4, "maxfev": 500})
    return {"image": f"{VIEWS[vis[0]][0]}/{VIEWS[vis[0]][1]}", "cost_before": c0, "cost_after": float(r.fun),
            "offset_rad": (r.x * JSCALE).tolist()}


def summary(pool, side, params, sessions):
    c, d = evaluate(pool, views_of(sessions, side), side, params, keep_d=True)
    return {"cost": round(c, 3), "median_px": round(float(np.median(d)), 2) if len(d) else None,
            "inlier_2px": round(float(np.mean(d < 2.0)), 3) if len(d) else None, "points": int(len(d))}


if __name__ == "__main__":
    mode, out = sys.argv[1], Path(sys.argv[2])
    out.mkdir(parents=True, exist_ok=True)
    print(f"{len(VIEWS)} views loaded", flush=True)
    ctx = mp.get_context("fork")
    if mode == "eval":
        rep = {}
        for arg in sys.argv[3:]:
            tag, urdf = arg.split("=", 1)
            set_model(urdf)
            with ctx.Pool(48) as pool:
                for side in ("left", "right"):
                    for sess in (TRAIN, TEST) + ((EXTRA,) if EXTRA else ()):
                        r = summary(pool, side, {}, sess)
                        rep[f"{tag}/{side}/{'+'.join(sess)}"] = r
                        print(f"{tag:12s} {side:5s} {'+'.join(sess):9s} {r}", flush=True)
        (out / "contour_eval.json").write_text(json.dumps(rep, indent=1))
    elif mode == "pose":
        urdf, which = sys.argv[3], sys.argv[4]
        set_model(urdf)
        result = {"urdf": urdf, "sides": {}}
        for side in (("left", "right") if which == "both" else (which,)):
            groups = {}
            for i, v in enumerate(VIEWS):
                if v[5] == side:                                   # images in which this arm moves
                    groups.setdefault((v[0], v[1]), []).append(i)
            t0 = time.time()
            with ctx.Pool(48) as pool:
                res = pool.map(pose_fit, [(vis, side) for vis in groups.values()], chunksize=1)
            off = np.degrees(np.array([r["offset_rad"] for r in res]))
            good = np.array([r["cost_after"] < r["cost_before"] for r in res])
            print(f"[{side}] {len(res)} images ({time.time() - t0:.0f} s); cost before/after median "
                  f"{np.median([r['cost_before'] for r in res]):.2f} / {np.median([r['cost_after'] for r in res]):.2f}",
                  flush=True)
            stats = {}
            for k, j in enumerate(arm_joints(side)):
                q1, med, q3 = np.percentile(off[good, k], [25, 50, 75])
                stats[j] = {"median_deg": round(float(med), 3), "iqr_deg": round(float(q3 - q1), 3)}
                print(f"   {j:28s} per-image offset median {med:+6.2f} deg, IQR {q3 - q1:5.2f} deg", flush=True)
            result["sides"][side] = {"per_image": res, "stats": stats}
        (out / f"contour_pose_{which}.json").write_text(json.dumps(result, indent=1))
    elif mode == "fit":
        urdf, which = sys.argv[3], sys.argv[4]
        kind = sys.argv[5] if len(sys.argv) > 5 else "mount"
        set_model(urdf)
        result = {"urdf": urdf, "kind": kind, "train": TRAIN, "test": TEST, "sides": {}}
        for side in (("left", "right") if which == "both" else (which,)):
            mount_names = [f"{side}_shoulder_pitch_joint/{k}" for k in MOUNT]
            mount_scale = np.array([0.01, 0.01, 0.01, 0.005, 0.005, 0.005])
            if kind == "zeros":
                names = [f"{j}/zero" for j in arm_joints(side)]
                XSCALE = np.full(7, JSCALE)
            elif kind == "mountzeros":
                names = mount_names + [f"{j}/zero" for j in arm_joints(side)[1:6]]
                XSCALE = np.concatenate([mount_scale, np.full(5, JSCALE)])
            else:
                names, XSCALE = mount_names, mount_scale
            idx = views_of(TRAIN, side)
            with ctx.Pool(48) as pool:
                t0 = time.time()
                hist = []

                def f(x):
                    c = evaluate(pool, idx, side, dict(zip(names, x * XSCALE)))
                    hist.append(c)
                    if len(hist) % 25 == 0:
                        print(f"   [{side}] eval {len(hist)}: cost {c:.3f} (best {min(hist):.3f}) "
                              f"{time.time() - t0:.0f}s", flush=True)
                    return c
                before = {s: summary(pool, side, {}, s) for s in (TRAIN, TEST)}
                print(f"[{side}] before {before}", flush=True)
                r = minimize(f, np.zeros(len(names)), method="Powell",
                             options={"xtol": 0.05, "ftol": 1e-4, "maxfev": 100 * len(names)})
                p = dict(zip(names, (r.x * XSCALE).tolist()))
                after = {s: summary(pool, side, p, s) for s in (TRAIN, TEST)}
                print(f"[{side}] after  {after}  ({time.time() - t0:.0f} s, {r.nfev} evals)", flush=True)
                print(f"[{side}] {kind}: " + ", ".join(
                    f"{k.split('/')[0].replace(side + '_', '') if k.endswith('/zero') and 'shoulder_pitch' not in k else k.split('/')[1]} "
                    f"{v * (1000 if k.split('/')[1].startswith('d') else 57.2958):+.2f}"
                    f"{'mm' if k.split('/')[1].startswith('d') else 'deg'}" for k, v in p.items()), flush=True)
                result["sides"][side] = {"params": p, "before": {"+".join(k): v for k, v in before.items()},
                                         "after": {"+".join(k): v for k, v in after.items()}}
        (out / f"contour_fit_{which}_{kind}.json").write_text(json.dumps(result, indent=1))
