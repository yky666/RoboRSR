# eval_layout.py -- run pose_design with the REAL table/board/camera setup (server, unitree_sim_env python)
# usage: eval_layout.py --shift 0.0 --out <dir>   (shift = how much closer the robot moves, m)
import argparse
import json
import sys
from pathlib import Path

import numpy as np

REALCAM = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
sys.path.insert(0, str(REALCAM))
import board_setups as bs  # noqa: E402
import pose_design as pd  # noqa: E402
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

INTR = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/intrinsics")

ap = argparse.ArgumentParser()
ap.add_argument("--shift", type=float, default=0.0)
ap.add_argument("--out", required=True)
ap.add_argument("--n", type=int, default=50)
ap.add_argument("--pool", type=int, default=400)
ap.add_argument("--max-dist", type=float, default=0.0, help="B setup: keep only poses with wrist-cam->board <= this (m)")
a = ap.parse_args()
out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

# measured with the head stereo (head_left PnP), torso frame
T_board = np.array(json.loads(Path("/dev/shm/isaac_work/board_pose.json").read_text())["head_left"]["T_torso_board"])
T_board[0, 3] -= a.shift
bs.TABLE_Z = -0.015
bs.TABLE_EDGE_X = 0.47 - a.shift

import cv2  # noqa: E402
cb = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
pts = [[i, float(p[0]), float(p[1]), float(p[2])] for i, p in enumerate(cb.getChessboardCorners())]

scene = bs.nominal_scene()
scene["boards"]["table"] = dict(type="charuco", squares_x=10, squares_y=7, square_length_m=0.040,
                                marker_length_m=0.030, dictionary="DICT_4X4_50", parent="torso_link",
                                T_parent_board=T_board.tolist(), points_m=pts)
for cam in list(scene["cameras"]):
    f = INTR / f"camera_intrinsics_{cam}.json"
    if f.exists():
        d = json.loads(f.read_text())
        scene["cameras"][cam].update(K=d["K"], dist=d["dist"], resolution=d["resolution"], model=d.get("model", "opencv"))

pd.HERE = out
geo = bs.Geometry(scene)
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")

if a.max_dist > 0:
    center = T_board[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_board[:3, 3]
    _orig_candidates = pd.candidates

    def _near_candidates(geo_, scene_, setup, side, n, rng_):
        if not str(setup).startswith("B"):   # pose_design passes the short name, e.g. "B_wrist"
            return _orig_candidates(geo_, scene_, setup, side, n, rng_)
        cam = f"{side}_wrist"
        Tpc = np.array(scene_["cameras"][cam]["T_parent_camera"])
        keep_q, keep_o, stats = [], [], {}
        for _ in range(4):
            qs, origin, st = _orig_candidates(geo_, scene_, setup, side, n, rng_)
            stats = st
            for qv, o in zip(qs, origin):
                if isinstance(qv, dict):
                    qd = {k: np.array([v]) for k, v in qv.items()}
                else:
                    qd = {j: np.array([v]) for j, v in zip(arm_joints(side), np.ravel(qv))}
                T = robot.fk(scene_["cameras"][cam]["parent"], qd, {}, None, 1)[0] @ Tpc
                if np.linalg.norm(center - T[:3, 3]) <= a.max_dist:
                    keep_q.append(qv); keep_o.append(o)
            if len(keep_q) >= n // 2:
                break
        print(f"[near filter] {side}: kept {len(keep_q)} candidates <= {a.max_dist} m", flush=True)
        return keep_q, keep_o, stats

    pd.candidates = _near_candidates
rng = np.random.default_rng(7)
summary = {}
for side in ["left", "right"]:
    doc, summary[side] = pd.design(geo, robot, scene, side, a.n, a.pool, rng)
    (out / f"poses_{side}.json").write_text(json.dumps(doc, indent=1))
summary["layout"] = {"shift_m": a.shift, "board_center_x": float(T_board[0, 3]), "table_edge_x": bs.TABLE_EDGE_X,
                     "table_z": bs.TABLE_Z}
(out / "summary.json").write_text(json.dumps(summary, indent=1, default=str))
print(json.dumps(summary, indent=1, default=str)[:4000])
