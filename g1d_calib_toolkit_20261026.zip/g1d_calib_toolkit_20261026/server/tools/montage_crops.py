# montage_crops.py -- tile the crop_<pid>.png zooms of a render comparison into one image with a colour legend
# usage: montage_crops.py <render_out_dir>
import sys
from pathlib import Path

import cv2
import numpy as np

OUT = Path(sys.argv[1])
H = 260
tiles = []
for f in sorted(OUT.glob("crop_*.png")):
    im = cv2.imread(str(f))
    tiles.append(cv2.resize(im, (int(im.shape[1] * H / im.shape[0]), H)))
W = 1500
rows, row, wsum = [], [], 0
for t in tiles:
    if row and wsum + t.shape[1] > W:
        rows.append(row); row, wsum = [], 0
    row.append(t); wsum += t.shape[1]
rows.append(row)
canvas = []
for r in rows:
    line = np.hstack(r)
    canvas.append(np.hstack([line, np.zeros((H, W - line.shape[1], 3), np.uint8)]) if line.shape[1] < W else line[:, :W])
legend = np.zeros((40, W, 3), np.uint8)
for k, (txt, col) in enumerate((("red: nominal URDF", (0, 0, 255)), ("green: calibrated (dual_trans)", (0, 220, 0)),
                                ("blue: calibrated + shoulder mount from touch", (255, 140, 0)))):
    cv2.putText(legend, txt, (10 + 420 * k, 27), cv2.FONT_HERSHEY_SIMPLEX, 0.7, col, 2)
cv2.imwrite(str(OUT / "montage.png"), np.vstack([legend] + canvas))
print("written", OUT / "montage.png")
