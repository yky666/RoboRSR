# dump_head_cam_T.py -- T_torso_camworld for both head eyes (head_link is fixed to torso)
import json
import sys
import numpy as np
sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import Robot

ROOT = "/root/unitree_sim_isaaclab/real2sim_calib_20261015"
robot = Robot(f"{ROOT}/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf")
con = {v["name"]: v for v in json.load(open(f"{ROOT}/assembled_calib_20261016/camera_contract_v5.json"))["views"]}
T_head = robot.fk("head_link", {}, {}, None, 1)[0]
out = {e: (T_head @ np.array(con[e]["T_parent_camera_world_convention"])).tolist() for e in ("head_left", "head_right")}
print(json.dumps(out))
