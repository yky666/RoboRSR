# make_urdf_variants.py -- calibrated URDF variants for the head-view render comparison (server, CPU, seconds)
#   dual_trans       : params_dual_trans_1019 (camera-based identification, both arms, joint translations)
#   dual_trans_mount : dual_trans + left shoulder mount from the touch data with the board held at the head measurement
# nothing outside OUT is written; meshes are symlinked from the nominal render asset
import json
import os
import subprocess
from pathlib import Path

import numpy as np

R = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015")
PY = os.environ.get("ISAAC_PY", "<ISAAC_ENV>/bin/python")
S = R / "real_data/20261019/sessions"
TOUCH = R / "real_data/20261019/touch/touch_auto_left_20261019_1720/touch_identify_auto.result.json"
OUT = R / "scratch/urdf_variants_20261019"
MESHES = R / "assembled_calib_20261016/meshes"

base = json.loads((S / "params_dual_trans_1019.json").read_text())
res = json.loads(TOUCH.read_text())
mount = res["variants"]["end_boardhead_fixed:params_dual_trans_1019"]["Mmount_shoulder_mount_vs_head"]
v = dict(base["values"])
for k, deg in mount["joint_params_deg"].items():
    # every entry was written as np.degrees(value); translations therefore come back in metres via radians()
    v[k] = float(np.radians(deg))
    print(f"{k:40s} {base['values'].get(k, 0.0):+.5f} -> {v[k]:+.5f}")
p2 = dict(base, values=v, status="IDENTIFIED_PLUS_TOUCH_MOUNT",
          description=base["description"] + " Left shoulder mount replaced by the touch-data fit with the table board "
                                            "held at the head-camera measurement (touch_identify_auto.py).")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "params_dual_trans_touchmount_1019.json").write_text(json.dumps(p2, indent=2))
for tag, pf in (("dual_trans", S / "params_dual_trans_1019.json"),
                ("dual_trans_mount", OUT / "params_dual_trans_touchmount_1019.json")):
    d = OUT / tag
    subprocess.check_call([PY, "apply_calibration.py", str(pf), str(d)], cwd=R)
    if not (d / "meshes").exists():
        (d / "meshes").symlink_to(MESHES)
    print(tag, "->", d / "g1_d_upper_dex1_v4.urdf")
