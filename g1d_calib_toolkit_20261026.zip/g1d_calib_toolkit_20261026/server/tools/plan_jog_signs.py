# plan_jog_signs.py -- direction check at the ready pose: per joint pick the jog sign that RAISES the gripper
# key points (FK), report predicted clearance for both signs.   server, unitree_sim_env python
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

DAY = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016")
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
TABLE_Z, RADIUS, JOG = -0.022, 0.03, 0.05
READY = [0.3280082345, -0.0444015563, -0.0210323147, -0.2193952054, -0.1763718426, -0.3590713441, -0.1322099715,
         0.1631669253, -0.0210245643, 0.1643322706, -0.1186949760, -0.1611172855, -0.2666637003, -0.2119511217]


def clearance(side, q7):
    qa = {n: np.array([v]) for n, v in zip(arm_joints(side), q7)}
    for k in (1, 2):
        qa[f"{side}_dex1_finger_joint_{k}"] = np.array([-0.02])
    links = [f"{side}_wrist_pitch_link", f"{side}_wrist_yaw_link", f"{side}_dex1_base_link",
             f"{side}_dex1_finger_link_1_tip", f"{side}_dex1_finger_link_2_tip"]
    return min(robot.fk(l, qa, {}, None, 1)[0][2, 3] for l in links) - RADIUS - TABLE_Z


plan = {"ready_arm_q": READY, "jog_rad": JOG}
for side, off in (("left", 0), ("right", 7)):
    q0 = np.array(READY[off:off + 7])
    c0 = clearance(side, q0)
    signs, info = [], []
    for j, name in enumerate(arm_joints(side)):
        cp = clearance(side, q0 + JOG * np.eye(7)[j])
        cm = clearance(side, q0 - JOG * np.eye(7)[j])
        s = 1 if cp >= cm else -1
        signs.append(s)
        info.append({"joint": name, "sign": s, "clear_plus_cm": round(cp * 100, 1), "clear_minus_cm": round(cm * 100, 1)})
        print(f"{name:28s} sign {s:+d} | clearance +jog {cp * 100:5.1f} cm  -jog {cm * 100:5.1f} cm (ready {c0 * 100:.1f})")
    plan[side] = {"joints": {n: float(v) for n, v in zip(arm_joints(side), q0)}, "jog_sign": signs,
                  "ready_clearance_cm": round(c0 * 100, 1), "per_joint": info, "delta_from_ready": {}}
(DAY / "poses" / "dircheck_plan.json").write_text(json.dumps(plan, indent=1))
print(json.dumps({s: plan[s]["jog_sign"] for s in ("left", "right")}))
