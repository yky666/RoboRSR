# check_urdf_vs_params.py -- does the calibrated URDF written by apply_calibration reproduce FK(nominal URDF, params)?
# usage: check_urdf_vs_params.py <params.json> <calibrated_urdf> <session_dir>
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

vals = json.loads(Path(sys.argv[1]).read_text())["values"]
P = {k: float(v) for k, v in vals.items() if ":" not in k.split("/")[0]}
nom, cal = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf"), Robot(Path(sys.argv[2]))
ALLJ = arm_joints("left") + arm_joints("right")
LINKS = ["left_shoulder_roll_link", "left_elbow_link", "left_wrist_pitch_link", "left_dex1_base_link",
         "right_elbow_link", "right_dex1_base_link", "head_link"]
print("joint params in file:", len(P), "| keys of left_shoulder_pitch:",
      {k: round(v, 5) for k, v in P.items() if k.startswith("left_shoulder_pitch")})
samples = [json.loads(l) for l in open(Path(sys.argv[3]) / "samples.jsonl") if l.strip()][::9]
for s in samples:
    qa = {n: np.array([float(s["joints_before"]["q"].get(n, 0.0))]) for n in ALLJ}
    out = []
    for ln in LINKS:
        a = nom.fk(ln, qa, P, None, 1)[0]
        b = cal.fk(ln, qa, {}, None, 1)[0]
        c = nom.fk(ln, qa, {}, None, 1)[0]
        out.append(f"{ln.replace('_link', '')}: |nom+P - calURDF| {np.linalg.norm(a[:3, 3] - b[:3, 3]) * 1000:.2f} mm, "
                   f"|nom+P - nom| {np.linalg.norm(a[:3, 3] - c[:3, 3]) * 1000:.1f} mm")
    print(s["pose_id"]); print("   " + "\n   ".join(out))
