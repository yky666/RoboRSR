# touch_identify_auto.py -- identify joint zeros + fingertip point + board pose from auto_touch.py records
# per touch:  T_torso_dex1base(q_onset + params) @ tip  ==  T_torso_board @ [x_H, y_H, 0]
#   q_onset: arm joints at the contact onset (knee of measured-vs-commanded travel in the step history)
#   x_H, y_H: board point under the fingertip pixel from the markers seen at contact (homography)
# models: M0 = tip + board only;  M1 = + 5 joint zeros (shoulder_roll .. wrist_pitch);  M2 = M1 + rot_v
# usage (server):  touch_identify_auto.py <board_pose_measured.json> <touches.jsonl> [more.jsonl ...] [--exclude ID,ID]
import json
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
from calib_model import NOMINAL, Robot, arm_joints  # noqa: E402

STALL_STEPS = 4
MIN_MARKERS = 2

args = sys.argv[1:]
exclude = set()
if "--exclude" in args:
    k = args.index("--exclude")
    exclude = set(args[k + 1].split(","))
    del args[k:k + 2]
fixed_files = []
while "--fixed" in args:
    k = args.index("--fixed")
    fixed_files.append(args[k + 1])
    del args[k:k + 2]
bp = json.loads(Path(args[0]).read_text())
files = args[1:]
def excluded(r):
    """--exclude tokens: POSE (all its points) or POSE@dx@dy (one offset point)"""
    ox, oy = r.get("offset_m", [0, 0])
    return r["pose"] in exclude or f"{r['pose']}@{ox:g}@{oy:g}" in exclude


recs = [r for f in files for l in open(f) if l.strip() for r in [json.loads(l)] if not excluded(r)]
n_all = len(recs)
recs = [r for r in recs if len(r["touches"]) >= 2]        # a single touch = second approach found nothing: suspect
print(f"{n_all - len(recs)} points dropped (no confirming second touch)")
side = "left" if any("left" in f for f in files) else "right"
off = 0 if side == "left" else 7
robot = Robot(NOMINAL / "g1_d_upper_dex1_v4.urdf")
ALLJ = arm_joints("left") + arm_joints("right")
J = arm_joints(side)
base = f"{side}_dex1_base_link"
T_b0 = 0.5 * (np.array(bp["head_left"]["T_torso_board"]) + np.array(bp["head_right"]["T_torso_board"]))
U, _, Vt = np.linalg.svd(T_b0[:3, :3]); T_b0[:3, :3] = U @ Vt


def onset(hist):
    """contact-onset joints: intersect the free-motion line with the contact (creep) line, interpolate q7"""
    c = np.array([h[0] for h in hist]); m = np.array([h[1] for h in hist]); q = np.array([h[2] for h in hist])
    k = len(hist) - STALL_STEPS - 1                        # last sample before the stall window
    free = slice(max(1, k - 8), k + 1)
    a1, b1 = np.polyfit(c[free], m[free], 1)
    a2, b2 = np.polyfit(c[k + 1:], m[k + 1:], 1)
    if abs(a1 - a2) < 0.2:
        return None, None
    c_on = (b2 - b1) / (a1 - a2)
    m_on = a1 * c_on + b1
    m_on = float(np.clip(m_on, m[free].min(), m.max()))
    order = np.argsort(m)
    q_on = np.array([np.interp(m_on, m[order], q[order, j]) for j in range(7)])
    return q_on, m_on


rows = []                    # (point index, touch index, q14 onset, q14 end, board xy)
for pi, r in enumerate(recs):
    for ti, t in enumerate(r["touches"]):
        h = t["contact"]
        if h is None or h["n_markers"] < MIN_MARKERS:
            continue
        q_end = np.array(t["arm_q_full"])
        q_on7, m_on = onset(t["history"])
        if q_on7 is None:
            continue
        q_on = q_end.copy(); q_on[off:off + 7] = q_on7
        rows.append((pi, ti, q_on, q_end, np.array(h["board_xy_m"])))
P_IDX = np.array([r[0] for r in rows])
XY = np.array([r[4] for r in rows])
print(f"{side}: {len(recs)} points, {len(rows)} usable touches")


def tip_world(qrow, p, tip):
    T = robot.fk(base, {n: np.array([v]) for n, v in zip(ALLJ, qrow)}, p, None, 1)[0]
    return T[:3, :3] @ tip + T[:3, 3]


def board_T(bpar):
    T = T_b0.copy()
    T[:3, :3] = T_b0[:3, :3] @ Rotation.from_rotvec(bpar[:3]).as_matrix(); T[:3, 3] = T_b0[:3, 3] + bpar[3:6]
    return T


P_FIXED = {}                           # joint params held fixed (e.g. from the camera-based identification)


def residuals(x, names, idx, Q):
    tip, bpar, p = x[:3], x[3:9], {**P_FIXED, **dict(zip(names, x[9:]))}
    Tb = board_T(bpar)
    return np.concatenate([tip_world(Q[i], p, tip) - (Tb[:3, :3] @ np.r_[XY[i], 0.0] + Tb[:3, 3]) for i in idx])


SIG_MEAS = 0.001                       # m per touch coordinate
PRIOR = None                           # (board rot rad, board t m, joint param rad) sigmas, or None = board free


def objective(x, names, idx, Q):
    r = residuals(x, names, idx, Q) / SIG_MEAS
    if PRIOR is None:
        return r
    return np.concatenate([r, x[3:6] / PRIOR[0], x[6:9] / PRIOR[1], x[9:] / PRIOR[2]])


def tip_guess(Q):
    v = []
    for i in range(len(rows)):
        T = robot.fk(base, {n: np.array([val]) for n, val in zip(ALLJ, Q[i])}, P_FIXED, None, 1)[0]
        v.append(T[:3, :3].T @ (T_b0[:3, :3] @ np.r_[XY[i], 0.0] + T_b0[:3, 3] - T[:3, 3]))
    return np.mean(v, axis=0)


def fit(names, idx, Q, x0tip):
    x0 = np.concatenate([x0tip, np.zeros(6), np.zeros(len(names))])
    return least_squares(objective, x0, args=(names, idx, Q), loss="soft_l1", f_scale=2.0, x_scale="jac").x


def split(e, Tb):
    """per-touch error -> (in-plane mm, normal mm)"""
    e = e.reshape(-1, 3); n = Tb[:3, 2]
    en = e @ n
    return np.linalg.norm(e - np.outer(en, n), axis=1) * 1000, np.abs(en) * 1000


def rms(v):
    return float(np.sqrt(np.mean(np.square(v))))


ZERO = [f"{j}/zero" for j in J[1:6]]
ROTV = [f"{j}/rot_v" for j in J[1:7]]
report = {"side": side, "files": files, "n_points": len(recs), "n_touches": len(rows), "variants": {}}

# repeatability of the two touches of one point (nominal model, onset joints)
for label, col in (("onset", 2), ("end", 3)):
    d = []
    for pi in sorted(set(P_IDX.tolist())):
        ii = np.where(P_IDX == pi)[0]
        if len(ii) == 2:
            a_, b_ = (tip_world(rows[i][col], {}, np.zeros(3)) for i in ii)
            d.append(np.linalg.norm(a_ - b_) * 1000)
    if d:
        print(f"repeat ({label} joints): dex1 base position touch1 vs touch2  median {np.median(d):.2f} mm  "
              f"max {np.max(d):.2f} mm  (n={len(d)})")
        report[f"repeat_{label}_mm"] = [round(float(v), 3) for v in d]

allidx = np.arange(len(rows))
points = sorted(set(P_IDX.tolist()))
BOARD_PRIOR = (np.radians(1.0), 0.005, np.radians(3.0))
# board held at the head-camera measurement -> the shoulder mount relative to the head becomes identifiable
TIGHT_BOARD = (np.radians(0.05), 0.0005, np.radians(5.0))
MOUNT = [f"{J[0]}/{k}" for k in ("zero", "rot_u", "rot_v", "dx", "dy", "dz")]
variants = [("end_boardprior", 3, BOARD_PRIOR, None), ("end_boardfree", 3, None, None),
            ("onset_boardprior", 2, BOARD_PRIOR, None)]
if fixed_files:                       # compare: nominal joints vs joint params fixed from each file (tip + board fit)
    variants = [("end_boardprior", 3, BOARD_PRIOR, None), ("end_boardfree", 3, None, None)]
    for ff in fixed_files:
        variants += [(f"end_boardprior_fixed:{Path(ff).stem}", 3, BOARD_PRIOR, ff),
                     (f"end_boardfree_fixed:{Path(ff).stem}", 3, None, ff),
                     (f"end_boardhead_fixed:{Path(ff).stem}", 3, TIGHT_BOARD, ff)]
for qlabel, col, PRIOR, ff in variants:
    P_FIXED = {}
    if ff:
        P_FIXED = {k: float(v) for k, v in json.loads(Path(ff).read_text())["values"].items()
                   if k.startswith(f"{side}_")}
    Q = np.array([r[col] for r in rows])
    t0 = tip_guess(Q)
    report["variants"][qlabel] = {}
    models = (("M0_tip_board_only", []),) if fixed_files else \
        (("M0_tip_board_only", []), ("M1_plus_zeros", ZERO), ("M2_plus_zeros_rotv", ZERO + ROTV))
    if ff and PRIOR is TIGHT_BOARD:
        models = (("Mmount_shoulder_mount_vs_head", MOUNT),)
    for label, names in models:
        if PRIOR is None and 9 + len(names) > 3 * len(points) - 3:
            continue
        x = fit(names, allidx, Q, t0)
        ip, nn = split(residuals(x, names, allidx, Q), board_T(x[3:9]))
        loo_ip, loo_n = [], []
        for pi in points:                                   # leave one POINT (both touches) out
            test = np.where(P_IDX == pi)[0]
            xi = fit(names, np.setdiff1d(allidx, test), Q, t0)
            a_, b_ = split(residuals(xi, names, test, Q), board_T(xi[3:9]))
            loo_ip += a_.tolist(); loo_n += b_.tolist()
        res = {"fit_inplane_rms_mm": rms(ip), "fit_normal_rms_mm": rms(nn),
               "loo_inplane_rms_mm": rms(loo_ip), "loo_normal_rms_mm": rms(loo_n),
               "tip_mm": (x[:3] * 1000).round(2).tolist(),
               "board_corr": {"rot_deg": np.degrees(x[3:6]).round(2).tolist(), "t_mm": (x[6:9] * 1000).round(1).tolist()},
               "joint_params_deg": {n: round(float(np.degrees(v)), 3) for n, v in zip(names, x[9:])}}
        res["per_touch"] = [{"pose": recs[P_IDX[i]]["pose"], "offset_m": recs[P_IDX[i]].get("offset_m", [0, 0]),
                             "roll_deg": recs[P_IDX[i]]["roll_deg"], "inplane_mm": round(float(ip[i]), 2),
                             "normal_mm": round(float(nn[i]), 2)} for i in allidx]
        report["variants"][qlabel][label] = res
        print(f"\n[{qlabel} / {label}] fit in-plane {rms(ip):.2f} mm, normal {rms(nn):.2f} mm | "
              f"leave-one-point-out in-plane {rms(loo_ip):.2f} mm, normal {rms(loo_n):.2f} mm")
        if qlabel == "end_boardprior" and not fixed_files:
            for i in allidx:
                r_ = recs[P_IDX[i]]
                print(f"     {r_['pose']} off {r_.get('offset_m', [0, 0])} roll {r_['roll_deg']:+.0f}: "
                      f"in-plane {ip[i]:.2f} mm, normal {nn[i]:.2f} mm")
        print(f"   tip in {base} (mm) {res['tip_mm']}; board corr rot {res['board_corr']['rot_deg']} deg "
              f"t {res['board_corr']['t_mm']} mm")
        for n, v in zip(names, x[9:]):
            if n.split("/")[-1] in ("dx", "dy", "dz"):
                print(f"   {n:40s} {v * 1000:+7.2f} mm")
            else:
                print(f"   {n:40s} {np.degrees(v):+7.3f} deg")
out = Path(files[0]).with_name("touch_identify_auto.result.json")
out.write_text(json.dumps(report, indent=1))
print("\nwritten", out)
