# robot_state_check.py -- read-only: rt/lowcmd writers in 1.5 s, current waist / arm / gripper positions, arm speed
import time

import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowCmd_, LowState_

ChannelFactoryInitialize(0, "eth0")
n_cmd, st = [0], []
s1 = ChannelSubscriber("rt/lowcmd", LowCmd_); s1.Init(lambda m: n_cmd.__setitem__(0, n_cmd[0] + 1), 50)
s2 = ChannelSubscriber("rt/lowstate", LowState_); s2.Init(lambda m: st.append(m), 50)
time.sleep(1.5)
m = st[-1]
q = np.array([m.motor_state[i].q for i in range(35)])
dq = np.abs([[x.motor_state[i].dq for i in range(15, 29)] for x in st[-200:]])
print(f"lowcmd messages in 1.5 s: {n_cmd[0]}  (0 = nobody is commanding)")
print(f"waist yaw (12): {q[12]:+.3f}  grippers L31/R33: {q[31]:+.3f} / {q[33]:+.3f}")
print("left  arm 15-21:", np.round(q[15:22], 3).tolist())
print("right arm 22-28:", np.round(q[22:29], 3).tolist())
print(f"arm |dq| max {dq.max():.3f} rad/s  mode_machine {m.mode_machine}")
