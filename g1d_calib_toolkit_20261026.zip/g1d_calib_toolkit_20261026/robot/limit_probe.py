# limit_probe.py -- does the real joint range end before the URDF limit? Automatic, one joint / one direction at a
# time from a collision-free base pose, small steps; "blocked" = the measured joint STOPS MOVING while the command
# keeps going (advance over the last STALL_N steps < STALL_FRAC of the commanded advance). The lag itself is not a
# blocking signal: the gravity lag changes with the arm pose (an extending elbow unloads and catches up with the
# command). LAG_MAX is only a force guard.
# Then back to the base pose and home. Needs calib_arm_server.py running, both arms at home (all-zero).
# usage: python -u limit_probe.py TEST [TEST ...]      TEST = side:joint:+|-   e.g. left:elbow:+ right:wrist_pitch:-
import json
import os
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

BASE = Path.home() / "calib_sessions"
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
STEP = 0.02           # rad per step
STALL_N, STALL_FRAC = 3, 0.3
LAG_MAX = 0.08        # rad lag growth: stop regardless (force guard; the server aborts at 0.2)
MARGIN = 0.06         # stop this far inside the URDF limit (the server rejects targets within 0.05 of it)
ABDUCT = {"left": 0.35, "right": -0.25}     # shoulder roll used for elbow probes (hands clear the body / chassis)
OUT = BASE / time.strftime("limit_probe_%Y%m%d_%H%M%S.json")

lim = {}
for j in ET.parse(BASE / "model" / "g1_d_upper_dex1_v4.urdf").getroot().findall("joint"):
    l = j.find("limit")
    if l is not None and j.get("type") == "revolute":
        lim[j.get("name")] = (float(l.get("lower")), float(l.get("upper")))


def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.05)
    return json.loads(STATUS.read_text())


def move(arm_q, seconds):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds, "seq": seq}))
    os.replace(tmp, CMD)
    while True:
        s = status()
        if s["state"] == "error":
            raise RuntimeError(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith(("REJECTED", "refused")):
                raise RuntimeError(s["msg"])
            return s
        time.sleep(0.02)


def move_split(target, seconds):
    """same straight joint-space line as one move, cut into pieces of <= 1.5 rad (server max per command 1.6)"""
    start = np.array(status()["arm_q_cmd"])
    n = max(1, int(np.ceil(np.abs(target - start).max() / 1.5)))
    for i in range(1, n + 1):
        move(start + (target - start) * i / n, seconds / n)


def meas(avg=0.15):
    qs, ts = [], []
    t0 = time.time()
    while time.time() - t0 < avg:
        s = status(); qs.append(s["arm_q"]); ts.append(s["arm_tau"]); time.sleep(0.02)
    return np.mean(qs, axis=0), np.mean(ts, axis=0)


def probe(side, joint, sgn):
    off = 0 if side == "left" else 7
    k = off + ARM.index(joint)
    name = f"{side}_{joint}_joint"
    lo, hi = lim[name]
    end = (hi - MARGIN) if sgn > 0 else (lo + MARGIN)
    home = np.zeros(14)
    base = home.copy()
    if joint == "elbow":
        base[off + 1] = ABDUCT[side]
    print(f"== {name} {'+' if sgn > 0 else '-'}: URDF {'upper' if sgn > 0 else 'lower'} {end + sgn * MARGIN:+.3f}, "
          f"probing to {end:+.3f}", flush=True)
    move(base, 3.0)
    time.sleep(0.8)
    q0, _ = meas(0.4)
    cmd = base.copy()
    lag0 = (cmd[k] - q0[k]) * sgn
    blocked, hist, why = False, [], ""
    while (end - cmd[k]) * sgn > 1e-9:
        cmd[k] = cmd[k] + sgn * min(STEP, abs(end - cmd[k]))
        move(cmd, 0.3)
        time.sleep(0.25)
        q, tau = meas()
        lag = (cmd[k] - q[k]) * sgn - lag0
        hist.append([round(float(cmd[k]), 4), round(float(q[k]), 4), round(float(tau[k]), 2)])
        if len(hist) > STALL_N:
            c_adv = (hist[-1][0] - hist[-1 - STALL_N][0]) * sgn
            m_adv = (hist[-1][1] - hist[-1 - STALL_N][1]) * sgn
            if c_adv > 0.5 * STALL_N * STEP and m_adv < STALL_FRAC * c_adv:
                blocked, why = True, f"stopped moving (measured {m_adv:+.3f} of commanded {c_adv:.3f} rad)"
                break
        if lag > LAG_MAX:
            blocked, why = True, f"lag grew {lag:.3f} rad"
            break
    q, tau = meas(0.4)
    reached = float(q[k])
    print(f"   {'BLOCKED (' + why + ')' if blocked else 'reached the URDF-side end'} at measured {reached:+.3f} rad "
          f"({np.degrees(reached):+.1f} deg); command {cmd[k]:+.3f}; torque {tau[k]:+.2f} Nm", flush=True)
    # back off: first 0.1 rad from where it stopped, then the base pose, then home
    back = cmd.copy(); back[k] = reached - sgn * 0.1
    move(back, 2.0)
    move_split(base, 3.0)
    move_split(home, 3.0)
    return {"joint": name, "direction": "+" if sgn > 0 else "-", "urdf_limit": end + sgn * MARGIN,
            "probe_end": end, "blocked": blocked, "why": why, "reached_rad": reached, "reached_deg": float(np.degrees(reached)),
            "torque_at_stop": float(tau[k]), "history": hist}


st = status()
if sys.argv[1:] == ["--recover"]:
    # an aborted probe leaves at most one probed joint (+ the elbow-probe shoulder abduction) off home:
    # retrace = every joint except the shoulder rolls back to 0, then the shoulder rolls
    cur = np.array(st["arm_q_cmd"])
    off_home = [i for i in range(14) if abs(cur[i]) > 0.02 and i not in (1, 8)]
    print("recover from", np.round(cur, 3).tolist(), "joints off home (besides shoulder rolls):", off_home)
    if len(off_home) > 1 or st["state"] != "idle":
        sys.exit("abort: not a single-joint probe state; operator decides")
    step1 = cur.copy(); step1[[i for i in range(14) if i not in (1, 8)]] = 0.0
    move_split(step1, 3.0)
    move_split(np.zeros(14), 3.0)
    print("at home:", np.round(np.array(status()["arm_q"]), 3).tolist())
    sys.exit(0)
if st["state"] != "idle" or np.abs(np.array(st["arm_q_cmd"])).max() > 0.02:
    sys.exit("abort: server not idle or arms not commanded at home (all-zero)")
results = []
try:
    for t in sys.argv[1:]:
        side, joint, d = t.split(":")
        results.append(probe(side, joint, 1.0 if d == "+" else -1.0))
        OUT.write_text(json.dumps(results, indent=1))
except Exception as e:
    print(f"ABORT: {e} -- arm left holding where it is", flush=True)
    OUT.write_text(json.dumps(results, indent=1))
    sys.exit(3)
print("DONE ->", OUT)
