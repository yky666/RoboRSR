# dex1_state.py -- READ-ONLY: print the Dex1 gripper motor states (rt/dex1/{left,right}/state) for a few seconds
import time

from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_go.msg.dds_ import MotorStates_

print("init dds", flush=True)
ChannelFactoryInitialize(0, "eth0")
print("subscribing", flush=True)
latest = {}
subs = {}
for side in ("left", "right"):
    s = ChannelSubscriber(f"rt/dex1/{side}/state", MotorStates_)
    s.Init()
    subs[side] = s
t0 = time.time()
while time.time() - t0 < 3.0:
    for side, s in subs.items():
        m = s.Read(0.05)
        if m is not None:
            latest[side] = [(round(ms.q, 4), round(ms.dq, 4), round(ms.tau_est, 3)) for ms in m.states]
    time.sleep(0.05)
for side in ("left", "right"):
    print(side, "(q, dq, tau) per motor:", latest.get(side, "NO DATA"))
