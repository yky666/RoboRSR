#!/bin/bash
# kill_touch.sh -- end the touch queue / auto_touch WITHOUT stopping the server's current move segment
pkill -f '[t]ouch_queue.sh'
pkill -f '[a]uto_touch.py'
sleep 1
date '+%T'
pgrep -af '[a]uto_touch.py|[t]ouch_queue.sh' || echo "touch processes ended"
cut -c1-160 /tmp/g1d_calib/status.json; echo
grep -v '^     [AB] cmd' /home/unitree/calib_sessions/touch_queue.log | tail -n 3
