#!/bin/bash
# start calib_arm_server holding the CURRENT measured pose (no motion)
PY=/home/unitree/miniconda3/envs/tv/bin/python
if pgrep -f '[c]alib_arm_server.py|[c]alib_ready_pose.py' > /dev/null; then
  echo "another arm controller is running:"; pgrep -af '[c]alib_arm_server.py|[c]alib_ready_pose.py'; exit 1
fi
rm -f /tmp/g1d_calib/status.json
cd /home/unitree/g1d_infra_calib/scripts
nohup $PY -u calib_arm_server.py --yes --vmax ${VMAX:-0.1} > /tmp/g1d_calib_server.log 2>&1 &
for i in $(seq 1 30); do
  sleep 0.5
  grep -q "server ready" /tmp/g1d_calib_server.log && break
done
cat /tmp/g1d_calib_server.log
grep -q "server ready" /tmp/g1d_calib_server.log || { echo "SERVER NOT READY"; exit 1; }
