#!/bin/bash
# touch_queue_right.sh -- background queue of auto_touch.py runs (right arm); stops on the first abort or if STOP_TOUCH exists
# start: setsid nohup bash ~/calib_sessions/touch_queue_right.sh > /dev/null 2>&1 < /dev/null &
cd /home/unitree/calib_sessions || exit 1
PY=/home/unitree/miniconda3/envs/tv/bin/python
LOG=/home/unitree/calib_sessions/touch_queue_right.log
COMMON="right --tip-u 330 --tip-v 265 --tip-depth 0.104 --rolls 15"
echo "=== queue start $(date '+%F %T')" >> $LOG
run() {
    [ -f STOP_TOUCH ] && { echo "=== STOP_TOUCH present, queue stopped $(date '+%T')" >> $LOG; exit 0; }
    echo "=== run: $* ($(date '+%T'))" >> $LOG
    $PY -u auto_touch.py $COMMON "$@" >> $LOG 2>&1
    rc=$?
    [ $rc -ne 0 ] && { echo "=== run exited $rc, queue stopped $(date '+%T')" >> $LOG; exit $rc; }
    sleep 61
}
run --center --max 20 \
    --poses B_right_021,B_right_041,B_right_043,B_right_042,B_right_044,B_right_034,B_right_019
run --center --offsets 0.04:0,-0.04:0,0:0.04,0:-0.04 --max 30 \
    --poses B_right_021,B_right_041,B_right_043,B_right_042
echo "=== queue done $(date '+%T')" >> $LOG
