# calib_ready_pose.py — G1-D 双臂平滑抬到 ready_pose 并保持（标定用）
# 安全设计：
#   1. 启动前检查：lowstate 必须在流、无其他 rt/lowcmd 写入者（--force 可绕过）
#   2. 每关节 |目标-当前| > 1.6 rad 拒绝执行（--force 可绕过）
#   3. smoothstep 缓动（默认 3s），非臂电机锁定在当前位置
#   4. lowstate 断流 >0.5s 或 mode_machine 变化：立即停止发布并退出
#   5. SIGINT/SIGTERM：平滑回到起始姿态后退出（--no-return 直接停发）
# 用法：
#   先干跑:  python calib_ready_pose.py --dry-run
#   实跑:    python calib_ready_pose.py --yes
import argparse
import json
import os
import signal
import sys
import threading
import time

import numpy as np
from unitree_sdk2py.core.channel import (
    ChannelFactory, ChannelPublisher, ChannelSubscriber, ChannelFactoryInitialize)
from unitree_sdk2py.idl.default import unitree_hg_msg_dds__LowCmd_
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowCmd_ as hg_LowCmd
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_ as hg_LowState
from unitree_sdk2py.utils.crc import CRC

NUM_MOTORS = 35
ARM_IDS = list(range(15, 29))          # 左臂15-21 右臂22-28
WAIST_ID = 12
WRIST_IDS = [19, 20, 21, 26, 27, 28]
WEAK_IDS = [4, 10, WAIST_ID]           # 踝pitch + 腰yaw（G1-D无腿，但保留分级）

KP_HIGH, KD_HIGH = 300.0, 3.0
KP_LOW, KD_LOW = 80.0, 3.0
KP_WRIST, KD_WRIST = 40.0, 1.5
KP_WAIST, KD_WAIST = 100.0, 2.0

CONTROL_DT = 1.0 / 250.0
MAX_DELTA = 1.6                        # rad，单关节最大允许位移
CMD_FILE = "/tmp/g1d_calib_arm_cmd"    # 写入 "return" 触发平滑撤回


class LowStateBuf:
    def __init__(self):
        self.data = None
        self.t = 0.0
        self.lock = threading.Lock()

    def set(self, msg):
        with self.lock:
            self.data = msg
            self.t = time.time()

    def get(self):
        with self.lock:
            return self.data, self.t


def smoothstep(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3.0 - 2.0 * x)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pose", default="/home/unitree/g1d_infra/configs/ready_pose.json")
    ap.add_argument("--seconds", type=float, default=3.0)
    ap.add_argument("--return-seconds", type=float, default=3.0)
    ap.add_argument("--no-return", action="store_true")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--yes", action="store_true", help="确认实跑（与--dry-run二选一）")
    args = ap.parse_args()
    if not args.dry_run and not args.yes:
        print("必须显式给 --dry-run 或 --yes")
        sys.exit(64)

    ready = json.load(open(args.pose))["arm_q"]
    assert len(ready) == 14

    ChannelFactoryInitialize(0, "eth0")
    sub = ChannelSubscriber("rt/lowstate", hg_LowState)
    sub.Init()
    buf = LowStateBuf()
    stop_flag = threading.Event()

    def sub_loop():
        while not stop_flag.is_set():
            msg = sub.Read()          # 无超时阻塞读（本机 SDK 版本 Read(timeout) 有bug）
            if msg is not None:
                buf.set(msg)

    th = threading.Thread(target=sub_loop, daemon=True)
    th.start()

    t0 = time.time()
    while buf.get()[0] is None:
        if time.time() - t0 > 10:
            print("FATAL: 10s 无 lowstate"); sys.exit(2)
        time.sleep(0.05)
    msg0, _ = buf.get()
    mode_machine = msg0.mode_machine
    q_now = np.array([msg0.motor_state[i].q for i in range(NUM_MOTORS)])
    print(f"lowstate OK, mode_machine={mode_machine}")
    print("当前臂 q:", np.round(q_now[15:29], 3).tolist())

    # 检查2：目标位移幅度
    target = q_now.copy()
    target[15:22] = ready[0:7]
    target[22:29] = ready[7:14]
    delta = target - q_now
    maxd = np.max(np.abs(delta[ARM_IDS]))
    print(f"最大单关节位移: {maxd:.3f} rad (限制 {MAX_DELTA})")
    print("目标臂 q:", np.round(target[15:29], 3).tolist())
    if maxd > MAX_DELTA and not args.force:
        print("FATAL: 位移过大，--force 才执行"); sys.exit(4)

    if args.dry_run:
        print("DRY-RUN 结束，未发任何指令")
        sys.exit(0)

    # 构建 lowcmd：全电机 mode=1，分级 kp/kd，q=当前
    crc = CRC()
    msg = unitree_hg_msg_dds__LowCmd_()
    msg.mode_pr = 0
    msg.mode_machine = mode_machine
    for i in range(NUM_MOTORS):
        msg.motor_cmd[i].mode = 1
        if i in ARM_IDS:
            if i in WRIST_IDS:
                msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP_WRIST, KD_WRIST
            else:
                msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP_LOW, KD_LOW
        elif i == WAIST_ID:
            msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP_WAIST, KD_WAIST
        elif i in WEAK_IDS:
            msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP_LOW, KD_LOW
        else:
            msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP_HIGH, KD_HIGH
        msg.motor_cmd[i].q = float(q_now[i])
        msg.motor_cmd[i].dq = 0.0
        msg.motor_cmd[i].tau = 0.0

    pub = ChannelPublisher("rt/lowcmd", hg_LowCmd)
    pub.Init()

    q_cmd = q_now.copy()               # 每周期写入的目标（先锁定当前）
    cmd_lock = threading.Lock()
    publish_alive = threading.Event()
    publish_alive.set()
    pub_stats = {"n": 0, "last_warn": 0}

    def pub_loop():
        while publish_alive.is_set():
            t_start = time.time()
            with cmd_lock:
                qc = q_cmd.copy()
            for i in ARM_IDS:
                msg.motor_cmd[i].q = float(qc[i])
                msg.motor_cmd[i].dq = 0.0
                msg.motor_cmd[i].tau = 0.0
            # 腰和非臂电机保持初始 q（不每周期重写）
            msg.crc = crc.Crc(msg)
            pub.Write(msg)
            pub_stats["n"] += 1
            # 心跳检查
            _, t_last = buf.get()
            if time.time() - t_last > 0.5:
                print("\nFATAL: lowstate 断流 >0.5s，停止发布")
                publish_alive.clear()
                break
            m, _ = buf.get()
            if m is not None and m.mode_machine != mode_machine:
                print(f"\nFATAL: mode_machine 变化 {mode_machine}->{m.mode_machine}，停止发布")
                publish_alive.clear()
                break
            time.sleep(max(0.0, CONTROL_DT - (time.time() - t_start)))

    pth = threading.Thread(target=pub_loop, daemon=True)
    pth.start()
    time.sleep(0.5)
    if not publish_alive.is_set():
        sys.exit(5)
    print(f"250Hz 发布已启动（仅臂关节写目标，其余锁定当前位）")

    def move_to(q_dst, seconds):
        """smoothstep 移动到 q_dst（仅臂关节），可被命令文件打断"""
        q_src = None
        with cmd_lock:
            q_src = q_cmd.copy()
        t_start = time.time()
        last_print = -1
        while True:
            el = time.time() - t_start
            x = smoothstep(el / seconds)
            with cmd_lock:
                for i in ARM_IDS:
                    q_cmd[i] = q_src[i] + (q_dst[i] - q_src[i]) * x
            pct = int(x * 100)
            if pct // 20 != last_print:
                last_print = pct // 20
                print(f"  移动 {pct}%")
            if x >= 1.0:
                break
            if not publish_alive.is_set():
                return False
            try:
                if open(CMD_FILE).read().strip() == "return":
                    print("收到撤回指令")
                    return False
            except FileNotFoundError:
                pass
            time.sleep(0.02)
        return publish_alive.is_set()

    print(f"开始 {args.seconds}s smoothstep 抬臂…  (撤回: echo return > {CMD_FILE})")
    ok = move_to(target, args.seconds)
    if ok:
        _, _ = buf.get()
        m, _ = buf.get()
        q_meas = np.array([m.motor_state[i].q for i in range(NUM_MOTORS)])
        err = np.max(np.abs(q_meas[15:29] - target[15:29]))
        print(f"READY POSE REACHED, 保持中…  (实测误差 {err:.3f} rad, 发布 {pub_stats['n']} 条)")

    # 保持循环：等待 SIGINT/SIGTERM 或撤回文件
    got_signal = {"sig": False}

    def on_sig(sig, frame):
        got_signal["sig"] = True

    signal.signal(signal.SIGINT, on_sig)
    signal.signal(signal.SIGTERM, on_sig)

    while ok and not got_signal["sig"]:
        if not publish_alive.is_set():
            break
        try:
            if open(CMD_FILE).read().strip() == "return":
                print("收到撤回指令")
                break
        except FileNotFoundError:
            pass
        time.sleep(0.2)

    if not args.no_return and publish_alive.is_set():
        m, _ = buf.get()
        q_cur = np.array([m.motor_state[i].q for i in range(NUM_MOTORS)]) if m is not None else target
        print(f"平滑回到起始姿态 ({args.return_seconds}s)…")
        move_to(q_now, args.return_seconds)
    publish_alive.clear()
    pth.join(timeout=1.0)
    stop_flag.set()
    print("已停止发布，退出")


if __name__ == "__main__":
    main()
