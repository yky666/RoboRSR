# grab_one.py -- save one frame from a teleimager ZMQ stream
# usage: python grab_one.py <port> <out.png>
import sys

import cv2
import numpy as np
import zmq

s = zmq.Context.instance().socket(zmq.SUB)
s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
s.connect(f"tcp://127.0.0.1:{sys.argv[1]}")
s.recv(); s.recv()
cv2.imwrite(sys.argv[2], cv2.imdecode(np.frombuffer(s.recv(), np.uint8), cv2.IMREAD_COLOR))
s.close(0)
