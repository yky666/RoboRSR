#!/bin/bash
cd /home/unitree/calib_sessions
for i in $(seq 1 30); do grep -q '^DONE' repeat.log && break; sleep 2; done
tail -n 2 repeat.log
D=$(ls -d repeat_2026*_left | sort | tail -1)
echo "analysing $D"
/home/unitree/miniconda3/envs/tv/bin/python repeat_analyze.py "$D"
