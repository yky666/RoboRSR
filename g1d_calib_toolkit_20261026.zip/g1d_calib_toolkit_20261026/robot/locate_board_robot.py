# locate_board_robot.py -- robot-side copy of pc_tools/locate_board.py (local stream, intrinsics in ~/calib_sessions/intrinsics)
# locate_board.py -- measure the table ChArUco board pose in the torso frame with the head stereo cameras
# board: A3 ChArUco 10x7, square 40 mm, marker 30 mm, DICT_4X4_50
import json
from pathlib import Path

import cv2
import numpy as np
import zmq

HERE = Path(__file__).parent
OUT = HERE / "board_locate_now"
OUT.mkdir(parents=True, exist_ok=True)
HOST, PORT = "127.0.0.1", 55555

# T_torso_camworld (camworld: +X fwd, +Y left, +Z up), from contract v5 + URDF FK (head_link fixed to torso)
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838],
                   [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
T_TORSO_CAM = {"head_left": (R_HEAD, np.array([0.04812857, 0.02963228, 0.43599143])),
               "head_right": (R_HEAD, np.array([0.04812857, -0.02996772, 0.43599143]))}
OPTICAL_FROM_CAMERA = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)

board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
_dp = cv2.aruco.DetectorParameters()
_dp.minMarkerPerimeterRate = 0.01
_dp.adaptiveThreshWinSizeMin, _dp.adaptiveThreshWinSizeMax, _dp.adaptiveThreshWinSizeStep = 3, 53, 4
_dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
_cp = cv2.aruco.CharucoParameters()
_cp.minMarkers = 1
det = cv2.aruco.CharucoDetector(board, _cp, _dp)
UPSCALE = 3
OBJ = board.getChessboardCorners()          # (54,3), id = array index
CENTER_B = np.array([0.20, 0.14, 0.0])     # board-frame centre of the 400x280 mm square area


def grab():
    s = zmq.Context.instance().socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{PORT}")
    frames = []
    for _ in range(8):
        frames.append(s.recv())
    s.close(0)
    img = cv2.imdecode(np.frombuffer(frames[-1], np.uint8), cv2.IMREAD_COLOR)
    w = img.shape[1] // 2
    return {"head_left": img[:, :w], "head_right": img[:, w:]}


res = {}
for eye, img in grab().items():
    doc = json.loads((HERE / "intrinsics" / f"camera_intrinsics_{eye}.json").read_text(encoding="utf-8"))
    K, dist = np.array(doc["K"]), np.array(doc["dist"])
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    big = cv2.resize(gray, None, fx=UPSCALE, fy=UPSCALE, interpolation=cv2.INTER_CUBIC)
    cc, ci, mc, mi = det.detectBoard(big)
    if cc is not None:
        cc = ((cc + 0.5) / UPSCALE - 0.5).astype(np.float32)   # back to original pixel coordinates
    if mc is not None:
        mc = tuple(((m + 0.5) / UPSCALE - 0.5).astype(np.float32) for m in mc)
    vis = img.copy()
    if mi is not None:
        cv2.aruco.drawDetectedMarkers(vis, mc, mi)
    n = 0 if ci is None else len(ci)
    print(f"[{eye}] markers={0 if mi is None else len(mi)} charuco_corners={n}")
    if n < 8:
        cv2.imencode(".png", vis)[1].tofile(str(OUT / f"{eye}.png"))
        res[eye] = None
        continue
    obj = OBJ[ci.ravel()].astype(np.float64)
    imgp = cc.reshape(-1, 2).astype(np.float64)
    ok, rvec, tvec = cv2.solvePnP(obj, imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
    ok, rvec, tvec = cv2.solvePnP(obj, imgp, K, dist, rvec, tvec, useExtrinsicGuess=True, flags=cv2.SOLVEPNP_ITERATIVE)
    proj, _ = cv2.projectPoints(obj, rvec, tvec, K, dist)
    rms = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - imgp) ** 2, axis=1))))
    R_ob, _ = cv2.Rodrigues(rvec)                       # board -> optical
    R_tc, t_tc = T_TORSO_CAM[eye]
    R_tb = R_tc @ OPTICAL_FROM_CAMERA.T @ R_ob           # board -> torso
    t_tb = R_tc @ (OPTICAL_FROM_CAMERA.T @ tvec.ravel()) + t_tc
    center = R_tb @ CENTER_B + t_tb
    normal = R_tb[:, 2]                                  # board z (into the board)
    res[eye] = {"corners": n, "reproj_rms_px": round(rms, 3),
                "board_center_torso_m": center.round(4).tolist(),
                "board_x_axis_torso": R_tb[:, 0].round(3).tolist(),
                "board_y_axis_torso": R_tb[:, 1].round(3).tolist(),
                "board_z_axis_torso": normal.round(3).tolist(),
                "T_torso_board": np.vstack([np.hstack([R_tb, t_tb[:, None]]), [0, 0, 0, 1]]).round(5).tolist()}
    for (u, v) in imgp:
        cv2.circle(vis, (int(round(u)), int(round(v))), 2, (0, 255, 0), -1)
    cv2.drawFrameAxes(vis, K, dist, rvec, tvec, 0.1)
    cv2.imencode(".png", vis)[1].tofile(str(OUT / f"{eye}.png"))
    print(f"  reproj RMS {rms:.2f}px | board centre in torso frame (x fwd, y left, z up) = "
          f"({center[0]:.3f}, {center[1]:.3f}, {center[2]:.3f}) m | board z-axis {normal.round(3).tolist()}")

json.dump(res, open(OUT / "board_pose.json", "w"), indent=1)
if res.get("head_left") and res.get("head_right"):
    a = np.array(res["head_left"]["board_center_torso_m"]); b = np.array(res["head_right"]["board_center_torso_m"])
    print(f"left/right eye centre disagreement: {np.linalg.norm(a - b) * 1000:.1f} mm")
