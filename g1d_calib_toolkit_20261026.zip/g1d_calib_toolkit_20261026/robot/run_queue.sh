#!/bin/bash
# background calibration queue on the robot; survives ssh disconnects.
# start:  setsid nohup bash ~/calib_sessions/run_queue.sh left right > /dev/null 2>&1 &
# watch:  tail -f ~/calib_sessions/queue.log
# stop:   touch ~/calib_sessions/STOP   (checked between jobs; to stop mid-session use the e-stop / L2+B)
PY=/home/unitree/miniconda3/envs/tv/bin/python
B=/home/unitree/calib_sessions
LOG=$B/queue.log
rm -f $B/STOP
echo "=== $(date '+%F %T') queue start: $*" >> $LOG
for side in "$@"; do
  if [ -f $B/STOP ]; then echo "=== STOP file found, queue ends" >> $LOG; exit 0; fi
  echo "=== $(date '+%F %T') job collect $side" >> $LOG
  $PY -u $B/collect_robot.py "$side" >> $LOG 2>&1
  rc=$?
  echo "=== $(date '+%F %T') job collect $side finished rc=$rc" >> $LOG
  if [ $rc -ne 0 ]; then echo "=== queue stopped (rc=$rc)" >> $LOG; exit $rc; fi
done
echo "=== $(date '+%F %T') queue done" >> $LOG
