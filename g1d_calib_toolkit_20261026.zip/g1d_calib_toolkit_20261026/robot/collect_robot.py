# collect_robot.py -- doc 02 setup-B collector that runs ON THE ROBOT (immune to PC <-> robot link drops)
# usage: python -u collect_robot.py <left|right> [--max N] [--start K]
# Needs calib_arm_server.py running locally, both arms at home (all-zero), pose tables in POSES dir.
# Safety: single-instance lock, checked-path waypoints only, park on the same line on error,
#         live board-drift monitor via the head camera (board must not move relative to the torso).
import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

BASE = Path.home() / "calib_sessions"
POSES = BASE / os.environ.get("G1D_POSES", "poses_current")      # poses_current -> poses_<date> (symlink)
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
HOST = "127.0.0.1"
WRIST_PORT = {"left": 55556, "right": 55557}  # since 2026-10-21 21:25 (teleimager config): 55556 = LEFT (JR0002), 55557 = RIGHT (JR0001)
HEAD_PORT = 55555
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
ALLJ = [f"{s}_{j}_joint" for s in ("left", "right") for j in ARM]
BOARD_DRIFT_MAX = 0.004   # m, head-camera board position change that aborts the session


# ---------------- local arm-server client ----------------
def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.1)
    return json.loads(STATUS.read_text())


def send(cmd):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(dict(cmd, seq=seq)))
    os.replace(tmp, CMD)
    return seq


def wait_done(seq, timeout):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] == "error":
            raise RuntimeError(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith(("REJECTED", "refused")):
                raise RuntimeError(f"command rejected: {s['msg']}")
            return s
        time.sleep(0.05)
    raise TimeoutError(f"seq {seq} not done after {timeout}s")


def move(arm_q, seconds, timeout=180):
    return wait_done(send({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds}), timeout)


def wait_idle(timeout=180):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] in ("idle", "error"):
            return s
        time.sleep(0.05)
    raise TimeoutError("server not idle")


# ---------------- args / files ----------------
ap = argparse.ArgumentParser()
ap.add_argument("side", choices=["left", "right"])
ap.add_argument("--max", type=int, default=0)
ap.add_argument("--start", type=int, default=0)
a = ap.parse_args()
side = a.side
off = 0 if side == "left" else 7
other = slice(7, 14) if side == "left" else slice(0, 7)
pose_file = POSES / f"poses_{side}.json"
doc = json.loads(pose_file.read_text())
hdr = json.loads((POSES / "scene_header_B.json").read_text())
S = doc["settle"]
poses = doc["setups"]["B_wrist_table_board"]["poses"]
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])

# ---------------- single-instance lock ----------------
LOCKD = CALIB / "collector.lock.d"
try:
    LOCKD.mkdir()
except FileExistsError:
    try:
        holder = json.loads((LOCKD / "info").read_text())
        os.kill(int(holder["pid"]), 0)
        sys.exit(f"abort: another collector is running ({holder})")
    except (ProcessLookupError, ValueError, KeyError, FileNotFoundError, json.JSONDecodeError):
        print("stale lock -> taking over")
(LOCKD / "info").write_text(json.dumps({"pid": os.getpid(), "t": time.time(), "side": side}))

sess = BASE / time.strftime(f"calib_%Y%m%d_%H%M_B_wrist_table_board_{side}")
(sess / "images").mkdir(parents=True)
ctx = zmq.Context.instance()
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.minMarkerPerimeterRate = 0.01
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners()
HK = np.array(hdr["cameras"]["head_left"]["K"]); HD = np.array(hdr["cameras"]["head_left"]["dist"])


def grab(port, n):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")
    s.recv(); s.recv()
    out = []
    for _ in range(n):
        data = s.recv()
        out.append((cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR), time.time()))
    s.close(0)
    return out


def head_board_centre(stereo_img):
    """board centre in the head_left optical frame (m), or None"""
    g = cv2.cvtColor(stereo_img[:, : stereo_img.shape[1] // 2], cv2.COLOR_BGR2GRAY)
    big = cv2.resize(g, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(big)
    if ci is None or len(ci) < 10:
        return None
    imgp = ((cc.reshape(-1, 2) + 0.5) / 2 - 0.5).astype(np.float64)
    ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()].astype(np.float64), imgp, HK, HD, flags=cv2.SOLVEPNP_IPPE)
    return cv2.Rodrigues(rv)[0] @ OBJ.mean(0) + tv.ravel()


def snapshot(st):
    return {"t_robot": st["t"], "q": dict(zip(ALLJ, st["arm_q"])), "dq": dict(zip(ALLJ, st["arm_dq"])),
            "tau": dict(zip(ALLJ, st["arm_tau"])), "all_motor_q": st["all_q"]}


def wait_settle():
    time.sleep(S["min_wait_s"])
    t_end = time.time() + S["timeout_s"]
    hist = []
    while time.time() < t_end:
        st = status()
        hist.append(np.array(st["arm_q"]))
        if len(hist) >= 10:
            rng = np.ptp(np.array(hist[-10:]), axis=0).max()
            if rng < 0.001 and np.abs(st["arm_dq"]).max() < 3 * S["velocity_threshold_rad_s"]:
                return True, float(rng)
        time.sleep(0.05)
    return False, None


def full_target(q7):
    t = np.array(status()["arm_q_cmd"])
    t[off:off + 7] = q7
    return t


def move_line(q7, seconds):
    start = np.array(status()["arm_q_cmd"])
    goal = full_target(q7)
    n = max(1, int(np.ceil(np.abs(goal - start).max() / 1.5)))
    for k in range(1, n + 1):
        move(start + (goal - start) * k / n, seconds=seconds / n)


# ---------------- preflight ----------------
st0 = status()
if st0["state"] != "idle":
    sys.exit(f"abort: server state {st0['state']} ({st0['msg']})")
q0 = np.array(st0["arm_q"])
if np.abs(q0[off:off + 7] - home).max() > 0.1:
    sys.exit(f"abort: {side} arm not at home (max dev {np.abs(q0[off:off + 7] - home).max():.3f} rad)")
start_all = np.array(st0["all_q"])
c0 = head_board_centre(grab(HEAD_PORT, 1)[0][0])
if c0 is None:
    sys.exit("abort: board not visible in the head camera at session start")
session = {
    "format": "g1d_calib_session_v1", "setup": "B_wrist_table_board", "side": side,
    "pose_list": {"file": pose_file.name, "sha256": hashlib.sha256(pose_file.read_bytes()).hexdigest()},
    "joint_mapping": {"file": "joint_mapping.json"},
    "intrinsics_files": {f"{side}_wrist": f"camera_intrinsics_{side}_wrist.json",
                         "head_left": "camera_intrinsics_head_left.json", "head_right": "camera_intrinsics_head_right.json"},
    "camera_ports": {f"{side}_wrist": WRIST_PORT[side], "head_stereo": HEAD_PORT},
    "boards": {"table": {k: v for k, v in hdr["boards"]["table"].items() if k != "points_m"}},
    "clock": "robot time.time() for frames and joint states", "camera_timestamp_meaning": "receive time of the ZMQ JPEG",
    "joint_state_start": snapshot(st0), "board_centre_head_left_optical_start": c0.tolist(),
    "gripper": "not commanded; state as at session start (visible in wrist images)",
    "server_vmax_rad_s": st0["vmax"], "collector": "collect_robot.py (runs on the robot)", "notes": [],
}
(sess / "session.json").write_text(json.dumps(session, indent=1))
print(f"session {sess.name}: {len(poses)} poses, {sum(p.get('skip', False) for p in poses)} flagged skip; "
      f"vmax {st0['vmax']}; board centre (head) {np.round(c0, 4).tolist()}", flush=True)

# ---------------- loop ----------------
trail = [("home", home.copy(), True)]
aborted = False


def abort_and_park(where, err):
    global aborted
    aborted = True
    print(f"ABORT at {where}: {err}", flush=True)
    session["notes"].append(f"aborted at {where}: {err}")
    try:
        send({"cmd": "stop"})
        s = wait_idle()
        if s["state"] == "error":
            print(f"  server error latched ({s['msg']}); arm holds its measured pose. Operator check required.", flush=True)
            return
        print(f"  parking on the same line at last waypoint {trail[-1][0]}", flush=True)
        move_line(trail[-1][1], 3.0)
        print("  parked; not moving further.", flush=True)
    except Exception as e2:
        print(f"  parking failed: {e2}. Arm holds where it is.", flush=True)


n_ok, fails_in_row = 0, 0
with open(sess / "samples.jsonl", "a") as fs:
    for p in poses[a.start:]:
        if a.max and n_ok >= a.max:
            break
        pid = p["id"]
        if p.get("skip"):
            print(f"  {pid}: SKIP (flagged)", flush=True)
            continue
        q_t = np.array([p["joints"][f"{side}_{j}_joint"] for j in ARM])
        try:
            if p.get("transition_actual") == "via_home" and trail[-1][0] != "home":
                move_line(home, 3.0)
                trail.append(("home", home.copy(), True))
            t_cmd = time.time()
            move_line(q_t, p["move_duration_s"])
            trail.append((pid, q_t.copy(), bool(p.get("home_path_ok", False))))
        except Exception as e:
            abort_and_park(pid, e)
            break
        ok, rng = wait_settle()
        if not ok:
            print(f"  {pid}: not settled, skip", flush=True)
            continue
        jb = snapshot(status())
        wrist = grab(WRIST_PORT[side], S["frames_per_pose"])
        head = grab(HEAD_PORT, 1)
        ja = snapshot(status())
        drift = max(abs(ja["q"][k] - jb["q"][k]) for k in ALLJ)
        if drift > 0.002:
            print(f"  {pid}: moved during capture ({drift:.4f} rad), reject", flush=True)
            continue
        oth = np.abs(np.array(ja["all_motor_q"]) - start_all)
        if oth[15:29][other].max() > 0.02 or oth[12] > 0.01:
            abort_and_park(pid, f"other arm / waist drift {oth[15:29][other].max():.4f} / {oth[12]:.4f} rad")
            break
        c = head_board_centre(head[0][0])
        bdrift = None if c is None else float(np.linalg.norm(c - c0))
        if bdrift is not None and bdrift > BOARD_DRIFT_MAX:
            abort_and_park(pid, f"BOARD MOVED {bdrift * 1000:.1f} mm (head camera)")
            break
        d = sess / "images" / pid
        d.mkdir(exist_ok=True)
        frames = []
        for k, (img, t) in enumerate(wrist):
            fn = f"images/{pid}/{side}_wrist_{k}.png"
            cv2.imwrite(str(sess / fn), img)
            frames.append({"file": fn, "t": t})
        cv2.imwrite(str(d / "head_stereo.png"), head[0][0])
        g = cv2.resize(cv2.cvtColor(wrist[0][0], cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
        cc, ci, _, _ = det.detectBoard(g)
        ncorn = 0 if ci is None else len(ci)
        fails_in_row = fails_in_row + 1 if ncorn < 6 else 0
        rec = {"id": pid, "pose_id": pid, "t_command": t_cmd, "t_settled": time.time(),
               "q_target": {f"{side}_{j}_joint": float(v) for j, v in zip(ARM, q_t)},
               "joints_before": jb, "joints_after": ja,
               "frames": {f"{side}_wrist": frames, "head_stereo": [{"file": f"images/{pid}/head_stereo.png", "t": head[0][1]}]},
               "settle": {"q_range_rad": rng}, "live_charuco_corners": ncorn, "board_drift_head_m": bdrift,
               "expected_corners": p["expected_nominal"][f"{side}_wrist"]["visible_corners"], "flags": []}
        fs.write(json.dumps(rec) + "\n"); fs.flush()
        n_ok += 1
        err = np.abs(np.array([jb["q"][f"{side}_{j}_joint"] for j in ARM]) - q_t).max()
        print(f"  {pid}: OK corners {ncorn:2d} (exp {rec['expected_corners']:2d}) track err {err:.3f} "
              f"board drift {('%.1f mm' % (bdrift * 1000)) if bdrift is not None else 'n/a'}", flush=True)
        if fails_in_row >= 3:
            abort_and_park(pid, "3 poses in a row without board detection")
            break

if not aborted:
    try:
        while not trail[-1][2]:
            trail.pop()
            print(f"  retreat to {trail[-1][0]}", flush=True)
            move_line(trail[-1][1], 3.0)
        if trail[-1][0] != "home":
            move_line(home, 3.0)
        print("  back at home", flush=True)
    except Exception as e:
        abort_and_park("return home", e)
session["joint_state_end"] = snapshot(status())
session["n_samples"] = n_ok
(sess / "session.json").write_text(json.dumps(session, indent=1))
try:
    (LOCKD / "info").unlink(); LOCKD.rmdir()
except OSError:
    pass
print(f"DONE {n_ok} samples -> {sess} {'(ABORTED)' if aborted else ''}", flush=True)
sys.exit(3 if aborted else 0)
