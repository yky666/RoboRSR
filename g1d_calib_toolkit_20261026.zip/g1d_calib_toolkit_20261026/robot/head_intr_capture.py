# head_intr_capture.py -- robot side, live: save head stereo frames for the intrinsics / stereo recalibration while a
# person holds the A3 ChArUco board (10x7, 40/30 mm, DICT_4X4_50). A frame is kept when both eyes see >= 12 corners,
# the board is still (corners moved < 1.5 px since the previous detection) and the view is new (mean corner position
# differs by > 25 px from every saved view, or the board looks different in size by > 15 %). Coverage of a 6 x 4 grid
# per eye is written to status.txt for the operator. Stop: touch <out>/STOP or --minutes.
import argparse
import json
import os
import time

import cv2
import numpy as np
import zmq

ap = argparse.ArgumentParser()
ap.add_argument("--out", required=True)
ap.add_argument("--minutes", type=float, default=20)
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.minMarkerPerimeterRate = 0.01
dp.adaptiveThreshWinSizeMin, dp.adaptiveThreshWinSizeMax, dp.adaptiveThreshWinSizeStep = 3, 53, 6
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
cp = cv2.aruco.CharucoParameters()
cp.minMarkers = 1
det = cv2.aruco.CharucoDetector(board, cp, dp)
UP = 2
GX, GY = 6, 4

s = zmq.Context.instance().socket(zmq.SUB)
s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 2000); s.setsockopt(zmq.SUBSCRIBE, b"")
s.connect("tcp://127.0.0.1:55555")


def detect(gray):
    g = cv2.resize(gray, None, fx=UP, fy=UP, interpolation=cv2.INTER_LINEAR)
    cc, ci, _, _ = det.detectBoard(g)
    if ci is None or len(ci) < 12:
        return None
    return {int(i): ((c + 0.5) / UP - 0.5) for i, c in zip(ci.ravel(), cc.reshape(-1, 2))}


cover = {"L": np.zeros((GY, GX), int), "R": np.zeros((GY, GX), int)}
saved, prev = [], None
t0, last_status = time.time(), 0.0
while time.time() - t0 < a.minutes * 60 and not os.path.exists(os.path.join(a.out, "STOP")):
    try:
        buf = s.recv()
    except Exception:
        continue
    img = cv2.imdecode(np.frombuffer(buf, np.uint8), cv2.IMREAD_COLOR)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    w = gray.shape[1] // 2
    L, R = detect(gray[:, :w]), detect(gray[:, w:])
    msg = ""
    if L and R:
        common = sorted(set(L) & (set(prev[0]) if prev else set()))
        still = bool(prev) and len(common) >= 8 and max(np.linalg.norm(L[i] - prev[0][i]) for i in common) < 1.5
        cL = np.mean(list(L.values()), 0)
        size = np.ptp(np.array(list(L.values())), 0).max()
        new = all(np.linalg.norm(cL - c) > 25 or abs(size / sz - 1) > 0.15 for c, sz in saved)
        if still and new:
            k = len(saved)
            cv2.imwrite(os.path.join(a.out, f"stereo_{k:03d}.png"), img)
            json.dump({"t": time.time(), "L": {i: p.tolist() for i, p in L.items()}, "R": {i: p.tolist() for i, p in R.items()}},
                      open(os.path.join(a.out, f"stereo_{k:03d}.json"), "w"))
            saved.append((cL, size))
            for eye, D in (("L", L), ("R", R)):
                for p in D.values():
                    cover[eye][min(GY - 1, int(p[1] / 480 * GY)), min(GX - 1, int(p[0] / w * GX))] += 1
            msg = f"saved #{k} (L {len(L)} / R {len(R)} corners)"
        prev = (L, R)
    else:
        prev = None
    if msg or time.time() - last_status > 3:
        last_status = time.time()
        rows = []
        for r in range(GY):
            rows.append(" ".join("#" if cover["L"][r, c] else "." for c in range(GX)) + "   " +
                        " ".join("#" if cover["R"][r, c] else "." for c in range(GX)))
        miss = [(r, c) for r in range(GY) for c in range(GX) if not cover["L"][r, c] or not cover["R"][r, c]]
        txt = (f"t={time.time() - t0:5.0f}s saved {len(saved)}  now: L {0 if not L else len(L)} R {0 if not R else len(R)} corners  {msg}\n"
               "coverage (left eye | right eye), rows top->bottom:\n" + "\n".join(rows) +
               f"\nmissing cells (row, col): {miss}\n")
        open(os.path.join(a.out, "status.txt"), "w").write(txt)
        if msg:
            print(txt, flush=True)
print("done", len(saved), flush=True)
