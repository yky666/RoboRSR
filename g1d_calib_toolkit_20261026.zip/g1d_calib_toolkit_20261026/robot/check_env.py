import cv2
import numpy
import zmq

print("cv2", cv2.__version__, "aruco", hasattr(cv2, "aruco"), "CharucoDetector", hasattr(cv2.aruco, "CharucoDetector"))
print("zmq", zmq.__version__, "numpy", numpy.__version__)
