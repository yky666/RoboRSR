# head_intr_calib.py -- robot side: recalibrate the head stereo from head_intr_capture.py frames (ChArUco detections).
#   per eye: calibrateCamera (k1 k2 p1 p2 k3, old K as the initial guess), 5-fold held-out RMS
#   old vs new intrinsics on these frames (per-frame pose refitted), split by image band (lower band = rows >= 360)
#   stereoCalibrate with the new intrinsics fixed (common corner ids)
# usage: head_intr_calib.py <capture_dir> <old_intrinsics_dir>
import glob
import json
import os
import sys

import cv2
import numpy as np

CAP, OLD = sys.argv[1], sys.argv[2]
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
OBJ = board.getChessboardCorners().astype(np.float32)
SIZE = (640, 480)
frames = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(CAP, "stereo_*.json")))]
print(f"{len(frames)} stereo frames")


def views(eye):
    obj, img = [], []
    for fr in frames:
        ids = sorted(fr[eye], key=int)
        obj.append(OBJ[[int(i) for i in ids]])
        img.append(np.array([fr[eye][i] for i in ids], np.float32))
    return obj, img


def per_view_rms(obj, img, K, D, band=None):
    errs = []
    for o, p in zip(obj, img):
        ok, rv, tv = cv2.solvePnP(o, p, K, D, flags=cv2.SOLVEPNP_IPPE)
        ok, rv, tv = cv2.solvePnP(o, p, K, D, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
        pr, _ = cv2.projectPoints(o, rv, tv, K, D)
        e = np.linalg.norm(pr.reshape(-1, 2) - p, axis=1)
        if band is not None:
            e = e[band(p)]
        errs.append(e)
    e = np.concatenate(errs)
    return float(np.sqrt(np.mean(e ** 2))) if len(e) else float("nan"), int(len(e))


res = {}
new = {}
for eye, name in (("L", "head_left"), ("R", "head_right")):
    old = json.load(open(os.path.join(OLD, f"camera_intrinsics_{name}.json")))
    K0, D0 = np.array(old["K"]), np.array(old["dist"])
    obj, img = views(eye)
    flags = cv2.CALIB_USE_INTRINSIC_GUESS
    rms, K, D, _, _ = cv2.calibrateCamera(obj, img, SIZE, K0.copy(), D0.copy().reshape(1, 5), flags=flags)
    D = D.ravel()
    # 5-fold held-out
    idx = np.arange(len(obj))
    ho = []
    for k in range(5):
        tr = [i for i in idx if i % 5 != k]; te = [i for i in idx if i % 5 == k]
        _, Kk, Dk, _, _ = cv2.calibrateCamera([obj[i] for i in tr], [img[i] for i in tr], SIZE, K0.copy(), D0.copy().reshape(1, 5), flags=flags)
        ho.append(per_view_rms([obj[i] for i in te], [img[i] for i in te], Kk, Dk.ravel())[0])
    lower = lambda p: p[:, 1] >= 360
    upper = lambda p: p[:, 1] < 360
    res[name] = {
        "n_views": len(obj), "train_rms_px": round(rms, 3), "heldout_rms_px_5fold": round(float(np.mean(ho)), 3),
        "K_new": np.round(K, 3).tolist(), "dist_new": np.round(D, 5).tolist(),
        "K_old": np.round(K0, 3).tolist(), "dist_old": np.round(D0, 5).tolist(),
        "old_on_these_frames": {"all": per_view_rms(obj, img, K0, D0), "rows<360": per_view_rms(obj, img, K0, D0, upper),
                                "rows>=360": per_view_rms(obj, img, K0, D0, lower)},
        "new_on_these_frames": {"all": per_view_rms(obj, img, K, D), "rows<360": per_view_rms(obj, img, K, D, upper),
                                "rows>=360": per_view_rms(obj, img, K, D, lower)},
    }
    new[name] = (K, D, old)
    print(name, json.dumps({k: v for k, v in res[name].items() if k not in ("K_old", "dist_old")}))

# stereo with the new intrinsics fixed
objs, pl, pr = [], [], []
for fr in frames:
    ids = sorted(set(fr["L"]) & set(fr["R"]), key=int)
    if len(ids) < 8:
        continue
    objs.append(OBJ[[int(i) for i in ids]])
    pl.append(np.array([fr["L"][i] for i in ids], np.float32))
    pr.append(np.array([fr["R"][i] for i in ids], np.float32))
KL, DL, _ = new["head_left"]; KR, DR, _ = new["head_right"]
srms, _, _, _, _, R, T, _, _ = cv2.stereoCalibrate(objs, pl, pr, KL, DL, KR, DR, SIZE, flags=cv2.CALIB_FIX_INTRINSIC)
rv = np.degrees(cv2.Rodrigues(R)[0].ravel())
res["stereo"] = {"pairs": len(objs), "stereo_rms_px": round(srms, 3), "R_right_from_left": R.tolist(),
                 "T_right_from_left_m": T.ravel().tolist(), "rotvec_deg": np.round(rv, 3).tolist(),
                 "baseline_mm": round(float(np.linalg.norm(T) * 1000), 2), "convention": "X_right = R X_left + T (OpenCV optical)"}
print("stereo", json.dumps({k: v for k, v in res["stereo"].items() if k != "R_right_from_left"}))
for name, (K, D, old) in new.items():
    doc = dict(old)
    doc.update({"K": K.tolist(), "dist": D.tolist(), "rms_px": res[name]["train_rms_px"],
                "heldout_rms_px": res[name]["heldout_rms_px_5fold"], "n_images": res[name]["n_views"],
                "board": {"type": "charuco", "squares_x": 10, "squares_y": 7, "square_length_m": 0.04, "marker_length_m": 0.03,
                          "dictionary": "DICT_4X4_50"},
                "notes": "2026-10-23 recalibration with full-field coverage incl. the lower quarter (hand-held ChArUco, "
                         "head_intr_capture.py); previous file kept as *_20261016.json",
                "created": "2026-10-23"})
    json.dump(doc, open(os.path.join(CAP, f"camera_intrinsics_{name}.json"), "w"), indent=2, ensure_ascii=False)
json.dump(res["stereo"], open(os.path.join(CAP, "head_stereo_extrinsics.json"), "w"), indent=1)
json.dump(res, open(os.path.join(CAP, "head_recalib_report.json"), "w"), indent=1)
