# go_home.py -- return one arm to home ONLY if it is parked at a pose-table pose whose pose->home path was checked
# usage: python -u go_home.py <left|right> [--via POSE_ID] [--near POSE_ID TOL_RAD] [--dry]
#   --via:  the arm is stopped part-way on the joint-space line between POSE_ID and another pose-table pose;
#           retrace that line back to POSE_ID first
#   --near: the arm is within TOL_RAD (every joint) of POSE_ID, e.g. after a small sideways shift / roll at the
#           hover height; move straight back to POSE_ID first
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

POSES = Path.home() / "calib_sessions" / os.environ.get("G1D_POSES", "poses_current")
CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
side = sys.argv[1]
off = 0 if side == "left" else 7
doc = json.loads((POSES / f"poses_{side}.json").read_text())
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])
poses = doc["setups"]["B_wrist_table_board"]["poses"]


def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.05)
    return json.loads(STATUS.read_text())


def move(arm_q, seconds):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds, "seq": seq}))
    os.replace(tmp, CMD)
    t0 = time.time()
    while time.time() - t0 < 120:
        s = status()
        if s["state"] == "error":
            sys.exit(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith(("REJECTED", "refused")):
                sys.exit(s["msg"])
            return s
        time.sleep(0.02)
    sys.exit("move timeout")


def move_line(q7, seconds):
    start = np.array(status()["arm_q_cmd"])
    goal = start.copy(); goal[off:off + 7] = q7
    n = max(1, int(np.ceil(np.abs(goal - start).max() / 1.5)))
    for k in range(1, n + 1):
        move(start + (goal - start) * k / n, seconds / n)


def pq(p):
    return np.array([p["joints"][f"{side}_{j}_joint"] for j in ARM])


s = status()
if s["state"] != "idle":
    sys.exit(f"abort: server state {s['state']}")
q = np.array(s["arm_q_cmd"])[off:off + 7]
if np.abs(q - home).max() < 0.02:
    print("already at home"); sys.exit(0)

if "--via" in sys.argv:
    via = next(p for p in poses if p["id"] == sys.argv[sys.argv.index("--via") + 1])
    a0 = pq(via)
    fits = []
    for p in poses + [{"id": "home", "joints": doc["home"]}]:
        u = pq(p) - a0
        if u @ u < 1e-6:
            continue
        t = float(np.clip((q - a0) @ u / (u @ u), 0, 1))
        fits.append((np.abs(q - (a0 + t * u)).max(), t, p["id"]))
    r, t, other = min(fits)
    print(f"on line {via['id']} -> {other} at t={t:.2f}, off-line {r:.4f} rad")
    if r > 0.02:
        sys.exit("abort: arm is not on a line from the --via pose; operator decides")
    if "--dry" in sys.argv:
        sys.exit(0)
    if other == "home" and via.get("home_path_ok"):
        move_line(home, via["move_duration_s"])          # rest of the checked pose -> home path
        print("at home:", np.round(np.array(status()["arm_q"])[off:off + 7], 3).tolist())
        sys.exit(0)
    move_line(a0, 3.0)
    q = np.array(status()["arm_q_cmd"])[off:off + 7]
    print(f"back at {via['id']}")

if "--near" in sys.argv:
    k = sys.argv.index("--near")
    near = next(p for p in poses if p["id"] == sys.argv[k + 1])
    tol = float(sys.argv[k + 2])
    d = q - pq(near)
    print(f"joint offsets from {near['id']} (rad): {np.round(d, 3).tolist()}")
    if np.abs(d).max() > tol:
        sys.exit(f"abort: max offset {np.abs(d).max():.3f} > {tol}; operator decides")
    if "--dry" in sys.argv:
        sys.exit(0)
    move_line(pq(near), 4.0)
    q = np.array(status()["arm_q_cmd"])[off:off + 7]
    print(f"back at {near['id']}")

best = min(poses, key=lambda p: np.abs(q - pq(p)).max())
d = np.abs(q - pq(best)).max()
print(f"nearest pose {best['id']}  max joint diff {d:.3f} rad  home_path_ok={best.get('home_path_ok')}")
if d > 0.05 or not best.get("home_path_ok"):
    sys.exit("abort: not parked at a pose with a checked path to home; operator decides")
if "--dry" in sys.argv:
    sys.exit(0)
move_line(home, best["move_duration_s"])
print("at home:", np.round(np.array(status()["arm_q"])[off:off + 7], 3).tolist())
