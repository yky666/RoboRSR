# calib_arm_server.py -- G1-D dual-arm position server for calibration (direction check / data collection)
#
# Starts by HOLDING the current measured pose (no motion). Commands arrive as JSON in CMD_PATH
# (written atomically by the PC client); status is written to STATUS_PATH every 50 ms.
#
# Commands ({"seq": int, "cmd": ...}):
#   move  : {"arm_q": [14 floats], "seconds": s}   left 7 then right 7, URDF joint values (= motor q)
#   jog   : {"motor": 15..28, "delta": d, "seconds": s}   |d| <= 0.1 rad, relative to current target
#   stop  : freeze at the current commanded point
#   reset : clear an error latch (after a tracking-error abort) -- operator must confirm first
#   return: move back to the startup pose, then exit
#
# Safety:
#   * per-joint URDF limits with 0.05 rad margin; reject any target outside
#   * single command max |delta| 1.6 rad; quintic min-jerk profile, duration stretched so that
#     peak joint speed <= --vmax (default 0.1 rad/s)
#   * tracking error > 0.2 rad on any arm joint -> hold at measured q, latch ERROR, refuse motion
#   * lowstate stale > 0.5 s or mode_machine change -> stop publishing and exit (same as ready_pose)
# Usage:  python calib_arm_server.py --yes [--vmax 0.1]
import argparse
import json
import os
import signal
import sys
import threading
import time

import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelPublisher, ChannelSubscriber
from unitree_sdk2py.idl.default import unitree_hg_msg_dds__LowCmd_
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowCmd_ as hg_LowCmd
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_ as hg_LowState
from unitree_sdk2py.utils.crc import CRC

NUM_MOTORS = 35
ARM_IDS = list(range(15, 29))          # left 15-21, right 22-28
WAIST_ID = 12
WRIST_IDS = [19, 20, 21, 26, 27, 28]
WEAK_IDS = [4, 10, WAIST_ID]
KP_HIGH, KD_HIGH = 300.0, 3.0
KP_LOW, KD_LOW = 80.0, 3.0
KP_WRIST, KD_WRIST = 40.0, 1.5
KP_WAIST, KD_WAIST = 100.0, 2.0
WAIST_LIMIT, WAIST_MAX_DELTA = 0.5, 0.6     # rad: 'waist' command range / single-move size
CONTROL_DT = 1.0 / 250.0

# URDF limits (rad), order = motors 15..28 (left pitch,roll,yaw,elbow,wroll,wpitch,wyaw, right ...)
LIMITS = np.array([[-3.0892, 2.6704], [-1.5882, 2.2515], [-2.618, 2.618], [-1.0472, 2.0944],
                   [-1.972222, 1.972222], [-1.614430, 1.614430], [-1.614430, 1.614430],
                   [-3.0892, 2.6704], [-2.2515, 1.5882], [-2.618, 2.618], [-1.0472, 2.0944],
                   [-1.972222, 1.972222], [-1.614430, 1.614430], [-1.614430, 1.614430]])
LIMIT_MARGIN = 0.05
MAX_DELTA = 1.6
MAX_JOG = 0.1
TRACK_ERR = 0.2
# hand-guiding ("free") mode for touch teaching: zero stiffness, light damping, command follows measurement
FREE_KD = {"big": 1.0, "wrist": 0.4}
FREE_TIMEOUT = 90.0     # s, auto re-stiffen
SIDE_IDS = {"left": list(range(15, 22)), "right": list(range(22, 29))}

DIR = "/tmp/g1d_calib"
CMD_PATH = os.path.join(DIR, "cmd.json")
STATUS_PATH = os.path.join(DIR, "status.json")


def minjerk(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * x * (10.0 - 15.0 * x + 6.0 * x * x)


class StateBuf:
    def __init__(self):
        self.msg, self.t = None, 0.0
        self.lock = threading.Lock()

    def set(self, m):
        with self.lock:
            self.msg, self.t = m, time.time()

    def get(self):
        with self.lock:
            return self.msg, self.t


def write_json_atomic(path, obj):
    tmp = f"{path}.{os.getpid()}.tmp"      # per-process tmp: two instances must not clobber each other
    with open(tmp, "w") as f:
        json.dump(obj, f)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vmax", type=float, default=0.1, help="peak joint speed rad/s")
    ap.add_argument("--yes", action="store_true")
    ap.add_argument("--init-pose", help="json with 'arm_q' (14): hold this target instead of the measured q "
                                        "(seamless takeover from calib_ready_pose.py holding the same pose)")
    args = ap.parse_args()
    if not args.yes:
        print("need --yes"); sys.exit(64)
    os.makedirs(DIR, exist_ok=True)
    if os.path.exists(CMD_PATH):
        os.remove(CMD_PATH)

    ChannelFactoryInitialize(0, "eth0")
    sub = ChannelSubscriber("rt/lowstate", hg_LowState)
    sub.Init()
    buf = StateBuf()
    stop_sub = threading.Event()

    def sub_loop():
        while not stop_sub.is_set():
            m = sub.Read()
            if m is not None:
                buf.set(m)

    threading.Thread(target=sub_loop, daemon=True).start()
    t0 = time.time()
    while buf.get()[0] is None:
        if time.time() - t0 > 10:
            print("FATAL: no lowstate"); sys.exit(2)
        time.sleep(0.05)
    m0, _ = buf.get()
    mode_machine = m0.mode_machine
    q_start = np.array([m0.motor_state[i].q for i in range(NUM_MOTORS)])
    print(f"lowstate OK mode_machine={mode_machine}; holding current pose")
    print("arm q:", np.round(q_start[15:29], 3).tolist())
    q_hold = q_start.copy()
    if args.init_pose:
        init = np.array(json.load(open(args.init_pose))["arm_q"], dtype=float)
        dev = np.abs(init - q_start[ARM_IDS]).max()
        print(f"init pose given; max |init - measured| = {dev:.3f} rad")
        if dev > 0.1:
            print("FATAL: init pose too far from measured pose"); sys.exit(3)
        q_hold[ARM_IDS] = init

    crc = CRC()
    msg = unitree_hg_msg_dds__LowCmd_()
    msg.mode_pr = 0
    msg.mode_machine = mode_machine
    for i in range(NUM_MOTORS):
        msg.motor_cmd[i].mode = 1
        if i in ARM_IDS:
            kp, kd = (KP_WRIST, KD_WRIST) if i in WRIST_IDS else (KP_LOW, KD_LOW)
        elif i == WAIST_ID:
            kp, kd = KP_WAIST, KD_WAIST
        elif i in WEAK_IDS:
            kp, kd = KP_LOW, KD_LOW
        else:
            kp, kd = KP_HIGH, KD_HIGH
        msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = kp, kd
        msg.motor_cmd[i].q = float(q_hold[i])
        msg.motor_cmd[i].dq = 0.0
        msg.motor_cmd[i].tau = 0.0
    pub = ChannelPublisher("rt/lowcmd", hg_LowCmd)
    pub.Init()

    q_cmd = q_hold.copy()
    lock = threading.Lock()
    alive = threading.Event(); alive.set()
    st = {"state": "idle", "seq_done": 0, "msg": "", "n_pub": 0, "free_ids": [], "free_side": None, "free_t0": 0.0}
    KP0 = {i: msg.motor_cmd[i].kp for i in ARM_IDS}
    KD0 = {i: msg.motor_cmd[i].kd for i in ARM_IDS}

    def pub_loop():
        while alive.is_set():
            ts = time.time()
            free_ids = st["free_ids"]
            if free_ids:
                m_now, _ = buf.get()
                with lock:
                    for i in free_ids:
                        q_cmd[i] = m_now.motor_state[i].q     # follow the hand, no spring-back
            with lock:
                qc = q_cmd.copy()
            for i in ARM_IDS + [WAIST_ID]:
                msg.motor_cmd[i].q = float(qc[i])
            msg.crc = crc.Crc(msg)
            pub.Write(msg)
            st["n_pub"] += 1
            m, tl = buf.get()
            if time.time() - tl > 0.5:
                print("\nFATAL: lowstate stale >0.5s, stop publishing"); alive.clear(); break
            if m.mode_machine != mode_machine:
                print(f"\nFATAL: mode_machine {mode_machine}->{m.mode_machine}, stop publishing"); alive.clear(); break
            time.sleep(max(0.0, CONTROL_DT - (time.time() - ts)))

    threading.Thread(target=pub_loop, daemon=True).start()

    def measured():
        m, _ = buf.get()
        q = np.array([m.motor_state[i].q for i in range(NUM_MOTORS)])
        dq = np.array([m.motor_state[i].dq for i in range(NUM_MOTORS)])
        tau = np.array([m.motor_state[i].tau_est for i in range(NUM_MOTORS)])
        return q, dq, tau

    def write_status():
        q, dq, tau = measured()
        with lock:
            qc = q_cmd[15:29].tolist()
        write_json_atomic(STATUS_PATH, {
            "t": time.time(), "state": st["state"], "seq_done": st["seq_done"], "msg": st["msg"],
            "arm_q": q[15:29].tolist(), "arm_dq": dq[15:29].tolist(), "arm_tau": tau[15:29].tolist(),
            "arm_q_cmd": qc, "all_q": q.tolist(), "waist_q_cmd": float(q_cmd[WAIST_ID]),
            "mode_machine": mode_machine, "vmax": args.vmax,
            "n_pub": st["n_pub"], "pid": os.getpid(), "free_side": st["free_side"]})

    def set_free(side):
        ids = SIDE_IDS[side]
        q, _, _ = measured()
        with lock:
            q_cmd[ids] = q[ids]
        for i in ids:
            msg.motor_cmd[i].kp = 0.0
            msg.motor_cmd[i].kd = FREE_KD["wrist"] if i in WRIST_IDS else FREE_KD["big"]
        st["free_ids"], st["free_side"], st["free_t0"] = ids, side, time.time()
        st["state"] = "free"

    def set_hold():
        ids = st["free_ids"]
        st["free_ids"] = []
        time.sleep(3 * CONTROL_DT)            # let pub_loop stop following
        q, _, _ = measured()
        with lock:
            q_cmd[ids] = q[ids]               # stiffen exactly where the hand left it -> no jump
        for i in ids:
            msg.motor_cmd[i].kp, msg.motor_cmd[i].kd = KP0[i], KD0[i]
        side = st["free_side"]
        st["free_side"] = None
        if st["state"] == "free":
            st["state"] = "idle"
        return side

    got_sig = {"v": False}
    signal.signal(signal.SIGINT, lambda s, f: got_sig.__setitem__("v", True))
    signal.signal(signal.SIGTERM, lambda s, f: got_sig.__setitem__("v", True))

    def read_cmd():
        try:
            with open(CMD_PATH) as f:
                c = json.load(f)
            return c if int(c.get("seq", 0)) > st["seq_done"] else None
        except (FileNotFoundError, json.JSONDecodeError, ValueError):
            return None

    def track_check():
        q, _, _ = measured()
        with lock:
            err = np.abs(q[ARM_IDS] - q_cmd[ARM_IDS])
        for i in st["free_ids"]:              # the hand-guided arm is not tracked
            err[ARM_IDS.index(i)] = 0.0
        if err.max() > TRACK_ERR:
            k = ARM_IDS[int(np.argmax(err))]
            with lock:
                q_cmd[ARM_IDS] = q[ARM_IDS]
            st["state"] = "error"
            st["msg"] = f"tracking error {err.max():.3f} rad on motor {k}; holding measured pose"
            print("ABORT:", st["msg"])
            return False
        return True

    def run_move(q_dst_arm, seconds, seq):
        """q_dst_arm: 14 values. Returns True when finished, False if interrupted/aborted."""
        with lock:
            src = q_cmd[ARM_IDS].copy()
        delta = np.abs(q_dst_arm - src)
        dur = max(float(seconds), 1.875 * float(delta.max()) / args.vmax, 0.5)
        st["state"], st["msg"] = "moving", f"seq {seq}: {dur:.1f}s, max delta {delta.max():.3f} rad"
        print(st["msg"])
        ts, last_status = time.time(), 0.0
        while True:
            x = minjerk((time.time() - ts) / dur)
            with lock:
                q_cmd[ARM_IDS] = src + (q_dst_arm - src) * x
            if not alive.is_set() or got_sig["v"]:
                return False
            if not track_check():
                return False
            c = read_cmd()
            if c is not None and c.get("cmd") == "stop":
                st["seq_done"], st["state"], st["msg"] = int(c["seq"]), "idle", "stopped by command"
                print("STOP received; frozen")
                return False
            if time.time() - last_status > 0.05:
                write_status(); last_status = time.time()
            if x >= 1.0:
                return True
            time.sleep(0.01)

    def run_waist(q_dst, seq):
        """waist yaw (motor 12) to q_dst with the same min-jerk profile / vmax; arms keep their commanded pose"""
        with lock:
            src = float(q_cmd[WAIST_ID])
        dur = max(3.0, 1.875 * abs(q_dst - src) / args.vmax)
        st["state"], st["msg"] = "moving", f"seq {seq}: waist {src:+.3f} -> {q_dst:+.3f} rad in {dur:.1f}s"
        print(st["msg"])
        ts, last_status = time.time(), 0.0
        while True:
            x = minjerk((time.time() - ts) / dur)
            with lock:
                q_cmd[WAIST_ID] = src + (q_dst - src) * x
            if not alive.is_set() or got_sig["v"]:
                return False
            if not track_check():
                return False
            q, _, _ = measured()
            with lock:
                werr = abs(q[WAIST_ID] - q_cmd[WAIST_ID])
            if werr > TRACK_ERR:
                with lock:
                    q_cmd[WAIST_ID] = q[WAIST_ID]
                st["state"] = "error"
                st["msg"] = f"waist tracking error {werr:.3f} rad; holding measured waist"
                print("ABORT:", st["msg"])
                return False
            c = read_cmd()
            if c is not None and c.get("cmd") == "stop":
                st["seq_done"], st["state"], st["msg"] = int(c["seq"]), "idle", "stopped by command"
                print("STOP received; frozen")
                return False
            if time.time() - last_status > 0.05:
                write_status(); last_status = time.time()
            if x >= 1.0:
                return True
            time.sleep(0.01)

    def validate(q_arm):
        lo, hi = LIMITS[:, 0] + LIMIT_MARGIN, LIMITS[:, 1] - LIMIT_MARGIN
        bad = [i for i in range(14) if not (lo[i] <= q_arm[i] <= hi[i])]
        if bad:
            return f"target outside URDF limits (margin {LIMIT_MARGIN}) at arm index {bad}"
        with lock:
            d = np.abs(q_arm - q_cmd[ARM_IDS]).max()
        if d > MAX_DELTA:
            return f"single move too large ({d:.3f} > {MAX_DELTA} rad)"
        return None

    print(f"server ready. cmd: {CMD_PATH}  status: {STATUS_PATH}  vmax={args.vmax} rad/s")
    last_status = 0.0
    while alive.is_set() and not got_sig["v"]:
        if st["state"] != "error":
            track_check()
        if st["free_ids"] and time.time() - st["free_t0"] > FREE_TIMEOUT:
            side = set_hold()
            st["msg"] = f"free timeout: {side} arm stiffened at its current pose"
            print(st["msg"])
        c = read_cmd()
        if c is not None:
            seq, kind = int(c["seq"]), c.get("cmd")
            if st["state"] == "error" and kind not in ("reset", "stop", "return", "hold"):
                st["seq_done"], st["msg"] = seq, f"refused '{kind}': error latched (send reset after checking)"
            elif kind == "free":
                side = c.get("side")
                if st["free_ids"] or side not in SIDE_IDS or st["state"] not in ("idle",):
                    st["seq_done"], st["msg"] = seq, f"REJECTED: free({side}) not allowed in state {st['state']}"
                else:
                    set_free(side)
                    st["seq_done"], st["msg"] = seq, f"{side} arm FREE (hand guiding); auto-hold after {FREE_TIMEOUT:.0f}s"
                print(st["msg"])
            elif kind == "hold":
                side = set_hold() if st["free_ids"] else None
                st["seq_done"], st["msg"] = seq, f"{side} arm stiffened at its current pose" if side else "hold (nothing free)"
                print(st["msg"])
            elif st["free_ids"] and kind in ("move", "jog"):
                st["seq_done"], st["msg"] = seq, f"REJECTED: {kind} while {st['free_side']} arm is free (send hold first)"
            elif kind == "reset":
                q, _, _ = measured()
                with lock:
                    q_cmd[ARM_IDS] = q[ARM_IDS]
                st["seq_done"], st["state"], st["msg"] = seq, "idle", "error cleared; holding measured pose"
            elif kind == "stop":
                side = set_hold() if st["free_ids"] else None
                st["seq_done"], st["state"] = seq, "idle"
                st["msg"] = f"stop: {side} arm stiffened" if side else "stop (already idle)"
            elif kind in ("move", "jog"):
                if kind == "move":
                    tgt = np.array(c["arm_q"], dtype=float)
                else:
                    k, d = int(c["motor"]), float(c["delta"])
                    if k not in ARM_IDS or abs(d) > MAX_JOG:
                        tgt = None
                        st["seq_done"], st["msg"] = seq, f"bad jog motor={k} delta={d}"
                    else:
                        with lock:
                            tgt = q_cmd[ARM_IDS].copy()
                        tgt[k - 15] += d
                if tgt is not None:
                    err = validate(tgt) if len(tgt) == 14 else "arm_q must have 14 values"
                    if err:
                        st["seq_done"], st["msg"] = seq, "REJECTED: " + err
                        print(st["msg"])
                    else:
                        done = run_move(tgt, c.get("seconds", 2.0), seq)
                        if done:
                            st["seq_done"], st["state"] = seq, "idle"
                            st["msg"] = f"seq {seq} done"
                        else:
                            # interrupted or aborted: mark consumed so it is not re-processed (error stays latched)
                            st["seq_done"] = max(st["seq_done"], seq)
            elif kind == "waist":
                with lock:
                    w0 = float(q_cmd[WAIST_ID])
                tgt = float(c.get("q", w0))
                if st["free_ids"]:
                    st["seq_done"], st["msg"] = seq, "REJECTED: waist while an arm is free (send hold first)"
                elif abs(tgt) > WAIST_LIMIT or abs(tgt - w0) > WAIST_MAX_DELTA:
                    st["seq_done"], st["msg"] = seq, (f"REJECTED: waist target {tgt:+.3f} (|q| <= {WAIST_LIMIT}, "
                                                      f"|delta| <= {WAIST_MAX_DELTA} rad)")
                    print(st["msg"])
                elif run_waist(tgt, seq):
                    st["seq_done"], st["state"], st["msg"] = seq, "idle", f"seq {seq} done (waist {tgt:+.3f})"
                else:
                    st["seq_done"] = max(st["seq_done"], seq)
            elif kind == "return":
                st["seq_done"] = seq
                break
            else:
                st["seq_done"], st["msg"] = seq, f"unknown cmd {kind}"
        if time.time() - last_status > 0.05:
            write_status(); last_status = time.time()
        time.sleep(0.02)

    if st["free_ids"]:
        set_hold()
    if alive.is_set():
        st["state"] = "returning"
        print("returning to startup pose ...")
        st["state"] = "idle"
        run_move(q_hold[ARM_IDS], 3.0, st["seq_done"])
    alive.clear()
    time.sleep(0.1)
    stop_sub.set()
    st["state"] = "exited"
    write_status()
    print("stopped publishing, exit")


if __name__ == "__main__":
    main()
