# contact_point.py -- board-plane point under the fingertip pixel, from the ArUco markers seen at contact (homography)
# usage: python contact_point.py <left|right> <tip_u> <tip_v> img1 [img2 ...]
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np

BASE = Path.home() / "calib_sessions"
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
MARKER_OBJ = {int(i): np.array(c, float)[:, :2] for i, c in zip(board.getIds().ravel(), board.getObjPoints())}
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
mdet = cv2.aruco.ArucoDetector(board.getDictionary(), dp)


def contact_point(img, tip_px, K, dist):
    """-> (board xy of the tip pixel, number of markers, homography reprojection rms in board mm) or None"""
    corners, ids, _ = mdet.detectMarkers(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    if ids is None:
        return None
    obj, imgp = [], []
    for c, i in zip(corners, ids.ravel()):
        if int(i) in MARKER_OBJ:
            obj.append(MARKER_OBJ[int(i)]); imgp.append(c.reshape(4, 2))
    if not obj:
        return None
    obj, imgp = np.concatenate(obj), np.concatenate(imgp)
    und = cv2.undistortPoints(imgp.reshape(-1, 1, 2).astype(np.float64), K, dist).reshape(-1, 2)
    H, _ = cv2.findHomography(und, obj, 0)
    rms = float(np.sqrt(np.mean(np.sum((cv2.perspectiveTransform(und.reshape(-1, 1, 2), H).reshape(-1, 2) - obj) ** 2,
                                       axis=1))))
    t = cv2.undistortPoints(np.array([[tip_px]], np.float64), K, dist).reshape(1, 1, 2)
    return cv2.perspectiveTransform(t, H).ravel(), len(obj) // 4, rms * 1000


if __name__ == "__main__":
    side, tu, tv = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
    cam = json.loads((BASE / os.environ.get("G1D_POSES", "poses_current") / "scene_header_B.json").read_text()
                     )["cameras"][f"{side}_wrist"]
    K, dist = np.array(cam["K"]), np.array(cam["dist"])
    for f in sys.argv[4:]:
        r = contact_point(cv2.imread(f), (tu, tv), K, dist)
        print(f.split("/")[-1], None if r is None else
              f"board xy {np.round(r[0], 4).tolist()} m  markers {r[1]}  homography rms {r[2]:.2f} mm")
