# joint_fit.py -- runs on the sim 5090 from /dev/shm/isaac_work. One arm's geometry fitted to BOTH the arm outline in
# the head images (contour_fit.py cost, 10-19 views) and the head-anchored wrist board data (board pose from the head
# stereo, corners projected through the arm FK into the wrist camera; one focal scale per session, closed form).
# Parameters are deltas on top of the base URDF (calib_model keys) plus an optional wrist camera mount delta.
#   models: mount (shoulder_pitch frame, 6) | mount_trans (+ dx/dy/dz of shoulder_roll..wrist_yaw, 18, prior 3 mm)
#           | mount_trans_rotu (+ rot_u of the same joints, prior 1 deg) | mount_trans_rotu_cam (+ wrist camera mount, 6)
# usage: BOARD_SQUARE_MM=38.2 CALIB_PKG=<pkg dir> joint_fit.py <side> <base_urdf> <out.json> <pool> <models,..>
#        train sessions / test sessions for the wrist term are given in env WRIST_TRAIN / WRIST_TEST (comma separated)
import json
import multiprocessing as mp
import os
import sys
import time
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.spatial.transform import Rotation

SIDE, BASE_URDF, OUT, POOL, MODELS = sys.argv[1], sys.argv[2], Path(sys.argv[3]), int(sys.argv[4]), sys.argv[5].split(",")
TRAIN_S = [s for s in os.environ["WRIST_TRAIN"].split(",") if s]
TEST_S = [s for s in os.environ["WRIST_TEST"].split(",") if s]
HERE = Path(__file__).resolve().parent
sys.argv = sys.argv[:1]
sys.path.insert(0, "/dev/shm/isaac_work")
import contour_fit as cf  # noqa: E402  (loads the head views at import)

# ---- head cameras: same mounts as the wrist evaluation (right eye = left eye + stereo R, T) ----
PKG = Path(os.environ["CALIB_PKG"])
SETUP = json.loads((PKG / "camera_setup_ours.json").read_text())["views"]
for e in cf.EYES:
    assert SETUP[e]["parent"] == cf.cams[e]["parent"]
    cf.cams[e]["T"] = np.array(SETUP[e]["T_parent_camera_world_convention"])

# ---- wrist data: loader of refine_wrist_mount.py (board from the head, board square from BOARD_SQUARE_MM) ----
src_path = HERE / "refine_wrist_mount.py"
src = open(src_path, encoding="utf-8").read().split("M0 = np.array(")[0]
g = {"__file__": str(src_path)}
sys.argv = [str(src_path), SIDE, "/tmp/unused.json"] + TRAIN_S + TEST_S
exec(compile(src, str(src_path), "exec"), g)
sys.argv = sys.argv[:1]
OBJ, K0, D0, ARMJ = g["OBJ"], g["K0"], g["D0"], g["ARMJ"]
M0 = np.array(SETUP[f"{SIDE}_wrist"]["T_parent_camera_world_convention"])
OPT = cf.OPTICAL_FROM_CAMERA
SESS = {}
for sd in g["data"]:
    P, uv, row = [], [], []
    for i, (_, Tb, ci, u) in enumerate(sd["rows"]):
        P.append(OBJ[ci] @ Tb[:3, :3].T + Tb[:3, 3]); uv.append(u); row.append(np.full(len(ci), i))
    SESS[sd["name"]] = {"qa": {n: np.array([float(q.get(n, 0.0)) for q in sd["q"]]) for n in ARMJ}, "n": len(sd["q"]),
                        "P": np.concatenate(P), "uv": np.concatenate(uv), "row": np.concatenate(row)}
TRAIN = [Path(s).name for s in TRAIN_S if Path(s).name in SESS]
TEST = [Path(s).name for s in TEST_S if Path(s).name in SESS]
print(SIDE, "wrist sessions train", TRAIN, "test", TEST, flush=True)

JOINTS6 = [f"{SIDE}_{n}_joint" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
GROUPS = {
    "mount": [(f"{SIDE}_shoulder_pitch_joint/{k}", 0.01 if k in ("zero", "rot_u", "rot_v") else 0.005, None)
              for k in ("zero", "rot_u", "rot_v", "dx", "dy", "dz")],
    "trans": [(f"{j}/{k}", 0.003, 0.003) for j in JOINTS6 for k in ("dx", "dy", "dz")],
    "rotu": [(f"{j}/rot_u", 0.01, np.radians(1.0)) for j in JOINTS6],
    "cam": [(f"cam/{k}", 0.01 if k[0] == "r" else 0.005, None) for k in ("rx", "ry", "rz", "dx", "dy", "dz")],
}
PRIOR_W = 0.05


def model_params(model):
    out = list(GROUPS["mount"])
    if "trans" in model:
        out += GROUPS["trans"]
    if "rotu" in model:
        out += GROUPS["rotu"]
    if model.endswith("cam"):
        out += GROUPS["cam"]
    return out


def split(names, x):
    p = dict(zip(names, x))
    cam = np.array([p.pop(f"cam/{k}", 0.0) for k in ("rx", "ry", "rz", "dx", "dy", "dz")])
    T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(cam[:3]).as_matrix(); T[:3, 3] = cam[3:]
    return p, M0 @ T


def project(pc, K):
    x, y = pc[:, 0] / pc[:, 2], pc[:, 1] / pc[:, 2]
    k1, k2, p1, p2, k3 = D0
    r2 = x * x + y * y
    rad = 1 + k1 * r2 + k2 * r2 ** 2 + k3 * r2 ** 3
    return x * rad + 2 * p1 * x * y + p2 * (r2 + 2 * x * x), y * rad + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y


def wrist_errors(params, Mw, name):
    s = SESS[name]
    T = cf.MODEL["robot"].fk(f"{SIDE}_dex1_base_link", s["qa"], params, None, s["n"]) @ Mw
    Tr = T[s["row"]]
    pc = np.einsum("nij,ni->nj", Tr[:, :3, :3], s["P"] - Tr[:, :3, 3]) @ OPT.T
    xd, yd = project(pc, K0)
    du, dv = s["uv"][:, 0] - K0[0, 2], s["uv"][:, 1] - K0[1, 2]
    a, b = K0[0, 0] * xd, K0[1, 1] * yd
    sc = float((a @ du + b @ dv) / (a @ a + b @ b))          # focal scale of this session, closed form
    return np.hypot(a * sc - du, b * sc - dv), sc


def wrist_cost(params, Mw, names):
    e = np.concatenate([wrist_errors(params, Mw, n)[0] for n in names])
    return float(np.mean(2 * 4.0 * (np.sqrt(1 + e ** 2 / 4.0) - 1)))  # soft_l1, scale 2 px (as refine_wrist_mount)


def wrist_report(params, Mw):
    out = {}
    for n in TRAIN + TEST:
        e, sc = wrist_errors(params, Mw, n)
        out[n] = {"rms_px": round(float(np.sqrt(np.mean(e ** 2))), 2), "median_px": round(float(np.median(e)), 2),
                  "focal_scale": round(sc, 4), "set": "train" if n in TRAIN else "test"}
    return out


def contour_report(pool, params):
    return {"+".join(s): cf.summary(pool, SIDE, params, s) for s in (cf.TRAIN, cf.TEST) + ((cf.EXTRA,) if cf.EXTRA else ())}


if __name__ == "__main__":
    cf.set_model(BASE_URDF)
    ctx = mp.get_context("fork")
    idx = cf.views_of(cf.TRAIN, SIDE)
    res = {"side": SIDE, "base_urdf": BASE_URDF, "board_square_mm": float(os.environ.get("BOARD_SQUARE_MM", "40")),
           "wrist_train": TRAIN, "wrist_test": TEST, "models": {}}
    with ctx.Pool(POOL) as pool:
        p0, M00 = split([], [])
        res["baseline"] = {"wrist": wrist_report(p0, M00), "contour": contour_report(pool, p0)}
        print("baseline", json.dumps(res["baseline"]), flush=True)
        for model in MODELS:
            spec = model_params(model)
            names = [n for n, _, _ in spec]
            xs = np.array([s for _, s, _ in spec])
            pri = np.array([np.nan if p is None else p for _, _, p in spec])
            hist, t0 = [], time.time()

            def f(x):
                p, Mw = split(names, x * xs)
                c = cf.evaluate(pool, idx, SIDE, p)
                w = wrist_cost(p, Mw, TRAIN)
                m = ~np.isnan(pri)
                pr = PRIOR_W * float(np.sum((x[m] * xs[m] / pri[m]) ** 2))
                hist.append((c + w + pr, c, w))
                if len(hist) % 50 == 0:
                    b = min(hist)
                    print(f"  [{SIDE} {model}] eval {len(hist)}: J {b[0]:.3f} (contour {b[1]:.3f}, wrist {b[2]:.3f}) "
                          f"{time.time() - t0:.0f}s", flush=True)
                return c + w + pr
            r = minimize(f, np.zeros(len(names)), method="Powell",
                         options={"xtol": 0.05, "ftol": 1e-4, "maxfev": 60 * len(names)})
            x = r.x * xs
            p, Mw = split(names, x)
            rep = {"params": dict(zip(names, x.tolist())), "J": float(r.fun), "nfev": int(r.nfev),
                   "wrist": wrist_report(p, Mw), "contour": contour_report(pool, p),
                   "readable": {n: round(v * (1000 if n.split("/")[-1].startswith("d") else np.degrees(1)), 3)
                                for n, v in zip(names, x)}}
            res["models"][model] = rep
            print(model, "done", f"{time.time() - t0:.0f}s", json.dumps({k: rep[k] for k in ("wrist", "contour", "readable")}), flush=True)
            OUT.write_text(json.dumps(res, indent=1))
    OUT.write_text(json.dumps(res, indent=1))
    print("JOINT_FIT_DONE", flush=True)
