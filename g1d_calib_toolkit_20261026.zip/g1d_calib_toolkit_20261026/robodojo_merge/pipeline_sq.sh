#!/bin/bash
# full rebuild for a printed board square: rescaled meas -> identify.py (dual_trans options of 10-19) -> URDF ->
# 10-20 shoulder mounts on top -> second contour pass from there -> params_final_<tag>c, plus head-outline scores
# usage: SQ=38.2 bash pipeline_sq.sh
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data/20261019/sessions
W=$R/board_scale_20261023
MESH=$R/assembled_calib_20261016/meshes
CM=/dev/shm/isaac_work/contour_out/params_contour_mount_1020.json
SQ=${SQ:?set SQ}
T=sq${SQ/./}
set -e
cd $R/../real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
for m in meas_B_left_1209 meas_B_left_1509_pm meas_B_right_1533_pm; do
  $PY $W/scale_meas.py $S/$m.json $W/${m}_$T.json $SQ > /dev/null
done
echo "===== identify $T $(date '+%T')"
$PY identify.py $W/meas_B_left_1209_$T.json $W/meas_B_left_1509_pm_$T.json $W/meas_B_right_1533_pm_$T.json \
  --preset auto --refine-intrinsics \
  --estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' \
  --loss soft_l1 --f-scale 1.0 --folds 5 --out $W/identify_dual_trans_$T.json --params-out $W/params_dual_trans_$T.json \
  > $W/identify_$T.log 2>&1
cd $R
rm -rf $W/urdf_dual_trans_$T $W/urdf_contour_$T $W/urdf_contour_${T}c
$PY apply_calibration.py $W/params_dual_trans_$T.json $W/urdf_dual_trans_$T > /dev/null
$PY apply_calibration.py $CM $W/urdf_contour_$T --nominal $W/urdf_dual_trans_$T > /dev/null
ln -s $MESH $W/urdf_dual_trans_$T/meshes
ln -s $MESH $W/urdf_contour_$T/meshes
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$R/real_data/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
O=$W/contour_${T}c
mkdir -p $O
cd /dev/shm/isaac_work
echo "===== contour fit $(date '+%T')"
$PY -u contour_fit.py fit $O $W/urdf_contour_$T/g1_d_upper_dex1_v4.urdf both mount 2>&1 | grep -v realcam | grep -v ' eval '
$PY - <<EOF
import json
r = json.load(open("$O/contour_fit_both_mount.json"))
vals = {}
for d in r["sides"].values():
    vals.update(d["params"])
json.dump({"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": False,
           "description": "second shoulder_pitch delta ON TOP OF urdf_contour_$T (dual_trans on a $SQ mm board + 10-20 mounts)",
           "convention": "q_model = q_encoder + zero (radians)", "values": vals},
          open("$W/params_contour_mount_${T}c.json", "w"), indent=2)
EOF
cd $R
$PY apply_calibration.py $W/params_contour_mount_${T}c.json $W/urdf_contour_${T}c --nominal $W/urdf_contour_$T > /dev/null
ln -s $MESH $W/urdf_contour_${T}c/meshes
$PY /dev/shm/isaac_work/compose_params.py $W/urdf_contour_${T}c/g1_d_upper_dex1_v4.urdf $W/params_dual_trans_$T.json \
  $W/params_final_${T}c.json
cd /dev/shm/isaac_work
echo "===== eval $(date '+%T')"
$PY -u contour_fit.py eval $O ${T}c=$W/urdf_contour_${T}c/g1_d_upper_dex1_v4.urdf 2>&1 | grep -v realcam
cd $W
$PY summarize_scan.py . 2>/dev/null | grep -A3 "square ${SQ}" || true
$PY - <<EOF
import json
r = json.load(open("$W/identify_dual_trans_$T.json"))
print("identify fit rms", {k: round(v["rms"], 3) for k, v in r["residuals"].items()})
print("identify held-out", {k: round(v, 3) for k, v in r["validation"]["heldout_rms_by_block"]["calibrated"].items()})
EOF
echo "PIPELINE_DONE $(date '+%T')"
