# make_confirm_video.py -- real vs sim confirmation video: rows head_left / left_wrist / right_wrist, columns
# real (undistorted with our calibrated intrinsics) | Isaac Lab render (calibrated RoboDojo G1-D, our cameras), 10 fps.
# usage: make_confirm_video.py <logger_run_dir> <confirm_traj.json> <render_dir> <camera_setup_ours.json> <out.mp4>
import glob
import json
import os
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

RUN, TRAJ, REN, CAMS, OUT = sys.argv[1:6]
ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
FFMPEG = next((ROOT / ".venv/Lib/site-packages/imageio_ffmpeg/binaries").glob("ffmpeg*.exe"))
cams = json.load(open(CAMS, encoding="utf-8"))["views"]
traj = json.load(open(TRAJ, encoding="utf-8"))["frames"]
F_T = ImageFont.truetype(r"C:\Windows\Fonts\msyhbd.ttc", 22)
F_S = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 17)
# (camera, logger folder, label). The confirmation logger used the old port names; since the teleimager config change of
# 2026-10-21 21:25 port 55556 (saved as "right_wrist") is the physical LEFT wrist and 55557 the RIGHT wrist.
ROWS = (("head_left", "head", "头部左眼"), ("left_wrist", "right_wrist", "左腕相机"), ("right_wrist", "left_wrist", "右腕相机"))
W, H = 640, 480


def stamps(d):
    fs = sorted(glob.glob(os.path.join(RUN, d, "*.jpg")))
    return fs, np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in fs])


src = {d: stamps(d) for _, d, _ in ROWS}
maps = {}
for v, _, _ in ROWS:
    K, D = np.array(cams[v]["K"]), np.array(cams[v]["dist_k1k2p1p2k3"])
    maps[v] = cv2.initUndistortRectifyMap(K, D, None, K, (W, H), cv2.CV_16SC2)


def bar(w, h, items, bg=(24, 38, 56)):
    im = Image.new("RGB", (w, h), bg)
    d = ImageDraw.Draw(im)
    for x, y, t, f, c in items:
        d.text((x, y), t, font=f, fill=c)
    return cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)


sp = np.array([fr["q"]["left_shoulder_pitch_joint"] for fr in traj])
el = np.array([fr["q"]["left_elbow_joint"] for fr in traj])
k_low = int(np.argmin(sp))
v = np.gradient(sp)
up_start = next(k for k in range(len(sp)) if sp[k] < -0.03)
down_end = next(k for k in range(k_low, len(sp)) if sp[k] > -0.03)
PH = []
for k in range(len(traj)):
    if k < up_start:
        PH.append("机器人回正（外展 → 回零 → 腰回正）" if el[k] > 0.1 or k < 60 else "零位（回正完成）")
    elif k <= down_end:
        PH.append("双臂抬起" if v[k] < -0.002 else "双臂放下" if v[k] > 0.002 else "抬起保持")
    else:
        PH.append("回到零位")


def phase(k):
    return PH[k]


tmp = Path(os.environ["TEMP"]) / "confirm_video_raw.mp4"
vw = cv2.VideoWriter(str(tmp), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (2 * W, 3 * H + 3 * 34 + 46))
col_hdr = {v: bar(2 * W, 34, [(12, 6, f"{lab}：左 = 真机（去畸变）   右 = Isaac Lab 仿真（同事 G1-D 模型 + 我们的标定 + 我们的相机）",
                              F_S, (230, 236, 242))], bg=(31, 59, 87)) for v, _, lab in ROWS}
for k, fr in enumerate(traj):
    t = fr["t"]
    parts = [bar(2 * W, 46, [(12, 9, f"真机 vs 仿真确认视频  t = {fr['t_rel'] - traj[0]['t_rel']:5.1f} s   {phase(k)}",
                              F_T, (255, 255, 255)),
                             (1010, 13, "仿真由真机实测关节角逐帧驱动", F_S, (175, 225, 255))])]
    for v, d, _ in ROWS:
        fs, ts = src[d]
        j = int(np.argmin(np.abs(ts - t)))
        img = cv2.imdecode(np.fromfile(fs[j], np.uint8), cv2.IMREAD_COLOR)
        img = img[:, :W] if img.shape[1] > W else img
        real = cv2.remap(img, *maps[v], cv2.INTER_LINEAR)
        sim = cv2.imdecode(np.fromfile(os.path.join(REN, f"sim_{v}_{k:04d}.jpg"), np.uint8), cv2.IMREAD_COLOR)
        sim = cv2.resize(sim, (W, H))
        cv2.line(sim, (0, 0), (0, H - 1), (220, 225, 230), 2)
        parts += [col_hdr[v], np.hstack([real, sim])]
    vw.write(np.vstack(parts))
    if k in (0, 150, 270, 330, 420):
        cv2.imencode(".png", np.vstack(parts))[1].tofile(str(Path(OUT).with_name(f"confirm_frame_{k:04d}.png")))
vw.release()
subprocess.run([str(FFMPEG), "-y", "-loglevel", "error", "-i", str(tmp), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                str(Path(os.environ["TEMP"]) / "confirm_h264.mp4")], check=True)
Path(OUT).write_bytes((Path(os.environ["TEMP"]) / "confirm_h264.mp4").read_bytes())
gif = Path(os.environ["TEMP"]) / "confirm_2x.gif"
subprocess.run([str(FFMPEG), "-y", "-loglevel", "error", "-i", str(tmp), "-vf",
                "setpts=PTS/2,fps=6,scale=640:-1:flags=lanczos,split[a][b];[a]palettegen=max_colors=128[p];[b][p]paletteuse=dither=bayer",
                str(gif)], check=True)
Path(OUT).with_suffix(".gif").write_bytes(gif.read_bytes())
print("wrote", OUT, "and", Path(OUT).with_suffix(".gif"))
