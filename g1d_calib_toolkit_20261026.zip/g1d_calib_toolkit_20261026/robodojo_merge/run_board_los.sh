#!/bin/bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015/robodojo_g1d_calib_20261022/check
B=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data
P=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
$P board_los.py left $B/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left \
  $B/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left board_views_20261022 left_session_20261022 \
  board_views_1023 left_session_1023 2>&1 | grep -v 'wrist frames'
$P board_los.py right $B/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right \
  $B/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right board_views_20261022 board_views_1023 2>&1 | grep -v 'wrist frames'
