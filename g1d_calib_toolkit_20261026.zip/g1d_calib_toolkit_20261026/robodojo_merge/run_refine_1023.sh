#!/bin/bash
# after the robot restart (2026-10-23): same wrist checks with the new captures, yesterday's included for comparison
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=4
$PY -u refine_wrist_mount.py left $D/refine_left_1023.json \
  $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023 > $D/refine_left_1023.log 2>&1 &
$PY -u refine_wrist_mount.py right $D/refine_right_1023.json \
  $D/board_views_20261022 $D/board_views_1023 > $D/refine_right_1023.log 2>&1 &
wait
echo DONE >> $D/refine_left_1023.log
