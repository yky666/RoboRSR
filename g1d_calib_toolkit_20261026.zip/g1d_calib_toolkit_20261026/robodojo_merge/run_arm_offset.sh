#!/bin/bash
# hypothesis test: one rigid offset of the whole arm (torso frame) instead of a wrist-camera mount correction,
# all head-anchored sessions of 10-19 .. 10-23 (camera_setup_ours v2: corrected right eye)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=4 ARM_OFFSET=1
$PY -u refine_wrist_mount.py left $D/armoff_left.json \
  $S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left \
  $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left \
  $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023 > $D/armoff_left.log 2>&1 &
$PY -u refine_wrist_mount.py right $D/armoff_right.json \
  $S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right \
  $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right \
  $D/board_views_20261022 $D/board_views_1023 > $D/armoff_right.log 2>&1 &
wait
echo DONE >> $D/armoff_left.log
