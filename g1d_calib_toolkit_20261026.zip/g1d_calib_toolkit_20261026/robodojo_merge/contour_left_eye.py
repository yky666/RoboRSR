# contour_left_eye.py -- head-outline scores using the LEFT head eye only (the reference camera of every measurement),
# so the comparison does not depend on how the right eye is mounted. usage: contour_left_eye.py tag=urdf ...
import json
import multiprocessing as mp
import sys

args = sys.argv[1:]
sys.argv = sys.argv[:1]
sys.path.insert(0, "/dev/shm/isaac_work")
import contour_fit as cf  # noqa: E402

cf.VIEWS[:] = [v for v in cf.VIEWS if v[2] == "head_left"]
rep = {}
for a in args:
    tag, urdf = a.split("=", 1)
    cf.set_model(urdf)
    with mp.get_context("fork").Pool(48) as pool:
        for side in ("left", "right"):
            for sess in (cf.TRAIN, cf.TEST) + ((cf.EXTRA,) if cf.EXTRA else ()):
                r = cf.summary(pool, side, {}, sess)
                rep[f"{tag}/{side}/{'+'.join(sess)}"] = r
                print(f"{tag:10s} {side:5s} {'+'.join(sess):9s} median {r['median_px']} px  inlier<2px {r['inlier_2px']}", flush=True)
print(json.dumps(rep))
