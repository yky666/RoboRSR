#!/bin/bash
# params_final for the measured printed square (38.5 mm), built exactly like params_final_1021 (server_build_1021.sh):
# dual_trans URDF (identify.py on rescaled meas) + the same contour shoulder-mount deltas, composed relative to nominal
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
W=$R/board_scale_20261023
CM=/dev/shm/isaac_work/contour_out/params_contour_mount_1020.json
set -e
ls -la $CM
cd $R
rm -rf $W/urdf_dual_trans_sq385 $W/urdf_contour_sq385
$PY apply_calibration.py $W/params_dual_trans_sq385.json $W/urdf_dual_trans_sq385 | tail -2
$PY apply_calibration.py $CM $W/urdf_contour_sq385 --nominal $W/urdf_dual_trans_sq385 | tail -2
$PY /dev/shm/isaac_work/compose_params.py $W/urdf_contour_sq385/g1_d_upper_dex1_v4.urdf $W/params_dual_trans_sq385.json \
  $W/params_final_sq385.json
cd $W
$PY - <<'EOF'
import json
import numpy as np
a = json.load(open("../real_data/20261021/params_final_1021.json"))["values"]
b = json.load(open("params_final_sq385.json"))["values"]
print(len(a), "->", len(b), "values")
d = []
for k in sorted(set(a) | set(b)):
    x = b.get(k, 0) - a.get(k, 0)
    u = 1000 if (k.split("/")[-1].startswith("d") and not k.startswith("intrinsics")) else (1 if k.startswith("intrinsics") else np.degrees(1))
    if abs(x * u) > 0.05:
        d.append((abs(x * u), k, round(x * u, 3)))
for _, k, x in sorted(d, reverse=True):
    print(f"  {k:42s} {x:+.3f}")
EOF
