# diff_scan_params.py -- which identified parameters move when the board square changes (sq400 -> sq385)?
import json
import sys

import numpy as np

a = json.load(open(sys.argv[1]))
b = json.load(open(sys.argv[2]))
va, vb, sd = a["values"], b["values"], b.get("std", {})
rows = []
for k in sorted(set(va) | set(vb)):
    d = vb.get(k, 0.0) - va.get(k, 0.0)
    s = sd.get(k)
    unit = "mm" if k.split("/")[-1].startswith("d") and not k.startswith("intrinsics") else ("px" if k.startswith("intrinsics") else "deg")
    f = 1000 if unit == "mm" else (1 if unit == "px" else np.degrees(1))
    rows.append((abs(d * f) / (s * f) if s else 0, k, d * f, s * f if s else None, unit))
rows.sort(reverse=True)
print(f"{len(rows)} params; largest changes (in units of the sq385 std):")
for z, k, d, s, u in rows[:25]:
    print(f"  {k:45s} {d:+9.3f} {u}   std {s if s is None else round(s, 3)}  ({z:.1f} sigma)")
jt = [(k, d, u) for _, k, d, _, u in rows if "_joint/" in k]
print("max joint change:", max((abs(d) for k, d, u in jt if u == "deg"), default=0), "deg,",
      max((abs(d) for k, d, u in jt if u == "mm"), default=0), "mm")
