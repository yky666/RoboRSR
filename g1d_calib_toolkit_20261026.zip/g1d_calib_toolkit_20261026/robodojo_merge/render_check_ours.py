# render_check_ours.py -- our sim 5090: load the calibrated RoboDojo G1-D URDF (Isaac Lab URDF converter), pose it at
# recorded real joint angles, render all four cameras from camera_setup_ours.json (undistorted pinhole with the
# calibrated principal point), check sim link poses against the URDF FK.
# usage: render_check_ours.py --urdf <g1d_dex1_calib.urdf> --cams camera_setup_ours.json --pose pose.json --tag <id> --out <dir>
import argparse
import json
import os
import sys
import traceback

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--urdf", required=True)
parser.add_argument("--cams", required=True)
parser.add_argument("--pose", action="append", required=True, help="tag=path.json (real joint angles)")
parser.add_argument("--out", required=True)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.headless = True
args.enable_cameras = True
app = AppLauncher(args).app

import xml.etree.ElementTree as ET  # noqa: E402

import numpy as np  # noqa: E402
import torch  # noqa: E402
from PIL import Image  # noqa: E402
from pxr import UsdGeom  # noqa: E402
from scipy.spatial.transform import Rotation  # noqa: E402

import isaaclab.sim as sim_utils  # noqa: E402
from isaaclab.actuators import ImplicitActuatorCfg  # noqa: E402
from isaaclab.assets import Articulation, ArticulationCfg  # noqa: E402
from isaaclab.sensors import Camera, CameraCfg  # noqa: E402
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg  # noqa: E402

DT = 1 / 60


def urdf_fk(path, q, link, root="torso_link"):
    J = {}
    for j in ET.parse(path).getroot().findall("joint"):
        o = j.find("origin")
        T = np.eye(4)
        T[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
        T[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
        ax = j.find("axis")
        J[j.find("child").get("link")] = (j.get("name"), j.find("parent").get("link"), j.get("type"), T,
                                          np.array([float(v) for v in (ax.get("xyz") if ax is not None else "1 0 0").split()]))
    T = np.eye(4)
    while link != root:
        name, parent, kind, M, axis = J[link]
        M = M.copy()
        v = q.get(name, 0.0)
        if kind == "revolute" and v:
            R = np.eye(4); R[:3, :3] = Rotation.from_rotvec(axis * v).as_matrix(); M = M @ R
        elif kind == "prismatic" and v:
            Pm = np.eye(4); Pm[:3, 3] = axis * v; M = M @ Pm
        T = M @ T
        link = parent
    return T


def pose_T(state):
    s = state.detach().cpu().numpy()
    T = np.eye(4); T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix(); T[:3, 3] = s[:3]
    return T


def main():
    os.makedirs(args.out, exist_ok=True)
    cams_cfg = json.load(open(args.cams))["views"]
    sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=DT, device=args.device))
    sim_utils.DomeLightCfg(intensity=350.0).func("/World/dome", sim_utils.DomeLightCfg(intensity=350.0))
    conv = UrdfConverter(UrdfConverterCfg(
        asset_path=args.urdf, usd_dir=os.path.join(args.out, "usd"), usd_file_name="g1d_dex1_calib.usd",
        fix_base=True, merge_fixed_joints=False, force_usd_conversion=True, make_instanceable=False,
        joint_drive=UrdfConverterCfg.JointDriveCfg(gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
    robot = Articulation(ArticulationCfg(
        prim_path="/World/Robot",
        spawn=sim_utils.UsdFileCfg(usd_path=conv.usd_path, rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
                                   articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                                       enabled_self_collisions=False, solver_position_iteration_count=16)),
        actuators={"all": ImplicitActuatorCfg(joint_names_expr=[".*"], stiffness=1e5, damping=1e3)}))
    cams = {n: Camera(CameraCfg(prim_path=f"/World/cam_{n}", width=c["resolution"][0], height=c["resolution"][1],
                                data_types=["rgb"],
                                spawn=sim_utils.PinholeCameraCfg(focal_length=24.0, clipping_range=(0.02, 20.0))))
            for n, c in cams_cfg.items()}
    sim.reset()
    stage = sim.stage
    for n, c in cams_cfg.items():
        W, H = c["resolution"]
        (fx, _, cx), (_, fy, cy) = c["K"][0], c["K"][1]
        prim = stage.GetPrimAtPath(f"/World/cam_{n}")
        hap, vap = 24.0 * W / fx, 24.0 * H / fy
        prim.GetAttribute("horizontalAperture").Set(float(hap)); prim.GetAttribute("verticalAperture").Set(float(vap))
        prim.GetAttribute("horizontalApertureOffset").Set(float((W / 2.0 - cx) * hap / W))
        prim.GetAttribute("verticalApertureOffset").Set(float((cy - H / 2.0) * vap / H))
    for p in stage.Traverse():  # head camera lenses sit inside the head shell
        if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link":
            UsdGeom.Imageable(p).MakeInvisible()

    jn, names = robot.joint_names, robot.body_names
    print("movable joints:", len(jn), jn)
    report = {}
    for item in args.pose:
        tag, path = item.split("=", 1)
        q_real = json.load(open(path))
        tgt = robot.data.default_joint_pos.clone() * 0
        for i, n in enumerate(jn):
            if n in q_real:
                tgt[0, i] = q_real[n]
            elif "dex1_finger" in n:
                tgt[0, i] = 0.024  # closed
        robot.write_joint_state_to_sim(tgt, torch.zeros_like(tgt))
        for _ in range(120):
            robot.set_joint_position_target(tgt)
            robot.write_data_to_sim()
            sim.step(render=False)
            robot.update(DT)
        jp = robot.data.joint_pos[0].cpu().numpy()
        q = {n: float(jp[i]) for i, n in enumerate(jn)}
        T_torso = pose_T(robot.data.body_link_state_w[0, names.index("torso_link"), :7])
        fk = {}
        for link in ("head_link", "left_dex1_base_link", "right_dex1_base_link"):
            T_sim = np.linalg.inv(T_torso) @ pose_T(robot.data.body_link_state_w[0, names.index(link), :7])
            T_ref = urdf_fk(args.urdf, q, link)
            fk[link] = round(float(np.linalg.norm(T_sim[:3, 3] - T_ref[:3, 3]) * 1000), 4)
        err = float(np.abs(jp - tgt[0].cpu().numpy()).max())
        print(f"[{tag}] max |q - target| {err:.2e} rad; sim vs URDF FK (mm): {fk}")
        for n, c in cams_cfg.items():
            T = pose_T(robot.data.body_link_state_w[0, names.index(c["parent"]), :7]) @ np.array(c["T_parent_camera_world_convention"])
            xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
            cams[n].set_world_poses(torch.tensor([T[:3, 3]], dtype=torch.float32, device=args.device),
                                    torch.tensor([xyzw[[3, 0, 1, 2]]], dtype=torch.float32, device=args.device),
                                    convention="world")
        for _ in range(30):
            sim.render()
        for n, cam in cams.items():
            cam.update(DT)
            rgb = cam.data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
            Image.fromarray(rgb).save(os.path.join(args.out, f"sim_{n}_{tag}.png"))
        report[tag] = {"max_joint_err_rad": err, "fk_diff_mm": fk}
    json.dump(report, open(os.path.join(args.out, "render_check.json"), "w"), indent=1)


try:
    main()
    failed = False
except Exception:
    traceback.print_exc()
    failed = True
sys.stdout.flush()
sys.stderr.flush()
os._exit(1 if failed else 0)
