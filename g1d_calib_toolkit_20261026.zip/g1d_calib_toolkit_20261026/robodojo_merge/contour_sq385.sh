#!/bin/bash
# shoulder mounts refitted (contour_fit.py, same views/settings as 10-20) on the dual_trans geometry identified with the
# measured 38.5 mm board, then composed into params_final_sq385b; head-view outline scores of all variants
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
W=$R/board_scale_20261023
O=$W/contour_sq385
MESH=$R/assembled_calib_20261016/meshes
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$R/real_data/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
mkdir -p $O
for d in urdf_dual_trans_sq385 urdf_contour_sq385; do [ -e $W/$d/meshes ] || ln -s $MESH $W/$d/meshes; done
cd /dev/shm/isaac_work
echo "===== fit $(date '+%T')"
$PY -u contour_fit.py fit $O $W/urdf_dual_trans_sq385/g1_d_upper_dex1_v4.urdf both mount 2>&1 | grep -v realcam | grep -v ' eval '
$PY - <<EOF
import json
r = json.load(open("$O/contour_fit_both_mount.json"))
vals = {}
for d in r["sides"].values():
    vals.update(d["params"])
doc = {"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": False,
       "description": "shoulder_pitch frame deltas ON TOP OF the dual_trans_sq385 URDF (board square 38.5 mm), "
                      "contour_fit.py; apply with --nominal <dual_trans_sq385 dir>",
       "convention": "q_model = q_encoder + zero (radians)", "values": vals}
json.dump(doc, open("$W/params_contour_mount_sq385.json", "w"), indent=2)
EOF
cd $R
rm -rf $W/urdf_contour_sq385b
$PY apply_calibration.py $W/params_contour_mount_sq385.json $W/urdf_contour_sq385b --nominal $W/urdf_dual_trans_sq385 > /dev/null
ln -s $MESH $W/urdf_contour_sq385b/meshes
$PY /dev/shm/isaac_work/compose_params.py $W/urdf_contour_sq385b/g1_d_upper_dex1_v4.urdf $W/params_dual_trans_sq385.json \
  $W/params_final_sq385b.json
cd /dev/shm/isaac_work
echo "===== eval $(date '+%T')"
$PY -u contour_fit.py eval $O final1021=$R/scratch/urdf_variants_20261020/contour/g1_d_upper_dex1_v4.urdf \
  sq385_oldmnt=$W/urdf_contour_sq385/g1_d_upper_dex1_v4.urdf sq385_refit=$W/urdf_contour_sq385b/g1_d_upper_dex1_v4.urdf \
  2>&1 | grep -v realcam
echo "CONTOUR_DONE $(date '+%T')"
