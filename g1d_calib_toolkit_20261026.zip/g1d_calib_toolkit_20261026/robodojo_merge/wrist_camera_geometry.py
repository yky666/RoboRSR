# wrist_camera_geometry.py -- where is the wrist camera, in the dex1_base_link frame?
#   official Unitree Dex1-1 base mesh (our nominal model) vs RoboDojo's rebuilt camera module (camera_geometry/*),
#   both with the closed fingers; marks: the nominal camera mount (Unitree contract = RoboDojo config), the lens of the
#   RoboDojo module (where the nominal optical axis exits their housing), and OUR calibrated left/right optical centres
#   (camera_setup_ours.json). Prints distances and writes a side view (x-z) and top view (x-y).
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]
plt.rcParams["axes.unicode_minus"] = False
from scipy.spatial.transform import Rotation  # noqa: E402

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
THEIRS = Path(sys.argv[1])          # RoboDojo asset dir (g1d_dex1.urdf, meshes/)
OURS = ROOT / "g1d_calib_20261015/g1d_calib_20261015/nominal"
CAMS = json.loads((ROOT / "pc_tools/robodojo_merge/camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
NOMINAL = {v["name"]: np.array(v["T_parent_camera_world_convention"]) for v in
           json.loads((OURS / "camera_contract_v5.json").read_text(encoding="utf-8"))["views"]}
OUT = Path(sys.argv[2])


def stl(path):
    b = path.read_bytes()
    n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
    return np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)["v"].astype(float)


def chain(urdf, link, root):
    J = {j.find("child").get("link"): j for j in ET.parse(urdf).getroot().findall("joint")}
    T = np.eye(4)
    while link != root:
        j = J[link]
        o = j.find("origin")
        M = np.eye(4)
        M[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
        M[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
        if j.get("type") == "prismatic":
            D = np.eye(4); D[:3, 3] = np.array([float(v) for v in j.find("axis").get("xyz").split()]) * 0.024; M = M @ D
        T = M @ T
        link = j.find("parent").get("link")
    return T


def link_tris(urdf, base_dir, link, root="left_dex1_base_link"):
    T = chain(urdf, link, root)
    out = []
    for l in ET.parse(urdf).getroot().findall("link"):
        if l.get("name") == link:
            for v in l.findall("visual"):
                m = v.find("geometry/mesh")
                if m is not None:
                    t = stl(base_dir / m.get("filename")).reshape(-1, 3)
                    out.append((m.get("filename").split("/")[-1], (t @ T[:3, :3].T + T[:3, 3]).reshape(-1, 3, 3)))
    return out


def ray_hits(tris, o, d):
    """Moller-Trumbore: distances t > 0 where the ray o + t d crosses the triangles"""
    v0, v1, v2 = tris[:, 0], tris[:, 1], tris[:, 2]
    e1, e2 = v1 - v0, v2 - v0
    p = np.cross(d, e2)
    det = (e1 * p).sum(1)
    ok = np.abs(det) > 1e-12
    inv = np.where(ok, 1 / np.where(ok, det, 1), 0)
    s = o - v0
    u = (s * p).sum(1) * inv
    q = np.cross(s, e1)
    v = (q * d).sum(1) * inv
    t = (e2 * q).sum(1) * inv
    hit = ok & (u >= 0) & (v >= 0) & (u + v <= 1) & (t > 1e-6)
    return np.sort(t[hit])


fingers = [f"left_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")]
U_t, U_o = THEIRS / "g1d_dex1.urdf", OURS / "g1_d_upper_dex1_v4.urdf"
mod_t = link_tris(U_t, THEIRS, "left_dex1_model_base_link")
mod_o = link_tris(U_o, OURS, "left_dex1_model_base_link")
fin = sum((link_tris(U_t, THEIRS, f) for f in fingers), [])
housing = np.concatenate([t for n, t in mod_t if "housing" in n])
module_all = np.concatenate([t for _, t in mod_t])
official = np.concatenate([t for _, t in mod_o])

nom = NOMINAL["left_wrist"]
o_nom, f_nom = nom[:3, 3], nom[:3, 0]
hits = ray_hits(module_all, o_nom - f_nom * 0.05, f_nom)  # start 5 cm behind the nominal sensor
lens_t = o_nom - f_nom * 0.05 + f_nom * hits[-1] if len(hits) else None  # last exit along +forward = front face
hits_o = ray_hits(official, o_nom - f_nom * 0.05, f_nom)
lens_o = o_nom - f_nom * 0.05 + f_nom * hits_o[-1] if len(hits_o) else None
print("left_dex1_base_link frame (x forward along the fingers, z up), mm")
print(f"  nominal camera mount (Unitree contract = RoboDojo config): {np.round(o_nom * 1000, 1)}, looks {np.degrees(np.arcsin(-f_nom[2])):.1f} deg down")
for tag, lens in (("RoboDojo module", lens_t), ("official base mesh", lens_o)):
    if lens is not None:
        print(f"  {tag:20s} front face on the nominal axis: {np.round(lens * 1000, 1)}  ({(lens - o_nom) @ f_nom * 1000:+.1f} mm along the axis from the nominal mount)")
res = {}
for side in ("left", "right"):
    T = np.array(CAMS[f"{side}_wrist"]["T_parent_camera_world_convention"])
    c, f = T[:3, 3].copy(), T[:3, 0].copy()
    if side == "right":  # mirror into the left frame for the comparison (y -> -y); the module is symmetric
        c[1] *= -1; f[1] *= -1
    d_nom = (c - o_nom) * 1000
    inside = len(ray_hits(module_all, c, np.array([0.0, 0.0, 1.0]))) % 2 == 1
    h = ray_hits(module_all, c, f)
    print(f"  OUR calibrated {side:5s} optical centre: {np.round(c * 1000, 1)}  = nominal {np.round(d_nom, 1)} "
          f"({np.linalg.norm(d_nom):.1f} mm), looks {np.degrees(np.arcsin(-f[2])):.1f} deg down; "
          f"vs RoboDojo lens {np.round((c - lens_t) * 1000, 1) if lens_t is not None else '-'} "
          f"({np.linalg.norm((c - lens_t) * 1000):.1f} mm); inside their module: {inside}; "
          f"module surface ahead along our axis: {np.round(h[:3] * 1000, 1).tolist()} mm")
    res[side] = (c, f)

fig, axes = plt.subplots(1, 2, figsize=(15, 6.2), dpi=170)
for ax, (i, j, lab) in zip(axes, ((0, 2, "侧视图 (x 前, z 上)"), (0, 1, "俯视图 (x 前, y 左)"))):
    for tris, col, name, s in ((official, "#9CA3AF", "官方 Dex1-1 基座网格（我们的名义模型）", 0.15),
                               (module_all, "#F59E0B", "同事重建的相机模块（RoboDojo）", 0.15),
                               (np.concatenate([t for _, t in fin]), "#374151", "手指（闭合）", 0.1)):
        P = tris.reshape(-1, 3)[::3] * 1000
        ax.scatter(P[:, i], P[:, j], s=s, c=col, alpha=0.35, label=name, rasterized=True)
    def arrow(o, f, col, name, mk):
        ax.plot(o[i] * 1000, o[j] * 1000, mk, color=col, ms=9, mec="black", label=name, zorder=5)
        ax.annotate("", xy=((o + f * 0.035)[i] * 1000, (o + f * 0.035)[j] * 1000), xytext=(o[i] * 1000, o[j] * 1000),
                    arrowprops=dict(arrowstyle="->", color=col, lw=1.8), zorder=5)
    arrow(o_nom, f_nom, "#2563EB", "相机名义位置（Unitree 合同 = 同事配置）", "s")
    if lens_t is not None:
        ax.plot(lens_t[i] * 1000, lens_t[j] * 1000, "D", color="#F59E0B", ms=8, mec="black", label="同事模型的镜头前表面", zorder=5)
    arrow(res["left"][0], res["left"][1], "#16A34A", "我们标定的左腕光心", "o")
    arrow(res["right"][0], res["right"][1], "#DC2626", "我们标定的右腕光心（镜像到左手）", "^")
    ax.set_aspect("equal")
    ax.set_xlim(15, 135)
    ax.set_ylim(*((-5, 100) if j == 2 else (-45, 45)))
    ax.set_xlabel(["x", "y", "z"][i] + " (mm)")
    ax.set_ylabel(["x", "y", "z"][j] + " (mm)")
    ax.set_title(lab, fontsize=12, fontweight="bold")
    ax.grid(True, ls=":", alpha=0.5)
h, l = axes[0].get_legend_handles_labels()
for hh in h[:3]:
    hh.set_sizes([30])
    hh.set_alpha(1.0)
fig.legend(h, l, loc="lower center", ncol=4, fontsize=9, framealpha=0.95)
fig.suptitle("左腕夹爪坐标系 left_dex1_base_link 下的腕部相机位置", fontsize=13, fontweight="bold")
fig.tight_layout(rect=(0, 0.1, 1, 0.95))
fig.savefig(OUT, dpi=170)
print("wrote", OUT)
