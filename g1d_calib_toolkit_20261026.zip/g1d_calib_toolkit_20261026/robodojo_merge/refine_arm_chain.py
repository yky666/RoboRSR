# refine_arm_chain.py -- runs on the sim 5090. Which part of the arm chain explains the wrist-vs-head board offset?
# Same data and board model as refine_wrist_mount.py (its loader is reused), wrist mount fixed at camera_setup_ours;
# candidate models, each with one focal scale per session and leave-one-session-out validation:
#   distal4: zero offsets of elbow + wrist roll/pitch/yaw (upper arm untouched, as the head-view outline requires)
#   joints7: zero offsets of all 7 arm joints
#   distal4_mount: distal4 + wrist camera mount correction (6)
#   origin6_<link>: 6-dof correction of one arm joint origin (link geometry / assembly error)
# usage: [CHAIN_MODELS=m1,m2] refine_arm_chain.py <side> <out.json> <session_dir> ...
import json
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

src_path = Path(__file__).parent / "refine_wrist_mount.py"
src = open(src_path, encoding="utf-8").read().split("M0 = np.array(")[0]
g = {"__file__": str(src_path)}
exec(compile(src, str(src_path), "exec"), g)
data, J, project, OBJ, K0, D0, ARMJ, SIDE, CAMS = (g[k] for k in ("data", "J", "project", "OBJ", "K0", "D0", "ARMJ", "SIDE", "CAMS"))
OUT = Path(sys.argv[2])
M0 = np.array(CAMS[f"{SIDE}_wrist"]["T_parent_camera_world_convention"])
# (joint zero offsets, child links whose joint origin gets a 6-dof correction, wrist camera mount correction)
LINK_MODELS = {f"origin6_{n}": [f"{SIDE}_{n}_link"] for n in ("shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")}
MODELS = {"distal4": (ARMJ[3:], [], False), "joints7": (ARMJ, [], False), "distal4_mount": (ARMJ[3:], [], True)}
MODELS |= {k: ([], v, False) for k, v in LINK_MODELS.items()}
# gravity compliance: joint deflection = c_j * gravity torque_j(q) (rad per N m), torques from the URDF inertials
COMPL = {"compl7": ARMJ, "compl4": [ARMJ[0], ARMJ[1], ARMJ[3], ARMJ[5]]}
MODELS |= {k: ([], [], False) for k in COMPL}
MODELS |= {k + "_mount": ([], [], True) for k in COMPL}
ONLY = [m for m in os.environ.get("CHAIN_MODELS", "").split(",") if m]
if ONLY:
    MODELS = {k: MODELS[k] for k in ONLY}


def se3(v):
    T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(v[:3]).as_matrix(); T[:3, 3] = v[3:6]
    return T


def fk(link, q, corr):
    T = np.eye(4)
    while link != "torso_link":
        name, parent, kind, M, axis = J[link]
        M = M @ corr[link] if link in corr else M
        if kind == "revolute" and q.get(name):
            R = np.eye(4); R[:3, :3] = Rotation.from_rotvec(axis * q[name]).as_matrix(); M = M @ R
        T = M @ T
        link = parent
    return T


MASS = {}
for l in ET.parse(g["PKG"] / "g1d_dex1_calib.urdf").getroot().findall("link"):
    it = l.find("inertial")
    if it is not None and it.find("mass") is not None:
        o = it.find("origin")
        MASS[l.get("name")] = (float(it.find("mass").get("value")),
                               np.array([float(v) for v in (o.get("xyz") if o is not None else "0 0 0").split()]))
JOINT_CHILD = {v[0]: k for k, v in J.items()}


def ancestors(link):
    out = []
    while link in J:
        out.append(link)
        link = J[link][1]
    return out


def gravity_torques(q):
    """torque of gravity about each arm joint axis, torso upright (z up)"""
    Tl = {ln: fk(ln, q, {}) for ln in MASS if ln in J and JOINT_CHILD[ARMJ[0]] in ancestors(ln)}
    tau = []
    for jn in ARMJ:
        c = JOINT_CHILD[jn]
        Tj = fk(c, q, {})
        a = Tj[:3, :3] @ J[c][4]
        f = np.zeros(3)
        for ln, T in Tl.items():
            if c in ancestors(ln):
                m, com = MASS[ln]
                f += np.cross(T[:3, :3] @ com + T[:3, 3] - Tj[:3, 3], [0, 0, -9.81 * m])
        tau.append(float(a @ f))
    return dict(zip(ARMJ, tau))


for sd in data:
    sd["tau"] = [gravity_torques(q) for q in sd["q"]]
    print(sd["name"], "gravity torque N m (median):", {n[len(SIDE) + 1:-6]: round(float(np.median([t[n] for t in sd["tau"]])), 2) for n in ARMJ}, flush=True)


def cam_pose(p, q, model, tau=None):
    joints, links, wm = MODELS[model]
    q2 = dict(q)
    for n, d in zip(joints, p):
        q2[n] = q2.get(n, 0.0) + d
    i = len(joints)
    base = model[:-6] if model.endswith("_mount") else model
    if base in COMPL:
        for n in COMPL[base]:
            q2[n] = q2.get(n, 0.0) + p[i] * tau[n]; i += 1
    corr = {}
    for ln in links:
        corr[ln] = se3(p[i:i + 6]); i += 6
    Tm = M0 @ se3(p[i:i + 6]) if wm else M0
    return fk(f"{SIDE}_dex1_base_link", q2, corr) @ Tm


def resid(p, scales, sessions, model):
    out = []
    for s, sd in zip(scales, sessions):
        K = K0.copy(); K[0, 0] *= s; K[1, 1] *= s
        for (_, Tb, ci, uv), q, tau in zip(sd["rows"], sd["q"], sd["tau"]):
            out.append((project(OBJ[ci] @ Tb[:3, :3].T + Tb[:3, 3], cam_pose(p, q, model, tau), K, D0) - uv).ravel())
    return np.concatenate(out)


def ncompl(model):
    base = model[:-6] if model.endswith("_mount") else model
    return len(COMPL.get(base, []))


def npar(model):
    joints, links, wm = MODELS[model]
    return len(joints) + ncompl(model) + 6 * len(links) + (6 if wm else 0)


def fit(sessions, model, p=None):
    n, k = len(sessions), npar(model)
    if p is None:
        f = lambda x: resid(x[:k], x[k:], sessions, model)
        r = least_squares(f, np.r_[np.zeros(k), np.ones(n)], loss="soft_l1", f_scale=2.0, x_scale=np.r_[np.full(k, 0.01), np.full(n, 0.01)])
        return r.x[:k], r.x[k:]
    r = least_squares(lambda x: resid(p, x, sessions, model), np.ones(n), loss="soft_l1", f_scale=2.0)
    return p, r.x


def rms(p, scales, sessions, model):
    e = resid(p, scales, sessions, model).reshape(-1, 2)
    return round(float(np.sqrt(np.mean(np.sum(e ** 2, 1)))), 2)


def describe(p, model):
    joints, links, wm = MODELS[model]
    d = {"joint_offsets_deg": dict(zip(joints, np.round(np.degrees(p[:len(joints)]), 3).tolist()))}
    i = len(joints)
    base = model[:-6] if model.endswith("_mount") else model
    if base in COMPL:
        d["compliance_deg_per_Nm"] = dict(zip(COMPL[base], np.round(np.degrees(p[i:i + ncompl(model)]), 4).tolist()))
        i += ncompl(model)
    for name in links + (["camera_mount"] if wm else []):
        d[f"{name}_delta_deg"] = np.round(np.degrees(p[i:i + 3]), 3).tolist()
        d[f"{name}_delta_mm"] = np.round(p[i + 3:i + 6] * 1000, 2).tolist()
        i += 6
    return d


res = {"side": SIDE, "sessions": [sd["name"] for sd in data]}
for model in MODELS:
    r = {"loso": {}}
    for k, sd in enumerate(data):
        train = [x for i, x in enumerate(data) if i != k]
        p, _ = fit(train, model)
        _, s = fit([sd], model, p)
        r["loso"][sd["name"]] = {"heldout_rms_px": rms(p, s, [sd], model)} | describe(p, model)
    p, s = fit(data, model)
    r["all"] = describe(p, model) | {"params": p.tolist(), "focal_scales": np.round(s, 4).tolist(),
                                    "rms_px": {x["name"]: rms(p, [si], [x], model) for x, si in zip(data, s)}}
    res[model] = r
    print(model, json.dumps({n: v["heldout_rms_px"] for n, v in r["loso"].items()}), json.dumps(r["all"]), flush=True)
OUT.write_text(json.dumps(res, indent=1))
