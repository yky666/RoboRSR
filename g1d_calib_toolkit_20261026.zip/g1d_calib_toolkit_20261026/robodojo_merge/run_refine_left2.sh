#!/bin/bash
# left wrist mount refinement with the new left-arm board session (2026-10-22 17:2x) added
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=4
$PY -u refine_wrist_mount.py left $D/refine_left2.json \
  $S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left \
  $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left \
  $D/board_views_20261022 \
  $D/left_session_20261022 > $D/refine_left2.log 2>&1
echo DONE >> $D/refine_left2.log
