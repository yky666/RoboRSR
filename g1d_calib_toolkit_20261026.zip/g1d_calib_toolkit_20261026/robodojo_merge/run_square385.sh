#!/bin/bash
# wrist checks with the measured printed square (38.5 mm instead of 40): camera-mount and whole-arm-offset modes, plus
# the board-scale fit on top (should now come out near 1)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=2 BOARD_SQUARE_MM=${BOARD_SQUARE_MM:-38.5}
T=sq${BOARD_SQUARE_MM/./}
LEFT="$S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023"
RIGHT="$S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right $D/board_views_20261022 $D/board_views_1023"
$PY -u refine_wrist_mount.py left $D/${T}_mount_left.json $LEFT > $D/${T}_mount_left.log 2>&1 &
$PY -u refine_wrist_mount.py right $D/${T}_mount_right.json $RIGHT > $D/${T}_mount_right.log 2>&1 &
ARM_OFFSET=1 $PY -u refine_wrist_mount.py left $D/${T}_armoff_left.json $LEFT > $D/${T}_armoff_left.log 2>&1 &
ARM_OFFSET=1 $PY -u refine_wrist_mount.py right $D/${T}_armoff_right.json $RIGHT > $D/${T}_armoff_right.log 2>&1 &
$PY -u refine_board_scale.py left $D/${T}_bscale_left.json $LEFT 2>&1 | grep -v 'wrist frames' > $D/${T}_bscale_left.log &
$PY -u refine_board_scale.py right $D/${T}_bscale_right.json $RIGHT 2>&1 | grep -v 'wrist frames' > $D/${T}_bscale_right.log &
wait
$PY - <<EOF
import json
for side in ("left", "right"):
    print("=====", side)
    for mode in ("mount", "armoff"):
        a = json.load(open(f"${T}_{mode}_{side}.json"))
        cur = {k: v["current_rms_px"] for k, v in a["sessions"].items()}
        fs = {k: v["focal_scale_current"] for k, v in a["sessions"].items()}
        lo = {k: v["heldout_rms_px"] for k, v in a["loso"]["full"].items()}
        if mode == "mount":
            print("current rms   ", cur)
            print("current focal ", fs)
        print(mode, "LOSO       ", lo)
        print(mode, "all delta  ", a["all_full"]["delta_deg"], a["all_full"]["delta_mm"], "focal", list(a["all_full"]["focal_scales"].values()))
EOF
echo "---- board scale on top of ${BOARD_SQUARE_MM} mm"
cat $D/${T}_bscale_left.log $D/${T}_bscale_right.log | grep -E '^(scale|scale_mount) '
