#!/bin/bash
# render check of the calibrated RoboDojo G1-D with our cameras on the sim 5090: bash run_render_check.sh <gpu>
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
D=/root/unitree_sim_isaaclab/real2sim_calib_20261015/robodojo_g1d_calib_20261022
GPU=${1:-1}
mkdir -p /dev/shm/tmp $D/check/out
cd $D/check
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6 TMPDIR=/dev/shm/tmp
CUDA_VISIBLE_DEVICES=$GPU timeout --signal=TERM --kill-after=20s 1500s $ENV/bin/python -u render_check_ours.py \
  --urdf $D/g1d_dex1_calib.urdf --cams $D/camera_setup_ours.json \
  --pose B_right_016=$D/check/pose_B_right_016.json --pose B_left_014=$D/check/pose_B_left_014.json \
  --out $D/check/out --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$GPU --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" > $D/check/render_check.log 2>&1
echo "EXIT=$?" >> $D/check/render_check.log
