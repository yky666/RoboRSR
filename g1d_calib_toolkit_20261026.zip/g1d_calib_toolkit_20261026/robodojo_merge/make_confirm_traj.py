# make_confirm_traj.py -- measured joint trajectory of the confirmation clip at the head camera frame times:
# 14 arm joints + waist yaw (motor 12 -> torso_Joint) + Dex1 fingers (motors 31/33 via Unitree's linear map).
# usage: make_confirm_traj.py <logger_run_dir> <out.json> [t_from_rel t_to_rel]
import glob
import json
import os
import sys

import numpy as np

RUN, OUT = sys.argv[1], sys.argv[2]
meta = json.load(open(os.path.join(RUN, "meta.json")))
ids = meta["motor_ids"]
nm = len(ids)
S = np.vstack([np.load(f) for f in sorted(glob.glob(os.path.join(RUN, "state_*.npy")))])
S = S[np.argsort(S[:, 0])]
tw, q = S[:, 0], S[:, 4:4 + nm]
ARM = ["left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
       "left_wrist_roll_joint", "left_wrist_pitch_joint", "left_wrist_yaw_joint",
       "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint",
       "right_wrist_roll_joint", "right_wrist_pitch_joint", "right_wrist_yaw_joint"]
heads = sorted(glob.glob(os.path.join(RUN, "head", "*.jpg")))
ht = np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in heads])
t0 = ht[0]
lo, hi = (float(sys.argv[3]), float(sys.argv[4])) if len(sys.argv) > 4 else (0.0, 1e9)
frames = []
for f, t in zip(heads, ht):
    if not (lo <= t - t0 <= hi) or t < tw[0] or t > tw[-1]:
        continue
    row = {n: float(np.interp(t, tw, q[:, ids.index(15 + k)])) for k, n in enumerate(ARM)}
    row["torso_Joint"] = float(np.interp(t, tw, q[:, ids.index(12)]))
    for side, m in (("left", 31), ("right", 33)):
        g = float(np.interp(t, tw, q[:, ids.index(m)]))
        row[f"{side}_dex1_finger_joint_1"] = row[f"{side}_dex1_finger_joint_2"] = 0.024 - 0.044 * min(max(g, 0.0), 5.4) / 5.4
    frames.append({"t": float(t), "t_rel": float(t - t0), "head": os.path.basename(f), "q": row})
json.dump({"run": os.path.basename(os.path.normpath(RUN)), "fps": 10.0, "frames": frames}, open(OUT, "w"), indent=0)
amp = np.ptp([[fr["q"][n] for n in ARM] for fr in frames], axis=0)
print(f"{len(frames)} frames, t_rel {frames[0]['t_rel']:.1f}-{frames[-1]['t_rel']:.1f} s; arm joint range of motion (rad): "
      f"{np.round(amp, 2).tolist()}")
