# make_camera_setup.py -- our calibrated cameras for the RoboDojo-derived G1-D URDF, as one ready-to-use file:
# per view the parent link, T_parent_camera_world_convention (+x forward, +y left, +z up) with the identified
# camera:<name> delta already right-multiplied, and the final intrinsics (checkerboard K/dist + identified deltas).
# The parent links (head_link, *_dex1_base_link) and the arm chain match our calibrated model exactly.
# usage: [CALIB_PARAMS=<params.json>] [BOARD_SQUARE_MM=38.5] make_camera_setup.py <out.json>
#   BOARD_SQUARE_MM: true printed square of the 40 mm-nominal boards; rescales the stereo translation (rotation unchanged)
import json
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
PKG = ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"
sys.path.insert(0, str(PKG))
from calib_model import load_params, se3, se3_of  # noqa: E402

PARAMS = Path(os.environ.get("CALIB_PARAMS", ROOT / "pc_tools/replay_cups/model/params_final_1021.json"))
SQUARE_MM = float(os.environ.get("BOARD_SQUARE_MM", "40"))
P = load_params(PARAMS)["values"]
contract = json.loads((PKG / "nominal/camera_contract_v5.json").read_text(encoding="utf-8"))
# head_right = head_left mount composed with the 2026-10-16 stereoCalibrate R,T (X_right = R X_left + T, OpenCV optical);
# the contract's parallel / 59.6 mm right-eye mount made the two eyes disagree by ~5 mm on the table board
STEREO = json.loads((ROOT / "pc_tools/replay_cups/out/head_stereo_extrinsics.json").read_text(encoding="utf-8"))
T_RL = np.eye(4)
T_RL[:3, :3] = np.array(STEREO["R_right_from_left"])
T_RL[:3, 3] = np.array(STEREO["T_right_from_left_m"]) * SQUARE_MM / 40
C2O = np.eye(4)
C2O[:3, :3] = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float).T  # optical -> x-fwd camera
views = {}
for v in contract["views"]:
    name = v["name"]
    d = json.loads((ROOT / f"pc_tools/calib_data/intrinsics/camera_intrinsics_{name}.json").read_text(encoding="utf-8"))
    K, dist = np.array(d["K"], float), np.array(d["dist"], float)
    for i, k in enumerate(("fx", "fy", "cx", "cy")):
        K[[0, 1, 0, 1][i], [0, 1, 2, 2][i]] += P.get(f"intrinsics:{name}/{k}", 0.0)
    dist = dist + np.array([P.get(f"intrinsics:{name}/{k}", 0.0) for k in ("k1", "k2", "p1", "p2", "k3")])
    T = np.array(v["T_parent_camera_world_convention"], float) @ se3(se3_of(P, f"camera:{name}"))
    if name == "head_right":
        T_left = np.array(next(x for x in contract["views"] if x["name"] == "head_left")["T_parent_camera_world_convention"], float)
        T = T_left @ C2O @ np.linalg.inv(T_RL) @ np.linalg.inv(C2O)
    views[name] = {
        "parent": v["parent"],
        "T_parent_camera_world_convention": np.round(T, 8).tolist(),
        "resolution": [int(x) for x in d["resolution"]],
        "K": np.round(K, 4).tolist(),
        "dist_k1k2p1p2k3": np.round(dist, 6).tolist(),
        "port": d.get("port", d.get("zmq_port")),
        "notes": ("wrist autofocus: fx valid for the 0.2-0.4 m working range (identified AF delta applied)"
                  if name.endswith("wrist") else
                  "fixed focus; mount = head_left mount + stereoCalibrate R,T (2026-10-16)" if name == "head_right" else "fixed focus"),
    }
out = {
    "format": "g1d_camera_setup_v1",
    "description": "Our calibrated head stereo + wrist cameras for g1d_dex1_calib.urdf / g1d_mobile_dex1_calib.urdf "
                   f"(RoboDojo G1-D asset + {PARAMS.stem} arm calibration, board square {SQUARE_MM} mm). Mounts already include the identified "
                   "camera deltas; K/dist already include the identified intrinsics deltas. Camera frame convention: "
                   "+x forward, +y left, +z up (Isaac 'world' camera convention); optical = OpenCV (z forward, y down).",
    "physical_ports": {"head_stereo": 55555, "left_wrist (JR0002)": 55556, "right_wrist (JR0001)": 55557},  # since 2026-10-21 21:25
    "views": views,
}
Path(sys.argv[1]).write_text(json.dumps(out, indent=1), encoding="utf-8")
for n, v in views.items():
    print(f"{n:11s} parent {v['parent']:22s} fx {v['K'][0][0]:7.2f} cx {v['K'][0][2]:6.1f} cy {v['K'][1][2]:6.1f} "
          f"pos {np.round(np.array(v['T_parent_camera_world_convention'])[:3, 3], 4).tolist()}")
