#!/bin/bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015/robodojo_g1d_calib_20261022/check
ls chain2_done 2>/dev/null
for f in chain2_*.log; do
  echo "== $f"
  grep -E '^origin6|Error|Traceback' "$f" | cut -c1-1200
  tail -2 "$f" | cut -c1-300
done
