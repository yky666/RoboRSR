# refine_board_scale.py -- runs on the sim 5090. Hypothesis: the printed board is not 40 mm per square. A board k times
# the assumed size looks identical to the head at k times the distance, so the head-derived corner positions are
# rescaled by k about the head stereo centre. Models (one focal scale per session, leave-one-session-out):
#   scale: k only; scale_mount: k + wrist camera mount correction (6); mount: mount only (reference)
# usage: refine_board_scale.py <side> <out.json> <session_dir> ...
import json
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

src_path = Path(__file__).parent / "refine_wrist_mount.py"
src = open(src_path, encoding="utf-8").read().split("M0 = np.array(")[0]
g = {"__file__": str(src_path)}
exec(compile(src, str(src_path), "exec"), g)
data, fk, project, OBJ, K0, D0, SIDE, CAMS = (g[k] for k in ("data", "fk", "project", "OBJ", "K0", "D0", "SIDE", "CAMS"))
OUT = Path(sys.argv[2])
M0 = np.array(CAMS[f"{SIDE}_wrist"]["T_parent_camera_world_convention"])
MODELS = {"mount": (False, True), "scale": (True, False), "scale_mount": (True, True)}


def head_centre(q):
    return np.mean([(fk(CAMS[e]["parent"], q) @ np.array(CAMS[e]["T_parent_camera_world_convention"]))[:3, 3]
                    for e in ("head_left", "head_right")], 0)


for sd in data:
    sd["P"] = [OBJ[ci] @ Tb[:3, :3].T + Tb[:3, 3] for _, Tb, ci, _ in sd["rows"]]
    sd["eye"] = [head_centre(q) for q in sd["q"]]


def split(p, model):
    ws, wm = MODELS[model]
    k = 1 + p[0] if ws else 1.0
    m = p[int(ws):int(ws) + 6] if wm else np.zeros(6)
    T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(m[:3]).as_matrix(); T[:3, 3] = m[3:]
    return k, M0 @ T


def resid(p, scales, sessions, model):
    k, Tm = split(p, model)
    out = []
    for s, sd in zip(scales, sessions):
        K = K0.copy(); K[0, 0] *= s; K[1, 1] *= s
        for (Tp, _, ci, uv), P, e in zip(sd["rows"], sd["P"], sd["eye"]):
            out.append((project(e + k * (P - e), Tp @ Tm, K, D0) - uv).ravel())
    return np.concatenate(out)


def npar(model):
    ws, wm = MODELS[model]
    return int(ws) + (6 if wm else 0)


def fit(sessions, model, p=None):
    n, k = len(sessions), npar(model)
    if p is None:
        r = least_squares(lambda x: resid(x[:k], x[k:], sessions, model), np.r_[np.zeros(k), np.ones(n)],
                          loss="soft_l1", f_scale=2.0, x_scale=0.01)
        return r.x[:k], r.x[k:]
    r = least_squares(lambda x: resid(p, x, sessions, model), np.ones(n), loss="soft_l1", f_scale=2.0)
    return p, r.x


def rms(p, scales, sessions, model):
    e = resid(p, scales, sessions, model).reshape(-1, 2)
    return round(float(np.sqrt(np.mean(np.sum(e ** 2, 1)))), 2)


def describe(p, model):
    ws, wm = MODELS[model]
    d = {}
    if ws:
        d["board_scale"] = round(1 + float(p[0]), 5)
        d["square_mm"] = round(40 * (1 + float(p[0])), 3)
    if wm:
        m = p[int(ws):]
        d["mount_delta_deg"] = np.round(np.degrees(m[:3]), 3).tolist()
        d["mount_delta_mm"] = np.round(m[3:6] * 1000, 2).tolist()
    return d


res = {"side": SIDE, "sessions": [sd["name"] for sd in data]}
for model in MODELS:
    r = {"loso": {}}
    for i, sd in enumerate(data):
        train = [x for j, x in enumerate(data) if j != i]
        p, _ = fit(train, model)
        _, s = fit([sd], model, p)
        r["loso"][sd["name"]] = {"heldout_rms_px": rms(p, s, [sd], model)} | describe(p, model)
    p, s = fit(data, model)
    r["all"] = describe(p, model) | {"focal_scales": np.round(s, 4).tolist(),
                                    "rms_px": {x["name"]: rms(p, [si], [x], model) for x, si in zip(data, s)}}
    res[model] = r
    print(model, "LOSO", json.dumps({n: (v["heldout_rms_px"], v.get("square_mm")) for n, v in r["loso"].items()}), flush=True)
    print(model, "ALL ", json.dumps(r["all"]), flush=True)
OUT.write_text(json.dumps(res, indent=1))
