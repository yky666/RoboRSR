# render_confirm.py -- our sim 5090: the calibrated RoboDojo G1-D with its real finish (metal / black materials and the
# forearm ring, same rules as RoboDojo's g1d.py), replaying the measured joint trajectory of the confirmation clip and
# rendering head_left / left_wrist / right_wrist from camera_setup_ours.json (calibrated pinholes, principal point via
# aperture offsets) for every head frame.
# usage: render_confirm.py --urdf ... --cams camera_setup_ours.json --traj confirm_traj.json --out <dir>
import argparse
import json
import os
import re
import sys
import traceback

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--urdf", required=True)
parser.add_argument("--cams", required=True)
parser.add_argument("--traj", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--views", default="head_left,left_wrist,right_wrist")
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.headless = True
args.enable_cameras = True
app = AppLauncher(args).app

import carb  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402
from PIL import Image  # noqa: E402
from pxr import Usd, UsdGeom, UsdShade, Vt  # noqa: E402
from scipy.spatial.transform import Rotation  # noqa: E402

import isaaclab.sim as sim_utils  # noqa: E402
from isaaclab.actuators import ImplicitActuatorCfg  # noqa: E402
from isaaclab.assets import Articulation, ArticulationCfg  # noqa: E402
from isaaclab.sensors import Camera, CameraCfg  # noqa: E402
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg  # noqa: E402

DT = 1 / 60
# real G1-D finish, as RoboDojo env/robot_manager/robot_config/g1d.py
MATERIALS = {
    "metal": sim_utils.PreviewSurfaceCfg(diffuse_color=(0.62, 0.63, 0.65), metallic=1.0, roughness=0.5),
    "black": sim_utils.PreviewSurfaceCfg(diffuse_color=(0.02, 0.02, 0.02), roughness=0.8),
    "white": sim_utils.PreviewSurfaceCfg(diffuse_color=(0.85, 0.86, 0.87), roughness=0.45),
}
LINK_MATERIALS = {  # as g1d.py, except the torso and chassis shells, which are white on the real robot
    r"torso_link|AGV_link": "white",
    r"LZ_.*_Link|.*_(shoulder_.*|elbow|wrist_.*)_link": "metal",
    r".*_dex1_.*|Yaw_Link|Pitching_Link|head_link|logo_link|.*_Wheel_Link": "black",
}
RING_LINKS, RING_X = r".*_elbow_link", (0.075, 0.2)


def paint_ring(link, material):
    cache = UsdGeom.XformCache()
    for p in Usd.PrimRange(link.GetChild("visuals")):
        if not p.IsA(UsdGeom.Mesh):
            continue
        mesh = UsdGeom.Mesh(p)
        to_link = np.array(cache.ComputeRelativeTransform(p, link)[0])
        pts = np.array(mesh.GetPointsAttr().Get())
        x = (pts @ to_link[:3, :3] + to_link[3, :3])[:, 0]
        counts = np.array(mesh.GetFaceVertexCountsAttr().Get())
        fx = np.add.reduceat(x[np.array(mesh.GetFaceVertexIndicesAttr().Get())], np.r_[0, np.cumsum(counts)[:-1]]) / counts
        faces = np.nonzero((fx > RING_X[0]) & (fx < RING_X[1]))[0].tolist()
        binding = UsdShade.MaterialBindingAPI.Apply(p)
        subset = binding.CreateMaterialBindSubset("ring", Vt.IntArray(faces), UsdGeom.Tokens.face)
        UsdShade.MaterialBindingAPI.Apply(subset.GetPrim()).Bind(material)


def apply_finish(stage, root):
    mats = {}
    for name, cfg in MATERIALS.items():
        cfg.func(f"/World/Looks/{name}", cfg)
        mats[name] = UsdShade.Material(stage.GetPrimAtPath(f"/World/Looks/{name}"))
    n = 0
    for link in stage.GetPrimAtPath(root).GetChildren():
        visuals = link.GetChild("visuals")
        name = next((m for pat, m in LINK_MATERIALS.items() if re.fullmatch(pat, link.GetName())), None)
        if not visuals or name is None:
            continue
        visuals.SetInstanceable(False)
        if re.fullmatch(RING_LINKS, link.GetName()):
            for p in Usd.PrimRange(visuals):
                if p.IsA(UsdGeom.Mesh):
                    UsdShade.MaterialBindingAPI.Apply(p).Bind(mats[name])
            paint_ring(link, mats["black"])
        else:
            sim_utils.bind_visual_material(str(visuals.GetPath()), str(mats[name].GetPath()))
        n += 1
    print(f"materials bound on {n} links", flush=True)


def pose_T(state):
    s = state.detach().cpu().numpy()
    T = np.eye(4); T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix(); T[:3, 3] = s[:3]
    return T


def main():
    os.makedirs(args.out, exist_ok=True)
    views = args.views.split(",")
    cams_cfg = {k: v for k, v in json.load(open(args.cams))["views"].items() if k in views}
    traj = json.load(open(args.traj))["frames"]
    render = sim_utils.RenderCfg(enable_reflections=True, enable_global_illumination=True, rendering_mode="quality",
                                 antialiasing_mode="DLAA")
    carb.settings.get_settings().set_float("/rtx/translucency/worldEps", 0.0)
    sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=DT, device=args.device, render=render))
    stage = sim.stage
    conv = UrdfConverter(UrdfConverterCfg(
        asset_path=args.urdf, usd_dir=os.path.join(args.out, "usd"), usd_file_name="g1d_dex1_calib.usd",
        fix_base=True, merge_fixed_joints=False, force_usd_conversion=True, make_instanceable=False,
        joint_drive=UrdfConverterCfg.JointDriveCfg(gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
    robot = Articulation(ArticulationCfg(
        prim_path="/World/Robot",
        spawn=sim_utils.UsdFileCfg(usd_path=conv.usd_path, rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
                                   articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                                       enabled_self_collisions=False, solver_position_iteration_count=16)),
        actuators={"all": ImplicitActuatorCfg(joint_names_expr=[".*"], stiffness=1e5, damping=1e3)}))
    apply_finish(stage, "/World/Robot")
    bottom = UsdGeom.BBoxCache(Usd.TimeCode.Default(), ["default", "render"]).ComputeWorldBound(
        stage.GetPrimAtPath("/World/Robot")).ComputeAlignedRange().GetMin()[2]
    floor = sim_utils.CuboidCfg(size=(30.0, 30.0, 0.02), visual_material=sim_utils.PreviewSurfaceCfg(
        diffuse_color=(0.36, 0.39, 0.44), roughness=0.9))  # grey-blue carpet
    floor.func("/World/floor", floor, translation=(0.0, 0.0, bottom - 0.01))
    wall = sim_utils.CuboidCfg(size=(0.05, 30.0, 6.0), visual_material=sim_utils.PreviewSurfaceCfg(
        diffuse_color=(0.82, 0.83, 0.80), roughness=0.9))
    wall.func("/World/wall", wall, translation=(3.0, 0.0, bottom + 3.0))
    sim_utils.DomeLightCfg(intensity=700.0, color=(1.0, 0.98, 0.95)).func("/World/dome", sim_utils.DomeLightCfg(intensity=700.0))
    sun = sim_utils.DistantLightCfg(intensity=1800.0, angle=8.0)
    sun.func("/World/sun", sun, orientation=(0.9397, 0.2418, 0.2418, 0.0))
    cams = {n: Camera(CameraCfg(prim_path=f"/World/cam_{n}", width=c["resolution"][0], height=c["resolution"][1],
                                data_types=["rgb"],
                                spawn=sim_utils.PinholeCameraCfg(focal_length=24.0, clipping_range=(0.02, 20.0))))
            for n, c in cams_cfg.items()}
    sim.reset()
    for n, c in cams_cfg.items():
        W, H = c["resolution"]
        (fx, _, cx), (_, fy, cy) = c["K"][0], c["K"][1]
        prim = stage.GetPrimAtPath(f"/World/cam_{n}")
        hap, vap = 24.0 * W / fx, 24.0 * H / fy
        prim.GetAttribute("horizontalAperture").Set(float(hap)); prim.GetAttribute("verticalAperture").Set(float(vap))
        prim.GetAttribute("horizontalApertureOffset").Set(float((W / 2.0 - cx) * hap / W))
        prim.GetAttribute("verticalApertureOffset").Set(float((cy - H / 2.0) * vap / H))
    head_vis = [p for p in stage.Traverse() if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link"]

    jn, names = robot.joint_names, robot.body_names
    print("movable joints:", len(jn), flush=True)
    for k, fr in enumerate(traj):
        tgt = torch.zeros_like(robot.data.default_joint_pos)
        for i, n in enumerate(jn):
            tgt[0, i] = fr["q"].get(n, 0.0)
        robot.write_joint_state_to_sim(tgt, torch.zeros_like(tgt))
        for _ in range(2):
            robot.set_joint_position_target(tgt)
            robot.write_data_to_sim()
            sim.step(render=False)
            robot.update(DT)
        for n, c in cams_cfg.items():
            T = pose_T(robot.data.body_link_state_w[0, names.index(c["parent"]), :7]) @ np.array(c["T_parent_camera_world_convention"])
            xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
            cams[n].set_world_poses(torch.tensor([T[:3, 3]], dtype=torch.float32, device=args.device),
                                    torch.tensor([xyzw[[3, 0, 1, 2]]], dtype=torch.float32, device=args.device),
                                    convention="world")
        for n, cam in cams.items():
            for p in head_vis:  # the head shell is hidden for the head camera only (its lens sits inside the shell)
                UsdGeom.Imageable(p).MakeInvisible() if n.startswith("head") else UsdGeom.Imageable(p).MakeVisible()
            for _ in range(6 if k == 0 else 3):
                sim.render()
            cam.update(DT)
            rgb = cam.data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
            Image.fromarray(rgb).save(os.path.join(args.out, f"sim_{n}_{k:04d}.jpg"), quality=92)
        if k % 50 == 0:
            print(f"frame {k}/{len(traj)}", flush=True)
    print("done", flush=True)


try:
    main()
    failed = False
except Exception:
    traceback.print_exc()
    failed = True
sys.stdout.flush()
sys.stderr.flush()
os._exit(1 if failed else 0)
