# inspect_meas.py -- print the structure of a meas_*.json (export_meas.py) and an identify_*.json
import json
import sys

d = json.load(open(sys.argv[1]))
print("meas keys", list(d.keys()))
for k, v in d.items():
    if k != "samples":
        print(" ", k, json.dumps(v)[:700])
s = d["samples"][0]
print("sample keys", list(s.keys()))
print(" ", json.dumps(s)[:600])
r = json.load(open(sys.argv[2]))
print("identify keys", list(r.keys()))
for k, v in r.items():
    if not isinstance(v, (list, dict)) or len(json.dumps(v)) < 900:
        print(" ", k, json.dumps(v)[:900])
