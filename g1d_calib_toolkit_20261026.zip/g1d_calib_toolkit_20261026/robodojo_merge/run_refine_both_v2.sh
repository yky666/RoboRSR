#!/bin/bash
# wrist checks again after the head_right mount fix (camera_setup_ours.json v2): left with all 4 sessions, right with 3
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=4
$PY -u refine_wrist_mount.py left $D/refine_left_v2.json \
  $S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left \
  $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left \
  $D/board_views_20261022 $D/left_session_20261022 > $D/refine_left_v2.log 2>&1 &
$PY -u refine_wrist_mount.py right $D/refine_right_v2.json \
  $S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right \
  $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right \
  $D/board_views_20261022 > $D/refine_right_v2.log 2>&1 &
wait
echo DONE >> $D/refine_right_v2.log
