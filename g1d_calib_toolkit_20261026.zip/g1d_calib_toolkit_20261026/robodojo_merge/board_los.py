# board_los.py -- runs on the sim 5090. Split the fitted whole-arm offset (armoff_<side>.json, all_full) at each
# session's board centre into the component along the head_left line of sight and the part perpendicular to it.
# usage: board_los.py <side> <session_dir> ...   (same session list as the armoff run)
import json
import sys
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

src_path = Path(__file__).parent / "refine_wrist_mount.py"
src = open(src_path, encoding="utf-8").read().split("M0 = np.array(")[0]
sys.argv = [str(src_path), sys.argv[1], "/tmp/unused.json"] + sys.argv[2:]
g = {"__file__": str(src_path)}
exec(compile(src, str(src_path), "exec"), g)
data, fk, CAMS, OBJ, SIDE = g["data"], g["fk"], g["CAMS"], g["OBJ"], g["SIDE"]
a = json.load(open(f"armoff_{SIDE}.json"))["all_full"]
To = np.eye(4)
To[:3, :3] = Rotation.from_rotvec(np.radians(a["delta_deg"])).as_matrix()
To[:3, 3] = np.array(a["delta_mm"]) / 1000
c = CAMS["head_left"]
Th = fk(c["parent"], {}) @ np.array(c["T_parent_camera_world_convention"])
eye = Th[:3, 3]
print(f"{SIDE}: head_left centre in torso {np.round(eye, 3).tolist()}, optical axis {np.round(Th[:3, 0], 3).tolist()}")
ctr = OBJ.mean(0)
for sd in data:
    Tb = sd["rows"][0][1]
    p = Tb[:3, :3] @ ctr + Tb[:3, 3]
    d = To @ np.r_[p, 1]
    d = d[:3] - p  # displacement of the arm at the board = minus the board's displacement relative to the arm
    los = (p - eye) / np.linalg.norm(p - eye)
    along = float(d @ los)
    perp = float(np.linalg.norm(d - along * los))
    print(f"  {sd['name']:48s} board {np.round(p, 3).tolist()} range {np.linalg.norm(p - eye) * 1000:6.0f} mm  "
          f"offset {np.round(d * 1000, 1).tolist()} mm -> along line of sight {along * 1000:+6.1f} mm "
          f"({along / np.linalg.norm(p - eye) * 100:+.2f} % of range), perpendicular {perp * 1000:5.1f} mm")
