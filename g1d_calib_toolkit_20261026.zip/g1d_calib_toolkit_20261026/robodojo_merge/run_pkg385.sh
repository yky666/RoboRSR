#!/bin/bash
# wrist-vs-head check of the 38.5 mm rebuild (params_final_sq385c: dual_trans on the rescaled board + refitted shoulder
# mounts; stereo baseline rescaled), board square 38.5 mm everywhere
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=2 BOARD_SQUARE_MM=38.5 CALIB_PKG=$BASE/robodojo_g1d_calib_sq385_20261023
T=pkg385
LEFT="$S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023"
RIGHT="$S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right $D/board_views_20261022 $D/board_views_1023"
$PY -u refine_wrist_mount.py left $D/${T}_mount_left.json $LEFT > $D/${T}_mount_left.log 2>&1 &
$PY -u refine_wrist_mount.py right $D/${T}_mount_right.json $RIGHT > $D/${T}_mount_right.log 2>&1 &
ARM_OFFSET=1 $PY -u refine_wrist_mount.py left $D/${T}_armoff_left.json $LEFT > $D/${T}_armoff_left.log 2>&1 &
ARM_OFFSET=1 $PY -u refine_wrist_mount.py right $D/${T}_armoff_right.json $RIGHT > $D/${T}_armoff_right.log 2>&1 &
wait
$PY - <<EOF
import json
for side in ("left", "right"):
    print("=====", side)
    for mode in ("mount", "armoff"):
        a = json.load(open(f"${T}_{mode}_{side}.json"))
        if mode == "mount":
            print("current rms   ", {k: v["current_rms_px"] for k, v in a["sessions"].items()})
            print("current focal ", {k: v["focal_scale_current"] for k, v in a["sessions"].items()})
        print(mode, "LOSO       ", {k: v["heldout_rms_px"] for k, v in a["loso"]["full"].items()})
        print(mode, "all delta  ", a["all_full"]["delta_deg"], a["all_full"]["delta_mm"], "focal", list(a["all_full"]["focal_scales"].values()))
EOF
