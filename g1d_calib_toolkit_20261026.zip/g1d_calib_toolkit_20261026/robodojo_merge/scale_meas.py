# scale_meas.py -- copy of a meas_*.json (export_meas.py) with the board rescaled to a different printed square size
# usage: scale_meas.py <in.json> <out.json> <square_mm>
import json
import sys

src, dst, sq = sys.argv[1], sys.argv[2], float(sys.argv[3])
d = json.load(open(src))
for b in d["boards"].values():
    k = sq / 1000 / b["square_length_m"]
    b["square_length_m"] *= k
    b["marker_length_m"] *= k
    b["points_m"] = [[p[0]] + [c * k for c in p[1:]] for p in b["points_m"]]
    b["scaled_from_square_m"] = b["square_length_m"] / k
json.dump(d, open(dst, "w"))
print(dst, {n: round(b["square_length_m"] * 1000, 3) for n, b in d["boards"].items()})
