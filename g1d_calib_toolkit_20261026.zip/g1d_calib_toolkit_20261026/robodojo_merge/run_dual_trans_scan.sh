#!/bin/bash
# re-run the dual_trans identification (same data and options as server_dual_trans.sh, 10-19) with the board rescaled
# to several printed square sizes; the arm kinematics carry metric scale, so the wrist data themselves pick the size
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data/20261019/sessions
W=$R/board_scale_20261023
mkdir -p $W
cp /tmp/scale_meas.py $W/
cd $R/../real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
for sq in 38.0 38.5 39.0 40.0; do
  t=${sq/./}
  for m in meas_B_left_1209 meas_B_left_1509_pm meas_B_right_1533_pm; do
    $PY $W/scale_meas.py $S/$m.json $W/${m}_sq$t.json $sq > /dev/null
  done
  $PY identify.py $W/meas_B_left_1209_sq$t.json $W/meas_B_left_1509_pm_sq$t.json $W/meas_B_right_1533_pm_sq$t.json \
    --preset auto --refine-intrinsics \
    --estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' \
    --loss soft_l1 --f-scale 1.0 --folds 5 --out $W/identify_dual_trans_sq$t.json --params-out $W/params_dual_trans_sq$t.json \
    > $W/identify_sq$t.log 2>&1 &
done
wait
echo DONE > $W/scan_done
