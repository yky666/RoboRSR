#!/bin/bash
# run the smoke test of the calibrated G1-D on 5090-2 (our folder only; the colleague's code is imported read-only)
D=${SMOKE_DIR:-/data/g1d_calib_merge_20261022}
export SMOKE_DIR=$D
GPU=${1:-4}
mkdir -p $D/robots
[ -e $D/robots/g1d ] || ln -s $D/calibrated $D/robots/g1d
cd $D/check
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 PYTHONPATH=/root/RoboDojo
CUDA_VISIBLE_DEVICES=$GPU timeout --signal=TERM --kill-after=20s 1500s /root/miniconda3/envs/RoboDojo/bin/python -u smoke_calib.py \
  > $D/check/smoke.log 2>&1
echo "EXIT=$?" >> $D/check/smoke.log
