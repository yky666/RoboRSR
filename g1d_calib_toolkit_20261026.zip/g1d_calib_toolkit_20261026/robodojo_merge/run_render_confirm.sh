#!/bin/bash
# render the confirmation clip on the sim 5090: bash run_render_confirm.sh <gpu>
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
D=/root/unitree_sim_isaaclab/real2sim_calib_20261015/robodojo_g1d_calib_20261022
GPU=${1:-1}
OUT=$D/check/confirm_render
mkdir -p /dev/shm/tmp $OUT
cd $D/check
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6 TMPDIR=/dev/shm/tmp
CUDA_VISIBLE_DEVICES=$GPU timeout --signal=TERM --kill-after=20s 3600s $ENV/bin/python -u render_confirm.py \
  --urdf $D/g1d_dex1_calib.urdf --cams $D/camera_setup_ours.json --traj $D/check/confirm_traj.json --out $OUT \
  --device cuda:0 --kit_args "--/renderer/activeGpu=$GPU --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" \
  > $D/check/render_confirm.log 2>&1
echo "EXIT=$?" >> $D/check/render_confirm.log
