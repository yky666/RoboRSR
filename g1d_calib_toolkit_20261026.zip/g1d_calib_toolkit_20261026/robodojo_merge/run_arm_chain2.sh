#!/bin/bash
# link-geometry hypotheses (6-dof joint origin corrections), one process per model, both arms
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=2
LEFT="$S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023"
RIGHT="$S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right $D/board_views_20261022 $D/board_views_1023"
for m in shoulder_yaw elbow wrist_roll wrist_pitch wrist_yaw; do
  CHAIN_MODELS=origin6_$m $PY -u refine_arm_chain.py left $D/chain2_left_$m.json $LEFT > $D/chain2_left_$m.log 2>&1 &
  CHAIN_MODELS=origin6_$m $PY -u refine_arm_chain.py right $D/chain2_right_$m.json $RIGHT > $D/chain2_right_$m.log 2>&1 &
done
wait
echo DONE > $D/chain2_done
