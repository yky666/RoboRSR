# refine_wrist_mount.py -- runs on the sim 5090. Refine a wrist camera mount against the head-measured table board.
# Per session the board pose comes from the head stereo (both eyes, all samples, outliers removed; per sample for
# sessions where the board moved). Model: calibrated arm FK (g1d_dex1_calib.urdf) @ current mount (camera_setup_ours)
# @ delta(rx, ry, rz, dx, dy, dz); wrist intrinsics = checkerboard K/dist with one focal scale per session (autofocus
# state). Leave-one-session-out: fit delta on the other sessions, then fit only the held-out session's focal scale.
# usage: refine_wrist_mount.py <side> <out.json> <session_dir>[:per_sample] ...
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

BASE = Path("/root/unitree_sim_isaaclab/real2sim_calib_20261015")
PKG = Path(__import__("os").environ.get("CALIB_PKG", BASE / "robodojo_g1d_calib_20261022"))
SIDE, OUT = sys.argv[1], Path(sys.argv[2])
SESS = [(Path(a.split(":")[0]), a.endswith(":per_sample")) for a in sys.argv[3:]]
CAMS = json.loads((PKG / "camera_setup_ours.json").read_text())["views"]
CHK = json.loads((BASE / f"real_data/20261016/intrinsics/camera_intrinsics_{SIDE}_wrist.json").read_text())
K0, D0 = np.array(CHK["K"], float), np.array(CHK["dist"], float)
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)  # x-fwd/y-left/z-up camera -> OpenCV optical
BOARD = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
DET = cv2.aruco.CharucoDetector(BOARD, cv2.aruco.CharucoParameters(), dp)
hp = cv2.aruco.DetectorParameters()  # small, far board in the head view (as locate_board_robot.py)
hp.minMarkerPerimeterRate = 0.01
hp.adaptiveThreshWinSizeMin, hp.adaptiveThreshWinSizeMax, hp.adaptiveThreshWinSizeStep = 3, 53, 4
hp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
hcp = cv2.aruco.CharucoParameters()
hcp.minMarkers = 1
DET_HEAD = cv2.aruco.CharucoDetector(BOARD, hcp, hp)
OBJ = BOARD.getChessboardCorners().astype(float) * float(__import__("os").environ.get("BOARD_SQUARE_MM", "40")) / 40  # printed size

J = {}
for j in ET.parse(PKG / "g1d_dex1_calib.urdf").getroot().findall("joint"):
    o = j.find("origin")
    T = np.eye(4)
    T[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
    T[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
    ax = j.find("axis")
    J[j.find("child").get("link")] = (j.get("name"), j.find("parent").get("link"), j.get("type"), T,
                                      np.array([float(v) for v in (ax.get("xyz") if ax is not None else "1 0 0").split()]))


def fk(link, q):
    T = np.eye(4)
    while link != "torso_link":
        name, parent, kind, M, axis = J[link]
        M = M.copy()
        if kind == "revolute" and q.get(name):
            R = np.eye(4); R[:3, :3] = Rotation.from_rotvec(axis * q[name]).as_matrix(); M = M @ R
        T = M @ T
        link = parent
    return T


def detect(path, half=None):
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        return None, None
    up, det = 2, DET
    if half is not None:
        w = img.shape[1] // 2
        img = img[:, :w] if half == 0 else img[:, w:]
        up, det = 3, DET_HEAD
    g = cv2.resize(img, None, fx=up, fy=up, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(g)
    if ci is None or len(ci) < 8:
        return None, None
    return ci.ravel(), (cc.reshape(-1, 2) + 0.5) / up - 0.5


def project(Pw, Tcam, K, D):
    pc = (Pw - Tcam[:3, 3]) @ Tcam[:3, :3] @ OPT.T
    uv, _ = cv2.projectPoints(pc.reshape(-1, 1, 3), np.zeros(3), np.zeros(3), K, D)
    return uv.reshape(-1, 2)


def head_board(path, q):
    """board pose in torso from both head eyes; None if neither eye sees >= 15 corners"""
    Ts = []
    for half, eye in ((0, "head_left"), (1, "head_right")):
        ci, uv = detect(path, half)
        if ci is None or len(ci) < 15:
            continue
        c = CAMS[eye]
        K, D = np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
        ok, rv, tv = cv2.solvePnP(OBJ[ci], uv, K, D, flags=cv2.SOLVEPNP_IPPE)
        ok, rv, tv = cv2.solvePnP(OBJ[ci], uv, K, D, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
        T_ob = np.eye(4); T_ob[:3, :3] = cv2.Rodrigues(rv)[0]; T_ob[:3, 3] = tv.ravel()
        T_cam = fk(c["parent"], q) @ np.array(c["T_parent_camera_world_convention"])
        C2O = np.eye(4); C2O[:3, :3] = OPT.T
        Ts.append(T_cam @ C2O @ T_ob)
    return Ts


def mean_pose(Ts):
    T = np.eye(4)
    T[:3, 3] = np.mean([t[:3, 3] for t in Ts], 0)
    T[:3, :3] = Rotation.from_matrix([t[:3, :3] for t in Ts]).mean().as_matrix()
    return T


# ---------------- load ----------------
ARMJ = [f"{SIDE}_{n}_joint" for n in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
data = []  # per session: name, list of (T_wrist_parent, T_board, ci, uv)
for sdir, per_sample in SESS:
    rows, boards = [], []
    if (sdir / "captures.json").exists():  # today's captures (capture_board_views.py)
        recs = json.loads((sdir / "captures.json").read_text())["records"]
        items = [({n: r["q_meas"][(0 if SIDE == "left" else 7) + i] for i, n in enumerate(ARMJ)},
                  sdir / r["frames"]["head"][0], sdir / r["frames"][f"{SIDE}_wrist"][0]) for r in recs]
    else:
        recs = [json.loads(l) for l in open(sdir / "samples.jsonl") if l.strip()]
        items = [(r["joints_before"]["q"], sdir / r["frames"]["head_stereo"][0]["file"],
                  sdir / r["frames"][f"{SIDE}_wrist"][0]["file"]) for r in recs if f"{SIDE}_wrist" in r["frames"]]
    for q, hpath, wpath in items:
        Th = head_board(hpath, q)
        ci, uv = detect(wpath)
        if ci is None:
            continue
        rows.append([fk(f"{SIDE}_dex1_base_link", q), Th, ci, uv, q])
        boards += Th
    if not rows:
        continue
    c = np.array([t[:3, 3] for t in boards])
    med = np.median(c, 0)
    good = [t for t in boards if np.linalg.norm(t[:3, 3] - med) < 0.012]
    T_sess = mean_pose(good)
    spread = float(np.sqrt(np.mean(np.sum((np.array([t[:3, 3] for t in good]) - T_sess[:3, 3]) ** 2, 1))) * 1000)
    out_rows, qs = [], []
    for Tp, Th, ci, uv, q in rows:
        if per_sample:
            if not Th:
                continue
            Tb = mean_pose(Th)
        else:
            Tb = T_sess
        out_rows.append((Tp, Tb, ci, uv))
        qs.append(q)
    data.append({"name": sdir.name, "rows": out_rows, "q": qs, "board_spread_mm": spread, "n_head": len(good)})
    print(f"{sdir.name}: {len(out_rows)} wrist frames, board from {len(good)} head views (spread {spread:.1f} mm)"
          f"{' per sample' if per_sample else ''}", flush=True)

M0 = np.array(CAMS[f"{SIDE}_wrist"]["T_parent_camera_world_convention"])


def mount(d):
    T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(d[:3]).as_matrix(); T[:3, 3] = d[3:6]
    return M0 @ T


ARM_OFFSET = "--arm-offset" in sys.argv[0:1] or bool(__import__("os").environ.get("ARM_OFFSET"))


def resid(delta, scales, sessions):
    """delta = camera-mount correction, or (ARM_OFFSET) one rigid transform of the whole arm in the torso frame,
    applied as the inverse transform of every head-measured board"""
    out = []
    if ARM_OFFSET:
        Tm = M0
        To = np.eye(4); To[:3, :3] = Rotation.from_rotvec(delta[:3]).as_matrix(); To[:3, 3] = delta[3:6]
        To = np.linalg.inv(To)
    else:
        Tm = mount(delta)
        To = np.eye(4)
    for s, sd in zip(scales, sessions):
        K = K0.copy(); K[0, 0] *= s; K[1, 1] *= s
        for Tp, Tb, ci, uv in sd["rows"]:
            Tb2 = To @ Tb
            out.append((project(OBJ[ci] @ Tb2[:3, :3].T + Tb2[:3, 3], Tp @ Tm, K, D0) - uv).ravel())
    return np.concatenate(out)


def fit(sessions, free_delta=True, delta=None, rot_only=False):
    n = len(sessions)
    nd = 3 if rot_only else 6
    d0 = np.zeros(6) if delta is None else delta

    def f(x):
        d = d0.copy()
        if free_delta:
            d[:nd] = x[:nd]
        return resid(d, x[nd if free_delta else 0:], sessions)
    x0 = np.r_[np.zeros(nd) if free_delta else [], np.ones(n)]
    r = least_squares(f, x0, loss="soft_l1", f_scale=2.0)
    d = d0.copy()
    if free_delta:
        d[:nd] = r.x[:nd]
    return d, r.x[nd if free_delta else 0:]


def rms(delta, scales, sessions):
    e = resid(delta, scales, sessions).reshape(-1, 2)
    return float(np.sqrt(np.mean(np.sum(e ** 2, 1))))


res = {"side": SIDE, "sessions": {}, "loso": {}}
for sd in data:  # baseline: current mount, only the focal scale fitted
    _, s = fit([sd], free_delta=False)
    res["sessions"][sd["name"]] = {"frames": len(sd["rows"]), "board_spread_mm": round(sd["board_spread_mm"], 1),
                                   "current_rms_px": round(rms(np.zeros(6), s, [sd]), 2), "focal_scale_current": round(float(s[0]), 4)}
for mode in ("full", "rot_only"):
    for k, sd in enumerate(data):
        train = [x for i, x in enumerate(data) if i != k]
        if not train:
            continue
        d, _ = fit(train, rot_only=(mode == "rot_only"))
        _, s = fit([sd], free_delta=False, delta=d)
        res["loso"].setdefault(mode, {})[sd["name"]] = {
            "heldout_rms_px": round(rms(d, s, [sd]), 2), "current_rms_px": res["sessions"][sd["name"]]["current_rms_px"],
            "delta_deg": np.round(np.degrees(d[:3]), 2).tolist(), "delta_mm": np.round(d[3:] * 1000, 1).tolist()}
    d, s = fit(data, rot_only=(mode == "rot_only"))
    res[f"all_{mode}"] = {"delta_deg": np.round(np.degrees(d[:3]), 3).tolist(), "delta_mm": np.round(d[3:] * 1000, 2).tolist(),
                          "rot_deg": round(float(np.degrees(np.linalg.norm(d[:3]))), 3),
                          "focal_scales": dict(zip([x["name"] for x in data], np.round(s, 4).tolist())),
                          "rms_px": {x["name"]: round(rms(d, [si], [x]), 2) for x, si in zip(data, s)},
                          "new_mount_T_parent_camera_world_convention": np.round(mount(d), 8).tolist()}
OUT.write_text(json.dumps(res, indent=1))
print(json.dumps({k: v for k, v in res.items() if k != "sessions"} | {"sessions": res["sessions"]}, indent=1))
