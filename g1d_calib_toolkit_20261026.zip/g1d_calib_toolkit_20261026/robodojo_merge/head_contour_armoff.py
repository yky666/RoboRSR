# head_contour_armoff.py -- is a rigid whole-left-arm offset (torso frame, from refine_wrist_mount.py ARM_OFFSET mode)
# compatible with the head view? Left arm / left gripper outline chamfer on the confirmation clip (never used for
# calibration) with the offset scaled by s; head camera = camera_setup_ours head_left (as the wrist evaluation).
# usage: head_contour_armoff.py <asset_dir> <camera_setup_ours.json> <logger_run_dir> <confirm_traj.json> <out.json>
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

sys.argv, ARGV = sys.argv[:1] + [sys.argv[1], os.environ.get("TEMP", "/tmp")], sys.argv
src_path = Path(__file__).parents[1] / "check_robodojo_merge.py"
src = open(src_path, encoding="utf-8").read().split("# ---------------- run ----------------")[0]
mod = {}
exec(compile(src, str(src_path), "exec"), mod)
Urdf, raster, chamfer, edge_dts = (mod[k] for k in ("Urdf", "raster", "chamfer", "edge_dts"))
ASSET, CAMS, RUN, TRAJ, OUT = Path(ARGV[1]), ARGV[2], ARGV[3], ARGV[4], ARGV[5]
u = Urdf(ASSET / "g1d_dex1_calib.urdf")
c = json.load(open(CAMS))["views"]["head_left"]
K, D = np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
T_head = np.array(c["T_parent_camera_world_convention"])
ROT_DEG, T_MM = np.array([-0.052, 1.018, 0.694]), np.array([15.02, 5.16, -8.23])  # armoff_left.json all_full
SCALES = (-0.5, 0.0, 0.5, 1.0, 1.5)


def offset(s):
    T = np.eye(4)
    T[:3, :3] = Rotation.from_rotvec(np.radians(ROT_DEG) * s).as_matrix()
    T[:3, 3] = T_MM * s / 1000
    return T


arm = {s: [f"{s}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
       for s in ("left", "right")}
grip = {s: [f"{s}_dex1_model_base_link"] + [f"{s}_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")]
        for s in ("left", "right")}
SEG = {"upper_arm": ["left_shoulder_roll_link", "left_shoulder_yaw_link"], "forearm": ["left_elbow_link", "left_wrist_roll_link"],
       "wrist": ["left_wrist_pitch_link", "left_wrist_yaw_link"], "gripper": grip["left"]}
traj = json.load(open(TRAJ))["frames"]
res = {s: {"arm": [], "grip": []} | {k: [] for k in SEG} for s in SCALES}
k15 = np.ones((15, 15), np.uint8)
for fr in traj[::3]:
    img = cv2.imdecode(np.fromfile(os.path.join(RUN, "head", fr["head"]), np.uint8), cv2.IMREAD_GRAYSCALE)[:, :640]
    q = fr["q"]
    Tc = np.linalg.inv(u.fk(c["parent"], q) @ T_head)
    right = raster(u, arm["right"] + grip["right"], q, Tc, K, D)
    if np.count_nonzero(raster(u, arm["left"], q, Tc, K, D)) < 1500:
        continue
    dts = edge_dts(img)
    for s in SCALES:
        Tl = Tc @ offset(s)
        ma, mg = raster(u, arm["left"], q, Tl, K, D), raster(u, grip["left"], q, Tl, K, D)
        da, _ = chamfer(ma, dts, block=cv2.dilate(right | mg, k15))
        dg, _ = chamfer(mg, dts, block=cv2.dilate(right, k15))
        if len(da) > 60:
            res[s]["arm"].append(float(np.median(da)))
        if len(dg) > 30:
            res[s]["grip"].append(float(np.median(dg)))
        ms = {n: raster(u, ls, q, Tl, K, D) for n, ls in SEG.items()}
        for n, m in ms.items():
            others = right.copy()
            for n2, m2 in ms.items():
                if n2 != n:
                    others |= m2
            d, _ = chamfer(m, dts, block=cv2.dilate(others, k15))
            if len(d) > 30:
                res[s][n].append(float(np.median(d)))
summ = {str(s): {k: {"frames": len(v), "median_px": round(float(np.median(v)), 2) if v else None,
                     "mean_px": round(float(np.mean(v)), 2) if v else None} for k, v in r.items()} for s, r in res.items()}
Path(OUT).write_text(json.dumps({"rot_deg": ROT_DEG.tolist(), "t_mm": T_MM.tolist(), "summary": summ, "per_frame": {str(s): r for s, r in res.items()}}, indent=1), encoding="utf-8")
print(json.dumps(summ, indent=1))
