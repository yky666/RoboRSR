#!/bin/bash
# joint fit (head outline + head-anchored wrist board data) on top of the official 38.2 mm geometry, both arms
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data
D=$R/robodojo_g1d_calib_20261022/check
W=$R/board_scale_20261023
O=$W/joint_fit
mkdir -p $O
cp $D/refine_wrist_mount.py $D/joint_fit.py $O/
BASE=$W/urdf_contour_sq382c/g1_d_upper_dex1_v4.urdf
export BOARD_SQUARE_MM=38.2 CALIB_PKG=$R/robodojo_g1d_calib_sq382_20261023 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
MODELS=${MODELS:-mount,mount_trans,mount_trans_rotu,mount_trans_rotu_cam}
NP=${NP:-30}
cd /dev/shm/isaac_work
WRIST_TRAIN="$S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left,$D/left_session_20261022" \
WRIST_TEST="$S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left,$D/board_views_20261022,$D/board_views_1023,$D/left_session_1023" \
  $PY -u $O/joint_fit.py left $BASE $O/joint_left.json $NP $MODELS > $O/joint_left.log 2>&1 &
WRIST_TRAIN="$S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right,$D/board_views_20261022" \
WRIST_TEST="$S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right,$D/board_views_1023" \
  $PY -u $O/joint_fit.py right $BASE $O/joint_right.json $NP $MODELS > $O/joint_right.log 2>&1 &
wait
echo ALL_DONE >> $O/joint_left.log
