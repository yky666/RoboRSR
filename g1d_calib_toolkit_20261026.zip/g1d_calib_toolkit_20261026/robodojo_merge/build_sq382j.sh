#!/bin/bash
# official params from the joint fit (model mount_trans, both arms) on top of urdf_contour_sq382c: delta params ->
# URDF -> compose relative to nominal (camera / intrinsics deltas from params_dual_trans_sq382) -> head-outline check ->
# assembled sim asset
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data
W=$R/board_scale_20261023
J=$W/joint_fit
MESH=$R/assembled_calib_20261016/meshes
set -e
cd $W
$PY - <<EOF
import json
vals = {}
for side in ("left", "right"):
    p = json.load(open("$J/joint_%s.json" % side))["models"]["mount_trans"]["params"]
    assert not any(k.startswith("cam/") for k in p)
    vals.update(p)
json.dump({"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": False,
           "description": "joint fit (joint_fit.py, model mount_trans): shoulder mounts + arm joint-origin translations "
                          "ON TOP OF urdf_contour_sq382c, fitted to the head-image arm outline and the head-anchored "
                          "wrist board data (board square 38.2 mm, stereo-calibrated right eye)",
           "convention": "q_model = q_encoder + zero (radians)", "values": vals}, open("$W/params_joint_delta_sq382.json", "w"), indent=2)
print(len(vals), "delta values")
EOF
cd $R
rm -rf $W/urdf_joint_sq382
$PY apply_calibration.py $W/params_joint_delta_sq382.json $W/urdf_joint_sq382 --nominal $W/urdf_contour_sq382c > /dev/null
ln -s $MESH $W/urdf_joint_sq382/meshes
$PY /dev/shm/isaac_work/compose_params.py $W/urdf_joint_sq382/g1_d_upper_dex1_v4.urdf $W/params_dual_trans_sq382.json \
  $W/params_final_sq382j.json
mkdir -p $S/20261023
cp $W/params_final_sq382j.json $S/20261023/
echo "===== head-outline check (contract head cameras, as all earlier contour scores) $(date '+%T')"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
cd /dev/shm/isaac_work
$PY -u contour_fit.py eval $J/contour_eval_sq382j sq382c=$W/urdf_contour_sq382c/g1_d_upper_dex1_v4.urdf \
  sq382j=$W/urdf_joint_sq382/g1_d_upper_dex1_v4.urdf 2>&1 | grep -v realcam
echo "===== build asset $(date '+%T')"
cd $R
[ -e assembled_calib_20261023_sq382j ] && { echo "exists, not overwriting"; exit 1; }
nvidia-smi --query-gpu=index,memory.used --format=csv,noheader | sed -n '5p'
$PY build_assembly.py $S/20261023/params_final_sq382j.json assembled_calib_20261023_sq382j --gpu 4 > logs/build_calib_20261023_sq382j.log 2>&1
echo "BUILD_EXIT=$?"
tail -n 3 logs/build_calib_20261023_sq382j.log
