# compare_render_real.py -- real frame (undistorted with our calibrated intrinsics) | Isaac render of the calibrated
# RoboDojo G1-D (same calibrated pinhole) | real image with the render's robot edges drawn on top
# usage: compare_render_real.py <session_dir> <sample_id> <render_dir> <out_dir> [<wrist cam>=right_wrist]
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
ses, sid, rdir, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4])
out.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"))
from calib_model import load_params  # noqa: E402

P = load_params(ROOT / "pc_tools/replay_cups/model/params_final_1021.json")["values"]
s = next(json.loads(l) for l in open(ses / "samples.jsonl", encoding="utf-8") if l.strip() and json.loads(l)["id"] == sid)
rows = []
wrist = sys.argv[5] if len(sys.argv) > 5 else "right_wrist"
for cam, frame, cut in (("head_left", "head_stereo", True), (wrist, wrist, False)):
    d = json.loads((ROOT / f"pc_tools/calib_data/intrinsics/camera_intrinsics_{cam}.json").read_text(encoding="utf-8"))
    K, D = np.array(d["K"], float), np.array(d["dist"], float)
    if cam.endswith("wrist"):
        for i, k in enumerate(("fx", "fy", "cx", "cy")):
            K[[0, 1, 0, 1][i], [0, 1, 2, 2][i]] += P.get(f"intrinsics:{cam}/{k}", 0.0)
        D = D + np.array([P.get(f"intrinsics:{cam}/{k}", 0.0) for k in ("k1", "k2", "p1", "p2", "k3")])
    real = cv2.imdecode(np.fromfile(str(ses / s["frames"][frame][0]["file"]), np.uint8), cv2.IMREAD_COLOR)
    real = real[:, :640] if cut else real
    und = cv2.undistort(real, K, D, None, K)
    sim = cv2.imdecode(np.fromfile(str(rdir / f"sim_{cam}_{sid}.png"), np.uint8), cv2.IMREAD_COLOR)
    robot = (np.abs(sim.astype(int) - np.median(sim.reshape(-1, 3), 0)).sum(2) > 40).astype(np.uint8) * 255
    robot = cv2.morphologyEx(robot, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cs, _ = cv2.findContours(robot, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    ov = und.copy()
    cv2.drawContours(ov, [c for c in cs if len(c) > 30], -1, (0, 230, 0), 2, cv2.LINE_AA)
    tiles = [und, sim, ov]
    for t, lab in zip(tiles, ("real (undistorted)", "Isaac Lab on our 5090: RoboDojo G1-D + our calib + our cams",
                              "real + render outline (green)")):
        cv2.putText(t, f"{cam}: {lab}", (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(t, f"{cam}: {lab}", (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
    rows.append(np.hstack(tiles))
cv2.imencode(".png", np.vstack(rows))[1].tofile(str(out / f"render_vs_real_{sid}.png"))
print("wrote", out / f"render_vs_real_{sid}.png")
