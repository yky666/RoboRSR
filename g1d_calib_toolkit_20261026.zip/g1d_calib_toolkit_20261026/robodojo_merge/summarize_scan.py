# summarize_scan.py -- dual_trans identification vs printed square size: residuals, held-out validation, wrist
# intrinsics corrections and camera mount translations
import json
import sys
from pathlib import Path

W = Path(sys.argv[1])
for t in ("380", "385", "390", "400"):
    f = W / f"identify_dual_trans_sq{t}.json"
    if not f.exists():
        print(t, "missing"); continue
    r = json.load(open(f))
    p = json.load(open(W / f"params_dual_trans_sq{t}.json"))["values"]
    print(f"===== square {t[:2]}.{t[2:]} mm  cost {r['optimizer']['cost']:.0f}")
    print("  fit rms px", {k.split(":", 1)[1]: round(v["rms"], 3) for k, v in r["residuals"].items()})
    v = r.get("validation", {})
    print("  validation", json.dumps(v)[:700])
    print("  intrinsics", {k: round(x, 2) for k, x in p.items() if k.startswith("intrinsics:") and k.split("/")[-1] in ("fx", "fy", "cx", "cy")})
    print("  camera mm ", {k: round(x * 1000, 2) for k, x in p.items() if k.startswith("camera:") and k.split("/")[-1] in ("dx", "dy", "dz")})
