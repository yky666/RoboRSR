#!/bin/bash
# second contour pass: start from the old shoulder mounts on the 38.5 mm geometry (urdf_contour_sq385) and fit a further
# mount delta on top (the from-zero right-arm fit stopped in a worse minimum), compose -> params_final_sq385c, score
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
W=$R/board_scale_20261023
O=$W/contour_sq385c
MESH=$R/assembled_calib_20261016/meshes
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$R/real_data/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
mkdir -p $O
cd /dev/shm/isaac_work
echo "===== fit $(date '+%T')"
$PY -u contour_fit.py fit $O $W/urdf_contour_sq385/g1_d_upper_dex1_v4.urdf both mount 2>&1 | grep -v realcam | grep -v ' eval '
$PY - <<EOF
import json
r = json.load(open("$O/contour_fit_both_mount.json"))
vals = {}
for d in r["sides"].values():
    vals.update(d["params"])
doc = {"format": "g1d_calib_params_v1", "status": "IDENTIFIED", "sign_verified": False,
       "description": "second shoulder_pitch delta ON TOP OF urdf_contour_sq385 (38.5 mm dual_trans + 10-20 mounts)",
       "convention": "q_model = q_encoder + zero (radians)", "values": vals}
json.dump(doc, open("$W/params_contour_mount_sq385c.json", "w"), indent=2)
EOF
cd $R
rm -rf $W/urdf_contour_sq385c
$PY apply_calibration.py $W/params_contour_mount_sq385c.json $W/urdf_contour_sq385c --nominal $W/urdf_contour_sq385 > /dev/null
ln -s $MESH $W/urdf_contour_sq385c/meshes
$PY /dev/shm/isaac_work/compose_params.py $W/urdf_contour_sq385c/g1_d_upper_dex1_v4.urdf $W/params_dual_trans_sq385.json \
  $W/params_final_sq385c.json
cd /dev/shm/isaac_work
echo "===== eval $(date '+%T')"
$PY -u contour_fit.py eval $O sq385c=$W/urdf_contour_sq385c/g1_d_upper_dex1_v4.urdf 2>&1 | grep -v realcam
echo "CONTOUR_DONE $(date '+%T')"
