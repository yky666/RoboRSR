# smoke_calib.py -- load the calibrated RoboDojo G1-D (mobile) through the colleague's own robot config, unmodified:
# env.robot_manager.robot_config.g1d.get_robot_config(mobile=True) with only the asset path / usd cache redirected to
# our copy. Holds a recorded real pose, checks physics stability and sim link poses vs our calibrated FK, and renders
# the head-left and right-wrist views with the calibrated mounts and our calibrated intrinsics (undistorted pinhole).
# usage (5090-2, from /data/g1d_calib_merge_20261022/check):
#   CUDA_VISIBLE_DEVICES=<gpu> PYTHONPATH=/root/RoboDojo python smoke_calib.py
import argparse

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.headless = True
args.enable_cameras = True
app = AppLauncher(args).app

import json  # noqa: E402
import os  # noqa: E402
import re  # noqa: E402
import sys  # noqa: E402
import traceback  # noqa: E402
import xml.etree.ElementTree as ET  # noqa: E402

import numpy as np  # noqa: E402
import torch  # noqa: E402
from PIL import Image  # noqa: E402
from scipy.spatial.transform import Rotation  # noqa: E402

import isaaclab.sim as sim_utils  # noqa: E402
from isaaclab.assets import Articulation  # noqa: E402
from isaaclab.sensors import Camera, CameraCfg  # noqa: E402

import env.robot_manager.robot_config.g1d as g1d  # noqa: E402  (colleague's module, used as is)

D = os.environ.get("SMOKE_DIR", "/data/g1d_calib_merge_20261022")
CAL = f"{D}/calibrated"
OUT = f"{D}/check"
DT = 1 / 60
POSE = json.load(open(f"{OUT}/pose_B_right_016.json"))  # real joint angles of session 1106, sample B_right_016
R_WORLD_USD = np.array([[0, 0, -1], [-1, 0, 0], [0, 1, 0]], float)
INTR = {  # our calibrated intrinsics (checkerboard + identified AF delta for the wrist), undistorted pinhole
    "head_left": (279.320, 279.875, 314.997, 234.187),
    "right_wrist": (312.993 - 17.348, 313.140 - 16.404, 337.444 + 0.224, 249.405 + 7.951),
}


def mount(yml, name):
    txt = open(yml).read()
    m = re.search(rf'link: "([^"]+)"\s*name: "{name}".*?pos: \[([^\]]+)\].*?ori: \[([^\]]+)\]', txt, re.S)
    w, x, y, z = (float(v) for v in m.group(3).split(","))
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([x, y, z, w]).as_matrix() @ R_WORLD_USD.T  # link -> camera (x fwd, z up)
    T[:3, 3] = [float(v) for v in m.group(2).split(",")]
    return m.group(1), T


def urdf_fk(path, q, link, root="torso_link"):
    J = {}
    for j in ET.parse(path).getroot().findall("joint"):
        o = j.find("origin")
        T = np.eye(4)
        T[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
        T[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
        ax = j.find("axis")
        J[j.find("child").get("link")] = (j.get("name"), j.find("parent").get("link"), j.get("type"), T,
                                          np.array([float(v) for v in (ax.get("xyz") if ax is not None else "1 0 0").split()]))
    T = np.eye(4)
    while link != root:
        name, parent, kind, M, axis = J[link]
        M = M.copy()
        v = q.get(name, 0.0)
        if kind == "revolute" and v:
            R = np.eye(4); R[:3, :3] = Rotation.from_rotvec(axis * v).as_matrix(); M = M @ R
        elif kind == "prismatic" and v:
            P = np.eye(4); P[:3, 3] = axis * v; M = M @ P
        T = M @ T
        link = parent
    return T


def pose_T(state):
    s = state.detach().cpu().numpy()
    T = np.eye(4); T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix(); T[:3, 3] = s[:3]
    return T


def main():
    g1d.ROBOTS_PATH = f"{D}/robots"  # robots/g1d -> calibrated/ (physics_contract.json for the collision filters)
    cfg = g1d.get_robot_config(mobile=True)
    cfg.spawn.asset_path = f"{CAL}/g1d_mobile_dex1_calib.urdf"
    cfg.spawn.usd_dir = f"{CAL}/usd_mobile_calib"
    joint_pos = {k: v for k, v in cfg.init_state.joint_pos.items()
                 if not any(s in k for s in ("shoulder", "elbow", "wrist", "dex1"))}  # lift, waist, chassis
    joint_pos.update(POSE)
    joint_pos[".*_dex1_finger_joint_.*"] = 0.024  # closed, as in the session
    cfg.init_state = cfg.init_state.replace(pos=(0.0, 0.0, 0.0), joint_pos=joint_pos)

    sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=DT, device=args.device))
    sim_utils.DomeLightCfg(intensity=1500.0).func("/World/dome", sim_utils.DomeLightCfg(intensity=1500.0))
    floor = sim_utils.CuboidCfg(size=(20.0, 20.0, 0.02), collision_props=sim_utils.CollisionPropertiesCfg(),
                                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.5, 0.5, 0.5)))
    floor.func("/World/floor", floor, translation=(0.0, 0.0, -0.01))
    robot = Articulation(cfg.replace(prim_path="/World/robot"))
    cams = {}
    for name, (fx, fy, cx, cy) in INTR.items():
        cams[name] = Camera(CameraCfg(prim_path=f"/World/cam_{name}", width=640, height=480, data_types=["rgb"],
                                      spawn=sim_utils.PinholeCameraCfg(focal_length=24.0, clipping_range=(0.02, 20.0))))
    sim.reset()
    stage = sim.stage
    for name, (fx, fy, cx, cy) in INTR.items():  # pinhole with the calibrated principal point (aperture offsets)
        prim = stage.GetPrimAtPath(f"/World/cam_{name}")
        hap, vap = 24.0 * 640 / fx, 24.0 * 480 / fy
        prim.GetAttribute("horizontalAperture").Set(float(hap)); prim.GetAttribute("verticalAperture").Set(float(vap))
        prim.GetAttribute("horizontalApertureOffset").Set(float((640 / 2.0 - cx) * hap / 640))
        prim.GetAttribute("verticalApertureOffset").Set(float((cy - 480 / 2.0) * vap / 480))
    for p in stage.Traverse():  # head camera lens sits inside the head shell
        if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link":
            from pxr import UsdGeom
            UsdGeom.Imageable(p).MakeInvisible()

    jn = robot.joint_names
    print("joints in sim:", len(jn), jn)
    tgt = robot.data.default_joint_pos.clone()
    robot.write_joint_state_to_sim(tgt, torch.zeros_like(tgt))
    drift = []
    for k in range(240):  # 4 s hold
        robot.set_joint_position_target(tgt)
        robot.write_data_to_sim()
        sim.step(render=False)
        robot.update(DT)
        drift.append(float((robot.data.joint_pos - tgt).abs().max()))
    jp = robot.data.joint_pos[0].cpu().numpy()
    arm = [i for i, n in enumerate(jn) if "shoulder" in n or "elbow" in n or "wrist" in n]
    print(f"hold 4 s: max |q - target| over arm joints {np.abs(jp[arm] - tgt[0].cpu().numpy()[arm]).max():.2e} rad, "
          f"max over all joints at end {drift[-1]:.2e}, nan {bool(np.isnan(jp).any())}")

    names = robot.body_names
    T_torso = pose_T(robot.data.body_link_state_w[0, names.index("torso_link"), :7])
    q = {n: float(jp[i]) for i, n in enumerate(jn)}
    res = {}
    for link in ("head_link", "left_dex1_base_link", "right_dex1_base_link", "right_wrist_yaw_link"):
        T_sim = np.linalg.inv(T_torso) @ pose_T(robot.data.body_link_state_w[0, names.index(link), :7])
        T_ref = urdf_fk(f"{CAL}/g1d_mobile_dex1_calib.urdf", q, link)
        dt = np.linalg.norm(T_sim[:3, 3] - T_ref[:3, 3]) * 1000
        dr = np.degrees(Rotation.from_matrix(T_ref[:3, :3].T @ T_sim[:3, :3]).magnitude())
        res[link] = {"dt_mm": dt, "dR_deg": dr}
        print(f"sim vs calibrated FK  {link:22s} {dt:7.3f} mm  {dr:6.3f} deg")

    for name, (yml, cname) in {"head_left": (f"{CAL}/left_robot_config_calib.yml", "cam_head"),
                               "right_wrist": (f"{CAL}/right_robot_config_calib.yml", "cam_wrist")}.items():
        link, Tm = mount(yml, cname)
        T = pose_T(robot.data.body_link_state_w[0, names.index(link), :7]) @ Tm
        xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
        cams[name].set_world_poses(torch.tensor([T[:3, 3]], dtype=torch.float32, device=args.device),
                                   torch.tensor([xyzw[[3, 0, 1, 2]]], dtype=torch.float32, device=args.device),
                                   convention="world")
    for _ in range(30):
        sim.render()
    for name, cam in cams.items():
        cam.update(DT)
        rgb = cam.data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
        Image.fromarray(rgb).save(f"{OUT}/sim_{name}_B_right_016.png")
        print("image:", f"{OUT}/sim_{name}_B_right_016.png")
    json.dump({"fk": res, "hold_drift_end": drift[-1], "joints": jn}, open(f"{OUT}/smoke_result.json", "w"), indent=1)


try:
    main()
    failed = False
except Exception:
    traceback.print_exc()
    failed = True
sys.stdout.flush()
sys.stderr.flush()
os._exit(1 if failed else 0)
