# summarize_armoff.py -- LOSO comparison: wrist-camera mount correction vs one rigid whole-arm offset
import json
import sys

for side in ("left", "right"):
    a = json.load(open(f"armoff_{side}.json"))
    print(f"== {side}")
    for k in ("sessions", "current_rms"):
        if k in a:
            print(" ", k, a[k])
    for k in ("loso", "all_full", "all_rot_only"):
        if k in a:
            print(" ", k, json.dumps(a[k], ensure_ascii=False)[:1500])
