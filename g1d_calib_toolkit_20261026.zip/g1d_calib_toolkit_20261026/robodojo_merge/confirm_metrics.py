# confirm_metrics.py -- head-view arm outline chamfer on the confirmation clip (new data, never used for calibration):
# RoboDojo URDF as delivered vs with our calibration, measured joint angles, our head intrinsics, raw head frames.
# usage: confirm_metrics.py <asset_dir> <logger_run_dir> <confirm_traj.json> <out.json>
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np

sys.argv, ARGV = sys.argv[:1] + [sys.argv[1], os.environ.get("TEMP", "/tmp")], sys.argv
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("crm", Path(__file__).parents[1] / "check_robodojo_merge.py")
src = open(spec.origin, encoding="utf-8").read().split("# ---------------- run ----------------")[0]
mod = {}
exec(compile(src, spec.origin, "exec"), mod)  # helpers only (URDF, meshes, projection, chamfer)
Urdf, raster, chamfer, edge_dts, intr, cam_mount = (mod[k] for k in ("Urdf", "raster", "chamfer", "edge_dts", "intr", "cam_mount"))
ASSET, RUN, TRAJ, OUT = Path(ARGV[1]), ARGV[2], ARGV[3], ARGV[4]
U = {"delivered": Urdf(ASSET / "g1d_dex1.urdf"), "calibrated": Urdf(ASSET / "g1d_dex1_calib.urdf")}
_, T_head = cam_mount(ASSET / "left_robot_config.yml", "cam_head")
K, D = intr("head_left", "checker")
arm = {s: [f"{s}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
       for s in ("left", "right")}
grip = {s: [f"{s}_dex1_model_base_link"] + [f"{s}_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")]
        for s in ("left", "right")}
traj = json.load(open(TRAJ))["frames"]
res = {k: [] for k in U}
for k, fr in enumerate(traj[::3]):
    img = cv2.imdecode(np.fromfile(os.path.join(RUN, "head", fr["head"]), np.uint8), cv2.IMREAD_GRAYSCALE)[:, :640]
    dts = edge_dts(img)
    for tag, u in U.items():
        Tc = np.linalg.inv(u.fk("head_link", fr["q"]) @ T_head)
        d_all = []
        for s in ("left", "right"):
            ma = raster(u, arm[s], fr["q"], Tc, K, D)
            if np.count_nonzero(ma) < 1500:
                continue
            other = raster(u, arm["right" if s == "left" else "left"] + grip["left"] + grip["right"], fr["q"], Tc, K, D)
            d, _ = chamfer(ma, dts, block=cv2.dilate(other, np.ones((15, 15), np.uint8)))
            d_all.append(d)
        if d_all and sum(len(d) for d in d_all) > 60:
            res[tag].append((fr["t_rel"], float(np.median(np.concatenate(d_all)))))
out = {tag: {"frames": len(v), "median_px": float(np.median([m for _, m in v])) if v else None,
             "p90_px": float(np.percentile([m for _, m in v], 90)) if v else None} for tag, v in res.items()}
both = [(a[1], b[1]) for a, b in zip(res["delivered"], res["calibrated"])]
out["calibrated_better_frames"] = float(np.mean([b < a for a, b in both])) if both else None
Path(OUT).write_text(json.dumps({"summary": out, "per_frame": res}, indent=1), encoding="utf-8")
print(json.dumps(out, indent=1))
