#!/bin/bash
# board-scale hypothesis, both arms, all head-anchored wrist sessions
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
BASE=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$BASE/real_data
D=$BASE/robodojo_g1d_calib_20261022/check
cd $D
export OPENBLAS_NUM_THREADS=4
$PY -u refine_board_scale.py left $D/bscale_left.json \
  $S/20261019/sessions/calib_20261019_1209_B_wrist_table_board_left \
  $S/20261019/sessions/calib_20261019_1509_B_wrist_table_board_left \
  $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023 2>&1 | grep -v 'wrist frames' > $D/bscale_left.log &
$PY -u refine_board_scale.py right $D/bscale_right.json \
  $S/20261019/sessions/calib_20261019_1533_B_wrist_table_board_right \
  $S/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right \
  $D/board_views_20261022 $D/board_views_1023 2>&1 | grep -v 'wrist frames' > $D/bscale_right.log &
wait
cat $D/bscale_left.log
echo ---
cat $D/bscale_right.log
