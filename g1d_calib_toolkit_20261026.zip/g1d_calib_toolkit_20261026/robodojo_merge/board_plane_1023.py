# board_plane_1023.py -- runs on the sim 5090. Table plane in the torso frame from this morning's head views of the
# board (board_views_1023, left_session_1023), in the same convention as replay_cups/fit_cups.py (40 mm board,
# 10-22 package head cameras): board centre and up normal (= -board z).
import json
import sys
from pathlib import Path

import numpy as np

src_path = Path(__file__).parent / "refine_wrist_mount.py"
src = open(src_path, encoding="utf-8").read().split("M0 = np.array(")[0]
D = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/robodojo_g1d_calib_20261022/check"
sys.argv = [str(src_path), "left", "/tmp/unused.json", f"{D}/board_views_1023", f"{D}/left_session_1023"]
g = {"__file__": str(src_path)}
exec(compile(src, str(src_path), "exec"), g)
OBJ = g["OBJ"]
for sd in g["data"]:
    Tb = sd["rows"][0][1]
    c = Tb[:3, :3] @ OBJ.mean(0) + Tb[:3, 3]
    n = -Tb[:3, 2]
    print(json.dumps({"session": sd["name"], "board_center": np.round(c, 4).tolist(), "up_normal": np.round(n, 4).tolist(),
                      "plane_offset": round(float(n @ c), 4), "spread_mm": round(sd["board_spread_mm"], 1)}))
