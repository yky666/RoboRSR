# choose_m.py -- pick the meeting point from out/m_search.json (plan2.py findm): feasible for both arms, largest
# worst-case margin to the torso and to the joint limits; prints "x,y yawL,yawR" for plan2.py plan
import json

r = [x for x in json.load(open("out/m_search.json")) if x["ok"]]
r.sort(key=lambda x: -min(x["left"]["torso"], x["right"]["torso"], x["left"]["lim"], x["right"]["lim"]))
for b in r[:3]:
    m = min(b["left"]["torso"], b["right"]["torso"], b["left"]["lim"], b["right"]["lim"])
    print(f"# candidate M ({b['x']}, {b['y']}) yaw L {b['left']['yaw_deg']} R {b['right']['yaw_deg']} margin {m:.3f}")
b = r[0]
print(f"{b['x']},{b['y']} {b['left']['yaw_deg']},{b['right']['yaw_deg']}")
