# arms_aside.py -- from the all-zero pose, abduct both shoulders so the grippers leave the head's view of the cups
# (hands move outward, away from the table centre); "back" returns to all zero
import sys

import numpy as np

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parents[1]))
import arm_client as arm  # noqa: E402

q = np.array(arm.status()["arm_q_cmd"])
print("start:", np.round(q, 3).tolist())
assert np.abs(q).max() < 0.4, "not near the zero / aside pose, refusing"
t = np.zeros(14)
if not (len(sys.argv) > 1 and sys.argv[1] == "back"):
    t[1], t[8] = 0.35, -0.25
s = arm.move(t, seconds=3.0, timeout=60)
print("now  :", np.round(s["arm_q"], 3).tolist())
