# check_grasp_reach.py -- are today's rim-pinch grasp poses reachable? plan2.grasp() with the numpy solver for a few
# approach tilts (--th) and fingertip depths; err = IK residual in mm + deg (< 1 = reachable)
# usage: REPLAY_URDF=<urdf> python check_grasp_reach.py
import contextlib
import io
import sys

sys.argv = ["plan2.py"]
import numpy as np  # noqa: E402

import plan2  # noqa: E402

for th in (65, 50, 35, 20):
    plan2.TH_L = plan2.TH_R = th
    row = []
    for side in ("left", "right"):
        with contextlib.redirect_stdout(io.StringIO()):
            T, q, err, tm, mis, flip, gaps = plan2.grasp(side)
        row.append(f"{side} err {err:6.2f} torso {tm:.3f}")
    print(f"tilt {th:2d} deg: " + " | ".join(row), flush=True)
