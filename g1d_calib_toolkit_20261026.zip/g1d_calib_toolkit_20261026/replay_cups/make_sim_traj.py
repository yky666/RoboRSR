# make_sim_traj.py -- drive the physics sim with the real run: at every head camera frame (10 Hz, window around the
# replay) the measured 14 arm joints and the COMMANDED Dex1 values (the measured ones stop at the cup wall).
# Writes <out>.npz (q, grip, fps) for sim_cups_views.py and <out>.json (head frame names / times) for the video.
# usage: make_sim_traj.py <logger_run_dir> <out_prefix> [--before 3] [--after 290]
import argparse
import glob
import json
import os

import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("run")
ap.add_argument("out")
ap.add_argument("--before", type=float, default=3.0)
ap.add_argument("--after", type=float, default=290.0)
a = ap.parse_args()
meta = json.load(open(os.path.join(a.run, "meta.json")))
ids = meta["motor_ids"]
nm = len(ids)
S = np.vstack([np.load(f) for f in sorted(glob.glob(os.path.join(a.run, "state_*.npy")))])
S = S[np.argsort(S[:, 0])]
C = np.vstack([np.load(f) for f in sorted(glob.glob(os.path.join(a.run, "cmd_*.npy")))])
C = C[np.argsort(C[:, 0])]
t_go = float(open(os.path.join(a.run, "go_time.txt")).read().split()[0])
heads = sorted(glob.glob(os.path.join(a.run, "head", "*.jpg")))
ht = np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in heads])
sel = [i for i in range(len(heads)) if t_go - a.before <= ht[i] <= t_go + a.after and S[0, 0] <= ht[i] <= S[-1, 0]]
arm = [ids.index(m) for m in range(15, 29)]
Q = np.array([[np.interp(ht[i], S[:, 0], S[:, 4 + j]) for j in arm] for i in sel])
G = np.array([[np.interp(ht[i], C[:, 0], C[:, 3 + ids.index(m)]) for m in (31, 33)] for i in sel])
np.savez(a.out + ".npz", q=Q, grip=G, fps=10.0)
json.dump({"run": os.path.basename(os.path.normpath(a.run)), "t_go": t_go,
           "frames": [{"head": os.path.basename(heads[i]), "t": float(ht[i]), "t_rel": float(ht[i] - t_go)} for i in sel]},
          open(a.out + ".json", "w"), indent=0)
print(f"{len(sel)} frames ({len(sel) / 10:.0f} s), grip command range L {G[:, 0].min():.2f}..{G[:, 0].max():.2f} "
      f"R {G[:, 1].min():.2f}..{G[:, 1].max():.2f}")
