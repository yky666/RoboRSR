# measure_table_plane.py -- table plane in the torso frame from the board lying on the table, seen by the head stereo
# (official camera setup, board square 38.2 mm). Grabs N head frames from the robot, PnP per eye, prints the
# --board-c / --board-n arguments for fit_cups.py.
# usage: python measure_table_plane.py [n_frames]
import json
import os
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

HERE = Path(__file__).parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"))
from calib_model import Robot  # noqa: E402

SQUARE = 0.0382
PKG = ROOT / "pc_tools" / "robodojo_merge_sq382j"
CAMS = json.loads((PKG / "camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
ROB = Robot(PKG / "g1_d_upper_dex1_v4.urdf")
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
BOARD = cv2.aruco.CharucoBoard((10, 7), SQUARE, SQUARE * 0.75, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
OBJ = BOARD.getChessboardCorners().astype(float)
hp = cv2.aruco.DetectorParameters()
hp.minMarkerPerimeterRate = 0.01
hp.adaptiveThreshWinSizeMin, hp.adaptiveThreshWinSizeMax, hp.adaptiveThreshWinSizeStep = 3, 53, 4
hp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
cp = cv2.aruco.CharucoParameters()
cp.minMarkers = 1
DET = cv2.aruco.CharucoDetector(BOARD, cp, hp)
n = int(sys.argv[1]) if len(sys.argv) > 1 else 5
tmp = Path(os.environ.get("TEMP", "/tmp"))
poses = []
for k in range(n):
    subprocess.run(["ssh", "unitree", f"~/miniconda3/envs/tv/bin/python ~/calib_sessions/grab_one.py 55555 /tmp/plane_{k}.png"],
                   check=True, capture_output=True)
    subprocess.run(["scp", f"unitree:/tmp/plane_{k}.png", str(tmp / f"plane_{k}.png")], check=True, capture_output=True)
    img = cv2.imread(str(tmp / f"plane_{k}.png"), cv2.IMREAD_GRAYSCALE)
    w = img.shape[1] // 2
    for half, eye in ((0, "head_left"), (1, "head_right")):
        g = cv2.resize(img[:, half * w:(half + 1) * w], None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
        cc, ci, _, _ = DET.detectBoard(g)
        if ci is None or len(ci) < 15:
            print(f"frame {k} {eye}: board not found ({0 if ci is None else len(ci)} corners)")
            continue
        uv = (cc.reshape(-1, 2) + 0.5) / 3 - 0.5
        c = CAMS[eye]
        K, D = np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
        ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()], uv, K, D, flags=cv2.SOLVEPNP_IPPE)
        ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()], uv, K, D, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
        T_ob = np.eye(4); T_ob[:3, :3] = cv2.Rodrigues(rv)[0]; T_ob[:3, 3] = tv.ravel()
        T_cam = ROB.fk(c["parent"], {}, {}, None, 1)[0] @ np.array(c["T_parent_camera_world_convention"])
        C2O = np.eye(4); C2O[:3, :3] = OPT.T
        T = T_cam @ C2O @ T_ob
        ctr = T[:3, :3] @ OBJ.mean(0) + T[:3, 3]
        poses.append((eye, ctr, -T[:3, 2], len(ci)))
        print(f"frame {k} {eye}: {len(ci)} corners, centre {ctr.round(4).tolist()}, up {(-T[:3, 2]).round(4).tolist()}")
if not poses:
    sys.exit("board not seen")
C = np.mean([p[1] for p in poses], 0)
Nn = np.mean([p[2] for p in poses], 0); Nn /= np.linalg.norm(Nn)
spread = np.sqrt(np.mean(np.sum((np.array([p[1] for p in poses]) - C) ** 2, 1))) * 1000
print(f"board centre {C.round(4).tolist()}  up normal {Nn.round(4).tolist()}  plane offset {Nn @ C:.4f}  spread {spread:.1f} mm")
print(f"fit_cups.py args: --board-c={C[0]:.4f},{C[1]:.4f},{C[2]:.4f} --board-n={Nn[0]:.4f},{Nn[1]:.4f},{Nn[2]:.4f} --stereo-scale=0.955")
