# geom.py -- shared kinematics / geometry for the cup-stacking replay plan (calibrated URDF, numpy only)
import json
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree
from scipy.spatial.transform import Rotation

HERE = Path(__file__).parent
PKG = HERE.parent.parent / "g1d_calib_20261015" / "g1d_calib_20261015"
sys.path.insert(0, str(PKG))
from calib_model import Robot, arm_joints  # noqa: E402

import os  # noqa: E402
# default: assembled_calib_20261021 (params_final_1021 applied); REPLAY_URDF selects another calibrated upper URDF
URDF = Path(os.environ.get("REPLAY_URDF", HERE / "model" / "g1_d_upper_dex1_v4.urdf"))
MESH_DIR = PKG / "nominal" / "meshes"
ROBOT = Robot(URDF)
LJ, RJ = arm_joints("left"), arm_joints("right")
ALLJ = LJ + RJ
READY = np.array([0.3280082345, -0.0444015563, -0.0210323147, -0.2193952054, -0.1763718426, -0.3590713441,
                  -0.1322099715, 0.1631669253, -0.0210245643, 0.1643322706, -0.1186949760, -0.1611172855,
                  -0.2666637003, -0.2119511217])
LIMITS = np.array([[ROBOT.joints[j]["lower"], ROBOT.joints[j]["upper"]] for j in ALLJ])
LIMIT_MARGIN = 0.05
TIP_X = 0.150            # m, finger-pad end along <side>_dex1_base_link x (touch fit of the real tip corner: 0.152)
PAD_X = (0.095, 0.150)   # m, pad extent along x (URDF pads 0.095..0.145, real fingers ~5 mm longer)
GRIP_STROKE = 0.044      # m per finger over the full 0..5.4 command range (URDF limits -0.02..0.024, Unitree sim map)


def grip_to_joint(g):
    """Dex1 command value (0 closed .. 5.4 open) -> URDF finger joint (0.024 closed .. -0.02 open), Unitree's linear map"""
    g = np.clip(np.asarray(g, float), 0.0, 5.4)
    return 0.024 + (-0.02 - 0.024) * g / 5.4


def grip_gap_linear(g):
    """pad gap (m) for the linear map: pads touch at g=0, 2*stroke at 5.4"""
    return 2 * GRIP_STROKE * np.clip(g, 0, 5.4) / 5.4


def qdict(q14, grip=(0.0, 0.0)):
    q14 = np.atleast_2d(q14)
    d = {n: q14[:, i] for i, n in enumerate(ALLJ)}
    for side, g in zip(("left", "right"), grip):
        gj = np.broadcast_to(grip_to_joint(g), (q14.shape[0],))
        d[f"{side}_dex1_finger_joint_1"] = gj
        d[f"{side}_dex1_finger_joint_2"] = gj
    return d


def fk(link, q14, grip=(0.0, 0.0)):
    q14 = np.atleast_2d(q14)
    return ROBOT.fk(link, qdict(q14, grip), {}, None, q14.shape[0])


def ee(q14, side="right"):
    return fk(f"{side}_dex1_base_link", q14)


def tip_point(T):
    return T[..., :3, :3] @ np.array([TIP_X, 0, 0]) + T[..., :3, 3]


def pose_err(T, Tg):
    dp = Tg[:3, 3] - T[:3, 3]
    dr = Rotation.from_matrix(Tg[:3, :3] @ T[:3, :3].T).as_rotvec()
    return np.r_[dp, dr]


EXTRA_BOUNDS = {}   # side -> (lo7, hi7) additional joint bounds (e.g. shoulder roll never closer to the torso than at ready)


def ik(Tg, q0, side="right", iters=200, w_rest=1e-3, q_rest=None):
    """damped least squares on <side>_dex1_base_link, joint limits with margin. Returns (q14, pos_err_m, rot_err_rad)"""
    off = 0 if side == "left" else 7
    q = np.array(q0, float)
    lo, hi = LIMITS[off:off + 7, 0] + LIMIT_MARGIN, LIMITS[off:off + 7, 1] - LIMIT_MARGIN
    if side in EXTRA_BOUNDS:
        lo, hi = np.maximum(lo, EXTRA_BOUNDS[side][0]), np.minimum(hi, EXTRA_BOUNDS[side][1])
    rest = q[off:off + 7].copy() if q_rest is None else np.asarray(q_rest[off:off + 7])
    for _ in range(iters):
        Q = np.tile(q, (8, 1))
        for j in range(7):
            Q[j + 1, off + j] += 1e-5
        T = ee(Q, side)
        e = pose_err(T[0], Tg)
        if np.linalg.norm(e[:3]) < 2e-5 and np.linalg.norm(e[3:]) < 2e-4:
            break
        J = np.zeros((6, 7))
        for j in range(7):
            J[:3, j] = (T[j + 1, :3, 3] - T[0, :3, 3]) / 1e-5
            J[3:, j] = Rotation.from_matrix(T[j + 1, :3, :3] @ T[0, :3, :3].T).as_rotvec() / 1e-5
        lam = 1e-4
        dq = J.T @ np.linalg.solve(J @ J.T + lam * np.eye(6), e)
        # null-space pull toward the rest posture
        N = np.eye(7) - np.linalg.pinv(J) @ J
        dq += N @ (w_rest * 50 * (rest - q[off:off + 7]))
        q[off:off + 7] = np.clip(q[off:off + 7] + np.clip(dq, -0.2, 0.2), lo, hi)
    e = pose_err(ee(q, side)[0], Tg)
    return q, float(np.linalg.norm(e[:3])), float(np.linalg.norm(e[3:]))


def torso_ok(q14):
    """our empirical upper-arm/torso guard: roll >= +0.05 beside the body, >= -0.10 when raised (pitch < -0.4); mirrored"""
    ok = True
    for off, sgn in ((0, 1.0), (7, -1.0)):
        p, r = q14[off], q14[off + 1]
        lim = -0.10 if p < -0.4 else 0.05
        ok &= (r * sgn >= lim)
    return bool(ok)


def torso_margin(q14):
    out = []
    for off, sgn in ((0, 1.0), (7, -1.0)):
        p, r = q14[off], q14[off + 1]
        lim = -0.10 if p < -0.4 else 0.05
        out.append(r * sgn - lim)
    return out


def limit_margin(q14):
    return np.minimum(q14 - LIMITS[:, 0], LIMITS[:, 1] - q14)


# ---------------- meshes -> surface point clouds per link ----------------
def load_stl(p):
    data = Path(p).read_bytes()
    n = struct.unpack("<I", data[80:84])[0]
    if 84 + 50 * n == len(data):
        arr = np.frombuffer(data[84:84 + 50 * n], dtype=np.dtype([("n", "<3f4"), ("v", "<9f4"), ("a", "<u2")]))
        return arr["v"].reshape(-1, 3, 3).astype(float)
    pts = [list(map(float, l.split()[1:4])) for l in data.decode(errors="ignore").splitlines() if l.strip().startswith("vertex")]
    return np.array(pts).reshape(-1, 3, 3)


def sample_tris(tris, spacing, rng):
    a = 0.5 * np.linalg.norm(np.cross(tris[:, 1] - tris[:, 0], tris[:, 2] - tris[:, 0]), axis=1)
    n = int(np.ceil(a.sum() / spacing ** 2)) + len(tris)
    idx = rng.choice(len(tris), n, p=a / a.sum())
    u, v = rng.random(n), rng.random(n)
    flip = u + v > 1
    u[flip], v[flip] = 1 - u[flip], 1 - v[flip]
    t = tris[idx]
    pts = t[:, 0] + u[:, None] * (t[:, 1] - t[:, 0]) + v[:, None] * (t[:, 2] - t[:, 0])
    return np.vstack([pts, tris.reshape(-1, 3)])


def link_clouds(spacing=0.004, kind="collision"):
    """{link: (N,3) points in the link frame} from the URDF collision meshes"""
    rng = np.random.default_rng(0)
    out = {}
    for link in ET.parse(URDF).getroot().findall("link"):
        pts = []
        for el in link.findall(kind):
            m = el.find("geometry/mesh")
            if m is None:
                continue
            o = el.find("origin")
            xyz = np.array([float(v) for v in (o.get("xyz", "0 0 0") if o is not None else "0 0 0").split()])
            rpy = np.array([float(v) for v in (o.get("rpy", "0 0 0") if o is not None else "0 0 0").split()])
            sc = np.array([float(v) for v in m.get("scale", "1 1 1").split()])
            tris = load_stl(MESH_DIR / m.get("filename").replace("meshes/", "")) * sc
            P = sample_tris(tris, spacing, rng)
            pts.append(P @ Rotation.from_euler("xyz", rpy).as_matrix().T + xyz)
        if pts:
            P = np.vstack(pts)
            _, keep = np.unique(np.floor(P / spacing).astype(np.int64), axis=0, return_index=True)
            out[link.get("name")] = P[keep]
    return out


def world_cloud(clouds, links, q14, grip):
    """transform the clouds of the given links for one configuration -> dict link -> (N,3) torso frame"""
    q14 = np.atleast_2d(q14)
    res = {}
    for l in links:
        T = fk(l, q14, grip)[0]
        res[l] = clouds[l] @ T[:3, :3].T + T[:3, 3]
    return res


# ---------------- cups ----------------
class Cup:
    """truncated cone standing on the table: bottom centre b, axis n, bottom/rim outer radius, height"""

    def __init__(self, b, n, rb=0.0345, rt=0.041, h=0.142):
        self.b, self.n, self.rb, self.rt, self.h = np.asarray(b, float), np.asarray(n, float), rb, rt, h

    @property
    def rim(self):
        return self.b + self.n * self.h

    def radius(self, hh):
        return self.rb + (self.rt - self.rb) * np.clip(hh, 0, self.h) / self.h

    def distance(self, P):
        """unsigned distance to the cup as a SOLID (conservative for everything except the planned fingers)"""
        d = P - self.b
        hh = d @ self.n
        rad = np.linalg.norm(d - np.outer(hh, self.n), axis=1)
        rr = self.radius(hh)
        out_r = np.maximum(rad - rr, 0)
        out_h = np.maximum(np.maximum(-hh, hh - self.h), 0)
        return np.sqrt(out_r ** 2 + out_h ** 2)

    def wall_distance(self, P):
        """distance to the thin wall surface (hollow cup, open top) + bottom disk"""
        d = P - self.b
        hh = d @ self.n
        rad = np.linalg.norm(d - np.outer(hh, self.n), axis=1)
        hc = np.clip(hh, 0, self.h)
        dw = np.sqrt((rad - self.radius(hc)) ** 2 + (hh - hc) ** 2)
        db = np.where(rad <= self.rb, np.abs(hh), np.sqrt((rad - self.rb) ** 2 + hh ** 2))
        return np.minimum(dw, db)

    def surface_points(self, k=72, rings=15):
        t = np.linspace(0, 2 * np.pi, k, endpoint=False)
        u = np.cross(self.n, [0, 1, 0]); u /= np.linalg.norm(u); v = np.cross(self.n, u)
        pts = []
        for f in np.linspace(0, 1, rings):
            r = self.rb + (self.rt - self.rb) * f
            pts.append(self.b + self.n * self.h * f + r * (np.cos(t)[:, None] * u + np.sin(t)[:, None] * v))
        for r in np.linspace(0, self.rb, 5):
            pts.append(self.b + r * (np.cos(t)[:, None] * u + np.sin(t)[:, None] * v))
        return np.vstack(pts)


def min_dist(A, B):
    if len(A) == 0 or len(B) == 0:
        return np.inf
    return float(cKDTree(B).query(A, k=1)[0].min())


def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))
