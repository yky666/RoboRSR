# frames_to_videos.py -- the logger's camera frames as they were recorded, one H.264 video per camera (10 fps)
# usage: frames_to_videos.py <logger_run_dir> <out_dir>
import glob
import os
import subprocess
import sys
from pathlib import Path

RUN, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
FFMPEG = next((Path(__file__).parents[2] / ".venv/Lib/site-packages/imageio_ffmpeg/binaries").glob("ffmpeg*.exe"))
tmp = Path(os.environ["TEMP"])
for cam in ("head", "left_wrist", "right_wrist"):
    files = sorted(glob.glob(str(RUN / cam / "*.jpg")))
    lst = tmp / f"frames_{cam}.txt"
    lst.write_text("".join(f"file '{f}'\nduration 0.1\n" for f in files), encoding="utf-8")
    out_tmp = tmp / f"{cam}.mp4"
    subprocess.run([str(FFMPEG), "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-vf", "fps=10,pad=ceil(iw/2)*2:ceil(ih/2)*2", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20",
                    str(out_tmp)], check=True)
    (OUT / f"{cam}.mp4").write_bytes(out_tmp.read_bytes())
    print(f"{cam}: {len(files)} frames -> {OUT / (cam + '.mp4')} ({out_tmp.stat().st_size / 1e6:.1f} MB)", flush=True)
