# table_plane_from_outline.py -- table plane in the torso frame from the table-top outline (known 1.2 m x 0.6 m) in the
# head stereo: per eye, undistort, flood-fill the bright table top from seeds, fit the four edge lines (RANSAC on the
# outline, rounded corners excluded), intersect -> corners, planar PnP with the rectangle, official camera setup.
# usage: python table_plane_from_outline.py <head_stereo.png> [--size 1.2,0.6]  -> prints fit_cups.py arguments
import argparse
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"))
from calib_model import Robot  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("image")
ap.add_argument("--size", default="1.2,0.6")
ap.add_argument("--tol", type=int, default=6, help="flood-fill gray tolerance between neighbours")
ap.add_argument("--edge-lo", type=int, default=12, help="Canny low threshold of the barrier edges")
a = ap.parse_args()
LX, LY = (float(v) for v in a.size.split(","))
PKG = ROOT / "pc_tools" / "robodojo_merge_sq382j"
CAMS = json.loads((PKG / "camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
ROB = Robot(PKG / "g1_d_upper_dex1_v4.urdf")
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
img = cv2.imread(a.image)
W = img.shape[1] // 2
out_dir = Path(os.environ.get("TEMP", "/tmp"))


def ransac_line(P, n_iter=400, thr=1.5, rng=np.random.default_rng(0)):
    best = None
    for _ in range(n_iter):
        i, j = rng.choice(len(P), 2, replace=False)
        d = P[j] - P[i]
        if np.linalg.norm(d) < 20:
            continue
        nrm = np.array([-d[1], d[0]]) / np.linalg.norm(d)
        inl = np.abs((P - P[i]) @ nrm) < thr
        if best is None or inl.sum() > best.sum():
            best = inl
    Q = P[best]
    c = Q.mean(0)
    u = np.linalg.svd(Q - c)[2][0]
    return c, u, Q


def intersect(l1, l2):
    (c1, u1), (c2, u2) = l1[:2], l2[:2]
    A = np.c_[u1, -u2]
    t = np.linalg.solve(A, c2 - c1)
    return c1 + u1 * t[0]


res = {}
for half, eye in ((0, "head_left"), (1, "head_right")):
    c = CAMS[eye]
    K, D = np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
    und = cv2.undistort(img[:, half * W:(half + 1) * W], K, D)
    gray = cv2.GaussianBlur(cv2.cvtColor(und, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    H = gray.shape[0]
    # Canny edges act as barriers (non-zero mask pixels are never filled): table and wall are both light gray
    mask = np.zeros((H + 2, W + 2), np.uint8)
    mask[1:-1, 1:-1] = (cv2.dilate(cv2.Canny(gray, a.edge_lo, 3 * a.edge_lo), np.ones((3, 3), np.uint8)) > 0).astype(np.uint8)
    for seed in ((90, 330), (560, 320), (320, 235), (160, 260), (480, 260)):
        if gray[seed[1], seed[0]] > 150 and mask[seed[1] + 1, seed[0] + 1] == 0:
            cv2.floodFill(gray.copy(), mask, seed, 255, a.tol, a.tol, cv2.FLOODFILL_MASK_ONLY | (255 << 8) | 4)
    m = (mask[1:-1, 1:-1] == 255).astype(np.uint8) * 255
    print(eye, "table region px", int((m > 0).sum()))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    ct = max(cs, key=cv2.contourArea).reshape(-1, 2).astype(float)
    ct = ct[(ct[:, 0] > 3) & (ct[:, 0] < W - 4) & (ct[:, 1] > 3) & (ct[:, 1] < H - 4)]
    # edge groups by position relative to the outline's bounding box
    x0, y0 = ct.min(0); x1, y1 = ct.max(0)
    top = ct[ct[:, 1] < y0 + 0.12 * (y1 - y0)]
    rest = ct[ct[:, 1] >= y0 + 0.12 * (y1 - y0)]
    xm = (x0 + x1) / 2
    left = rest[(rest[:, 0] < xm) & (rest[:, 1] < y0 + 0.75 * (y1 - y0))]
    right = rest[(rest[:, 0] > xm) & (rest[:, 1] < y0 + 0.75 * (y1 - y0))]
    bottom = rest[rest[:, 1] > y0 + 0.85 * (y1 - y0)]
    lines = {k: ransac_line(P) for k, P in (("top", top), ("left", left), ("right", right), ("bottom", bottom)) if len(P) > 30}
    vis = und.copy()
    cv2.drawContours(vis, [ct.astype(np.int32).reshape(-1, 1, 2)], -1, (0, 200, 255), 1)
    for k, (cc, u, Q) in lines.items():
        p, q = cc - u * 800, cc + u * 800
        cv2.line(vis, tuple(p.astype(int)), tuple(q.astype(int)), (0, 0, 255), 1, cv2.LINE_AA)
        for pt in Q[::5]:
            cv2.circle(vis, tuple(pt.astype(int)), 1, (0, 255, 0), -1)
    if len(lines) < 4:
        print(eye, "edges found:", list(lines)); cv2.imwrite(str(out_dir / f"table_outline_{eye}.png"), vis); continue
    # image corners: far-left, far-right, near-right, near-left; table frame x toward the far edge? -> rectangle in the
    # table frame with u along the long (left-right) side, v along the depth
    UV = np.array([intersect(lines["top"], lines["left"]), intersect(lines["top"], lines["right"]),
                   intersect(lines["bottom"], lines["right"]), intersect(lines["bottom"], lines["left"])])
    for p in UV:
        cv2.circle(vis, tuple(p.astype(int)), 4, (255, 0, 0), 2)
    cv2.imwrite(str(out_dir / f"table_outline_{eye}.png"), vis)
    OBJ = np.array([[0, 0, 0], [LX, 0, 0], [LX, LY, 0], [0, LY, 0]], float)     # board-like frame: x right, y toward the robot
    ok, rv, tv = cv2.solvePnP(OBJ, UV, K, np.zeros(5), flags=cv2.SOLVEPNP_IPPE)
    T_ob = np.eye(4); T_ob[:3, :3] = cv2.Rodrigues(rv)[0]; T_ob[:3, 3] = tv.ravel()
    T_cam = ROB.fk(c["parent"], {}, {}, None, 1)[0] @ np.array(c["T_parent_camera_world_convention"])
    C2O = np.eye(4); C2O[:3, :3] = OPT.T
    T = T_cam @ C2O @ T_ob
    ctr = T[:3, :3] @ OBJ.mean(0) + T[:3, 3]
    nz = T[:3, 2] if T[2, 2] > 0 else -T[:3, 2]
    rep = cv2.projectPoints(OBJ, rv, tv, K, np.zeros(5))[0].reshape(-1, 2) - UV
    res[eye] = (ctr, nz)
    print(f"{eye}: corners {UV.round(1).tolist()} reproj {np.abs(rep).max():.2f} px | table centre {ctr.round(4).tolist()} "
          f"up {nz.round(4).tolist()} offset {nz @ ctr:.4f}")
if res:
    C = np.mean([v[0] for v in res.values()], 0)
    Nn = np.mean([v[1] for v in res.values()], 0); Nn /= np.linalg.norm(Nn)
    print(f"mean: centre {C.round(4).tolist()} up {Nn.round(4).tolist()} offset {Nn @ C:.4f}")
    print(f"fit_cups.py args: --board-c={C[0]:.4f},{C[1]:.4f},{C[2]:.4f} --board-n={Nn[0]:.4f},{Nn[1]:.4f},{Nn[2]:.4f} "
          f"--board-thick=0 --stereo-scale=0.955")
