# check_cup_spots.py -- grasp reachability (numpy solver, plan2 grasp family) if the cups stood at other spots on the
# measured table: cup bottoms at (x, +y) left and (x, -y) right; err = IK residual mm + deg (< 1 = reachable)
# usage: REPLAY_URDF=<urdf> python check_cup_spots.py
import contextlib
import io
import sys

sys.argv = ["plan2.py"]
import plan2  # noqa: E402
from geom import Cup  # noqa: E402
from reach_diag import N, on_table  # noqa: E402

for x in (0.36, 0.40, 0.44):
    for y in (0.13, 0.16):
        for th in (65, 50, 35):
            plan2.CUP_L, plan2.CUP_R = Cup(on_table((x, y)), N), Cup(on_table((x, -y)), N)
            plan2.TH_L = plan2.TH_R = th
            e = []
            for side in ("left", "right"):
                with contextlib.redirect_stdout(io.StringIO()):
                    e.append(plan2.grasp(side)[2])
            print(f"x {x:.2f} y +-{y:.2f} tilt {th}: left {e[0]:7.2f} right {e[1]:7.2f}{'   <- both reachable' if max(e) < 1 else ''}",
                  flush=True)
