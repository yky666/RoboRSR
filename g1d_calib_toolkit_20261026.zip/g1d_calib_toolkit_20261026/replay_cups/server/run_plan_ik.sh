#!/bin/bash
# cup-stacking plan with the simulator's IK on the official asset (assembled_calib_20261023_sq382j)
# usage: bash run_plan_ik.sh <gpu> [tag]
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
B=$R/scratch/replay_1023
W=$B/pc_tools/replay_cups
gpu=${1:-4}
TAG=${2:-_1023ik}
A=$R/assembled_calib_20261023_sq382j
mkdir -p $B/g1d_calib_20261015/g1d_calib_20261015/nominal /dev/shm/tmp /dev/shm/isaac_work
ln -sfn $R/calib_model.py $B/g1d_calib_20261015/g1d_calib_20261015/calib_model.py
ln -sfn $A/meshes $B/g1d_calib_20261015/g1d_calib_20261015/nominal/meshes
cd $W
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6 TMPDIR=/dev/shm/tmp
CUDA_VISIBLE_DEVICES=$gpu timeout --signal=TERM --kill-after=20s 3600s $ENV/bin/python -u plan_sim_ik.py \
  --urdf $A/g1_d_upper_dex1_v4.urdf --tag $TAG --th ${TH:-35} --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$gpu --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" > $W/plan$TAG.log 2>&1
echo "EXIT=$?" >> $W/plan$TAG.log
