# sim_cups_views.py -- sim_cups.py plus per-frame renders of our calibrated cameras (--cams camera_setup_ours.json:
# head_left / left_wrist / right_wrist, principal point via aperture offsets) and --no-startup (the trajectory already
# starts at the robot's real pose, e.g. the measured joints of a real run), for the real-vs-sim video. Unedited physics.
# sim_cups.py -- Isaac Lab physics check of the cup-stacking replay on the CALIBRATED asset (assembled_calib_20261021)
# torso fixed at the world origin (= our torso frame); table tilted to the head-measured normal; two hollow truncated
# cone paper cups (24 thin wall boxes + bottom disk, 10 g); the replayed joint trajectory drives stiff position
# actuators (ideal tracking), Dex1 fingers from the command value via Unitree's linear map (force-limited).
# Sequence = what replay.py does: start at the all-zero pose, 3 s smoothstep to the ready pose, then the episode.
#   --trial name:dx_left,dy_left,dx_right,dy_right  (cup offsets in m vs the plan; several --trial allowed)
#   --video  render the first trial (scene camera + head_left camera)
import argparse
import json
import os

import numpy as np
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--plan", required=True)
parser.add_argument("--traj", required=True)
parser.add_argument("--urdf", required=True)
parser.add_argument("--contract", required=True)
parser.add_argument("--intr", required=True)
parser.add_argument("--out", required=True)
parser.add_argument("--trial", action="append", default=[], help="name:dxL,dyL,dxR,dyR[,dz]  (m)")
parser.add_argument("--video", action="store_true")
parser.add_argument("--real-head", default="", help="real head stereo png (left half used) for the overlay video")
parser.add_argument("--no-nominal", action="store_true")
parser.add_argument("--table-dz", type=float, default=0.0, help="real table (and cups) this much higher than planned (m)")
parser.add_argument("--cams", default="", help="camera_setup_ours.json: render these views every frame into <out>/frames")
parser.add_argument("--views", default="head_left,left_wrist,right_wrist")
parser.add_argument("--no-startup", action="store_true", help="no zero -> ready ramp; start at the first trajectory frame")
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
args.enable_cameras = bool(args.video or args.cams)
args.headless = True
app = AppLauncher(args).app

import cv2
import torch
from pxr import Gf, Sdf, UsdGeom, UsdLux, UsdPhysics, UsdShade
from scipy.spatial.transform import Rotation

import isaaclab.sim as sim_utils
from isaaclab.actuators import ImplicitActuatorCfg
from isaaclab.assets import Articulation, ArticulationCfg, RigidObject, RigidObjectCfg
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg

os.makedirs(args.out, exist_ok=True)
plan = json.load(open(args.plan))
tr = np.load(args.traj)
Q, GR, FPS = tr["q"], tr["grip"], float(tr["fps"])
N = np.array(plan["table_normal"])
CUPS = {k: np.array(plan["cups"][k]["bottom"]) for k in ("left", "right")}
DIMS = plan["cup_dims"]
READY = np.array(plan["ready"])
PHYS_DT = 1.0 / 240.0
SUB = int(round(1.0 / FPS / PHYS_DT))
trials = ([] if args.no_nominal else [("nominal", np.zeros(5))]) + \
         [(t.split(":")[0], np.r_[[float(v) for v in t.split(":")[1].split(",")], [0.0]][:5]) for t in args.trial]
M_PLAN = np.array(plan["M_bottom_torso"])

sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=PHYS_DT, device=args.device, use_fabric=False,
                                                          gravity=(0.0, 0.0, -9.81)))
stage = sim.stage
conv = UrdfConverter(UrdfConverterCfg(
    asset_path=args.urdf, usd_dir=f"/dev/shm/isaac_work/usd_conv_cups_{os.path.basename(os.path.normpath(args.out))}",
    usd_file_name="g1d_calib_cups.usd",
    fix_base=True, merge_fixed_joints=False, force_usd_conversion=True, make_instanceable=False,
    joint_drive=UrdfConverterCfg.JointDriveCfg(gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
robot = Articulation(ArticulationCfg(
    prim_path="/World/Robot",
    spawn=sim_utils.UsdFileCfg(usd_path=conv.usd_path,
                               rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
                               articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                                   enabled_self_collisions=False, solver_position_iteration_count=16)),
    actuators={"arms": ImplicitActuatorCfg(joint_names_expr=[".*_(shoulder|elbow|wrist).*"], stiffness=3000., damping=120.),
               "fingers": ImplicitActuatorCfg(joint_names_expr=[".*dex1_finger.*"], stiffness=3000., damping=60.,
                                              effort_limit_sim=20.0)}))

# ---------------- materials / table / cups ----------------
mat = UsdShade.Material.Define(stage, "/World/PhysMat")
pm = UsdPhysics.MaterialAPI.Apply(mat.GetPrim())
pm.CreateStaticFrictionAttr(0.8); pm.CreateDynamicFrictionAttr(0.6); pm.CreateRestitutionAttr(0.0)


def bind(prim):
    UsdShade.MaterialBindingAPI.Apply(prim).Bind(mat, UsdShade.Tokens.weakerThanDescendants, "physics")


def quat_from_R(R):
    x, y, z, w = Rotation.from_matrix(R).as_quat()
    return Gf.Quatd(float(w), Gf.Vec3d(float(x), float(y), float(z)))


def add_box(parent, name, center, R, size, color, collide=True):
    c = UsdGeom.Cube.Define(stage, f"{parent}/{name}")
    c.CreateSizeAttr(1.0)
    x = UsdGeom.Xformable(c)
    x.AddTranslateOp().Set(Gf.Vec3d(*map(float, center)))
    x.AddOrientOp(UsdGeom.XformOp.PrecisionDouble).Set(quat_from_R(R))
    x.AddScaleOp().Set(Gf.Vec3d(*map(float, size)))
    c.CreateDisplayColorAttr([Gf.Vec3f(*color)])
    if collide:
        UsdPhysics.CollisionAPI.Apply(c.GetPrim())
        bind(c.GetPrim())
    return c


def basis(n):
    u = np.cross(n, [0, 1, 0]); u /= np.linalg.norm(u)
    return u, np.cross(n, u)


# table: 0.9 x 1.4 x 0.04 slab whose top face is the measured plane; near edge at x = 0.17
ut, vt = basis(N)
Rt = np.c_[ut, vt, N]
top_pt = (CUPS["left"] + CUPS["right"]) / 2 + N * args.table_dz
c_tab = np.array([0.62, 0.0, 0.0]); c_tab[2] = (N @ top_pt - N[0] * c_tab[0] - N[1] * c_tab[1]) / N[2]; c_tab -= N * 0.02
UsdGeom.Xform.Define(stage, "/World/Table")
add_box("/World/Table", "slab", c_tab, Rt, (0.9, 1.4, 0.04), (0.92, 0.92, 0.92))


def make_cup(path, color):
    """hollow truncated cone in its own frame (z = axis, bottom at z=0), rigid body"""
    UsdGeom.Xform.Define(stage, path)
    prim = stage.GetPrimAtPath(path)
    UsdPhysics.RigidBodyAPI.Apply(prim)
    UsdPhysics.MassAPI.Apply(prim).CreateMassAttr(0.010)
    rb, rt, h = DIMS["rb"], DIMS["rt"], DIMS["h"]
    nseg, th = 24, 0.0015
    slope = np.arctan2(rt - rb, h)
    L = h / np.cos(slope)
    for k in range(nseg):
        ang = 2 * np.pi * k / nseg
        rm = (rb + rt) / 2
        w = 2 * rm * np.tan(np.pi / nseg) * 1.08
        radial = np.array([np.cos(ang), np.sin(ang), 0.0])
        tang = np.array([-np.sin(ang), np.cos(ang), 0.0])
        up = np.array([0, 0, 1.0])
        axis = np.cos(slope) * up + np.sin(slope) * radial          # along the slanted wall
        nrm = np.cross(axis, tang)                                  # right-handed: tang x nrm = axis
        R = np.c_[tang, nrm, axis]
        add_box(path, f"w{k:02d}", radial * rm + up * h / 2, R, (w, th, L), color)
    # bottom: 8 overlapping boxes approximating a disk, slightly raised (paper cups have a recessed bottom)
    for k in range(4):
        R = Rotation.from_euler("z", 45 * k, degrees=True).as_matrix()
        add_box(path, f"b{k}", np.array([0, 0, 0.004]), R, (2 * rb * 0.98, 2 * rb * 0.41, 0.004), color)
    return path


cup_paths = {"left": make_cup("/World/CupL", (0.15, 0.15, 0.35)), "right": make_cup("/World/CupR", (0.1, 0.1, 0.25))}
cups = {k: RigidObject(RigidObjectCfg(prim_path=p, spawn=None)) for k, p in cup_paths.items()}
UsdLux.DomeLight.Define(stage, "/World/Light").CreateIntensityAttr(900.0)

cams = {}
VIEWS = {}
if args.cams:
    from isaaclab.sensors import Camera, CameraCfg
    VIEWS = {k: v for k, v in json.load(open(args.cams))["views"].items() if k in args.views.split(",")}
    for n, c in VIEWS.items():
        cams[f"v_{n}"] = Camera(CameraCfg(prim_path=f"/World/cam_{n}", width=c["resolution"][0], height=c["resolution"][1],
                                          data_types=["rgb"],
                                          spawn=sim_utils.PinholeCameraCfg(focal_length=24.0, clipping_range=(0.02, 20.0))))
    os.makedirs(f"{args.out}/frames", exist_ok=True)
if args.video:
    from isaaclab.sensors import Camera, CameraCfg
    cams["scene"] = Camera(CameraCfg(prim_path="/World/CamScene", width=960, height=720, data_types=["rgb"],
                                     spawn=sim_utils.PinholeCameraCfg(focal_length=18.0, clipping_range=(0.05, 20.0))))
    mount = {v["name"]: v for v in json.load(open(args.contract))["views"]}["head_left"]
    doc = json.load(open(f"{args.intr}/camera_intrinsics_head_left.json"))
    K = np.array(doc["K"], dtype=float); W, H = [int(x) for x in doc["resolution"]]
    cams["head"] = Camera(CameraCfg(prim_path="/World/CamHead", width=W, height=H, data_types=["rgb"],
                                    spawn=sim_utils.PinholeCameraCfg.from_intrinsic_matrix(
                                        intrinsic_matrix=K.flatten().tolist(), width=W, height=H, focal_length=24.0,
                                        clipping_range=(0.01, 20.0))))

sim.reset()
for n, c in VIEWS.items():
    Wv, Hv = c["resolution"]
    (fxv, _, cxv), (_, fyv, cyv) = c["K"][0], c["K"][1]
    pv = stage.GetPrimAtPath(f"/World/cam_{n}")
    hap_v, vap_v = 24.0 * Wv / fxv, 24.0 * Hv / fyv
    pv.GetAttribute("focalLength").Set(24.0)
    pv.GetAttribute("horizontalAperture").Set(float(hap_v)); pv.GetAttribute("verticalAperture").Set(float(vap_v))
    pv.GetAttribute("horizontalApertureOffset").Set(float((Wv / 2.0 - cxv) * hap_v / Wv))
    pv.GetAttribute("verticalApertureOffset").Set(float((cyv - Hv / 2.0) * vap_v / Hv))
if VIEWS:
    for p in stage.Traverse():     # hide the head shell (the head lens sits inside it)
        if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link":
            UsdGeom.Imageable(p).MakeInvisible()
if args.video:
    prim = stage.GetPrimAtPath("/World/CamHead")
    hap, vap = 24.0 * W / K[0, 0], 24.0 * H / K[1, 1]
    prim.GetAttribute("focalLength").Set(24.0)
    prim.GetAttribute("horizontalAperture").Set(float(hap)); prim.GetAttribute("verticalAperture").Set(float(vap))
    prim.GetAttribute("horizontalApertureOffset").Set(float((W / 2.0 - K[0, 2]) * hap / W))
    prim.GetAttribute("verticalApertureOffset").Set(float((K[1, 2] - H / 2.0) * vap / H))
    for p in stage.Traverse():     # hide the head shell for the head camera (lens sits inside it)
        if p.GetName() == "visuals" and p.GetParent().GetName() == "head_link":
            UsdGeom.Imageable(p).MakeInvisible()
    eye = np.array([0.95, -0.75, 0.45]); look = np.array([0.45, -0.02, -0.05])
    cams["scene"].set_world_poses_from_view(torch.tensor([eye.tolist()], device=args.device),
                                           torch.tensor([look.tolist()], device=args.device))

jn = robot.joint_names
arm_idx = [jn.index(n) for n in plan["joint_names"]]
fing = {s: [jn.index(f"{s}_dex1_finger_joint_1"), jn.index(f"{s}_dex1_finger_joint_2")] for s in ("left", "right")}


def grip_to_joint(g):
    return 0.024 + (-0.02 - 0.024) * np.clip(g, 0, 5.4) / 5.4


def target(q14, g2):
    t = robot.data.default_joint_pos.clone()
    for i, k in enumerate(arm_idx):
        t[0, k] = float(q14[i])
    for s, g in zip(("left", "right"), g2):
        for k in fing[s]:
            t[0, k] = float(grip_to_joint(g))
    return t


def pose_T(s):
    s = s.detach().cpu().numpy()
    T = np.eye(4); T[:3, :3] = Rotation.from_quat([s[4], s[5], s[6], s[3]]).as_matrix(); T[:3, 3] = s[:3]
    return T


def place_cups(off):
    dz = args.table_dz
    for k, (dx, dy) in (("left", off[:2]), ("right", off[2:4])):
        b = CUPS[k] + np.array([dx, dy, 0.0])
        b[2] = (N @ CUPS[k] + dz * N[2] - N[0] * b[0] - N[1] * b[1]) / N[2] + 0.0005
        xyzw = Rotation.from_matrix(np.c_[ut, vt, N]).as_quat()
        st = torch.tensor([[*b, xyzw[3], xyzw[0], xyzw[1], xyzw[2], 0, 0, 0, 0, 0, 0]], device=args.device, dtype=torch.float32)
        cups[k].write_root_state_to_sim(st)


def cup_state(k):
    T = pose_T(cups[k].data.root_state_w[0, :7])
    return T[:3, 3].copy(), T[:3, 2].copy()


def step_frame(t, render):
    for k in range(SUB):
        robot.set_joint_position_target(t)
        robot.write_data_to_sim()
        sim.step(render=render and k == SUB - 1)       # render=True syncs PhysX poses into USD (use_fabric=False)
        robot.update(PHYS_DT)
        for c in cups.values():
            c.update(PHYS_DT)
    if render:
        mount_head()
        mount_views()
        for c in cams.values():
            c.update(1.0 / FPS)


def mount_views():
    for n, c in VIEWS.items():
        parent = pose_T(robot.data.body_link_state_w[0, robot.body_names.index(c["parent"]), :7])
        T = parent @ np.array(c["T_parent_camera_world_convention"], dtype=float)
        xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
        cams[f"v_{n}"].set_world_poses(torch.tensor([T[:3, 3].tolist()], device=args.device),
                                       torch.tensor([xyzw[[3, 0, 1, 2]].tolist()], device=args.device), convention="world")


def mount_head():
    if "head" not in cams:
        return
    parent = pose_T(robot.data.body_link_state_w[0, robot.body_names.index(mount["parent"]), :7])
    T = parent @ np.array(mount["T_parent_camera_world_convention"], dtype=float)
    xyzw = Rotation.from_matrix(T[:3, :3]).as_quat()
    cams["head"].set_world_poses(torch.tensor([T[:3, 3].tolist()], device=args.device),
                                 torch.tensor([xyzw[[3, 0, 1, 2]].tolist()], device=args.device), convention="world")


def smoothstep(x):
    return x * x * (3 - 2 * x)


real_bg = None
if args.video and args.real_head:
    rimg = cv2.imread(args.real_head)
    rimg = rimg[:, : rimg.shape[1] // 2]
    real_bg = cv2.undistort(rimg, K, np.array(doc["dist"], dtype=float))

results = {}
for ti, (name, off) in enumerate(trials):
    render = bool(args.video or VIEWS) and ti == 0
    q0 = target(Q[0], GR[0]) if args.no_startup else target(np.zeros(14), (0.0, 0.0))
    robot.write_joint_state_to_sim(q0, torch.zeros_like(q0))
    place_cups(off)
    for _ in range(30):
        step_frame(q0, False)
    writers = {}
    if render and args.video:
        writers = {"scene": cv2.VideoWriter(f"{args.out}/sim_scene.mp4", cv2.VideoWriter_fourcc(*"mp4v"), FPS, (960, 720)),
                   "head": cv2.VideoWriter(f"{args.out}/sim_head_left.mp4", cv2.VideoWriter_fourcc(*"mp4v"), FPS, (W, H))}
        if real_bg is not None:
            writers["overlay"] = cv2.VideoWriter(f"{args.out}/head_overlay_real.mp4", cv2.VideoWriter_fourcc(*"mp4v"), FPS, (2 * W, H))
    key_snap = {0, 104} | {104 + v for v in plan["key_frames"].values()} | {len(Q) + 104}
    log = []
    if args.no_startup:
        seq = [(Q[i], GR[i]) for i in range(len(Q))]
    else:
        seq = [(np.zeros(14) + (READY - 0) * smoothstep(i / 90), (0.0, 0.0)) for i in range(1, 91)] + \
              [(READY, (0.0, 0.0))] * 15 + [(Q[i], GR[i]) for i in range(len(Q))]
    max_err, max_fing = 0.0, 0.0
    for i, (q14, g2) in enumerate(seq):
        t = target(q14, g2)
        step_frame(t, render)
        qa = robot.data.joint_pos[0].cpu().numpy()
        e = np.abs(qa[arm_idx] - np.asarray(q14)).max()
        max_err = max(max_err, float(e))
        pl, al = cup_state("left"); pr, ar = cup_state("right")
        log.append([i, *pl, *pr, float(np.degrees(np.arccos(np.clip(ar @ N, -1, 1)))), float(e)])
        if render and VIEWS:
            for n in VIEWS:
                rgb = cams[f"v_{n}"].data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
                cv2.imwrite(f"{args.out}/frames/sim_{n}_{i:05d}.jpg", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR),
                            [cv2.IMWRITE_JPEG_QUALITY, 92])
            if i % 100 == 0:
                print(f"frame {i}/{len(seq)}", flush=True)
        if render and args.video:
            frames = {}
            for k in ("scene", "head"):
                rgb = cams[k].data.output["rgb"][0].cpu().numpy()[..., :3].astype(np.uint8)
                frames[k] = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            ph = "replay.py startup (zero -> ready)" if i < 105 else f"episode frame {i - 105}/{len(Q)}  t={(i - 105) / FPS:5.1f}s"
            cv2.putText(frames["scene"], f"{name}  {ph}", (12, 28), 0, 0.7, (0, 0, 0), 2)
            if real_bg is not None:
                blend = cv2.addWeighted(real_bg, 0.55, frames["head"], 0.45, 0)
                ov = np.hstack([blend, frames["head"]])
                cv2.putText(ov, "real head_left (undistorted) + sim | sim", (8, 20), 0, 0.5, (0, 0, 255), 1)
                frames["overlay"] = ov
            for k, wtr in writers.items():
                wtr.write(frames[k])
                if i in key_snap:
                    cv2.imwrite(f"{args.out}/{k}_f{i:05d}.png", frames[k])
    for wtr in writers.values():
        wtr.release()
    L = np.array(log)
    pl, pr = L[-1, 1:4], L[-1, 4:7]
    d = pr - pl
    horiz = float(np.linalg.norm(d - N * (d @ N)))
    rise = float(((L[:, 4:7] - L[0, 4:7]) @ N).max())
    left_at_M = pl - M_PLAN
    nested = horiz < 0.012 and 0.0 < float(d @ N) < 0.10 and L[-1, 7] < 8.0
    results[name] = {"offsets_m": off.tolist(), "right_cup_max_rise_m": rise, "final_axis_offset_m": horiz,
                     "final_height_above_left_bottom_m": float(d @ N), "right_cup_final_tilt_deg": float(L[-1, 7]),
                     "left_cup_final_minus_M_m": left_at_M.round(4).tolist(),
                     "left_cup_max_rise_m": float(((L[:, 1:4] - L[0, 1:4]) @ N).max()),
                     "max_arm_tracking_err_rad": max_err, "nested": bool(nested)}
    np.save(f"{args.out}/log_{name}.npy", L)
    print(f"[trial] {name}: {results[name]}", flush=True)
json.dump(results, open(f"{args.out}/sim_results.json", "w"), indent=1)
print("[done]", flush=True)
os._exit(0)
