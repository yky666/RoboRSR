# plan_sim_ik.py -- cup-stacking plan whose joint trajectory is solved by the simulator's IK: Isaac Lab's
# DifferentialIKController (damped least squares) on the PhysX Jacobian of the calibrated articulation (the same
# solver scene3_pour_pack/motion/controller.py uses). plan2.py's task geometry (grasp frames, meeting point M, carry /
# set-down / insert poses, timing) is unchanged; every geom.ik call is answered by the simulator.
# usage (from the replay dir, which holds plan2.py / geom.py / reach_diag.py / out/cups.json):
#   python plan_sim_ik.py --urdf <calibrated upper urdf> --tag _1023ik [--m x,y --yaw l,r]  (findm first if no --m)
import argparse
import os
import runpy
import sys
import time

from isaaclab.app import AppLauncher

ap = argparse.ArgumentParser()
ap.add_argument("--urdf", required=True)
ap.add_argument("--tag", default="_simik")
ap.add_argument("--m", default="")
ap.add_argument("--yaw", default="")
ap.add_argument("--th", default="", help="approach tilt below horizontal (deg), passed to plan2.py")
ap.add_argument("--seq", action="store_true", help="right arm starts after the left arm is back at ready (plan2.py --seq)")
AppLauncher.add_app_launcher_args(ap)
args = ap.parse_args()
args.headless = True
app = AppLauncher(args).app

import numpy as np  # noqa: E402
import torch  # noqa: E402
from scipy.spatial.transform import Rotation  # noqa: E402

import isaaclab.sim as sim_utils  # noqa: E402
from isaaclab.actuators import ImplicitActuatorCfg  # noqa: E402
from isaaclab.assets import Articulation, ArticulationCfg  # noqa: E402
from isaaclab.controllers import DifferentialIKController, DifferentialIKControllerCfg  # noqa: E402
from isaaclab.sim.converters import UrdfConverter, UrdfConverterCfg  # noqa: E402

os.environ["REPLAY_URDF"] = args.urdf
sys.path.insert(0, os.getcwd())
import geom  # noqa: E402  (numpy FK on the same URDF, used for the task geometry)

DT = 1.0 / 240.0
sim = sim_utils.SimulationContext(sim_utils.SimulationCfg(dt=DT, device=args.device, gravity=(0.0, 0.0, 0.0)))
conv = UrdfConverter(UrdfConverterCfg(
    asset_path=args.urdf, usd_dir=f"/dev/shm/isaac_work/usd_conv_planik{args.tag}", usd_file_name="g1d_planik.usd",
    fix_base=True, merge_fixed_joints=False, force_usd_conversion=True, make_instanceable=False,
    joint_drive=UrdfConverterCfg.JointDriveCfg(gains=UrdfConverterCfg.JointDriveCfg.PDGainsCfg(stiffness=100., damping=1.))))
robot = Articulation(ArticulationCfg(
    prim_path="/World/Robot",
    spawn=sim_utils.UsdFileCfg(usd_path=conv.usd_path, rigid_props=sim_utils.RigidBodyPropertiesCfg(disable_gravity=True),
                               articulation_props=sim_utils.ArticulationRootPropertiesCfg(enabled_self_collisions=False)),
    actuators={"all": ImplicitActuatorCfg(joint_names_expr=[".*"], stiffness=3000., damping=120.)}))
sim.reset()
JN = robot.joint_names
IDS = {s: [JN.index(n) for n in (geom.LJ if s == "left" else geom.RJ)] for s in ("left", "right")}
BODY = {s: robot.body_names.index(f"{s}_dex1_base_link") for s in ("left", "right")}
IK = DifferentialIKController(DifferentialIKControllerCfg(command_type="pose", use_relative_mode=False, ik_method="dls"),
                              num_envs=1, device=robot.device)
STATS = {"calls": 0, "iters": 0, "t": 0.0}


def set_q(q14):
    q = robot.data.default_joint_pos.clone()
    for s, off in (("left", 0), ("right", 7)):
        q[0, IDS[s]] = torch.tensor(q14[off:off + 7], dtype=torch.float32, device=robot.device)
    robot.write_joint_state_to_sim(q, torch.zeros_like(q))
    robot.set_joint_position_target(q)
    robot.write_data_to_sim()
    sim.step(render=False)
    robot.update(DT)


def pose_err(side, Tg):
    b = robot.data.body_link_state_w[0, BODY[side], :7].cpu().numpy()
    R = Rotation.from_quat(b[[4, 5, 6, 3]]).as_matrix()
    return Tg[:3, 3] - b[:3], Rotation.from_matrix(Tg[:3, :3] @ R.T).as_rotvec()


def sim_ik(Tg, q0, side="right", iters=200, w_rest=1e-3, q_rest=None):
    """same contract as geom.ik: (q14, pos_err_m, rot_err_rad); solved by Isaac Lab DLS on the PhysX Jacobian"""
    t0 = time.time()
    off = 0 if side == "left" else 7
    q = np.array(q0, float)
    lo = geom.LIMITS[off:off + 7, 0] + geom.LIMIT_MARGIN
    hi = geom.LIMITS[off:off + 7, 1] - geom.LIMIT_MARGIN
    if side in geom.EXTRA_BOUNDS:
        lo, hi = np.maximum(lo, geom.EXTRA_BOUNDS[side][0]), np.minimum(hi, geom.EXTRA_BOUNDS[side][1])
    q[off:off + 7] = np.clip(q[off:off + 7], lo, hi)
    set_q(q)
    q_t = torch.tensor(Tg[:3, 3], dtype=torch.float32, device=robot.device)[None]
    xyzw = Rotation.from_matrix(Tg[:3, :3]).as_quat()
    q_r = torch.tensor([[xyzw[3], xyzw[0], xyzw[1], xyzw[2]]], dtype=torch.float32, device=robot.device)
    IK.set_command(torch.cat([q_t, q_r], dim=-1))       # root = torso at the world origin, identity
    n = 0
    for n in range(iters):
        dp, dr = pose_err(side, Tg)
        if np.linalg.norm(dp) < 2e-5 and np.linalg.norm(dr) < 2e-4:
            break
        b = robot.data.body_link_state_w[:, BODY[side], :7]
        J = robot.root_physx_view.get_jacobians()[:, BODY[side] - 1, :, :][:, :, IDS[side]]
        new = IK.compute(b[:, :3], b[:, 3:7], J, robot.data.joint_pos[:, IDS[side]])[0].cpu().numpy().astype(float)
        step = np.clip(new - q[off:off + 7], -0.2, 0.2)
        q[off:off + 7] = np.clip(q[off:off + 7] + step, lo, hi)
        set_q(q)
    dp, dr = pose_err(side, Tg)
    STATS["calls"] += 1; STATS["iters"] += n + 1; STATS["t"] += time.time() - t0
    return q, float(np.linalg.norm(dp)), float(np.linalg.norm(dr))


# consistency of the simulator articulation with the numpy model used for the task geometry
rng = np.random.default_rng(0)
worst = 0.0
for _ in range(5):
    qq = geom.READY + rng.uniform(-0.4, 0.4, 14)
    set_q(qq)
    for s in ("left", "right"):
        dp, dr = pose_err(s, geom.ee(qq, s)[0])
        worst = max(worst, np.linalg.norm(dp) * 1000)
print(f"[sim vs numpy FK] max gripper base position difference {worst:.4f} mm", flush=True)

geom.ik = sim_ik
argv0 = ["plan2.py"]
TH = (["--th", args.th] if args.th else []) + (["--seq"] if args.seq else [])
if not args.m:
    sys.argv = argv0 + ["findm"] + TH
    runpy.run_path("plan2.py", run_name="__main__")
    import json
    r = [x for x in json.load(open("out/m_search.json")) if x["ok"]]
    r.sort(key=lambda x: -min(x["left"]["torso"], x["right"]["torso"], x["left"]["lim"], x["right"]["lim"]))
    b = r[0]
    args.m, args.yaw = f"{b['x']},{b['y']}", f"{b['left']['yaw_deg']},{b['right']['yaw_deg']}"
    print(f"[findm] chosen M {args.m} yaw {args.yaw} (margin "
          f"{min(b['left']['torso'], b['right']['torso'], b['left']['lim'], b['right']['lim']):.3f})", flush=True)
sys.argv = argv0 + ["plan", f"--m={args.m}", f"--yaw={args.yaw}", "--tag", args.tag] + TH
runpy.run_path("plan2.py", run_name="__main__")
print(f"[sim IK] {STATS['calls']} solves, {STATS['iters']} iterations, {STATS['t']:.0f} s", flush=True)
os._exit(0)
