#!/bin/bash
# physics sim driven by the real run (measured arm joints, commanded grippers), rendering our three cameras every frame
# usage: bash run_sim_views_1023.sh <gpu>
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
W=$R/scratch/replay_1023/pc_tools/replay_cups
A=$R/assembled_calib_20261023_sq382j
P=$R/robodojo_g1d_calib_sq382j_20261023
gpu=${1:-1}
OUT=$W/sim_views_1023
mkdir -p /dev/shm/tmp /dev/shm/isaac_work
cd $W
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6 TMPDIR=/dev/shm/tmp
rm -rf $OUT; mkdir -p $OUT
CUDA_VISIBLE_DEVICES=$gpu timeout --signal=TERM --kill-after=20s 10800s $ENV/bin/python -u sim_cups_views.py \
  --plan out/plan2_1023s.json --traj sim_traj.npz --urdf $A/g1_d_upper_dex1_v4.urdf \
  --contract $A/camera_contract_v5.json --intr $R/real_data/20261016/intrinsics \
  --cams $P/camera_setup_ours.json --no-startup --out $OUT --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$gpu --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" > $OUT.log 2>&1
echo "EXIT=$?" >> $OUT.log
cd $OUT && tar cf ../sim_views_1023_frames.tar frames
echo ALL_SIM_DONE >> $OUT.log
