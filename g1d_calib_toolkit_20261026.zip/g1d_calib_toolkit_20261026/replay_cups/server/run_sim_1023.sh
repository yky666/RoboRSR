#!/bin/bash
# physics check + videos of the sim-IK plan on the official asset (assembled_calib_20261023_sq382j)
# usage: bash run_sim_1023.sh <gpu> <tag>
ENV=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
W=$R/scratch/replay_1023/pc_tools/replay_cups
A=$R/assembled_calib_20261023_sq382j
gpu=${1:-1}
TAG=${2:-_1023s}
OUT=$W/sim$TAG
mkdir -p /dev/shm/tmp /dev/shm/isaac_work
cd $W
export OMNI_KIT_ACCEPT_EULA=YES PYTHONUNBUFFERED=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=4
export LD_PRELOAD=$ENV/lib/libstdc++.so.6 TMPDIR=/dev/shm/tmp
rm -rf $OUT; mkdir -p $OUT
CUDA_VISIBLE_DEVICES=$gpu timeout --signal=TERM --kill-after=20s 2400s $ENV/bin/python -u sim_cups.py \
  --plan out/plan2$TAG.json --traj out/traj2$TAG.npz --urdf $A/g1_d_upper_dex1_v4.urdf \
  --contract $A/camera_contract_v5.json --intr $R/real_data/20261016/intrinsics \
  --out $OUT --video --real-head head_1023_1.png --device cuda:0 \
  --kit_args "--/renderer/activeGpu=$gpu --/renderer/multiGpu/enabled=false --/physics/cudaDevice=0" > $OUT.log 2>&1
echo "EXIT=$?" >> $OUT.log
for f in $OUT/sim_scene.mp4 $OUT/head_overlay_real.mp4 $OUT/sim_head_left.mp4; do
  [ -f "$f" ] && ffmpeg -y -loglevel error -i "$f" -c:v libx264 -pix_fmt yuv420p -crf 23 "${f%.mp4}_h264.mp4" 2>/dev/null
done
echo ALL_SIM_DONE >> $OUT.log
