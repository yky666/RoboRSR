# make_cups_cmp_video.py -- real vs sim video of the 2026-10-23 cup replay: rows head_left / left_wrist / right_wrist,
# columns real (undistorted with our calibrated intrinsics) | Isaac Lab physics sim (unedited render; calibrated asset
# sq382j, our cameras) driven by the measured arm joints and the commanded grippers, 10 fps = recording time.
# usage: make_cups_cmp_video.py <logger_run_dir> <sim_traj.json> <sim_frames_dir> <camera_setup_ours.json> <out.mp4>
import glob
import json
import os
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

RUN, TRAJ, REN, CAMS, OUT = sys.argv[1:6]
ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
FFMPEG = next((ROOT / ".venv/Lib/site-packages/imageio_ffmpeg/binaries").glob("ffmpeg*.exe"))
cams = json.load(open(CAMS, encoding="utf-8"))["views"]
frames = json.load(open(TRAJ, encoding="utf-8"))["frames"]
F_T = ImageFont.truetype(r"C:\Windows\Fonts\msyhbd.ttc", 22)
F_S = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 17)
ROWS = (("head_left", "head", "头部左眼"), ("left_wrist", "left_wrist", "左腕相机"), ("right_wrist", "right_wrist", "右腕相机"))
W, H = 640, 480


def stamps(d):
    fs = sorted(glob.glob(os.path.join(RUN, d, "*.jpg")))
    return fs, np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in fs])


src = {d: stamps(d) for _, d, _ in ROWS}
maps = {v: cv2.initUndistortRectifyMap(np.array(cams[v]["K"]), np.array(cams[v]["dist_k1k2p1p2k3"]), None,
                                       np.array(cams[v]["K"]), (W, H), cv2.CV_16SC2) for v, _, _ in ROWS}


def bar(w, h, items, bg=(24, 38, 56)):
    im = Image.new("RGB", (w, h), bg)
    d = ImageDraw.Draw(im)
    for x, y, t, f, c in items:
        d.text((x, y), t, font=f, fill=c)
    return cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)


tmp = Path(os.environ["TEMP"]) / "cups_cmp_raw.mp4"
vw = cv2.VideoWriter(str(tmp), cv2.VideoWriter_fourcc(*"mp4v"), 10.0, (2 * W, 3 * H + 3 * 34 + 46))
col_hdr = {v: bar(2 * W, 34, [(12, 6, f"{lab}：左 = 真机（去畸变）   右 = Isaac Lab 物理仿真（原样渲染）", F_S, (230, 236, 242))],
                  bg=(31, 59, 87)) for v, _, lab in ROWS}
n_done = 0
for k, fr in enumerate(frames):
    simf = {v: os.path.join(REN, f"sim_{v}_{k:05d}.jpg") for v, _, _ in ROWS}
    if not all(os.path.exists(f) for f in simf.values()):
        continue
    parts = [bar(2 * W, 46, [(12, 9, f"叠杯回放 真机 vs 仿真   t = {fr['t_rel']:6.1f} s", F_T, (255, 255, 255)),
                             (790, 13, "仿真由真机实测关节角 + 夹爪指令逐帧驱动", F_S, (175, 225, 255))])]
    for v, d, _ in ROWS:
        fs, ts = src[d]
        j = int(np.argmin(np.abs(ts - fr["t"])))
        img = cv2.imdecode(np.fromfile(fs[j], np.uint8), cv2.IMREAD_COLOR)
        img = img[:, :W] if img.shape[1] > W else img
        real = cv2.remap(img, *maps[v], cv2.INTER_LINEAR)
        sim = cv2.resize(cv2.imdecode(np.fromfile(simf[v], np.uint8), cv2.IMREAD_COLOR), (W, H))
        cv2.line(sim, (0, 0), (0, H - 1), (220, 225, 230), 2)
        parts += [col_hdr[v], np.hstack([real, sim])]
    img = np.vstack(parts)
    vw.write(img)
    if k % 300 == 0:
        cv2.imencode(".png", img)[1].tofile(str(Path(OUT).with_name(f"cmp_frame_{k:05d}.png")))
    n_done += 1
vw.release()
h264 = Path(os.environ["TEMP"]) / "cups_cmp_h264.mp4"
subprocess.run([str(FFMPEG), "-y", "-loglevel", "error", "-i", str(tmp), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "21",
                str(h264)], check=True)
Path(OUT).write_bytes(h264.read_bytes())
print(f"wrote {OUT}: {n_done} frames ({n_done / 10:.0f} s), {h264.stat().st_size / 1e6:.1f} MB")
