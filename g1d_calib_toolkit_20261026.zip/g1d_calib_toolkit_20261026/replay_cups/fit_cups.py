# fit_cups.py -- locate the two paper cups in the torso frame from one head stereo frame (model-based silhouette fit)
# cup model: truncated cone (rim 8.2 cm, bottom 6.9 cm, height 14.2 cm, tape-measured), axis along the table normal.
# predicted image: dark outer wall = convex hull(rim ellipse, bottom ellipse) minus the bright rim-interior ellipse.
# cost: squared difference of predicted dark fraction (4x supersampled) and a soft dark map of the averaged frames,
# both eyes jointly; gripper pixels (dark, outside the dilated predicted cup) are excluded and the fit repeated.
# usage: python fit_cups.py [--frames head_now_1.png,...]   -> out/cups.json + out/fit_*.png
import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import minimize

HERE = Path(__file__).parent
CAL = HERE.parent / "calib_data" / "intrinsics"
OUT = HERE / "out"
OUT.mkdir(exist_ok=True)

R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838],
                   [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
T_EYE = {"head_left": np.array([0.04812857, 0.02963228, 0.43599143]),
         "head_right": np.array([0.04812857, -0.02996772, 0.43599143])}
OFC = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
# table normal (up) from this morning's head ChArUco measurement (board z-axis points into the table)
N_BOARD = -np.array([0.067, 0.0005, -0.998]); N_BOARD /= np.linalg.norm(N_BOARD)
RIM_D, BOT_D, H = 0.082, 0.069, 0.142
SS = 4

ap = argparse.ArgumentParser()
ap.add_argument("--frames", default="head_now_1.png,head_now_2.png,head_now_3.png")
ap.add_argument("--lo", type=float, default=95.0, help="gray level counted fully dark")
ap.add_argument("--hi", type=float, default=145.0, help="gray level counted fully bright")
ap.add_argument("--tag", default="")
ap.add_argument("--stereo", choices=["nominal", "calib"], default="calib",
                help="nominal: both eyes at their contract v5 poses (parallel, 59.6 mm apart); calib: left eye at its "
                     "contract pose, right eye from the stereoCalibrate R,T (61.37 mm, 0.57 deg relative yaw)")
ap.add_argument("--board-thick", type=float, default=0.003, help="table surface = board plane minus this (m)")
ap.add_argument("--seeds-from", default="", help="previous cups json: seed pixels = its plane-fit cups shifted by --seed-dx")
ap.add_argument("--seed-dx", type=float, default=0.0, help="expected move of both cups along torso x since --seeds-from (m)")
ap.add_argument("--seed-uv", default="", help="left-eye pixels of the two cup bodies: u1,v1,u2,v2")
ap.add_argument("--board-c", default="", help="table board centre in torso x,y,z (head measurement of the day)")
ap.add_argument("--board-n", default="", help="table up normal in torso x,y,z (= -board z)")
ap.add_argument("--stereo-scale", type=float, default=1.0,
                help="true / assumed board square of the stereoCalibrate (38.2/40: the 10-16 R,T used a 40 mm board)")
a = ap.parse_args()
if a.board_n:
    N_BOARD = np.array([float(v) for v in a.board_n.split(",")]); N_BOARD /= np.linalg.norm(N_BOARD)
STEREO = json.loads((OUT / "head_stereo_extrinsics.json").read_text())
R_LR, T_LR = np.array(STEREO["R_right_from_left"]), np.array(STEREO["T_right_from_left_m"]) * a.stereo_scale

imgs = [cv2.imdecode(np.fromfile(str(HERE / "images" / f), np.uint8), cv2.IMREAD_COLOR).astype(np.float32)
        for f in a.frames.split(",")]
img = np.mean(imgs, axis=0)
W = img.shape[1] // 2
EYES = {}
for eye, sl in (("head_left", slice(0, W)), ("head_right", slice(W, 2 * W))):
    doc = json.loads((CAL / f"camera_intrinsics_{eye}.json").read_text(encoding="utf-8"))
    gray = cv2.cvtColor(img[:, sl].astype(np.uint8), cv2.COLOR_BGR2GRAY).astype(np.float32)
    pd = np.clip((a.hi - gray) / (a.hi - a.lo), 0, 1)
    EYES[eye] = dict(K=np.array(doc["K"]), dist=np.array(doc["dist"]), gray=gray, pdark=pd,
                     bgr=img[:, sl].astype(np.uint8))


def basis(n):
    u = np.cross(n, [0, 1, 0]); u /= np.linalg.norm(u)
    return u, np.cross(n, u)


def cup_points(b, n=N_BOARD, s=1.0, k=96):
    u, v = basis(n)
    t = np.linspace(0, 2 * np.pi, k, endpoint=False)
    ring = np.cos(t)[:, None] * u + np.sin(t)[:, None] * v
    bot = b + ring * BOT_D / 2 * s
    top = b + n * H * s + ring * RIM_D / 2 * s
    gen = [b + n * H * s * f + ring * (BOT_D + (RIM_D - BOT_D) * f) / 2 * s for f in (0.25, 0.5, 0.75)]
    return top, np.vstack([bot, top] + gen)


def to_optical(eye, P):
    if eye == "head_right" and a.stereo == "calib":
        Pl = (OFC @ R_HEAD.T @ (P - T_EYE["head_left"]).T).T
        return (R_LR @ Pl.T).T + T_LR
    return (OFC @ R_HEAD.T @ (P - T_EYE[eye]).T).T


def project(eye, P):
    e = EYES[eye]
    Pc = to_optical(eye, P)
    uv, _ = cv2.projectPoints(Pc.reshape(-1, 1, 3), np.zeros(3), np.zeros(3), e["K"], e["dist"])
    return uv.reshape(-1, 2)


def render(eye, b, roi, s=1.0, n=N_BOARD):
    """predicted dark fraction and cup-hull fraction inside roi=(u0,v0,u1,v1)"""
    u0, v0, u1, v1 = roi
    top, allp = cup_points(b, n, s)
    hull = cv2.convexHull(((project(eye, allp) - [u0, v0]) * SS * 16).astype(np.int32))
    rim = cv2.convexHull(((project(eye, top) - [u0, v0]) * SS * 16).astype(np.int32))
    m_h = np.zeros(((v1 - v0) * SS, (u1 - u0) * SS), np.uint8)
    m_r = np.zeros_like(m_h)
    cv2.fillConvexPoly(m_h, hull, 255, cv2.LINE_8, 4)
    cv2.fillConvexPoly(m_r, rim, 255, cv2.LINE_8, 4)
    sh = (u1 - u0, v1 - v0)
    fh = cv2.resize(m_h.astype(np.float32) / 255, sh, interpolation=cv2.INTER_AREA)
    fr = cv2.resize(m_r.astype(np.float32) / 255, sh, interpolation=cv2.INTER_AREA)
    return np.clip(fh - fr, 0, 1), fh


def roi_for(eye, b, margin=22):
    uv = project(eye, cup_points(b)[1])
    u0, v0 = np.floor(uv.min(0)).astype(int) - margin
    u1, v1 = np.ceil(uv.max(0)).astype(int) + margin
    return max(u0, 0), max(v0, 0), min(u1, W), min(v1, 480)


def cost(params, ctx, n=None):
    """params = x, y, z_bottom[, scale]"""
    b = np.asarray(params[:3])
    sc = params[3] if len(params) > 3 else 1.0
    c = 0.0
    for eye in ctx["eyes"]:
        roi, excl = ctx["roi"][eye], ctx["excl"][eye]
        u0, v0, u1, v1 = roi
        pred, _ = render(eye, b, roi, sc, N_BOARD if n is None else n)
        obs = EYES[eye]["pdark"][v0:v1, u0:u1]
        c += float(np.sum(((pred - obs) ** 2)[~excl]))
    return c


def exclusion(eye, roi, b, s=1.0, near_px=7):
    """dark pixels not explained by the cup predicted at b (grippers, cables), dilated"""
    u0, v0, u1, v1 = roi
    _, fh = render(eye, b, roi, s)
    near = cv2.dilate((fh > 0.01).astype(np.uint8), np.ones((near_px, near_px), np.uint8)) > 0
    dark = EYES[eye]["pdark"][v0:v1, u0:u1] > 0.5
    other = dark & ~near
    n, lab = cv2.connectedComponents(dark.astype(np.uint8))
    # whole dark components that leave the dilated cup region are foreign (gripper), except inside the cup hull
    foreign = np.isin(lab, np.unique(lab[other])) & (lab > 0) & ~(fh > 0.5)
    return cv2.dilate((other | foreign).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0


def nm(f, p0, steps):
    simp = np.asarray(p0, float) + np.vstack([np.zeros(len(p0)), np.diag(steps)])
    return minimize(f, p0, method="Nelder-Mead",
                    options=dict(xatol=1e-6, fatol=1e-5, initial_simplex=simp, maxiter=4000))


def on_plane(xy, off):
    """point on the table plane n.p = off with the given torso x, y"""
    return np.array([xy[0], xy[1], (off - N_BOARD[0] * xy[0] - N_BOARD[1] * xy[1]) / N_BOARD[2]])


def fit(b0, roi, eyes=("head_left", "head_right"), free_scale=False, fixed_z=None, s0=1.0, iters=4, plane=None):
    """fixed ROI per eye; the exclusion mask is refreshed from the current estimate each iteration.
    plane=offset: bottom centre constrained to the table plane, free x, y and scale"""
    p = np.r_[np.asarray(b0, float), s0]
    if plane is not None:
        p[:3] = on_plane(p[:2], plane)
    for it in range(iters):
        ctx = {"eyes": eyes, "roi": {e: roi[e] for e in eyes},
               "excl": {e: exclusion(e, roi[e], p[:3], p[3], near_px=15 if it == 0 else 7) for e in eyes}}
        if plane is not None:
            r = nm(lambda q: cost(np.r_[on_plane(q[:2], plane), q[2]], ctx), np.r_[p[:2], p[3]], [0.005, 0.005, 0.02])
            p = np.r_[on_plane(r.x[:2], plane), r.x[2]]
        elif fixed_z is not None:
            r = nm(lambda q: cost([q[0], q[1], fixed_z, p[3]], ctx), p[:2], [0.005, 0.005])
            p = np.r_[r.x, fixed_z, p[3]]
        elif free_scale:
            r = nm(lambda q: cost(q, ctx), p, [0.005, 0.005, 0.005, 0.02])
            p = r.x
        else:
            r = nm(lambda q: cost(np.r_[q, p[3]], ctx), p[:3], [0.005, 0.005, 0.005])
            p = np.r_[r.x, p[3]]
    npx = sum(int((~ctx["excl"][e]).sum()) for e in eyes)
    return p, r.fun, npx, ctx


def coarse(eye_guess_uv):
    """grid over the table plane near the guessed left-eye pixel"""
    best = None
    for x in np.arange(0.30, 0.70, 0.01):
        for y in np.arange(-0.25, 0.25, 0.01):
            if a.board_c:   # point on the table plane of the day
                z = (PLANE_OFF - a.board_thick - N_BOARD[0] * x - N_BOARD[1] * y) / N_BOARD[2]
            else:
                z = -0.15 + 0.066 * (x - 0.30)
            b = np.array([x, y, z])
            uv = project("head_left", (b + N_BOARD * H / 2)[None])[0]
            d = np.linalg.norm(uv - eye_guess_uv)
            if best is None or d < best[0]:
                best = (d, b)
    return best[1]


def draw(b_list, name, scales=None):
    tiles = []
    for eye in ("head_left", "head_right"):
        vis = EYES[eye]["bgr"].copy()
        for b, s in zip(b_list, scales or [1.0] * len(b_list)):
            top, allp = cup_points(b, s=s)
            hull = cv2.convexHull(project(eye, allp).astype(np.float32)).astype(np.int32)
            cv2.polylines(vis, [hull], True, (0, 255, 0), 1, cv2.LINE_AA)
            cv2.polylines(vis, [project(eye, top).astype(np.int32)], True, (0, 0, 255), 1, cv2.LINE_AA)
        tiles.append(cv2.resize(vis[170:330, 200:470], None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC))
    cv2.imencode(".png", np.hstack(tiles))[1].tofile(str(OUT / name))


# seeds: left-eye pixel of each cup body middle, read off the zoomed crop (images/zoom_L.png) of head_now_1
SEEDS = [np.array([265.0, 238.0]), np.array([398.0, 234.0])]
BOARD_C = np.array([float(v) for v in a.board_c.split(",")]) if a.board_c else np.array([0.2993, 0.0656, -0.1581])
PLANE_OFF = float(N_BOARD @ BOARD_C)
if a.seed_uv:
    u = [float(v) for v in a.seed_uv.split(",")]
    SEEDS = [np.array(u[:2]), np.array(u[2:])]
elif a.seeds_from:
    prev = json.loads(Path(a.seeds_from).read_text())
    SEEDS = []
    for k in ("left_cup", "right_cup"):
        b = np.array(prev["cups"][k]["plane_fit"]["bottom_center"]) + [a.seed_dx, 0, 0]
        SEEDS.append(project("head_left", (b + N_BOARD * H / 2)[None])[0])
    print("seed pixels from", a.seeds_from, "shifted", a.seed_dx, ":", [s.round(1).tolist() for s in SEEDS])
starts = [coarse(c) for c in SEEDS]
starts = sorted(starts, key=lambda b: -b[1])      # +y (robot left) first
# default BOARD_C: 2026-10-21 10:59 head-left PnP of the table board (a print on thin card lying on the table)
res = {"frames": a.frames, "thresholds": [a.lo, a.hi], "stereo_model": a.stereo,
       "table_normal_torso": N_BOARD.round(4).tolist(), "board_plane_offset": round(PLANE_OFF, 4),
       "cup_dims_m": {"rim_d": RIM_D, "bottom_d": BOT_D, "height": H}, "cups": {}}
fits, plane_fits = [], []
for name, b0 in zip(("left_cup", "right_cup"), starts):
    roi = {e: roi_for(e, b0, margin=30) for e in EYES}
    b, c, npx, ctx = fit(b0, roi)
    # free scale from several starts (silhouettes alone have a scale/depth ambiguity; stereo breaks it)
    fs = min((fit(b[:3] + (s0 - 1) * (b[:3] - T_EYE["head_left"]), roi, free_scale=True, s0=s0) for s0 in (0.9, 1.0, 1.1)),
             key=lambda t: t[1])
    per_eye = {e: fit(b[:3], roi, eyes=(e,), fixed_z=b[2])[0][:3].round(4).tolist() for e in EYES}
    # primary: bottom on the table plane (board plane minus the board thickness), free scale, both eyes
    pl = min((fit(fs[0][:3], roi, plane=PLANE_OFF - a.board_thick, s0=s0) for s0 in (0.9, 1.0)), key=lambda t: t[1])
    pl_eye = {e: fit(pl[0][:3], roi, eyes=(e,), plane=PLANE_OFF - a.board_thick, s0=pl[0][3])[0].round(4).tolist() for e in EYES}
    rim = b[:3] + N_BOARD * H
    res["cups"][name] = {"bottom_center_torso": b[:3].round(4).tolist(), "rim_center_torso": rim.round(4).tolist(),
                         "cost": round(c, 2), "pixels_used": npx, "rms_dark_residual": round(float(np.sqrt(c / npx)), 3),
                         "bottom_height_above_board_plane": round(float(N_BOARD @ b[:3] - PLANE_OFF), 4),
                         "free_scale_fit": {"bottom_center": fs[0][:3].round(4).tolist(), "scale": round(float(fs[0][3]), 4),
                                            "cost": round(fs[1], 2),
                                            "bottom_height_above_board_plane": round(float(N_BOARD @ fs[0][:3] - PLANE_OFF), 4)},
                         "single_eye_fixed_z": per_eye,
                         "plane_fit": {"bottom_center": pl[0][:3].round(4).tolist(), "scale": round(float(pl[0][3]), 4),
                                       "rim_center": (pl[0][:3] + N_BOARD * H * pl[0][3]).round(4).tolist(),
                                       "cost": round(pl[1], 2), "per_eye": pl_eye}}
    print(f"   plane-constrained (board thickness {a.board_thick * 1000:.0f} mm): bottom {pl[0][:3].round(4)} s={pl[0][3]:.3f} "
          f"cost {pl[1]:.1f} | per eye L {pl_eye['head_left']} R {pl_eye['head_right']}")
    fits.append(b[:3])
    plane_fits.append(pl[0])
    print(f"{name}: bottom {b[:3].round(4)} rim {rim.round(4)} | rms {np.sqrt(c / npx):.3f} | above board plane "
          f"{1000 * (N_BOARD @ b[:3] - PLANE_OFF):+.1f} mm | free-scale s={fs[0][3]:.3f} cost {fs[1]:.1f} vs {c:.1f}, "
          f"above plane {1000 * (N_BOARD @ fs[0][:3] - PLANE_OFF):+.1f} mm | L-eye xy {per_eye['head_left'][:2]} "
          f"R-eye xy {per_eye['head_right'][:2]}")
d = plane_fits[0][:3] - plane_fits[1][:3]
res["left_minus_right_plane_fit"] = d.round(4).tolist()
print("left - right (plane fit):", d.round(4))
draw(fits, f"fit_overlay_fixedsize{a.tag}.png")
draw([p[:3] for p in plane_fits], f"fit_overlay{a.tag}.png", scales=[p[3] for p in plane_fits])
json.dump(res, open(OUT / f"cups{a.tag}.json", "w"), indent=1)
