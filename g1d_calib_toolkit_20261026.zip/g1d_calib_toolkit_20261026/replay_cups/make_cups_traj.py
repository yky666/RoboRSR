# make_cups_traj.py -- measured joint trajectory of the real cup replay at the head camera frame times (every
# --stride-th frame, window around the replay), plus the gripper grasp / release events detected from the measured
# Dex1 positions (open > OPEN, then closing below CLOSE = grasp; reopening above OPEN = release), for the sim render.
# usage: make_cups_traj.py <logger_run_dir> <out.json> [--stride 2] [--before 3] [--after 290]
import argparse
import glob
import json
import os

import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("run")
ap.add_argument("out")
ap.add_argument("--stride", type=int, default=2)
ap.add_argument("--before", type=float, default=3.0)
ap.add_argument("--after", type=float, default=290.0)
a = ap.parse_args()
OPEN, CLOSE = 2.5, 2.0
meta = json.load(open(os.path.join(a.run, "meta.json")))
ids = meta["motor_ids"]
nm = len(ids)
S = np.vstack([np.load(f) for f in sorted(glob.glob(os.path.join(a.run, "state_*.npy")))])
S = S[np.argsort(S[:, 0])]
tw, q = S[:, 0], S[:, 4:4 + nm]
t_go = float(open(os.path.join(a.run, "go_time.txt")).read().split()[0])
ARM = ["left_shoulder_pitch_joint", "left_shoulder_roll_joint", "left_shoulder_yaw_joint", "left_elbow_joint",
       "left_wrist_roll_joint", "left_wrist_pitch_joint", "left_wrist_yaw_joint",
       "right_shoulder_pitch_joint", "right_shoulder_roll_joint", "right_shoulder_yaw_joint", "right_elbow_joint",
       "right_wrist_roll_joint", "right_wrist_pitch_joint", "right_wrist_yaw_joint"]
heads = sorted(glob.glob(os.path.join(a.run, "head", "*.jpg")))
ht = np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in heads])
sel = [i for i in range(len(heads)) if t_go - a.before <= ht[i] <= t_go + a.after and tw[0] <= ht[i] <= tw[-1]][::a.stride]
frames = []
for i in sel:
    t = ht[i]
    row = {n: float(np.interp(t, tw, q[:, ids.index(15 + k)])) for k, n in enumerate(ARM)}
    row["torso_Joint"] = float(np.interp(t, tw, q[:, ids.index(12)]))
    grip = {}
    for side, m in (("left", 31), ("right", 33)):
        g = float(np.interp(t, tw, q[:, ids.index(m)]))
        grip[side] = g
        row[f"{side}_dex1_finger_joint_1"] = row[f"{side}_dex1_finger_joint_2"] = 0.024 - 0.044 * min(max(g, 0.0), 5.4) / 5.4
    frames.append({"t": float(t), "t_rel": float(t - t_go), "head": os.path.basename(heads[i]), "q": row, "grip": grip})
# replay.py closes both grippers on its way to the ready pose (first closing), the episode opens them for the approach
# and closes them on the cup (second closing = grasp); the next opening is the release
events = {}
for side in ("left", "right"):
    g = np.array([fr["grip"][side] for fr in frames])
    state, closings, openings = ("open" if g[0] > OPEN else "closed"), [], []
    for k, v in enumerate(g):
        if state == "open" and v < CLOSE:
            state = "closed"; closings.append(k)
        elif state == "closed" and v > OPEN:
            state = "open"; openings.append(k)
    grasp = closings[1] if len(closings) > 1 else None
    release = next((k for k in openings if grasp is not None and k > grasp), None)
    events[side] = {"grasp": grasp, "release": release, "closings": closings, "openings": openings}
    print(f"{side}: gripper range {g.min():.2f}..{g.max():.2f}, grasp at frame {grasp} "
          f"(t {frames[grasp]['t_rel'] if grasp is not None else None}), release at frame {release} "
          f"(t {frames[release]['t_rel'] if release is not None else None})")
json.dump({"run": os.path.basename(os.path.normpath(a.run)), "fps": 10.0 / a.stride, "t_go": t_go, "events": events,
           "frames": frames}, open(a.out, "w"), indent=0)
print(f"{len(frames)} frames, t_rel {frames[0]['t_rel']:.1f}..{frames[-1]['t_rel']:.1f} s")
