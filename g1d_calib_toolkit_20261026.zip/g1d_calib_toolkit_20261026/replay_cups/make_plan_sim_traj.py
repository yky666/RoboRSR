# make_plan_sim_traj.py -- drive the physics sim with the PLANNED episode (the sim-IK trajectory that the real robot
# executed), time-aligned to the real recording: replay.py's progress lines ("replay k/N" with wall-clock stamps) give
# episode frame -> real time; every real head frame inside the episode gets the planned arm joints and gripper commands
# interpolated at its episode frame. Writes <out>.npz (q, grip, fps) for sim_cups_views.py and <out>.json (head frames).
# usage: make_plan_sim_traj.py <logger_run_dir> <traj2.npz> <out_prefix>
import glob
import json
import os
import re
import sys

import numpy as np

RUN, PLAN, OUT = sys.argv[1:4]
t_go = float(open(os.path.join(RUN, "go_time.txt")).read().split()[0])
txt = re.sub(r"\x1b\[[0-9;]*m", "", open(os.path.join(RUN, "replay_terminal.log"), encoding="utf-8", errors="ignore").read())


def hms(s):
    h, m, sec = s.split(":")
    return int(h) * 3600 + int(m) * 60 + float(sec)


go_line = re.search(r"(\d\d:\d\d:\d\d\.\d+)\s+INFO\s+\[replay\] press Q", txt)
off = t_go - hms(go_line.group(1))                      # wall clock of the log stamps (same machine, same second)
pts = [(int(m.group(2)), hms(m.group(1)) + off) for m in re.finditer(r"(\d\d:\d\d:\d\d\.\d+)\s+INFO\s+\[replay\] replay (\d+)/(\d+)", txt)]
k, t = np.array(pts, float).T
b, a = np.polyfit(k, t, 1)
res = t - (a + b * k)
print(f"{len(pts)} progress stamps; {1 / b:.3f} episode frames per second, fit residual max {np.abs(res).max() * 1000:.0f} ms; "
      f"episode frame 0 at t_go + {a - t_go:.2f} s")
P = np.load(PLAN)
Q, G = P["q"], P["grip"]
n = len(Q)
heads = sorted(glob.glob(os.path.join(RUN, "head", "*.jpg")))
ht = np.array([float(os.path.basename(f).split("_")[1][:-4]) for f in heads])
fe = (ht - a) / b                                      # episode frame of every head frame
sel = np.nonzero((fe >= 0) & (fe <= n - 1))[0]
idx = np.arange(n)
q = np.array([[np.interp(fe[i], idx, Q[:, j]) for j in range(Q.shape[1])] for i in sel])
g = np.array([[np.interp(fe[i], idx, G[:, j]) for j in range(G.shape[1])] for i in sel])
np.savez(OUT + ".npz", q=q, grip=g, fps=10.0)
json.dump({"run": os.path.basename(os.path.normpath(RUN)), "t_go": t_go, "episode_frames_per_s": 1 / b,
           "frames": [{"head": os.path.basename(heads[i]), "t": float(ht[i]), "t_rel": float(ht[i] - t_go),
                       "episode_frame": float(fe[i])} for i in sel]}, open(OUT + ".json", "w"), indent=0)
print(f"{len(sel)} head frames inside the episode ({len(sel) / 10:.0f} s), episode frames {fe[sel[0]]:.1f}..{fe[sel[-1]]:.1f}")
