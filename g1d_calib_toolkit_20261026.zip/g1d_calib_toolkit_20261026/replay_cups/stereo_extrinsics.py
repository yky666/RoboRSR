# stereo_extrinsics.py -- recompute the head stereo R,T (fixed intrinsics from the JSONs; nothing is rewritten)
import json
import sys
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent))
from calibrate_intrinsics import DATA, load_views  # noqa: E402

views = load_views("head", 0.040)
K = {}
for eye in ("head_left", "head_right"):
    d = json.loads((DATA / f"camera_intrinsics_{eye}.json").read_text(encoding="utf-8"))
    K[eye] = (np.array(d["K"]), np.array(d["dist"]))
vl, vr = views["L"], views["R"]
confl, confr = dict(zip(vl["idx"], vl["conf"])), dict(zip(vr["idx"], vr["conf"]))
common = sorted(i for i in set(vl["idx"]) & set(vr["idx"]) if confl.get(i) and confr.get(i))
lmap, rmap = dict(zip(vl["idx"], vl["pts"])), dict(zip(vr["idx"], vr["pts"]))
obj = [vl["objp"]] * len(common)
rms, _, _, _, _, R, T, E, F = cv2.stereoCalibrate(
    obj, [lmap[i] for i in common], [rmap[i] for i in common], K["head_left"][0], K["head_left"][1],
    K["head_right"][0], K["head_right"][1], vl["size"], flags=cv2.CALIB_FIX_INTRINSIC)
rv = cv2.Rodrigues(R)[0].ravel()
# leave-group-out spread of R,T (5 folds) as an uncertainty estimate
rng = np.random.default_rng(0)
idx = np.array(common); rng.shuffle(idx)
folds = []
for k in range(5):
    keep = [i for j, i in enumerate(idx) if j % 5 != k]
    r2 = cv2.stereoCalibrate([vl["objp"]] * len(keep), [lmap[i] for i in keep], [rmap[i] for i in keep],
                             K["head_left"][0], K["head_left"][1], K["head_right"][0], K["head_right"][1],
                             vl["size"], flags=cv2.CALIB_FIX_INTRINSIC)
    folds.append(np.r_[cv2.Rodrigues(r2[5])[0].ravel(), r2[6].ravel()])
folds = np.array(folds)
print(f"pairs {len(common)} stereoRMS {rms:.3f}px |T| {np.linalg.norm(T) * 1000:.2f} mm T(mm) {(T.ravel() * 1000).round(2)}")
print(f"rotvec (deg, left-optical axes x right / y down / z fwd) {np.degrees(rv).round(3)} |rot| {np.degrees(np.linalg.norm(rv)):.3f}")
print(f"5-fold std: rotvec deg {np.degrees(folds[:, :3].std(0)).round(3)} T mm {(folds[:, 3:].std(0) * 1000).round(2)}")
out = {"pairs": len(common), "stereo_rms_px": rms, "R_right_from_left": R.tolist(), "T_right_from_left_m": T.ravel().tolist(),
       "rotvec_deg": np.degrees(rv).tolist(), "fold_std_rotvec_deg": np.degrees(folds[:, :3].std(0)).tolist(),
       "fold_std_T_mm": (folds[:, 3:].std(0) * 1000).tolist(), "convention": "X_right = R X_left + T (OpenCV optical)"}
(HERE / "out").mkdir(exist_ok=True)
json.dump(out, open(HERE / "out" / "head_stereo_extrinsics.json", "w"), indent=1)
