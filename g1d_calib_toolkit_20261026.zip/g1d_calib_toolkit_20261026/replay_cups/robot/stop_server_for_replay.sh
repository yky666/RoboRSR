#!/bin/bash
# Hand the arms from our calib_arm_server to replay.py WITHOUT a gap:
#   run this only while replay.py is waiting at its "Replay? [y/N]" prompt (it is already publishing its hold).
#   1. verify (read-only) that a second rt/lowcmd writer with replay's signature (Dex1 gripper kp = 5) is active
#   2. kill -9 our server (SIGINT/SIGTERM would first move back to its startup pose -> never use them here)
#   3. verify our server is gone and the replay writer is still publishing
PY=/home/unitree/miniconda3/envs/tv/bin/python
D=/home/unitree/calib_sessions/replay_cups
check() {
  $PY - <<'EOF'
import time
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowCmd_
ChannelFactoryInitialize(0, "eth0")
n = {"replay": 0, "ours": 0}
def cb(m):
    kp = m.motor_cmd[33].kp
    n["replay" if abs(kp - 5.0) < 1e-3 else "ours"] += 1
s = ChannelSubscriber("rt/lowcmd", LowCmd_); s.Init(cb, 50)
time.sleep(1.0)
print(f"lowcmd in 1 s: replay-writer {n['replay']}, other {n['ours']}")
raise SystemExit(0 if n["replay"] > 50 else 1)
EOF
}
SRV=$(pgrep -f '[c]alib_arm_server.py')
[ -z "$SRV" ] && { echo "our server is not running (nothing to stop)"; exit 1; }
pgrep -af '[t]eleop.replay' > /dev/null || { echo "replay.py is not running -> NOT stopping our server"; exit 1; }
check || { echo "replay.py is not publishing yet -> NOT stopping our server"; exit 1; }
echo "killing our server pid $SRV (kill -9: no motion, publishing stops)"
kill -9 $SRV
sleep 0.5
pgrep -f '[c]alib_arm_server.py' && { echo "!!! server still alive"; exit 2; }
check && echo "OK: replay.py is the only writer. Now answer 'y' in the replay terminal." || echo "!!! replay writer not seen - check immediately (e-stop)"
