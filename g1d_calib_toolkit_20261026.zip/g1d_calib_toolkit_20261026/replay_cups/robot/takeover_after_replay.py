# takeover_after_replay.py -- start our calib_arm_server during replay.py's final hold so the arms never lose command
# when replay.py exits (its publisher threads are daemon threads; with no writer the arms fall).
# Read-only until the trigger: subscribes to rt/lowstate and waits for the END state of our episode:
#   all 14 arm joints within TOL of the ready pose, right Dex1 open (> 2.5), left Dex1 closed (< 0.8),
#   joint speeds small, continuously for STABLE seconds, and at least MIN_ELAPSED after start.
# Then launches calib_arm_server.py --init-pose ready_pose_arm_q.json (holds the ready pose; a few seconds of
# overlap with replay.py commanding the same pose), and waits until the server reports "server ready".
# usage (start right after answering 'y' in the replay terminal):
#   python -u takeover_after_replay.py --speed 0.5
import argparse
import json
import os
import subprocess
import time

import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_

D = "/home/unitree/calib_sessions/replay_cups"
PY = "/home/unitree/miniconda3/envs/tv/bin/python"
SERVER_DIR = "/home/unitree/g1d_infra_calib/scripts"
READY = np.array(json.load(open(f"{D}/ready_pose_arm_q.json"))["arm_q"])
ap = argparse.ArgumentParser()
ap.add_argument("--speed", type=float, required=True, help="the --speed given to replay.py")
ap.add_argument("--episode", required=True, help="episode directory given to replay.py")
ap.add_argument("--tol", type=float, default=0.08)
ap.add_argument("--stable", type=float, default=2.0)
a = ap.parse_args()
_ep = json.load(open(os.path.join(os.path.expanduser(a.episode), "data.json")))
EPISODE_S = len(_ep["data"]) / float(_ep["info"]["image"]["fps"])   # at speed 1; the last 20 s hold the ready pose
del _ep
MIN_ELAPSED = 6.5 + (EPISODE_S - 20.0) / a.speed - 5.0
TIMEOUT = 6.5 + EPISODE_S / a.speed + 30.0

latest = {}
ChannelFactoryInitialize(0, "eth0")
sub = ChannelSubscriber("rt/lowstate", LowState_)
sub.Init(lambda m: latest.__setitem__("m", m), 10)
t0 = time.time()
stable_since = None
print(f"waiting for the final hold (earliest {MIN_ELAPSED:.0f}s, timeout {TIMEOUT:.0f}s) ...", flush=True)
while True:
    time.sleep(0.05)
    el = time.time() - t0
    if el > TIMEOUT:
        print("TIMEOUT: final hold not detected -> NOT starting the server. Operator: take over manually / e-stop.", flush=True)
        raise SystemExit(2)
    m = latest.get("m")
    if m is None:
        continue
    q = np.array([m.motor_state[i].q for i in range(15, 29)])
    dq = np.array([m.motor_state[i].dq for i in range(15, 29)])
    gl, gr = m.motor_state[31].q, m.motor_state[33].q
    ok = (el > MIN_ELAPSED and np.abs(q - READY).max() < a.tol and gr > 2.5 and gl < 0.8 and np.abs(dq).max() < 0.15)
    if ok:
        stable_since = stable_since or time.time()
        if time.time() - stable_since > a.stable:
            break
    else:
        stable_since = None
print(f"final hold detected at {el:.1f}s (max |q-ready| {np.abs(q - READY).max():.3f}); starting calib_arm_server", flush=True)
if subprocess.run(["pgrep", "-f", "[c]alib_arm_server.py"], capture_output=True).stdout.strip():
    print("a calib_arm_server is already running -> nothing to do", flush=True)
    raise SystemExit(0)
if os.path.exists("/tmp/g1d_calib/status.json"):
    os.remove("/tmp/g1d_calib/status.json")
log = open("/tmp/g1d_calib_server.log", "w")
p = subprocess.Popen([PY, "-u", "calib_arm_server.py", "--yes", "--vmax", "0.1", "--init-pose", f"{D}/ready_pose_arm_q.json"],
                     cwd=SERVER_DIR, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
for _ in range(60):
    time.sleep(0.25)
    txt = open("/tmp/g1d_calib_server.log").read()
    if "server ready" in txt or p.poll() is not None:
        break
print(open("/tmp/g1d_calib_server.log").read(), flush=True)
print("OK: our server is holding the ready pose" if "server ready" in txt and p.poll() is None
      else "!!! SERVER DID NOT START - arms will drop when replay.py exits: operator e-stop / damping", flush=True)
