# passive_logger.py -- READ-ONLY recorder for the replay run. Subscribes (never publishes) to
#   rt/lowstate : measured q / dq / tau_est of waist (12), arms (15-28), Dex1 grippers (31 left, 33 right)
#   rt/lowcmd   : what the active writer (replay.py) actually sends: q target, kp, kd, tau feed-forward, mode
# and optionally grabs head stereo frames (teleimager ZMQ, port 55555) as raw JPEG bytes.
# Every message is timestamped on arrival (time.time + time.monotonic). Data are flushed to chunk files every 2 s,
# so a crash or kill loses at most 2 s. Stop: Ctrl+C, SIGTERM, a STOP file in the output dir, or --seconds.
# usage: python -u passive_logger.py --out ~/calib_sessions/replay_cups/run_YYYYmmdd_HHMM [--head-hz 2] [--seconds 600]
import argparse
import json
import os
import signal
import threading
import time

import numpy as np
from unitree_sdk2py.core.channel import ChannelFactoryInitialize, ChannelSubscriber
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowCmd_ as hg_LowCmd
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_ as hg_LowState

IDS = [12] + list(range(15, 29)) + [31, 33]          # 17 motors
ap = argparse.ArgumentParser()
ap.add_argument("--out", required=True)
ap.add_argument("--seconds", type=float, default=900.0)
ap.add_argument("--head-hz", type=float, default=0.0, help="head frames per second (0 = off)")
ap.add_argument("--iface", default="eth0")
a = ap.parse_args()
OUT = os.path.expanduser(a.out)
os.makedirs(OUT, exist_ok=True)
json.dump({"motor_ids": IDS, "started": time.time(), "args": vars(a),
           "state_cols": "t_wall, t_mono, tick, mode_machine, q[17], dq[17], tau_est[17]",
           "cmd_cols": "t_wall, t_mono, mode_machine, q[17], kp[17], kd[17], tau[17], mode[17]"},
          open(os.path.join(OUT, "meta.json"), "w"), indent=1)

lock = threading.Lock()
st_rows, cmd_rows = [], []
n_st = n_cmd = 0


def on_state(m):
    global n_st
    tw, tm = time.time(), time.monotonic()
    ms = m.motor_state
    row = [tw, tm, float(getattr(m, "tick", 0)), float(m.mode_machine)]
    row += [ms[i].q for i in IDS] + [ms[i].dq for i in IDS] + [ms[i].tau_est for i in IDS]
    with lock:
        st_rows.append(row)
        n_st += 1


def on_cmd(m):
    global n_cmd
    tw, tm = time.time(), time.monotonic()
    mc = m.motor_cmd
    row = [tw, tm, float(m.mode_machine)]
    row += [mc[i].q for i in IDS] + [mc[i].kp for i in IDS] + [mc[i].kd for i in IDS] + [mc[i].tau for i in IDS]
    row += [float(mc[i].mode) for i in IDS]
    with lock:
        cmd_rows.append(row)
        n_cmd += 1


ChannelFactoryInitialize(0, a.iface)
s1 = ChannelSubscriber("rt/lowstate", hg_LowState); s1.Init(on_state, 50)
s2 = ChannelSubscriber("rt/lowcmd", hg_LowCmd); s2.Init(on_cmd, 50)

stop = threading.Event()
signal.signal(signal.SIGTERM, lambda *_: stop.set())
signal.signal(signal.SIGINT, lambda *_: stop.set())


def head_loop():
    import zmq
    ctx = zmq.Context.instance()
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 2000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect("tcp://127.0.0.1:55555")
    d = os.path.join(OUT, "head"); os.makedirs(d, exist_ok=True)
    k = 0
    while not stop.is_set():
        t0 = time.time()
        try:
            buf = s.recv()
        except Exception:
            continue
        with open(os.path.join(d, f"{k:05d}_{time.time():.3f}.jpg"), "wb") as f:
            f.write(buf)
        k += 1
        time.sleep(max(0.0, 1.0 / a.head_hz - (time.time() - t0)))
    s.close(0)


if a.head_hz > 0:
    threading.Thread(target=head_loop, daemon=True).start()

chunk = 0
t_start = time.time()
last_print = 0.0


def flush():
    global chunk
    with lock:
        st, cm = list(st_rows), list(cmd_rows)
        st_rows.clear(); cmd_rows.clear()
    if st:
        np.save(os.path.join(OUT, f"state_{chunk:05d}.npy"), np.asarray(st, np.float64))
    if cm:
        np.save(os.path.join(OUT, f"cmd_{chunk:05d}.npy"), np.asarray(cm, np.float64))
    chunk += 1


print(f"logging to {OUT} (read-only subscribers on rt/lowstate and rt/lowcmd)", flush=True)
while not stop.is_set() and time.time() - t_start < a.seconds and not os.path.exists(os.path.join(OUT, "STOP")):
    time.sleep(2.0)
    flush()
    if time.time() - last_print > 10:
        el = time.time() - t_start
        print(f"[{el:6.1f}s] lowstate {n_st} ({n_st / el:.0f} Hz) lowcmd {n_cmd} ({n_cmd / el:.0f} Hz)", flush=True)
        last_print = time.time()
flush()
print(f"done: {n_st} lowstate, {n_cmd} lowcmd messages in {time.time() - t_start:.1f}s", flush=True)
os._exit(0)
