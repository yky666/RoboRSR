#!/bin/bash
# run the colleague's replay (unmodified) on one of our episodes
# usage: run_cups_replay.sh <episode data.json> [teleop.replay options, e.g. --dry-run | --speed 0.5 --no-go-home]
cd ~/g1d_infra && PYTHONDONTWRITEBYTECODE=1 PATH=/home/unitree/miniconda3/envs/tv/bin:$PATH ./scripts/run_replay.sh "$@"
