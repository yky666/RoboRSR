#!/bin/bash
# orchestrate the real cup replay; replay.py runs unmodified inside tmux session "cups" (it needs a TTY)
# v2 (2026-10-23): logger records head + both wrists (passive_logger_cams.py, 10 Hz each); takeover_after_replay_v2.py
#                  kills replay.py as soon as our server holds, so the two writers barely overlap
#   real_run.sh start <episode_dir>   logger + replay up to its "Replay? [y/N]" prompt (already holding)
#   real_run.sh go <episode_dir>      hand over (kill -9 our server once replay publishes), start takeover, answer y
#   real_run.sh status                replay pane + logger/takeover logs
#   real_run.sh abort                 press q in the replay terminal (replay holds 1 s then stops publishing)
D=/home/unitree/calib_sessions/replay_cups
PY=/home/unitree/miniconda3/envs/tv/bin/python
SPEED=0.5
case "$1" in
start)
    EP=$2
    [ -f "$EP/data.json" ] || { echo "no $EP/data.json"; exit 1; }
    tmux has-session -t cups 2>/dev/null && { echo "tmux session cups already exists"; exit 1; }
    OUT=$D/run_$(date +%Y%m%d_%H%M%S)
    mkdir -p $OUT
    echo $OUT > $D/current_run.txt
    setsid nohup $PY -u /home/unitree/calib_sessions/passive_logger_cams.py --out $OUT --head-hz 10 --seconds 900 > $OUT.log 2>&1 < /dev/null &
    sleep 3
    cat $OUT.log
    tmux new-session -d -s cups -x 200 -y 50
    tmux pipe-pane -o -t cups "cat >> $OUT/replay_terminal.log"
    tmux send-keys -t cups "$D/run_cups_replay.sh $EP/data.json --speed $SPEED --no-go-home" Enter
    for i in $(seq 1 60); do
        sleep 1
        tmux capture-pane -p -t cups | grep -q "Replay? \[y/N\]" && break
    done
    tmux capture-pane -p -t cups | grep -v '^$' | tail -25
    tmux capture-pane -p -t cups | grep -q "Replay? \[y/N\]" && echo "== AT PROMPT (replay is holding) ==" || echo "!! prompt not reached"
    ;;
go)
    EP=$2
    OUT=$(cat $D/current_run.txt)
    tmux capture-pane -p -t cups | grep -q "Replay? \[y/N\]" || { echo "replay not at its prompt -> nothing done"; exit 1; }
    bash $D/stop_server_for_replay.sh || { echo "handover refused -> nothing else done (our server still holding)"; exit 1; }
    setsid nohup $PY -u $D/takeover_after_replay_v2.py --speed $SPEED --episode $EP > $OUT/takeover.log 2>&1 < /dev/null &
    sleep 1
    tmux send-keys -t cups "y" Enter
    date +%s.%N > $OUT/go_time.txt
    sleep 4
    tmux capture-pane -p -t cups | grep -v '^$' | tail -8
    cat $OUT/takeover.log
    ;;
status)
    OUT=$(cat $D/current_run.txt)
    tmux capture-pane -p -t cups 2>/dev/null | grep -v '^$' | tail -12
    echo "--- logger"; tail -n 2 $OUT.log
    echo "--- takeover"; tail -n 6 $OUT/takeover.log 2>/dev/null
    echo "--- frames: head $(ls $OUT/head 2>/dev/null | wc -l), left_wrist $(ls $OUT/left_wrist 2>/dev/null | wc -l), right_wrist $(ls $OUT/right_wrist 2>/dev/null | wc -l)"
    ;;
abort)
    tmux send-keys -t cups "q"
    ;;
*)
    echo "usage: real_run.sh start|go <episode_dir> | status | abort"; exit 1 ;;
esac
