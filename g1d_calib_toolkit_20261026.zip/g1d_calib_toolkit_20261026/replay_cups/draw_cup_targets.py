# draw_cup_targets.py -- head-left image with the current cup fits (red) and the target cup spots (green circles on
# the measured table) so the operator can place the cups. usage: python draw_cup_targets.py <head_stereo.png> <out.png>
import json
import sys

import cv2
import numpy as np

sys.argv += [] if len(sys.argv) > 2 else ["out.png"]
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838], [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
T_L = np.array([0.04812857, 0.02963228, 0.43599143])
doc = json.load(open("../calib_data/intrinsics/camera_intrinsics_head_left.json", encoding="utf-8"))
K, D = np.array(doc["K"]), np.array(doc["dist"])
cj = json.load(open("out/cups.json", encoding="utf-8"))
N = np.array(cj["table_normal_torso"])
off = cj["board_plane_offset"]


def on_table(x, y):
    return np.array([x, y, (off - N[0] * x - N[1] * y) / N[2]])


def proj(P):
    pc = (np.atleast_2d(P) - T_L) @ R_HEAD @ OPT.T
    return cv2.projectPoints(pc.reshape(-1, 1, 3), np.zeros(3), np.zeros(3), K, D)[0].reshape(-1, 2)


img = cv2.imread(sys.argv[1])
img = img[:, : img.shape[1] // 2].copy()
u = np.cross(N, [0, 1, 0]); u /= np.linalg.norm(u); v = np.cross(N, u)
ang = np.linspace(0, 2 * np.pi, 48)
for name, col in (("left_cup", (0, 0, 255)), ("right_cup", (0, 0, 255))):
    b = np.array(cj["cups"][name]["plane_fit"]["bottom_center"])
    ring = b + 0.035 * (np.cos(ang)[:, None] * u + np.sin(ang)[:, None] * v)
    cv2.polylines(img, [proj(ring).astype(np.int32)], True, col, 1, cv2.LINE_AA)
for x, y in ((0.39, 0.15), (0.39, -0.15)):
    b = on_table(x, y)
    ring = b + 0.035 * (np.cos(ang)[:, None] * u + np.sin(ang)[:, None] * v)
    cv2.polylines(img, [proj(ring).astype(np.int32)], True, (0, 200, 0), 2, cv2.LINE_AA)
    cv2.circle(img, tuple(proj(b)[0].astype(int)), 3, (0, 200, 0), -1)
cv2.putText(img, "red: cup bottoms now   green: target spots", (10, 24), 0, 0.6, (0, 0, 0), 2)
cv2.imwrite(sys.argv[2], img)
print("wrote", sys.argv[2])
