# reach_diag.py -- fast, targeted reachability of rim-pinch grasps / placements on the calibrated model
# (a handful of IK solves per target instead of a brute-force sweep).
# Grasp frame: pinch azimuth phi (wall point = rim centre + R*u_r), approach a tilted theta below horizontal, pointing
# from the wall toward azimuth psi (0 = toward the cup axis); pads as parallel to the wall as a allows
# (o = u_r projected orthogonal to a). Fingertip D_TIP below the rim plane on the line through the rim/wall point.
#   python reach_diag.py diag      -> which step of the single-arm plan fails, per-cup grasp reach (current cups)
#   python reach_diag.py map       -> reachable cup-centre region per arm (table grid), for choosing M / new cup spots
import json
import sys
import time

import numpy as np

from geom import READY, Cup, ee, ik, tip_point, torso_margin, limit_margin

cj = json.loads(open("out/cups.json").read())
N = np.array(cj["table_normal_torso"])
Z_TOUCH = 0.011
B_L = np.array(cj["cups"]["left_cup"]["plane_fit"]["bottom_center"]) + [0, 0, Z_TOUCH]
B_R = np.array(cj["cups"]["right_cup"]["plane_fit"]["bottom_center"]) + [0, 0, Z_TOUCH]
TABLE_OFF = float(N @ (B_L + B_R) / 2)
D_TIP, R_PINCH, TIP_X = 0.030, 0.040, 0.150
SEED_FWD = {"right": np.r_[READY[:7], [-0.6, -0.15, 0.1, 0.6, 0.0, 0.3, 0.0]],
            "left": np.r_[[-0.6, 0.15, -0.1, 0.6, 0.0, 0.3, 0.0], READY[7:]]}


def on_table(xy):
    return np.array([xy[0], xy[1], (TABLE_OFF - N[0] * xy[0] - N[1] * xy[1]) / N[2]])


def frame(cup, phi, theta, psi=0.0, flip=1, lift=0.0):
    u_r = np.array([np.cos(phi), np.sin(phi), 0.0]); u_r -= N * (u_r @ N); u_r /= np.linalg.norm(u_r)
    hdir = -u_r * np.cos(psi) + np.cross(N, u_r) * np.sin(psi)
    a = hdir * np.cos(theta) - N * np.sin(theta); a /= np.linalg.norm(a)
    o = u_r - a * (a @ u_r); o /= np.linalg.norm(o)
    y = o * flip; z = np.cross(a, y)
    wall = cup.rim + u_r * R_PINCH
    tip = wall + a * D_TIP / max(-(a @ N), 1e-3) + N * lift
    T = np.eye(4); T[:3, :3] = np.c_[a, y, z]; T[:3, 3] = tip - T[:3, :3] @ np.array([TIP_X, 0, 0])
    return T, float(np.degrees(np.arccos(abs(o @ u_r))))


def solve(T, side, seeds=None):
    best = None
    for s in (seeds or [READY, SEED_FWD[side]]):
        q, ep, er = ik(T, s, side, iters=120)
        tm = torso_margin(q)[0 if side == "left" else 1]
        err = ep * 1000 + np.degrees(er)
        if best is None or (err, -tm) < (best[1], -best[2]):
            best = (q, err, tm)
    return best


def best_grasp(cup, side, thetas=(50, 65, 80), phis=None, psis=(0.0,)):
    """near-wall family (phi toward the robot +- 45 deg) with steep approaches; returns best feasible-or-closest"""
    sgn = 1 if side == "left" else -1
    phis = phis or [np.pi, np.pi + sgn * np.radians(-35), np.pi + sgn * np.radians(35)]
    out = None
    for phi in phis:
        for th in thetas:
            for psi in psis:
                for flip in (1, -1):
                    T, mis = frame(cup, phi, np.radians(th), psi, flip)
                    q, err, tm = solve(T, side)
                    ok = err < 1.0 and tm >= 0
                    key = (not ok, err if not ok else -th)
                    if out is None or key < out["key"]:
                        out = dict(key=key, ok=ok, err=round(err, 2), torso=round(tm, 3), phi_deg=round(np.degrees(phi) % 360, 1),
                                   theta_deg=th, flip=flip, pad_misalign_deg=round(mis, 1), q=q,
                                   lim=round(float(limit_margin(q)[(0 if side == 'left' else 7):][:7].min()), 3))
    out.pop("key")
    return out


if __name__ == "__main__":
    t0 = time.time()
    mode = sys.argv[1]
    if mode == "diag":
        cupL, cupR = Cup(B_L, N), Cup(B_R, N)
        print("current cups (arm frame): rim L", cupL.rim.round(3), "rim R", cupR.rim.round(3))
        for side, cup in (("right", cupR), ("left", cupL)):
            g = best_grasp(cup, side)
            print(f"[grasp {side} arm, own cup] ok={g['ok']} err={g['err']} mm+deg torso={g['torso']} phi={g['phi_deg']} "
                  f"theta={g['theta_deg']} pad_misalign={g['pad_misalign_deg']}", flush=True)
            g2 = best_grasp(cup, side, thetas=(30, 40))
            print(f"   shallower (30-40 deg): ok={g2['ok']} err={g2['err']} theta={g2['theta_deg']}", flush=True)
        # single-arm place: right arm, held cup over the left cup (fingertip at the held cup's wall, 2.5 cm inside)
        place_ok = None
        for th in (50, 65, 80):
            for phi in (np.pi, np.pi - np.radians(35), np.pi + np.radians(35)):
                lift = cupL.h - 0.025            # fingers relative to the held cup = same as at the grasp, cup raised
                T, _ = frame(cupL, phi, np.radians(th), 0.0, 1, lift=lift)
                q, err, tm = solve(T, "right")
                if place_ok is None or err < place_ok[0]:
                    place_ok = (err, th, round(np.degrees(phi) % 360), tm)
        print(f"[place right arm over left cup] best err={place_ok[0]:.1f} mm+deg theta={place_ok[1]} phi={place_ok[2]} torso={place_ok[3]:.3f}")
    else:
        res = {}
        for side in ("left", "right"):
            rows = []
            for x in (0.34, 0.38, 0.42, 0.46):
                for y in ((-0.22, -0.14, -0.06, 0.02, 0.10) if side == "right" else (-0.10, -0.02, 0.06, 0.14, 0.22)):
                    cup = Cup(on_table((x, y)), N)
                    g = best_grasp(cup, side, thetas=(65,), phis=[np.pi])
                    if not g["ok"]:
                        g = best_grasp(cup, side, thetas=(50, 80), phis=[np.pi])
                    rows.append(dict(x=x, y=y, ok=g["ok"], err=g["err"], torso=g["torso"], theta=g["theta_deg"], lim=g["lim"]))
                    print(f"{side} cup centre ({x:.2f},{y:+.2f}): {'OK ' if g['ok'] else 'NO '} err {g['err']:6.1f} "
                          f"torso {g['torso']:+.3f} theta {g['theta_deg']} limmargin {g['lim']}", flush=True)
            res[side] = rows
        json.dump(res, open("out/reach_map.json", "w"), indent=1)
    print(f"[{time.time() - t0:.0f}s]")
