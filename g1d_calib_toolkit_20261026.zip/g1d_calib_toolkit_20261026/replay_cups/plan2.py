# plan2.py -- two-arm cup stacking on the calibrated model (assembled_calib_20261021):
#   left arm : rim-pinch the left cup, carry it to the meeting point M, set it down ~1 cm above the measured table,
#              release, retreat to the ready pose
#   right arm: rim-pinch the right cup, lift it clear, move it above M, lower it 2.5 cm into the left cup, release,
#              retreat, ready pose
# Grasps are near-wall pinches with the fingers pointing forward-down (from reach_diag.py). While a cup is held it is
# only translated and yawed about the table normal, so it stays upright.
#   python plan2.py findm             -> out/m_search.json (targeted IK at the place poses, ~1 min)
#   python plan2.py plan [--seq]      -> out/plan2.json, out/traj2.npz, out/episode/episode_0000/data.json
import argparse
import json
import time

import numpy as np
from scipy.spatial.transform import Rotation

import geom
from geom import ALLJ, READY, Cup, ee, ik, limit_margin, tip_point, torso_margin
from reach_diag import B_L, B_R, N, TABLE_OFF, frame, on_table, solve

# shoulder roll never closer to the torso than in replay.py's ready pose (which itself is inside our empirical guard)
geom.EXTRA_BOUNDS["left"] = (np.r_[-np.inf, READY[1], [-np.inf] * 5], np.full(7, np.inf))
geom.EXTRA_BOUNDS["right"] = (np.full(7, -np.inf), np.r_[np.inf, READY[8], [np.inf] * 5])

OUT_DIR = __import__("pathlib").Path(__file__).parent / "out"
FPS = 30.0
import sys as _sys
# --shift-x: plan for a PROPOSED layout with both cups moved along torso x (negative = toward the robot), same y
SHIFT_X = float(_sys.argv[_sys.argv.index("--shift-x") + 1]) if "--shift-x" in _sys.argv else 0.0
CUP_L = Cup(on_table((B_L[0] + SHIFT_X, B_L[1])), N)
CUP_R = Cup(on_table((B_R[0] + SHIFT_X, B_R[1])), N)
G_OPEN, G_CLOSED = 3.2, 0.0
# grasp: SIDE-wall rim pinch, pads parallel to the wall: outer side of each cup, fingers pointing forward (+x) and
# down by TH (one finger inside, one outside). Tilted-pad near-wall pinches slipped in the physics check.
TH_L = TH_R = float(_sys.argv[_sys.argv.index("--th") + 1]) if "--th" in _sys.argv else 65
PHI = {"left": np.pi / 2, "right": -np.pi / 2}
PSI = {"left": -np.pi / 2, "right": np.pi / 2}
import reach_diag as _rd
# deeper pinch (more pad on the wall -> the hanging cup swings less; the 3 cm pinch tilted 5-7 deg in the physics check)
_rd.D_TIP = float(_sys.argv[_sys.argv.index("--dtip") + 1]) if "--dtip" in _sys.argv else 0.045
SETTLE_ABOVE = 0.010                 # pause with the held cup's bottom this far above the left rim before inserting
RELEASE_UP = 0.010                   # left cup set down with its bottom 10 mm above the measured table (+-1 cm)
INSERT = 0.025                       # right cup bottom this far below the left rim at release
CLEAR = 0.035                        # held right cup bottom above the left rim while moving over it
CARRY_UP = 0.05                      # left cup bottom lifted this much while carried
RETREAT_UP = 0.11
YAWS = np.radians([-45, -30, -15, 0, 15, 30, 45])


def finger_wall(T, side, cup, g=G_OPEN):
    """distance of finger 1 / finger 2 (open) to the cup wall for a gripper base pose T"""
    from geom import fk, link_clouds
    global _FCL
    if "_FCL" not in globals():
        _FCL = link_clouds(0.003)
    q = READY.copy()
    T0 = ee(q, side)[0]
    out = []
    for fl in ("1", "2"):
        P = []
        for l in [k for k in _FCL if k.startswith(f"{side}_dex1_finger_link_{fl}")]:
            Tl = fk(l, q, (g, g))[0]
            Pl = _FCL[l] @ Tl[:3, :3].T + Tl[:3, 3]
            P.append((Pl - T0[:3, 3]) @ T0[:3, :3])          # in the gripper base frame
        P = np.vstack(P) @ T[:3, :3].T + T[:3, 3]
        out.append(float(cup.wall_distance(P).min()))
    return out


def grasp(side):
    cup = CUP_L if side == "left" else CUP_R
    th = TH_L if side == "left" else TH_R
    best = None
    for flip in (1, -1):
        T, mis = frame(cup, PHI[side], np.radians(th), PSI[side], flip)
        # centre the wall between the open pads: shift along the opening axis (base y) until both gaps are equal
        for _ in range(3):
            d1, d2 = finger_wall(T, side, cup)
            for sgn in (1, -1):
                Tt = T.copy(); Tt[:3, 3] += T[:3, 1] * sgn * (abs(d1 - d2) / 2)
                e1, e2 = finger_wall(Tt, side, cup)
                if abs(e1 - e2) < abs(d1 - d2) - 1e-4:
                    T = Tt; break
        d1, d2 = finger_wall(T, side, cup)
        q, err, tm = solve(T, side)
        key = (err > 1.0, -tm if err <= 1.0 else err)
        if best is None or key < best[-1]:
            best = (T, q, err, tm, mis, flip, (d1, d2), key)
    off = 0 if side == "left" else 7
    print(f"[grasp {side}] err {best[2]:.2f} torso {best[3]:.3f} pad gaps to wall {np.round(best[6], 4)} m, flip {best[5]}, "
          f"max |q - ready| {np.abs(best[1][off:off + 7] - READY[off:off + 7]).max():.2f} rad, q {best[1][off:off + 7].round(2)}")
    return best[:7]


def along_approach(T, d):
    """gripper pose moved by d along its own approach axis (base x): the fingers slide along their own line"""
    T2 = T.copy(); T2[:3, 3] = T[:3, 3] + T[:3, 0] * d
    return T2


def cup_frame(cup):
    u = np.cross(N, [0, 1, 0]); u /= np.linalg.norm(u)
    T = np.eye(4); T[:3, :3] = np.c_[u, np.cross(N, u), N]; T[:3, 3] = cup.b
    return T


def yaw_about_n(T, psi, pivot):
    R = Rotation.from_rotvec(N * psi).as_matrix()
    T2 = T.copy(); T2[:3, :3] = R @ T[:3, :3]; T2[:3, 3] = pivot + R @ (T[:3, 3] - pivot)
    return T2


def gripper_for_cup(T_gc, cup_bottom, psi):
    """gripper pose that puts the held cup's bottom centre at cup_bottom, yawed by psi about n"""
    Tc = cup_frame(Cup(cup_bottom, N))
    T = Tc @ T_gc
    return yaw_about_n(T, psi, cup_bottom)


def findm():
    gl, gr = grasp("left"), grasp("right")
    print(f"left grasp err {gl[2]:.2f} torso {gl[3]:.3f} pad-misalign {gl[4]:.0f}deg | right grasp err {gr[2]:.2f} torso {gr[3]:.3f} pad-misalign {gr[4]:.0f}deg")
    T_gc_L = np.linalg.inv(cup_frame(CUP_L)) @ gl[0]          # gripper pose in the cup frame (rigid while held)
    T_gc_R = np.linalg.inv(cup_frame(CUP_R)) @ gr[0]
    res = []
    for x in (0.36, 0.40, 0.44):
        for y in (-0.06, -0.02, 0.02, 0.06):
            M = on_table((x, y))
            if np.linalg.norm(M[:2] - CUP_R.b[:2]) < 0.13:
                continue
            row = {"x": x, "y": y}
            for side, T_gc, bottom in (("left", T_gc_L, M + N * RELEASE_UP), ("right", T_gc_R, M + N * (CUP_L.h - INSERT))):
                best = None
                for psi in YAWS:
                    T = gripper_for_cup(T_gc, bottom, psi)
                    q, err, tm = solve(T, side, seeds=[READY, (gl if side == "left" else gr)[1]])
                    lm = float(limit_margin(q)[(0 if side == "left" else 7):][:7].min())
                    key = (not (err < 1.0 and tm >= 0), err, -min(tm, lm))
                    if best is None or key < best[0]:
                        best = (key, round(float(np.degrees(psi))), round(err, 2), round(tm, 3), round(lm, 3))
                row[side] = {"ok": not best[0][0], "yaw_deg": best[1], "err": best[2], "torso": best[3], "lim": best[4]}
            ok = row["left"]["ok"] and row["right"]["ok"]
            row["ok"] = ok
            res.append(row)
            print(f"M ({x:.2f},{y:+.2f}) {'OK ' if ok else 'NO '} L {row['left']} R {row['right']}", flush=True)
    json.dump(res, open(OUT_DIR / "m_search.json", "w"), indent=1)


# ---------------- dense two-arm trajectory ----------------
M_XY = (0.40, -0.02)
YAW_L, YAW_R = np.radians(-45), np.radians(30)       # from findm at M (0.40, -0.02)
STEP_NEAR, STEP_FAR = 0.008, 0.016                   # rad per 30 fps frame
V_SLOW, V_MED, V_FAST = 0.02, 0.035, 0.05            # m/s TCP
PRE_UP = 0.08


def minjerk(n):
    s = np.linspace(0, 1, n + 1)[1:]
    return s ** 3 * (10 - 15 * s + 6 * s ** 2)


def n_frames(dq, step, dist=0.0, v=1.0, tmin=0.6):
    return int(np.ceil(max(tmin, 1.875 * dq / (step * FPS), 1.875 * dist / v) * FPS))


class Arm:
    """per-arm frame list (7 joints) + gripper command, built segment by segment"""

    def __init__(self, side):
        self.side, self.off = side, (0 if side == "left" else 7)
        self.q = [READY[self.off:self.off + 7].copy()]
        self.g = [0.0]
        self.keys = {}
        self.ik_err = 0.0
        self.err_log = []          # (frame, pos err mm, rot err deg) of every Cartesian IK frame

    def full(self, q7):
        q = READY.copy(); q[self.off:self.off + 7] = q7
        return q

    def hold(self, sec, g=None):
        for _ in range(int(round(sec * FPS))):
            self.q.append(self.q[-1].copy()); self.g.append(self.g[-1] if g is None else g)

    def wait_until(self, n):
        while len(self.q) < n:
            self.q.append(self.q[-1].copy()); self.g.append(self.g[-1])

    def joint_to(self, q7, step, g_to=None):
        q0, g0 = self.q[-1], self.g[-1]
        n = n_frames(np.abs(q7 - q0).max(), step)
        for s in minjerk(n):
            self.q.append(q0 + (q7 - q0) * s)
            self.g.append(g0 if g_to is None else g0 + (g_to - g0) * s)

    def grip_to(self, g_to, sec):
        g0 = self.g[-1]
        for s in minjerk(int(round(sec * FPS))):
            self.q.append(self.q[-1].copy()); self.g.append(g0 + (g_to - g0) * s)

    def cart(self, pose_fn, dist, step, v):
        """pose_fn(s) -> 4x4 gripper pose for s in [0,1] (straight line / yaw), min-jerk timing, IK per frame"""
        T_end = pose_fn(1.0)
        q_end, _, _ = ik(T_end, self.full(self.q[-1]), self.side)
        n = n_frames(np.abs(q_end[self.off:self.off + 7] - self.q[-1]).max(), step, dist, v)
        q = self.full(self.q[-1])
        for s in minjerk(n):
            q, ep, er = ik(pose_fn(s), q, self.side, iters=60)
            self.ik_err = max(self.ik_err, ep * 1000 + np.degrees(er))
            self.err_log.append((len(self.q), ep * 1000, np.degrees(er)))
            self.q.append(q[self.off:self.off + 7].copy()); self.g.append(self.g[-1])

    def pose_to(self, T_b, step, v=V_MED, w=0.5, g_to=None, rest=None, exact=None):
        """Cartesian pose interpolation from the current gripper pose (position line + orientation slerp), IK per
        frame with the null space pulled toward 'rest' (default READY) -> the hand stays in its lane.
        exact: final 7-joint vector to blend into at the end (e.g. the ready pose)"""
        from scipy.spatial.transform import Slerp
        T_a = ee(self.full(self.q[-1]), self.side)[0]
        rot = Slerp([0, 1], Rotation.from_matrix([T_a[:3, :3], T_b[:3, :3]]))
        ang = np.linalg.norm((Rotation.from_matrix(T_b[:3, :3]) * Rotation.from_matrix(T_a[:3, :3]).inv()).as_rotvec())
        dist = np.linalg.norm(T_b[:3, 3] - T_a[:3, 3])
        rest = READY if rest is None else rest
        q_end, _, _ = ik(T_b, self.full(self.q[-1]), self.side, q_rest=rest)
        n = int(np.ceil(max(n_frames(np.abs(q_end[self.off:self.off + 7] - self.q[-1]).max(), step, dist, v) / FPS,
                            1.875 * ang / w) * FPS))
        q, g0 = self.full(self.q[-1]), self.g[-1]
        for s in minjerk(n):
            T = np.eye(4); T[:3, :3] = rot(s).as_matrix(); T[:3, 3] = T_a[:3, 3] + (T_b[:3, 3] - T_a[:3, 3]) * s
            q, ep, er = ik(T, q, self.side, iters=60, q_rest=rest)
            self.ik_err = max(self.ik_err, ep * 1000 + np.degrees(er))
            self.err_log.append((len(self.q), ep * 1000, np.degrees(er)))
            self.q.append(q[self.off:self.off + 7].copy())
            self.g.append(g0 if g_to is None else g0 + (g_to - g0) * s)
        if exact is not None:
            gap = np.abs(exact - self.q[-1]).max()
            if gap > 1e-6:
                self.joint_to(exact, STEP_NEAR)
            print(f"   [{self.side}] pose_to end gap to the target branch {gap:.4f} rad (blended in joint space)", flush=True)

    def mark(self, k):
        self.keys[k] = len(self.q) - 1


def lerp_pose(Ta, Tb):
    return lambda s: (lambda T: T)(np.block([[Ta[:3, :3], (Ta[:3, 3] + (Tb[:3, 3] - Ta[:3, 3]) * s)[:, None]], [np.zeros((1, 3)), np.ones((1, 1))]]))


def cup_path_pose(T_gc, b_a, b_b, psi_a, psi_b):
    return lambda s: gripper_for_cup(T_gc, b_a + (b_b - b_a) * s, psi_a + (psi_b - psi_a) * s)


HIGH_UP = 0.08


def approach(arm, g, Tg):
    """ready -> (joint space) high pre-grasp 8 cm above the pre-grasp, in the grasp's IK branch -> (Cartesian, straight
    down) pre-grasp 8 cm back along the finger axis. The descent to the grasp follows along the finger axis."""
    T_pre = along_approach(Tg, -PRE_UP)
    q_pre = ik(T_pre, g[1], arm.side)[0]
    T_high = T_pre.copy(); T_high[:3, 3] += N * HIGH_UP
    q_high, e, _ = ik(T_high, q_pre, arm.side)
    print(f"   [{arm.side}] high pre-grasp IK err {e * 1000:.2f} mm, joint distance from ready "
          f"{np.abs(q_high[arm.off:arm.off + 7] - READY[arm.off:arm.off + 7]).max():.2f} rad", flush=True)
    tgt = q_high[arm.off:arm.off + 7]
    mid = arm.q[-1].copy(); mid[:2] = tgt[:2]       # phase 1: shoulder pitch + roll (arm lifts and swings outward)
    arm.joint_to(mid, STEP_FAR, g_to=G_OPEN / 2)
    arm.joint_to(tgt, STEP_FAR, g_to=G_OPEN); arm.mark("pre_high")   # phase 2: yaw, elbow, wrists
    arm.cart(lerp_pose(T_high, T_pre), HIGH_UP, STEP_NEAR, V_MED); arm.mark("pre")


def go_ready(arm, g_to):
    """reverse of the approach: yaw/elbow/wrists back first (hand stays outboard), then shoulder pitch + roll"""
    tgt = READY[arm.off:arm.off + 7]
    mid = tgt.copy(); mid[:2] = arm.q[-1][:2]
    arm.joint_to(mid, STEP_FAR)
    arm.joint_to(tgt, STEP_FAR, g_to=g_to)


def build(seq=False):
    gl, gr = grasp("left"), grasp("right")
    T_gc = {"left": np.linalg.inv(cup_frame(CUP_L)) @ gl[0], "right": np.linalg.inv(cup_frame(CUP_R)) @ gr[0]}
    M = on_table(M_XY)
    L, R = Arm("left"), Arm("right")
    for arm in (L, R):
        arm.hold(1.0)
    # ---------- left: pick the left cup, carry to M, set down, release, retreat ----------
    T_ready = {s: ee(READY, s)[0] for s in ("left", "right")}
    TgL = gl[0]
    approach(L, gl, TgL)
    L.hold(0.4)
    L.cart(lerp_pose(ee(L.full(L.q[-1]), "left")[0], TgL), PRE_UP, STEP_NEAR, V_SLOW); L.mark("grasp")
    L.hold(0.4); L.grip_to(G_CLOSED, 1.2); L.mark("closed"); L.hold(1.0)
    bL0, bL1 = CUP_L.b, CUP_L.b + N * CARRY_UP
    L.cart(cup_path_pose(T_gc["left"], bL0, bL1, 0, 0), CARRY_UP, STEP_NEAR, V_MED); L.mark("lifted")
    bL2 = M + N * CARRY_UP
    L.cart(cup_path_pose(T_gc["left"], bL1, bL2, 0, YAW_L), np.linalg.norm(bL2 - bL1), STEP_FAR, V_MED); L.mark("over_M")
    L.hold(0.3)
    bL3 = M + N * RELEASE_UP
    L.cart(cup_path_pose(T_gc["left"], bL2, bL3, YAW_L, YAW_L), CARRY_UP - RELEASE_UP, STEP_NEAR, V_SLOW); L.mark("set_down")
    L.hold(0.4); L.grip_to(G_OPEN, 1.0); L.mark("released"); L.hold(0.8)
    T_rel = ee(L.full(L.q[-1]), "left")[0]
    L.cart(lerp_pose(T_rel, along_approach(T_rel, -RETREAT_UP)), RETREAT_UP, STEP_NEAR, V_MED); L.mark("retreated")
    go_ready(L, G_CLOSED); L.mark("back_at_ready")
    # ---------- right: pick the right cup (in parallel with the left arm unless --seq) ----------
    if seq:
        R.wait_until(len(L.q))
    TgR = gr[0]
    R.wait_until(max(len(R.q), L.keys["pre_high"] + 1))         # sequenced joint-space approaches (no simultaneous swing)
    approach(R, gr, TgR)
    R.hold(0.4)
    R.cart(lerp_pose(ee(R.full(R.q[-1]), "right")[0], TgR), PRE_UP, STEP_NEAR, V_SLOW); R.mark("grasp")
    R.hold(0.4); R.grip_to(G_CLOSED, 1.2); R.mark("closed"); R.hold(1.0)
    lift = CUP_L.h + CLEAR + RELEASE_UP
    bR0, bR1 = CUP_R.b, CUP_R.b + N * lift
    R.cart(cup_path_pose(T_gc["right"], bR0, bR1, 0, 0), lift, STEP_NEAR, V_MED); R.mark("lifted")
    # wait until the left arm is back at the ready pose before moving the held cup over M
    R.wait_until(max(len(R.q), L.keys["back_at_ready"] + 1))
    bR2 = M + N * lift
    R.cart(cup_path_pose(T_gc["right"], bR1, bR2, 0, YAW_R), np.linalg.norm(bR2 - bR1), STEP_NEAR, V_MED); R.mark("over_M")
    R.hold(1.5)                                           # let the hanging cup settle
    left_cup_at_M = M + N * 0.0                           # after release the left cup rests on the table at M
    bRs = left_cup_at_M + N * (CUP_L.h + SETTLE_ABOVE)
    R.cart(cup_path_pose(T_gc["right"], bR2, bRs, YAW_R, YAW_R), np.linalg.norm(bRs - bR2), STEP_NEAR, V_SLOW); R.mark("above_rim")
    R.hold(1.5)
    bR3 = left_cup_at_M + N * (CUP_L.h - INSERT)
    R.cart(cup_path_pose(T_gc["right"], bRs, bR3, YAW_R, YAW_R), np.linalg.norm(bR3 - bRs), STEP_NEAR, 0.01); R.mark("inserted")
    R.hold(0.4); R.grip_to(G_OPEN, 1.0); R.mark("released"); R.hold(1.0)
    T_rel = ee(R.full(R.q[-1]), "right")[0]
    R.cart(lerp_pose(T_rel, along_approach(T_rel, -RETREAT_UP)), RETREAT_UP, STEP_NEAR, V_MED); R.mark("retreated")
    go_ready(R, G_OPEN); R.mark("back_at_ready")
    n = max(len(L.q), len(R.q))
    L.wait_until(n); R.wait_until(n)
    for arm in (L, R):
        arm.hold(20.0)                                   # handover window for our server (see README)
    Q = np.hstack([np.array(L.q), np.array(R.q)])
    G = np.c_[np.array(L.g), np.array(R.g)]
    return Q, G, L, R, T_gc, M


def collisions(Q, G, L, R, T_gc, M, stride=3):
    from scipy.spatial import cKDTree

    from geom import fk, link_clouds
    clouds = link_clouds(0.005)
    arm_links = {s: [l for l in clouds if l.startswith(f"{s}_") and not l.startswith((f"{s}_shoulder_pitch", f"{s}_shoulder_roll"))]
                 for s in ("left", "right")}
    sh_links = {s: [l for l in clouds if l.startswith((f"{s}_shoulder_pitch", f"{s}_shoulder_roll"))] for s in ("left", "right")}
    fing = {s: [l for l in arm_links[s] if "finger" in l] for s in ("left", "right")}
    T_body = {l: fk(l, READY)[0] for l in ("torso_link", "head_link") if l in clouds}
    body = np.vstack([clouds[l] @ T[:3, :3].T + T[:3, 3] for l, T in T_body.items()])
    kd_body = cKDTree(body)
    cup_pts_local = Cup(np.zeros(3), np.array([0, 0, 1.0])).surface_points()
    worst = {}

    def upd(k, d, f):
        if d < worst.get(k, (np.inf,))[0]:
            worst[k] = (float(d), int(f))

    def cup_world(b):
        return cup_pts_local @ cup_frame(Cup(b, N))[:3, :3].T + b

    # frames to check: every stride-th frame where something moves, plus every key frame
    moving = np.r_[True, (np.abs(np.diff(Q, axis=0)).max(1) > 1e-9) | (np.abs(np.diff(G, axis=0)).max(1) > 1e-9)]
    sel = sorted(set(np.flatnonzero(moving)[::stride].tolist()) | set(L.keys.values()) | set(R.keys.values()))
    sel = [f for f in sel if f < len(Q)]
    Ts = {}
    for s in ("left", "right"):          # batched FK over all selected frames, one call per link
        from geom import qdict, ROBOT
        qd = qdict(Q[sel], (G[sel, 0], G[sel, 1]))
        for l in arm_links[s] + sh_links[s]:
            Ts[l] = ROBOT.fk(l, qd, {}, None, len(sel))
    EEs = {s: ROBOT.fk(f"{s}_dex1_base_link", qd, {}, None, len(sel)) for s in ("left", "right")}
    for i, f in enumerate(sel):
        pts = {l: clouds[l] @ Ts[l][i, :3, :3].T + Ts[l][i, :3, 3] for l in Ts}
        A = {s: np.vstack([pts[l] for l in arm_links[s]]) for s in ("left", "right")}
        nf = {s: np.vstack([pts[l] for l in arm_links[s] if l not in fing[s]]) for s in ("left", "right")}
        F = {s: np.vstack([pts[l] for l in fing[s]]) for s in ("left", "right")}
        # cup states
        holdL = L.keys["closed"] <= f < L.keys["released"]
        holdR = R.keys["closed"] <= f < R.keys["released"]
        Tl, Tr = EEs["left"][i], EEs["right"][i]
        cupL_b = (Tl @ np.linalg.inv(T_gc["left"]))[:3, 3] if holdL else (CUP_L.b if f < L.keys["closed"] else M)
        cupR_b = (Tr @ np.linalg.inv(T_gc["right"]))[:3, 3] if holdR else (CUP_R.b if f < R.keys["closed"] else None)
        cL = Cup(cupL_b, N)
        # self / arm-arm
        for s in ("left", "right"):
            o = 0 if s == "left" else 7
            upd(f"self_torso_{s}", kd_body.query(A[s], k=1)[0].min(), f)
            upd(f"table_{s}", float((A[s] @ N - TABLE_OFF).min()), f)
            tm = torso_margin(Q[f])[0 if s == "left" else 1]
            upd(f"torso_guard_{s}_incl_ready", tm, f)
            if np.abs(Q[f, o:o + 7] - READY[o:o + 7]).max() > 0.05:
                upd(f"torso_guard_{s}_away_from_ready", tm, f)
        for s, cup_b, arm in (("left", cupL_b, L), ("right", cupR_b, R)):
            if f == arm.keys["grasp"]:            # open gripper at the pinch pose: each finger's gap to the wall
                c = Cup(cup_b, N)
                for fl in ("1", "2"):
                    P = np.vstack([pts[l] for l in fing[s] if f"finger_link_{fl}" in l])
                    worst[f"{s}_finger{fl}_to_wall_at_grasp"] = (float(c.wall_distance(P).min()), int(f))
        allL = np.vstack([A["left"]] + [pts[l] for l in sh_links["left"]])
        allR = np.vstack([A["right"]] + [pts[l] for l in sh_links["right"]])
        upd("arm_arm", cKDTree(allL).query(allR, k=1)[0].min(), f)
        # arms vs cups (solid), fingers vs the wall of the cup they are about to pinch
        if not holdL:
            upd("left_nonfinger_vs_left_cup", float(cL.distance(nf["left"]).min()), f)
            if f <= L.keys["grasp"]:
                upd("left_fingers_vs_left_cup_wall_descent", float(cL.wall_distance(F["left"]).min()), f)
            elif f > L.keys["released"]:
                upd("left_fingers_vs_left_cup_after_release", float(cL.wall_distance(F["left"]).min()), f)
        upd("right_arm_vs_left_cup", float(cL.distance(A["right"] if not (holdR or f >= R.keys["released"]) else nf["right"]).min()), f)
        if cupR_b is not None:
            cR = Cup(cupR_b, N)
            upd("left_arm_vs_right_cup", float(cR.distance(A["left"]).min()), f)
            if not holdR and f < R.keys["closed"]:
                upd("right_nonfinger_vs_right_cup", float(cR.distance(nf["right"]).min()), f)
                if f <= R.keys["grasp"]:
                    upd("right_fingers_vs_right_cup_wall_descent", float(cR.wall_distance(F["right"]).min()), f)
        if holdL:
            P = cup_world(cupL_b)
            if f > L.keys["lifted"]:
                upd("held_left_cup_vs_table", float((P @ N - TABLE_OFF).min()), f)
            upd("held_left_cup_vs_right_arm", cKDTree(allR).query(P, k=1)[0].min(), f)
            upd("held_left_cup_vs_body", kd_body.query(P, k=1)[0].min(), f)
            if cupR_b is not None:
                upd("held_left_cup_vs_right_cup", float(Cup(cupR_b, N).distance(P).min()), f)
        if holdR:
            P = cup_world(cupR_b)
            if f > R.keys["lifted"] - 10:
                upd("held_right_cup_vs_table", float((P @ N - TABLE_OFF).min()), f)
            upd("held_right_cup_vs_left_arm", cKDTree(allL).query(P, k=1)[0].min(), f)
            upd("held_right_cup_vs_body", kd_body.query(P, k=1)[0].min(), f)
            if f < R.keys["over_M"]:
                upd("held_right_cup_vs_left_cup_solid", float(cL.distance(P).min()), f)
            else:
                upd("held_right_cup_vs_left_cup_wall_insertion", float(cL.wall_distance(P).min()), f)
    return {k: {"min_m": round(v[0], 4), "frame": v[1]} for k, v in sorted(worst.items())}


def export_episode(Q, G, path, note):
    data = []
    for i in range(len(Q)):
        a = {"left_arm": {"qpos": [round(float(v), 6) for v in Q[i, :7]], "qvel": [], "torque": []},
             "right_arm": {"qpos": [round(float(v), 6) for v in Q[i, 7:]], "qvel": [], "torque": []},
             "left_ee": {"qpos": [round(float(G[i, 0]), 4)], "qvel": [], "torque": []},
             "right_ee": {"qpos": [round(float(G[i, 1]), 4)], "qvel": [], "torque": []}}
        data.append({"idx": i, "colors": {}, "depths": {}, "states": json.loads(json.dumps(a)), "actions": a,
                     "tactiles": {}, "audios": {}, "sim_state": ""})
    doc = {"info": {"version": "1.0.0", "date": time.strftime("%Y-%m-%d"), "author": "real2sim calib (IK-planned, not recorded)",
                    "image": {"width": 640, "height": 480, "fps": FPS},
                    "joint_names": {"left_arm": [], "left_ee": [], "right_arm": [], "right_ee": [], "body": []}, "note": note},
           "text": {"goal": "left arm moves the left cup to M; right arm nests the right cup into it"},
           "data": data, "success": None}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc), encoding="utf-8")


def builtin_paths(M):
    """replay.py's own motions: all-zero -> ready at the start; go-home ready -> zero at the end (stack at M)"""
    from geom import fk, link_clouds
    clouds = link_clouds(0.005)
    links = [l for l in clouds if l.startswith(("right_", "left_")) and any(k in l for k in ("dex1", "wrist", "elbow"))]
    res = {}
    stack = Cup(M + N * 0.015, N)
    for name, (qa, qb, cups) in {"zero_to_ready": (np.zeros(14), READY, [CUP_L, CUP_R]),
                                 "ready_to_zero_gohome": (READY, np.zeros(14), [stack])}.items():
        d = {"table": np.inf, "cups": np.inf}
        for s in np.linspace(0, 1, 31):
            q = qa + (qb - qa) * (s * s * (3 - 2 * s))
            P = np.vstack([clouds[l] @ fk(l, q)[0][:3, :3].T + fk(l, q)[0][:3, 3] for l in links])
            d["table"] = min(d["table"], float((P @ N - TABLE_OFF).min()))
            d["cups"] = min(d["cups"], min(float(c.distance(P).min()) for c in cups))
        res[name] = {k: round(v, 4) for k, v in d.items()}
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["findm", "plan"])
    ap.add_argument("--seq", action="store_true", help="fully sequential arms (no overlap)")
    ap.add_argument("--shift-x", type=float, default=0.0)
    ap.add_argument("--m", default="", help="meeting point x,y (cup bottom, torso frame)")
    ap.add_argument("--yaw", default="", help="yaw at M, left,right (deg)")
    ap.add_argument("--tag", default="")
    ap.add_argument("--dtip", type=float, default=0.045, help="fingertip depth below the rim at the pinch (m)")
    ap.add_argument("--th", type=float, default=65, help="approach tilt below horizontal, both arms (deg)")
    a = ap.parse_args()
    if a.m:
        M_XY = tuple(float(v) for v in a.m.split(","))
    if a.yaw:
        YAW_L, YAW_R = (np.radians(float(v)) for v in a.yaw.split(","))
    print(f"layout shift x {SHIFT_X:+.3f} m | cups bottom L {CUP_L.b.round(3)} R {CUP_R.b.round(3)} | M {M_XY}", flush=True)
    t0 = time.time()
    if a.mode == "findm":
        findm()
    else:
        Q, G, L, R, T_gc, M = build(a.seq)
        steps = np.abs(np.diff(Q, axis=0)).max(0)
        print(f"frames {len(Q)} ({len(Q) / FPS:.1f} s); max joint step L {steps[:7].max():.4f} R {steps[7:].max():.4f} rad/frame; "
              f"IK err L {L.ik_err:.2f} R {R.ik_err:.2f} mm+deg [{time.time() - t0:.0f}s]", flush=True)
        print("keys L", L.keys, "\nkeys R", R.keys, flush=True)
        for arm in (L, R):
            e = np.array(arm.err_log)
            worst = e[np.argmax(e[:, 1] + e[:, 2])]
            print(f"{arm.side}: Cartesian IK frames {len(e)}, max pos err {e[:, 1].max():.2f} mm, max rot err {e[:, 2].max():.3f} deg, "
                  f"worst at frame {int(worst[0])}; frames with err > 0.5 mm: {int((e[:, 1] > 0.5).sum())}", flush=True)
        col = collisions(Q, G, L, R, T_gc, M)
        print(json.dumps(col, indent=0), flush=True)
        paths = builtin_paths(M)
        print("replay built-in paths:", paths, flush=True)
        wp = {}
        for arm in (L, R):
            for k, fr in arm.keys.items():
                T = ee(Q[fr], arm.side)[0]
                wp[f"{arm.side}_{k}"] = {"frame": fr, "t_s": round(fr / FPS, 2), "q": Q[fr, arm.off:arm.off + 7].round(4).tolist(),
                                         "tip_torso_m": tip_point(T).round(4).tolist(), "gripper_base_torso_m": T[:3, 3].round(4).tolist(),
                                         "approach_dir": T[:3, 0].round(3).tolist(), "opening_dir": T[:3, 1].round(3).tolist(),
                                         "gripper_cmd": round(float(G[fr, 0 if arm.side == 'left' else 1]), 3)}
        lim = float(min(limit_margin(q).min() for q in Q))
        plan = {"strategy": "two-arm: left cup to M, right cup nested into it", "M_bottom_torso": M.tolist(),
                "yaw_deg": {"left": float(np.degrees(YAW_L)), "right": float(np.degrees(YAW_R))},
                "approach_tilt_deg": {"left": TH_L, "right": TH_R}, "sequential": a.seq,
                "params": {"RELEASE_UP": RELEASE_UP, "INSERT": INSERT, "CLEAR": CLEAR, "CARRY_UP": CARRY_UP, "RETREAT_UP": RETREAT_UP,
                           "PRE_UP": PRE_UP, "G_OPEN": G_OPEN, "G_CLOSED": G_CLOSED, "STEP_NEAR": STEP_NEAR, "STEP_FAR": STEP_FAR},
                "fps": FPS, "n_frames": len(Q), "duration_s": round(len(Q) / FPS, 1),
                "max_joint_step_rad": float(steps.max()), "min_joint_limit_margin_rad": round(lim, 3),
                "ik_err_mm_plus_deg": {"left": L.ik_err, "right": R.ik_err},
                "key_frames": {**{f"left_{k}": v for k, v in L.keys.items()}, **{f"right_{k}": v for k, v in R.keys.items()}},
                "waypoints": wp, "clearances": col, "replay_builtin_paths": paths,
                "table_normal": N.tolist(), "table_offset": TABLE_OFF,
                "cups": {"left": {"bottom": CUP_L.b.tolist(), "rim": CUP_L.rim.tolist()},
                         "right": {"bottom": CUP_R.b.tolist(), "rim": CUP_R.rim.tolist()}},
                "cup_dims": {"rb": CUP_L.rb, "rt": CUP_L.rt, "h": CUP_L.h}, "ready": READY.tolist(), "joint_names": ALLJ,
                "T_gripper_in_cup": {k: v.round(6).tolist() for k, v in T_gc.items()}}
        plan["layout_shift_x_m"] = SHIFT_X
        plan["grasp_family"] = "side-wall rim pinch, pads parallel to the wall, fingers forward-down"
        json.dump(plan, open(OUT_DIR / f"plan2{a.tag}.json", "w"), indent=1)
        np.savez(OUT_DIR / f"traj2{a.tag}.npz", q=Q, grip=G, fps=FPS)
        export_episode(Q, G, OUT_DIR / f"episode{a.tag}" / "episode_0000" / "data.json",
                       f"two-arm IK plan on the calibrated model (assembled_calib_20261021), layout shift x {SHIFT_X:+.3f} m; states == actions")
        print(f"wrote plan2{a.tag}.json, traj2{a.tag}.npz, episode{a.tag}/episode_0000/data.json")
    print(f"[{time.time() - t0:.0f}s]")
