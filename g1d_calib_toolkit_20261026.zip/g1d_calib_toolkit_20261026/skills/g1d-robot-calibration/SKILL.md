---
name: g1d-robot-calibration
description: 安全地操作 G1-D（Unitree 轮式底盘 + 升降柱 + 双 7 自由度手臂 + Dex1 夹爪 + 头部双目 + 左右腕相机）真机→仿真标定工具包（2026-10-26 版）：标定板实测格长、相机内参、头部双目右眼安装、采集（calib_arm_server / collect_robot / 头部定位的腕部看板会话）、dual_trans 辨识、头部轮廓对齐（contour_fit）、联合拟合（joint_fit）、合成参数（compose_params）与构建资产、合并到 RoboDojo G1-D、验收（refine_wrist_mount 留一、左眼轮廓、冒烟测试）、叠杯回放（仿真 IK 规划 + real_run_v2 交接 + 三路录像）。在需要移动 G1-D 手臂、交接手臂控制权、监控或恢复标定任务、处理 status.json 报错、解读标定结果时使用。
---

# G1-D 真机标定（2026-10-26 版）

工具包根目录（下称 `<KIT>`）：`robot/`（机器人）、`pc/`（Windows PC）、`server/`（GPU 服务器）、`robodojo_merge/`（新方法：格长、联合拟合、RoboDojo）、`replay_cups/`（叠杯应用）、`docs/`、`examples/`。完整步骤见 `<KIT>/docs/使用手册_zh.md`，安全规则见 `<KIT>/docs/安全规范_zh.md`。

## 安全铁律

每次让手臂运动或改变手臂控制权之前对照一遍。

1. **先问人**：任何会让手臂运动的命令（采集、看板会话、回 home、恢复、`which_wrist_now.py`、回放）之前，确认有人守急停并得到这一次的明确许可。
2. **不碰系统服务和权限**：不停止/修改相机服务 `teleimager`；不执行或索取 sudo；不修改同事仓库（`~/g1d_infra`、RoboDojo）。
3. **恰好一个 rt/lowcmd 写入者**：0 个 = 手臂掉落；2 个长时间并存 = 抖动。交接只用 `takeover2.sh`（换服务实例）或 `replay_cups/robot/real_run_v2.sh`（回放）。
4. **kill 规则**：`kill -9` 控制程序 = 手臂掉落（除非另一个写入者已确认在发布）；SIGINT/SIGTERM 会让服务先回启动位姿（会动）。kill 之前先说清"之后谁在控制手臂"。
5. **不要 `pkill -f`**：模式会匹配到 ssh 命令行本身并杀掉远端 shell。用 `pgrep -af '[x]xx'` 查 PID 再处理。
6. **只走检查过的路径**：不从悬停姿态直接去另一个悬停姿态；跳过姿态先回 home；不去 `skip=true`；`home_path_ok=false` 不直接回 home。
7. **REJECTED / refused = 手臂没动**：当作跳过，原路退回；不重发。
8. **板附近出异常不自动恢复**：先汇报，由用户决定；ERROR 锁定用 `recover.py`（先 `--dry`），不要只发 `reset`。
9. **躯干护栏、IK 收敛**：左肩 roll 身侧 ≥ +0.05、身前 ≥ −0.10（右臂取反）；IK 残差 > 2 mm / 0.5° 不执行。
10. **板必须固定，格长必须实测**：量整排 10 格；所有尺度步骤传 `BOARD_SQUARE_MM=<实测值>`。
11. **开机先查**：腰部 `all_q[12]`（不为 0 用 `waist_to.py 0`）、`robot_state_check.py` 的写入者、腕部端口（10-21 21:25 起 55556 = 左腕、55557 = 右腕，`which_wrist_now.py` 复查）。
12. **长任务放到机器人本机后台**（`setsid nohup ... &`）；不要从 PC 用 ssh 循环驱动机器人。
13. **叠杯类回放两臂顺序执行**（`--seq`），否则两臂间隙只有 2–5 mm。
14. PowerShell `-match` 不区分大小写，判断日志/进程名时用 `-cmatch`。

## 工作流

复制这个清单并逐项更新：

```text
- [ ] 0 使能（L2+R2）→ peek_lowstate / robot_state_check（腰、写入者）→ start_server.sh → which_wrist_now.py → 双臂 home
- [ ] 1 量板：10 格总长 /10 = 实测格长 s（本机 38.2 mm）
- [ ] 2 内参：capture_intrinsics → calibrate_intrinsics（头部重采可选：head_intr_capture + live_capture_view + head_intr_calib）
- [ ] 3 双目 R,T（stereo_extrinsics）→ make_camera_setup（CALIB_PARAMS, BOARD_SQUARE_MM=s）
- [ ] 4 采集：设置 B（gen_poses → run_queue）+ 头部定位的腕部看板（plan_board_view / plan_left_session → capture_*）
- [ ] 5 dual_trans：export_meas → scale_meas s → identify.py（或 SQ=s bash pipeline_sq.sh）
- [ ] 6 头部轮廓：contour_fit.py fit ... both mount（二次拟合从上次安装出发）
- [ ] 8/9 compose_params → params_final_sq382c → merge_calib_into_robodojo + make_camera_setup（基础包）
- [ ] 7 联合拟合：run_joint_fit.sh → build_sq382j.sh（采用 mount_trans）
- [ ] 8/9 再合成、build_assembly、合并 RoboDojo 包
- [ ] 10 验收：refine_wrist_mount 留一、contour_left_eye、run_smoke.sh（服务器 2）
- [ ] 11 应用（可选）：fit_cups → plan2 findm/choose_m → run_plan_ik.sh（--seq）→ run_sim_1023.sh → real_run_v2.sh start/go
```

每步的命令、通过标准、典型数值见 [reference.md](reference.md)。

## 后台任务与监控

```bash
ssh unitree "setsid nohup bash ~/calib_sessions/run_queue.sh left right > /dev/null 2>&1 < /dev/null &"
ssh unitree "tail -n 15 ~/calib_sessions/queue.log"
ssh unitree "cut -c1-220 /tmp/g1d_calib/status.json; echo"
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/robot_state_check.py"
ssh unitree "pgrep -af '[c]alib_arm_server.py|[c]ollect_robot.py|[t]eleop.replay|[p]assive_logger'"
ssh unitree "touch ~/calib_sessions/STOP"        # 两个任务之间停
ssh unitree "bash ~/calib_sessions/replay_cups/real_run_v2.sh status"
```

等待时用后台计时再读结果，不要在 PC 上紧循环轮询 ssh。PowerShell 里不要在 `ssh "..."` 中写含 `$`、嵌套引号的 bash：写成 `.sh`，`scp` 后执行。

## 出错时

1. 读 `status.json` 的 `state`/`msg`、日志最后 30 行、`robot_state_check.py` 的写入者，**先汇报，不动手臂**。
2. 得到许可后再执行（都先 `--dry`）：`recover.py <side> <POSE_ID>`（ERROR）、`go_home.py <side> [--near|--via]`（停在姿态附近）。
3. 服务进程不在了：立即告诉用户（手臂可能已掉落），不要自行启动服务去"接住"手臂，除非用户确认现场安全。
4. 发现两个写入者长时间并存：汇报，由用户决定停哪一个；不要自己 kill。
5. 回放异常：不要按 `q`（replay 1 s 后停止发布）除非手臂安全或我们的服务已准备接管；紧急情况让用户用遥控器 `L2+B`。

## 向用户汇报

```markdown
## <步骤> 结果
- 做了什么：<命令 / 目录>
- 结果：<残差、留出误差、轮廓分数……与 reference.md 的典型值对比>
- 异常：<中止原因、跳过、REJECTED>；手臂当前状态：<home / 某姿态 / error>；当前 rt/lowcmd 写入者：<…>
- 下一步建议：<……>（需要用户许可的动作单独列出）
```

## 参考

- [reference.md](reference.md)
- `<KIT>/docs/使用手册_zh.md`、`安全规范_zh.md`、`环境配置_zh.md`、`项目记录_20261020-26.md`
