# G1-D 标定参考（给 Agent，2026-10-26 版）

`<KIT>` = 工具包根目录。机器人 python：`PYR=~/miniconda3/envs/tv/bin/python`。服务器 python：`$ISAAC_PY`（= `$ISAAC_ENV/bin/python`）。服务器目录：`R=/root/unitree_sim_isaaclab/real2sim_calib_20261015`，`W=$R/board_scale_20261023`，`D=$R/robodojo_g1d_calib_20261022/check`。

## 1. 手臂控制服务协议

指令：原子写 `/tmp/g1d_calib/cmd.json`，`seq` 必须比 `status.seq_done` 大。

| cmd | 字段 | 说明 |
|---|---|---|
| `move` | `arm_q`（左 7 + 右 7）、`seconds` | 最小加加速度轨迹，峰值速度 ≤ vmax |
| `jog` | `motor`（15–28）、`delta`（≤ 0.1 rad） | 相对当前指令 |
| `waist` | `q`（目标腰部 yaw，rad） | \|q\| ≤ 0.5、单次 ≤ 0.6 rad、0.1 rad/s（`pc/waist_to.py`） |
| `stop` | — | 冻结在当前指令点 |
| `reset` | — | 清除 ERROR（会多下沉一个下垂量，用 `recover.py` 代替） |

状态 `/tmp/g1d_calib/status.json`：`state`（idle / moving / error / exited）、`seq_done`、`msg`、`arm_q`、`arm_q_cmd`、`all_q`（35 个，`all_q[12]` = 腰）、`vmax`、`n_pub`（应持续增长）、`pid`。

## 2. 每步命令与典型值（这台机器人）

| 步骤 | 命令（简） | 通过标准 / 典型值 |
|---|---|---|
| 0 使能 | `peek_lowstate.py`、`robot_state_check.py`、`start_server.sh`、`waist_to.py 0`、`which_wrist_now.py` | `server ready`；腰 ≈ 0；写入者只有我们的服务 |
| 1 量板 | 钢尺量 10 格 | 本机 382 mm → 38.2 mm（单格量得 38.5，不准） |
| 2 内参 | `capture_intrinsics.py <cam> N` → `calibrate_intrinsics.py all` | 留出 ≤ 1.3× 训练；头 fx ≈ 279.3/279.8，左腕 ≈ 315.7，右腕 ≈ 313.0 |
| 2 头部重采 | `head_intr_capture.py --out <dir>` + `live_capture_view.py` → `head_intr_calib.py <dir> <old>` | 主点差约 7 px；**未采用** |
| 3 右眼 | `stereo_extrinsics.py` → `CALIB_PARAMS=... BOARD_SQUARE_MM=38.2 make_camera_setup.py out.json` | 基线 61.35 × 0.955 = 58.6 mm |
| 4 采集 | `run_queue.sh left right`；`plan_board_view.py` / `plan_left_session.py` → `capture_board_views.py` / `capture_left_session.py` | 每臂 40–50 样本；板漂移 ≤ 2–3 mm |
| 5 dual_trans | `export_meas.py` → `scale_meas.py in out 38.2` → `identify.py ... --estimate '*_joint/d*' --prior '*=0.003' --refine-intrinsics --loss soft_l1 --folds 5` | 残差 ~5 px（与格长无关）；腕 fx −16/−17 px |
| 5 一键 | `SQ=38.2 bash pipeline_sq.sh` | 输出 `params_final_sq382c.json` |
| 6 轮廓 | `contour_fit.py fit <out> <urdf> both mount`；`contour_fit.py eval <out> tag=urdf` | sq382c：左 1.75 / 留出 2.21 px，右 1.75 px |
| 7 联合拟合 | `MODELS=mount,mount_trans,... bash run_joint_fit.sh` → `bash build_sq382j.sh` | 采用 mount_trans；腕部留出 4.5–8.1 px |
| 8 合成 | `compose_params.py <final_urdf> <cam_src.json> <out.json>` | 106 values；FK 差 ~1e-15 |
| 8 资产 | `build_assembly.py <params> assembled_<tag> --gpu N` | USD 与 URDF 差 ~1e-8 m；`test_apply_calibration.py` 6/6 |
| 9 RoboDojo | `merge_calib_into_robodojo.py <their> <our upper urdf> <params> <out>` + `make_camera_setup.py` | 只变 14 个手臂关节；相机用 camera_setup_ours.json |
| 10 留一 | `BOARD_SQUARE_MM=38.2 CALIB_PKG=<包> refine_wrist_mount.py <side> <out> <会话...>`（`ARM_OFFSET=1` 检验整臂偏移） | sq382j 左 4.5–6.7、右 4.9–8.1 px |
| 10 左眼轮廓 | `contour_left_eye.py tag=urdf ...` | 左 1.75/2.86/1.75，右 1.75/1.51/2.26 px |
| 10 冒烟 | `SMOKE_DIR=... bash run_smoke.sh <gpu>`（服务器 2） | 25 关节、FK 差 0.000 mm |
| 11 叠杯 | `fit_cups.py --board-c --board-n --stereo-scale 0.955 --seed-uv` → `plan2.py findm` → `choose_m.py` → `run_plan_ik.sh`（`--seq`）→ `run_sim_1023.sh` → `real_run_v2.sh start/go` | 10-23 真机成功 |

## 3. 回放交接（`replay_cups/robot/real_run_v2.sh`）

| 子命令 | 做什么 | 检查 |
|---|---|---|
| `start <episode_dir>` | 启动 `passive_logger_cams.py`（三路 10 Hz）；tmux `cups` 里运行 replay.py 到 `Replay? [y/N]` | 输出 `== AT PROMPT (replay is holding) ==` |
| `go <episode_dir>` | `stop_server_for_replay.sh`（确认 replay 写入者 > 50 条/s 后 kill -9 我们的服务）→ 启动 `takeover_after_replay_v2.py` → 回答 y | `OK: replay.py is the only writer`；任一检查失败就什么都不做 |
| `status` | 回放画面、记录器、交接日志、三路帧数 | 帧数在增长 |
| `abort` | 回放终端按 q | **replay 约 1 s 后停止发布**，只在安全时用 |

终态接管判据：14 个关节离 ready < 0.08 rad、右夹爪 > 2.5（开）、左夹爪 < 0.8（闭）、稳定 2 s；我们的服务 `server ready` 后立即 kill -9 replay.py。

## 4. 日志关键字

| 来源 | 关键字 | 处理 |
|---|---|---|
| `queue.log` | `ABORT at <id>: BOARD MOVED` | 停止，汇报，检查板固定 |
| `queue.log` | `server error latched` | 按出错处理（需许可） |
| `status.json` | `REJECTED: ...` / `refused` | 手臂没动；跳过、原路退回 |
| `stop_server_for_replay.sh` | `NOT stopping our server` / `handover refused` | 正常保护，我们的服务仍在控制 |
| `stop_server_for_replay.sh` | `!!! replay writer not seen` | **立即汇报**，提醒用户准备急停 |
| `takeover.log` | `replay.py killed ... our server is the only writer` + `OK: our server is holding the ready pose` | 交接完成，用 `robot_state_check.py` 确认只有一个写入者 |
| `takeover.log` | `TIMEOUT: final hold not detected` / `!!! SERVER DID NOT START` | **立即汇报**：replay 退出后手臂会掉，提醒用户急停 / 阻尼 |
| `joint_fit` 日志 | `JOINT_FIT_DONE` | 完成 |
| `compose_params` | `max |FK(...)| = 1e-15` 量级 | 大于 1e-9 会断言失败 |
| `pipeline_sq.sh` | `PIPELINE_DONE` | 完成 |

## 5. 恢复脚本（需许可，先 `--dry`）

| 情况 | 命令 |
|---|---|
| 服务 ERROR | `$PYR -u ~/calib_sessions/recover.py <side> <POSE_ID> --dry` |
| 停在姿态表某姿态 | `go_home.py <side> [--near POSE TOL | --via POSE] --dry` |
| 手臂下垂 → 全 0 | PC：`python raise_to_zero2.py` |
| 手臂下坠到板上方 | PC：`python lift_back_to_zero.py` |
| 换服务实例 | `VMAX=0.2 bash ~/calib_sessions/takeover2.sh` |

## 6. 数据传输

机器人 → PC → 服务器用 `tar czf` + `scp`；路径一律英文。GPU 服务器 sshd 有并发限制：串行执行、合并成脚本、失败退避重试。
