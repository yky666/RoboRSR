# 环境配置：需要按你的环境修改的地方（2026-10-26 版）

脚本是在一台具体的 G1-D、两台具体的 GPU 服务器上边做边写的，很多主机、路径、端口直接写在代码里。本文列出写死的值、出现在哪些文件、怎么改。相对 10-19 版的主要变化：**腕部相机端口对调**（§2.2）、新增环境变量（§0）、新增服务器目录和第二台 GPU 服务器（§3）、PC 端工作区布局（§4）。

打包时做过的替换（只改了工具包里的副本，原文件未动；`MANIFEST.md` 里标 ✎）：
- GPU 服务器上的个人 conda 路径换成环境变量：shell 脚本用 `${ISAAC_ENV:?...}`（没设置会直接报错退出），`build_assembly.py`、`make_urdf_variants.py` 用 `ISAAC_PY`。
- PC 端脚本里写死的个人 Windows 工作区路径换成环境变量 `G1D_WORKSPACE`（工作区根）或 `PC_TOOLS_DIR`（`pc_tools` 目录）；`pc/which_wrist_now.py` 的临时文件改到 `%TEMP%`。
- `server/tools/compose_params.py` 里写死的服务器标定包路径换成环境变量 `G1D_CALIB_PKG`（默认工具包里的 `server/g1d_calib_20261015`）。
- 所有 `.py`/`.sh` 统一为 LF、无 BOM（`replay_cups/draw_cup_targets.py`、`replay_cups/server/run_sim_planviews_1023.sh`、`server/runs/server_build_1023_sq382.sh` 的原文件带 UTF-8 BOM，已去掉；带 BOM 的 `.sh` 在 Linux 上首行 `#!/bin/bash` 会失效）。
- `extras/diagnostics/inspect_teleimager2.sh` 里检查 sudo 是否需要认证的提示文字改写（行为不变，仍是只读的 `sudo -n true`）。
- 文档里的 GPU 服务器主机名换成 `<GPU_SERVER>` / `<GPU_SERVER_2>`；原文的"5090""5090-2"是这两台服务器的代号，保留在注释和记录里。
- 其余路径（`/root/unitree_sim_isaaclab/...`、`/home/unitree/...`、`/dev/shm/...`、`/data/...`）保持原样，按下文修改。

## 0. 环境变量一览

| 变量 | 用在哪 | 含义 / 默认 |
|---|---|---|
| `ISAAC_ENV` | 所有服务器 `.sh` | unitree_sim_env conda 环境路径（必须设置） |
| `ISAAC_PY` | `build_assembly.py`、`make_urdf_variants.py` | `$ISAAC_ENV/bin/python` |
| `G1D_CALIB_NOMINAL` | `calib_model.py`（所有 import 它的脚本） | 名义资产目录（URDF + meshes + 相机合同）；默认 `/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled` |
| `G1D_CALIB_PKG` | `server/tools/compose_params.py` | `calib_model.py` 所在目录；默认 `../g1d_calib_20261015` |
| `G1D_WORKSPACE` | `pc/merge_calib_into_robodojo.py`、`compare_robodojo_cams.py`、`check_robodojo_merge.py`、`robodojo_merge/make_camera_setup.py`、`make_confirm_video.py`、`compare_render_real.py`、`wrist_camera_geometry.py`、`replay_cups/make_cups_cmp_video.py` | 原工作区根（含 `pc_tools/`、`g1d_calib_20261015/g1d_calib_20261015/`）；默认当前目录 |
| `PC_TOOLS_DIR` | `pc/head_lr_consistency.py`、`extras/diagnostics/check_charuco_legacy.py`、`detect_charuco_dict.py` | `pc_tools` 目录 |
| `BOARD_SQUARE_MM` | `make_camera_setup.py`、`refine_wrist_mount.py`、`joint_fit.py`、`refine_board_scale.py`、`refine_arm_chain.py`、`board_los.py`（经 refine_wrist_mount 的加载器） | 实测格长（mm），默认 40 —— **必须设成实测值** |
| `CALIB_PKG` | `refine_wrist_mount.py`、`joint_fit.py` 等 | 我们的 RoboDojo 包目录（含 `camera_setup_ours.json`、`g1d_dex1_calib.urdf`） |
| `CALIB_PARAMS` | `make_camera_setup.py` | 参数文件；默认 `pc_tools/replay_cups/model/params_final_1021.json`（旧版，正式用时设为 `params_final_sq382j.json`） |
| `ARM_OFFSET` | `refine_wrist_mount.py` | 设为 1：检验"整臂刚体偏移"假设 |
| `CHAIN_MODELS` | `refine_arm_chain.py` | 只跑指定的手臂链模型 |
| `WRIST_TRAIN` / `WRIST_TEST` | `joint_fit.py` | 逗号分隔的腕部会话目录（训练 / 留出） |
| `CONTOUR_EXTRA` | `contour_fit.py`（及 import 它的脚本） | 额外留出会话 `key=path,...`，例如 `1106=<10-21 会话目录>` |
| `MODELS` / `NP` | `run_joint_fit.sh` | 模型列表 / 进程数 |
| `SQ` | `pipeline_sq.sh` | 实测格长（mm），必填 |
| `SMOKE_DIR` | `smoke_calib.py`、`run_smoke.sh` | `<GPU_SERVER_2>` 上我们的合并目录 |
| `REPLAY_URDF` | `replay_cups/geom.py`（`plan2.py`、`check_*.py` 等） | 规划用的标定后上身 URDF；默认 `replay_cups/model/g1_d_upper_dex1_v4.urdf`（本包未附带，见使用手册 §8.2） |
| `TH` | `run_plan_ik.sh` | 抓取接近倾角（度），默认 35 |
| `TEMP` | 多个 PC 脚本 | 临时输出目录 |

## 1. 网络与连接

| 项 | 本机值 | 出现位置 | 怎么改 |
|---|---|---|---|
| 机器人 SSH 别名 | `unitree` | `pc/arm_client.py`、`live_capture_view.py`、`which_wrist_now.py`、所有文档命令 | PC 的 SSH 配置里设 `Host unitree`（192.168.123.164，用户 unitree，免密钥登录）。本包不含任何 SSH 配置或密钥 |
| 机器人 IP | `192.168.123.164` | `pc/` 下 `capture_intrinsics.py`、`check_wrist_view.py`、`dircheck.py`、`locate_board.py`、`pull_frames.py`、`which_wrist_cam.py`、`live_capture_view.py` 的 `HOST`/`ROBOT`；机器人本机脚本用 `127.0.0.1` | 改常量 |
| PC 在机器人网段的 IP | `192.168.123.22`（静态） | 信息 | — |
| GPU 服务器 | `<GPU_SERVER>`（代号 5090）、`<GPU_SERVER_2>`（代号 5090-2） | 只在文档里 | 用你自己的 SSH 配置；服务器端脚本都在服务器本机运行 |

## 2. 机器人端

### 2.1 DDS 与控制

| 项 | 值 | 出现位置 |
|---|---|---|
| DDS 网卡 | `ChannelFactoryInitialize(0, "eth0")` | `calib_arm_server.py`、`peek_lowstate.py`、`robot_state_check.py`、`passive_logger*.py`、`takeover_after_replay*.py`、`stop_server_for_replay.sh` 等 |
| 话题 | `rt/lowcmd`（发布）、`rt/lowstate`（订阅），unitree_hg IDL，35 个电机；Dex1：电机 31（左）、33（右），`rt/dex1/{left,right}/state` | 同上；`dex1_state.py` |
| 发布频率 | 250 Hz | `calib_arm_server.py` |
| 电机序号 | 左臂 15–21、右臂 22–28，腰 yaw 12 | `examples/joint_mapping.json` |
| 安全参数 | 限位余量 0.05 rad、单步 ≤ 1.6 rad、jog ≤ 0.1 rad、跟踪误差 0.2 rad、断流 0.5 s、`--vmax` 默认 0.1 rad/s；`waist`：\|q\| ≤ 0.5、单次 ≤ 0.6 rad | `calib_arm_server.py` |
| replay 写入者特征 | 夹爪（电机 33）kp = 5 | `stop_server_for_replay.sh` |

### 2.2 相机（ZMQ）

相机由 Unitree 的系统服务 `teleimager` 通过 pyuvc 打开并以 ZMQ PUB 推 JPEG（机器人上没有 `/dev/video*`）。客户端用 SUB + `CONFLATE`。

| 端口 | 相机（**2026-10-21 21:25 起**） | 格式 |
|---|---|---|
| 55555 | 头部双目 | 1280×480 左右拼接，左半 = head_left；定焦 |
| 55556 | **左腕**（JR0002） | 640×480 @ 30 fps；自动对焦关不掉 |
| 55557 | **右腕**（JR0001） | 640×480 @ 30 fps；自动对焦关不掉 |

10-16 ~ 10-21 21:25 之间是反的（55557 = 左腕）。本包中按新映射写死的文件：`robot/collect_robot.py`、`auto_touch.py`、`repeat_test.py`（`WRIST_PORT`）、`robot/passive_logger_cams.py`、`pc/capture_intrinsics.py`、`pull_frames.py`、`dircheck.py`、`check_wrist_view.py`、`capture_board_views.py`、`capture_left_session.py`、`robodojo_merge/make_camera_setup.py`（`physical_ports`）。**仍是旧映射或旧注释**：`examples/intrinsics/*.json` 和 `examples/joint_mapping.json` 的 `zmq_port` 字段、`extras/diagnostics/diag_cameras.py` 的注释、`pc/which_wrist_cam.py` 的标签、`extras/legacy/swap_wrist_intrinsics.py`。内参属于物理相机，数值不受影响。每次开机用 `pc/which_wrist_now.py` 复查。

### 2.3 路径

| 路径 | 用途 | 出现位置 |
|---|---|---|
| `/home/unitree/miniconda3/envs/tv/bin/python` | conda `tv` | 所有 `robot/*.sh`、`replay_cups/robot/*` 的 `PY=` |
| `~/calib_sessions/` | 脚本、日志、停止文件、会话目录；`head_intr_current.txt`（`live_capture_view.py` 读，内容是当前头部采图目录） | robot 下脚本的 `BASE`/`cd` |
| `~/calib_sessions/model/`、`intrinsics/`、`poses_20261019/` | 模型、头部内参、姿态表 | 见 10-19 版说明（原记录） |
| `~/calib_sessions/replay_cups/` | 回放交接脚本、`ready_pose_arm_q.json`、`current_run.txt`、`run_<时间>/` 记录 | `real_run*.sh`、`takeover_after_replay*.py`、`stop_server_for_replay.sh` 的 `D=` |
| `/home/unitree/g1d_infra_calib/scripts/` | `calib_arm_server.py` 所在目录 | `start_server.sh`、`takeover2.sh`、`takeover_after_replay*.py`（`SERVER_DIR`） |
| `~/g1d_infra/`（同事仓库，只读） | `scripts/run_replay.sh`（replay.py） | `replay_cups/robot/run_cups_replay.sh` |
| `/tmp/g1d_calib/` | `cmd.json`、`status.json`、`collector.lock.d/` | 服务、所有客户端 |

### 2.4 写死的实验参数

| 参数 | 值 | 出现位置 |
|---|---|---|
| 标定板 | `CharucoBoard((10, 7), 0.040, 0.030, DICT_4X4_50)` —— **名义 40 mm，这台机器人的板实测 38.2 mm** | 大多数检测脚本；支持 `BOARD_SQUARE_MM` 的见 §0；`measure_table_plane.py` 写死 `SQUARE = 0.0382` |
| 板漂移中止阈值 | 4 mm | `collect_robot.py` |
| 指尖像素 | 左腕 (309, 255)，右腕 (330, 265) | 触碰脚本命令行 |
| 腕相机焦距系数 | 0.963 | `auto_touch.py --fx-scale` |
| 回放速度 | 0.5 | `real_run_v2.sh` 的 `SPEED` |
| 交接判据 | 14 个手臂关节离 ready 位姿 < 0.08 rad、右夹爪张开 > 2.5、左夹爪闭合 < 0.8、稳定 2 s | `takeover_after_replay_v2.py` |
| 记录频率 | 三路相机各 10 Hz，最长 900 s | `real_run_v2.sh` → `passive_logger_cams.py` |

## 3. GPU 服务器端

### 3.1 Python 环境

| 环境 | 用途 |
|---|---|
| `$ISAAC_ENV`（Isaac Lab + IsaacSim 5.1，numpy/scipy/trimesh/coal/cv2） | 辨识、轮廓、联合拟合、合成、渲染、仿真 IK |
| `/usr/bin/python3` + opencv | `export_meas.py`、`dircheck_analyze.py`、`overlay_isaaclab.py`、`compare_overlay.py`、`inspect_identify.py` |
| `<GPU_SERVER_2>`：`/root/miniconda3/envs/RoboDojo/bin/python`、`PYTHONPATH=/root/RoboDojo` | `smoke_calib.py`（同事环境，只读） |

渲染/仿真脚本还用到：`LD_PRELOAD=$ENV/lib/libstdc++.so.6`、`OMNI_KIT_ACCEPT_EULA=YES`、`TMPDIR=/dev/shm/tmp`、`CUDA_VISIBLE_DEVICES=$GPU`、`--kit_args "--/renderer/activeGpu=$GPU ..."`、外层 `timeout`。默认 GPU 4（当时空闲），运行前 `nvidia-smi` 选卡。

### 3.2 路径（`R=/root/unitree_sim_isaaclab/real2sim_calib_20261015`）

| 路径 | 用途 | 出现位置 |
|---|---|---|
| `/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled/` | 名义资产（URDF + meshes） | `calib_model.py` 默认 `NOMINAL` |
| `$R/real_data/20261016/intrinsics/` | 正式内参（10-16） | `contour_fit.py`、`refine_wrist_mount.py`、`run_sim_*.sh` |
| `$R/real_data/20261019/sessions/`、`20261021/sessions/` | 设置 B 会话、测量文件 | `contour_fit.py`、`pipeline_sq.sh`、`run_joint_fit.sh` |
| `$R/real_data/20261023/` | 正式参数 `params_final_sq382c.json`、`params_final_sq382j.json` | `server_build_1023_sq382.sh`、`build_sq382j.sh` |
| `$R/assembled_calib_20261016/` | 渲染资产；`meshes/` 被符号链接到各 URDF 目录；`camera_contract_v5.json` 被 `contour_fit.py` 读取 | `contour_fit.py`、`pipeline_sq.sh` |
| `$R/assembled_calib_20261021/`、`_20261023_sq385/`、`_sq382/`、**`_sq382j/`** | 各版仿真资产（sq382j 为正式版） | 构建脚本、`run_plan_ik.sh`、`run_sim_*.sh` |
| `$R/board_scale_20261023/`（`W`） | 缩放后的测量、各格长辨识、`urdf_*`、`contour_*`、`joint_fit/` | `robodojo_merge/*.sh` |
| `$R/robodojo_g1d_calib_20261022/check/`（`D`） | 头部定位的腕部数据（`board_views_*`、`left_session_*`）和检验脚本 | `run_refine_*.sh`、`run_joint_fit.sh`、`board_plane_1023.py` |
| `$R/robodojo_g1d_calib_<版本>/` | 我们的 RoboDojo 包（`CALIB_PKG`） | 同上 |
| `$R/scratch/replay_1023/` | 叠杯规划工作目录（按 PC 工作区布局放 `pc_tools/replay_cups`） | `run_plan_ik.sh`、`run_sim_*.sh` |
| `/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam/` | 注入真实内参的标定包副本 | `identify.py` 运行目录、`contour_fit.py` 的 `sys.path` |
| `/dev/shm/isaac_work/` | `contour_fit.py`、`compose_params.py`、`contour_left_eye.py` 的位置（被 import / 调用） | `joint_fit.py`、`pipeline_sq.sh`、`build_sq382j.sh` |
| `<GPU_SERVER_2>:/data/robodojo-runs/g1d-mobile-20261021/Assets/Robots/g1d` | 同事的 RoboDojo G1-D 资产（只读复制） | 文档 |
| `<GPU_SERVER_2>:/data/g1d_calib_merge_<日期>_<版本>/` | 我们的合并目录（`SMOKE_DIR`） | `run_smoke.sh` |

### 3.3 写死的几何

- `pc/locate_board.py`、`board_timeline.py`、`table_edge.py` 写死了头部左右目在躯干系的位姿（来自 `camera_contract_v5` + FK）；右眼是**名义**安装，新流程用 `camera_setup_ours.json`。
- `server/tools/plan_jog_signs.py` 写死了方向检查的准备位姿和桌面高度。

## 4. PC 端（Windows）

| 项 | 说明 |
|---|---|
| 工作区布局 | `robodojo_merge/`、`replay_cups/` 和 `pc/` 的新脚本按 `<WS>/pc_tools/...`、`<WS>/g1d_calib_20261015/g1d_calib_20261015/` 布局查找文件；用使用手册 §0.4 的 PowerShell 片段恢复布局并设 `G1D_WORKSPACE`、`PC_TOOLS_DIR` |
| `pc/` 的老脚本 | `validate_intrinsics.py`、`touch_plan.py` 找 `<pc>/../g1d_calib_20261015/g1d_calib_20261015`（同一布局） |
| 依赖于同目录文件 | `plan_board_view.py`、`plan_left_session.py`、`analyze_board_views.py` 读同目录的 `check_robodojo_merge.py`；`replay_cups/stereo_extrinsics.py` 从上一级目录 import `calibrate_intrinsics.py`；`joint_fit.py`、`board_plane_1023.py` 读同目录的 `refine_wrist_mount.py` |
| `replay_cups/measure_table_plane.py`、`table_plane_from_outline.py` | 读 `<WS>/pc_tools/robodojo_merge_sq382j/camera_setup_ours.json` |
| Windows 专用 | `capture_intrinsics.py`、`show_board.py` 用 `ctypes.windll`；`live_capture_view.py` 用微软雅黑字体 `msyh.ttc` |
| 中文路径 | `cv2.imwrite` / `cv2.imread` 和 scp 不支持中文路径：工作区放英文路径；脚本里用 `imencode(...).tofile` / `np.fromfile` + `imdecode` |
| 视频 | `make_cups_cmp_video.py`、`make_confirm_video.py` 需要 ffmpeg（H.264） |

## 5. 常见坑

1. **PowerShell 引号和 `$`**：不要在 `ssh unitree "..."` 里写复杂 bash；写成 `.sh`、去 CRLF、`scp` 后执行。
2. **PowerShell `-match` 不区分大小写**：要区分时用 `-cmatch`。
3. **`pkill -f` 杀掉远端 shell**：模式出现在 ssh 命令行里；用 `pgrep -f '[x]xx'` 查 PID。
4. **CRLF**：Windows 上编辑过的 `.sh` 传到 Linux 前 `sed -i 's/\r$//'`。本包里的 `.py`/`.sh` 都是 LF、无 BOM。
5. **SSH 被拒**：GPU 服务器 sshd 并发限制；串行、合并脚本、退避重试。
6. **代理软件劫持内网**：TUN 模式会接管 192.168.123.0/24；关闭 TUN 或设直连。
7. **nohup 日志为空**：加 `-u`。
8. **`/dev/shm` 重启清空**：结果及时归档到 `real_data/<日期>/`。
9. **Isaac 进程不退出**：脚本结尾 `os._exit(0)`，外层 `timeout`；只杀自己的进程。
