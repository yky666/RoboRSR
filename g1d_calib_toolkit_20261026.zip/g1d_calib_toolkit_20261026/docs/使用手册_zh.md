# G1-D 真机→仿真标定：使用手册（2026-10-26 版）

本手册按实际执行顺序写出每一步的目的、输入、命令、输出、通过标准和**这台机器人上的典型数值**。典型数值只用来判断"是不是在正常范围"，换一台机器人要重新测。

- 动机器人之前先读 `安全规范_zh.md`。
- 所有写死的主机、路径、端口、环境变量及修改方法见 `环境配置_zh.md`。
- 10-20 ~ 10-26 试过什么、哪些被否决、具体数字见 `项目记录_20261020-26.md`；完整原始记录见 `项目记录_20261015-23_原始记录.md`。
- 原标定包自带的方法文档在 `server/g1d_calib_20261015/docs/00–07`，本手册在相应位置引用。

**和 10-19 版相比，推荐流程的变化**：

1. 标定板必须**用尺子量整排格子**得到实测格长，所有带尺度的步骤都用实测值（第 1 步）。这台机器人的板打印出来是 38.2 mm/格，不是 40 mm。
2. 头部右眼不再用名义安装，而是"左眼安装 + 双目标定 R、T（T 按实测格长缩放）"（第 3 步）。
3. 手臂相对头部的位置由头部图像里的手臂轮廓确定（第 6 步），再与"头部定位标定板、腕相机看板"的数据**联合拟合**（第 7 步，新方法，推荐）。
4. 最终参数用 `compose_params.py` 合成为一个相对名义 URDF 的参数文件（第 8 步），并合并到同事的 RoboDojo G1-D 资产上（第 9 步）。
5. 验收以"腕相机 vs 头部定位的板"留一检验和头部左眼轮廓为主（第 10 步）；触碰标定（10-19 版第 7 步）保留为独立检验工具。

---

## 0. 环境与安全

### 0.1 机器分工

| 机器 | 本包目录 | 运行环境 | 做什么 |
|---|---|---|---|
| 机器人（G1-D 本机，`ssh unitree`，192.168.123.164） | `robot/`、`replay_cups/robot/` | conda 环境 `tv`：numpy、scipy、opencv-contrib（带 `cv2.aruco.CharucoDetector`）、pyzmq、unitree_sdk2py | 手臂控制服务、采集、头部内参采图、被动记录、回放交接 |
| GPU 服务器（原文代号 5090，记作 `<GPU_SERVER>`） | `server/`、`robodojo_merge/` 中标"服务器"的脚本、`replay_cups/server/` | Isaac Lab + IsaacSim 5.1 的 conda 环境 `$ISAAC_ENV`（unitree_sim_env）；`/usr/bin/python3` + cv2 | 导出、辨识、轮廓对齐、联合拟合、合成参数、构建资产、渲染、仿真 IK 规划 |
| 第二台 GPU 服务器（原文代号 5090-2，记作 `<GPU_SERVER_2>`） | `robodojo_merge/smoke_calib.py`、`run_smoke.sh` | 同事的 RoboDojo 环境（`/root/RoboDojo`、conda `RoboDojo`），只读使用 | 用同事的机器人配置加载我们的标定资产做冒烟测试 |
| PC（Windows） | `pc/`、`robodojo_merge/` 中标"PC"的脚本、`replay_cups/` | ssh、Python 3.12 + numpy/scipy/opencv-contrib/pyzmq/Pillow | 内参采图与求解、相机配置、合并 RoboDojo 资产、杯子定位、规划、出视频 |

数据流（推荐流程）：

```text
实测格长 s (mm) ──────────────┬──────────────────────────────┬─────────────────────────┐
相机内参（第 2 步） ───────────┤                              │                         │
双目 R,T（第 3 步，T×s/40）────┤                              │                         │
采集会话（第 4 步）→ export_meas → scale_meas(s) → identify.py(dual_trans) → apply_calibration
                                                                        │
                       contour_fit.py（头部轮廓，肩部安装，第 6 步，二次拟合）
                                                                        │
            compose_params → params_final_sq382c → merge/make_camera_setup（RoboDojo 包，第 9 步）
                                                                        │
     joint_fit.py（头部轮廓 + 头部定位的腕部看板，第 7 步）→ build_sq382j.sh → params_final_sq382j
                                                                        │
           build_assembly（Isaac 资产）+ merge_calib_into_robodojo + make_camera_setup（第 8、9 步）
                                                                        │
         验收：refine_wrist_mount 留一 / contour_left_eye / smoke_calib（第 10 步）→ 应用（第 11 步）
```

### 0.2 部署到机器人

目录约定（脚本里写死，见 `环境配置_zh.md` §2）：

```text
~/calib_sessions/                   # robot/ 下的脚本、日志、会话数据
~/calib_sessions/model/             # calib_model.py + g1_d_upper_dex1_v4.urdf + camera_contract_v5.json
~/calib_sessions/poses_<日期>/      # 姿态表、scene_header_B.json
~/calib_sessions/replay_cups/       # replay_cups/robot/ 下的回放交接脚本 + ready_pose_arm_q.json
~/g1d_infra_calib/scripts/          # calib_arm_server.py（start_server.sh 等写死的位置）
/tmp/g1d_calib/                     # 服务的 cmd.json / status.json（重启后消失）
```

在 PC 上执行（工具包放在**纯英文路径**下：scp 和 OpenCV 都处理不了中文路径；本地普通复制没有问题）：

```bash
ssh unitree "mkdir -p ~/calib_sessions/model ~/calib_sessions/replay_cups ~/g1d_infra_calib/scripts"
scp robot/*.py robot/*.sh unitree:~/calib_sessions/
scp robot/calib_arm_server.py unitree:~/g1d_infra_calib/scripts/
scp replay_cups/robot/* unitree:~/calib_sessions/replay_cups/
scp server/g1d_calib_20261015/calib_model.py server/g1d_calib_20261015/nominal/g1_d_upper_dex1_v4.urdf server/g1d_calib_20261015/nominal/camera_contract_v5.json unitree:~/calib_sessions/model/
ssh unitree "sed -i 's/\r$//' ~/calib_sessions/*.sh ~/calib_sessions/replay_cups/*.sh"
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/check_env.py"     # 期望 aruco True CharucoDetector True
```

### 0.3 部署到 GPU 服务器

服务器目录（详见 `环境配置_zh.md` §3）：

```text
/root/unitree_sim_isaaclab/real2sim_g1d_20261015/assembled/       # 名义资产（URDF + meshes）
/root/unitree_sim_isaaclab/real2sim_calib_20261015/  (= $R)       # 标定包本体、real_data/<日期>/、各版资产 assembled_calib_*
$R/board_scale_20261023/  (= $W)                                  # 实测格长重建、联合拟合（joint_fit/）
$R/robodojo_g1d_calib_<版本>/                                     # 我们的 RoboDojo 包（含 camera_setup_ours.json、g1d_dex1_calib.urdf）
$R/robodojo_g1d_calib_20261022/check/  (= $D)                     # 头部定位的腕部看板数据（board_views_*、left_session_*）
/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam/       # 注入真实内参的标定包副本（identify.py 在这里运行）
/dev/shm/isaac_work/                                              # 临时工作目录（重启清空）
```

1. 标定包、真实内参副本按 10-19 版做法部署（`server/tools/inject_real_intrinsics_patch.py`，见原记录）。
2. 环境变量：

   ```bash
   export ISAAC_ENV=<unitree_sim_env 路径>  ISAAC_PY=$ISAAC_ENV/bin/python
   export G1D_CALIB_PKG=/root/unitree_sim_isaaclab/real2sim_calib_20261015    # compose_params.py 用
   ```

3. 把下列脚本放到 `/dev/shm/isaac_work/`（运行脚本按这个位置 import）：`server/tools/contour_fit.py`、`server/tools/compose_params.py`、`robodojo_merge/contour_left_eye.py`；把 `robodojo_merge/scale_meas.py`、`summarize_scan.py`、`diff_scan_params.py` 放到 `$W/`；把 `robodojo_merge/refine_wrist_mount.py`、`joint_fit.py`、`refine_*.py`、`board_los.py`、`head_contour_armoff.py` 放到 `$D/`（`run_joint_fit.sh` 会把前两个拷到 `$W/joint_fit/`）。
4. 单元测试：`cd $R && $ISAAC_PY test_apply_calibration.py`，应 6/6 通过。

### 0.4 PC 端工作区布局

`robodojo_merge/` 和 `replay_cups/` 里的 PC 端脚本（以及 `pc/` 里的新脚本）是按原工作区布局写的：`<WS>/pc_tools/<脚本>`、`<WS>/pc_tools/replay_cups/`、`<WS>/pc_tools/robodojo_merge/`、`<WS>/g1d_calib_20261015/g1d_calib_20261015/`（标定包）。打包时把写死的个人路径换成了环境变量 `G1D_WORKSPACE`（工作区根）和 `PC_TOOLS_DIR`。从工具包恢复这个布局（PowerShell）：

```powershell
$KIT = "D:\g1d_calib_toolkit_20261026"; $WS = "D:\g1d_ws"        # 都用英文路径
New-Item -ItemType Directory "$WS\pc_tools\calib_data\intrinsics", "$WS\g1d_calib_20261015" -Force | Out-Null
Copy-Item -Recurse "$KIT\server\g1d_calib_20261015" "$WS\g1d_calib_20261015\g1d_calib_20261015"
Copy-Item "$KIT\pc\*.py" "$WS\pc_tools\"
Copy-Item -Recurse "$KIT\replay_cups", "$KIT\robodojo_merge" "$WS\pc_tools\"
Copy-Item -Recurse "$KIT\examples\robodojo_merge_sq382j" "$WS\pc_tools\robodojo_merge_sq382j"
Copy-Item "$KIT\examples\intrinsics\*.json" "$WS\pc_tools\calib_data\intrinsics\"
New-Item -ItemType Directory "$WS\pc_tools\replay_cups\model" -Force | Out-Null
Copy-Item "$KIT\examples\params_20261023\params_final_1021.json" "$WS\pc_tools\replay_cups\model\"   # make_camera_setup.py 的默认 CALIB_PARAMS（旧版，正式用时用环境变量覆盖）
$env:G1D_WORKSPACE = $WS; $env:PC_TOOLS_DIR = "$WS\pc_tools"
```

### 0.5 机器人使能和手臂控制服务

1. 遥控器：开机等约 1 分钟进入零力矩 → `L2+B` 阻尼 → `L2+R2` 调试模式（不要进 `R2+A` 主运控）。
2. 只读检查：

   ```bash
   ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/peek_lowstate.py"       # lowstate 频率、mode_machine、关节角
   ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/robot_state_check.py"   # 1.5 s 内 rt/lowcmd 写入者、腰/臂/夹爪位置
   ```

   **每次开机先看腰部 yaw（电机 12，`all_q[12]`）**：10-20 重启后腰停在 0.31 rad（上半身歪约 18°），10-21 停在 −1.2°。
3. 启动服务（保持当前实测位姿，不运动）：`ssh unitree "bash ~/calib_sessions/start_server.sh"`，输出有 `server ready` 才算成功。
4. 腰部回正：`cd pc && python waist_to.py 0`（服务的 `waist` 指令：最小加加速度、0.1 rad/s、|q| ≤ 0.5、单次 ≤ 0.6 rad）。
5. 双臂：下垂 → 全 0 用 `python raise_to_zero2.py`；全 0 → 下垂（让出头部相机下部视场）用 `python lower_arms.py`。
6. 结束时**不要随手 kill 服务**（没有 rt/lowcmd 写入者时手臂会掉下来）；先把手臂放到安全位姿，按安全规范 §3 处理。

### 0.6 相机端口（2026-10-21 21:25 起变化）

| 端口 | 相机 | 说明 |
|---|---|---|
| 55555 | 头部双目 | 1280×480 左右拼接，左半 = head_left，定焦 |
| 55556 | **左腕**（序列号 JR0002） | 640×480，自动对焦关不掉 |
| 55557 | **右腕**（序列号 JR0001） | 640×480，自动对焦关不掉 |

10-16 ~ 10-21 21:25 期间是反的（55557 = 左腕），那段时间的会话数据和 `examples/intrinsics/*.json` 里的 `zmq_port` 字段按旧映射记录；内参本身属于物理相机，不受影响。本包里的采集脚本已改成新映射。teleimager 的配置可能再变，**每次开机后**用 `pc/which_wrist_now.py`（微动右腕 yaw，看哪个端口的画面在动）复查。

### 0.7 安全要点（详见 `安全规范_zh.md`）

- 有人守急停；同一时间只能有一个程序写 rt/lowcmd（两个写入者长时间并存手臂会抖）；`kill -9` 控制程序 = 手臂掉落。
- 不停止、不修改相机服务 teleimager；不用 sudo；不改同事仓库。
- 远程结束进程不要用 `pkill -f <模式>`，模式会匹配到 ssh 命令行本身，把远端 shell 一起杀掉；用 `pgrep -f '[x]xx'` 查到 PID 再精确处理。

---

## 1. 标定板制作与实测格长

**这是 10-26 版最重要的一课**：这台机器人的 A3 ChArUco 板按 40 mm 设计，实际打印出来是 **38.2 mm/格**（10 格总长约 382 mm）。所有用到绝对尺度的步骤都必须用实测格长。

### 1.1 规格与打印

- A3 ChArUco，10×7 格（9×6 = 54 个内角点），名义格长 40 mm、码边 30 mm，字典 `DICT_4X4_50`（ID 0–34）。
- 打印时选 **"实际大小 / 100%"**，不要选"适合页面""缩放到纸张"。打印后贴在约 6 mm 厚的硬纸板或更硬的板上，**用胶带固定在桌面**。软板弯曲是剩余误差来源之一。

### 1.2 测量（必须做）

1. 用钢尺沿长边量**整排 10 格**的总长 L₁₀（从第一格外边到第十格外边），短边量 7 格总长 L₇ 作交叉检查。
2. 实测格长 s = L₁₀ / 10（mm）；L₇ / 7 应与之一致（差 > 0.2 mm 说明板被拉伸或量错）。
3. **不要只量一个黑格**：10-23 上午量单个黑格得到 38.5 mm，下午量 10 格才得到 38.2 mm，两次重建的结果不同。
4. 把 s 记在会话记录里；下文记 `SQ=38.2`、比例 k = s / 40 = 0.955。

### 1.3 哪些步骤受格长影响

| 类型 | 脚本 / 结果 | 处理 |
|---|---|---|
| 与尺度无关 | 相机内参 K / 畸变；dual_trans 辨识的残差、留出误差、关节角（38.0/38.5/39.0/40.0 mm 逐位相同，关节角变化 < 0.001°）；腕相机焦距修正（−16/−17 px 是真实的自动对焦效应） | 不用改 |
| 有参数，传实测值 | `robodojo_merge/scale_meas.py <in> <out> 38.2`；`make_camera_setup.py`、`refine_wrist_mount.py`、`joint_fit.py`、`refine_board_scale.py` 的环境变量 `BOARD_SQUARE_MM=38.2`；`pc/calibrate_intrinsics.py --square-mm`；`replay_cups/fit_cups.py --stereo-scale 0.955`；`replay_cups/measure_table_plane.py`（常量 `SQUARE = 0.0382`） | 必须传 |
| 写死 40 mm | `export_meas.py`（导出后用 `scale_meas.py` 改）、`pc/locate_board.py`、`robot/locate_board_robot.py`、`board_timeline.py`、`gen_poses.py`、`collect_robot.py`（板漂移监控）、`auto_touch.py` / `contact_point.py`（触碰板面坐标） | 单目 PnP 得到的平移乘 k；换板或换机器人时建议把常量改成实测值 |

### 1.4 格长错了会怎样（这台机器人上的实际影响）

- **dual_trans 辨识**：残差和留出误差完全一样，尺度误差全部被腕相机安装平移吸收（38.2 mm 时两侧各往后约 5.7 mm）和几组不可观的关节平移吸收，所以**从辨识残差上看不出来**。
- **头部双目基线**：40 mm 时 61.3 mm，按 38.2 mm 缩放后 58.6 mm（设计值 59.6 mm）。
- **头部单目 PnP 深度**：按 40 mm 计算会把板测远 4.7%（0.65 m 处约 3 cm）。10-19/10-21 触碰中"头部测得的板面比触碰面高约 1 cm"的遗留问题由此得到解释。
- **怎么发现的**：头部定位板后，腕相机看板差 17–24 px（1.5–2 cm）；把所需修正分解到头部视线方向，近似和距离成正比（2.4–3.1%），双目标定基线也比设计值大 2.8%，于是去量板。

---

## 2. 相机内参

方法见包文档 `01_camera_intrinsics_zh.md`。内参与板尺度无关；只有双目平移 T（基线）与尺度有关（第 3 步处理）。

### 2.1 头部（含底部视场覆盖）

旧的头部内参（10-16，棋盘格）在图像下部 1/4 视场里是外推的，而手臂恰好多出现在下部。10-23 用手持 ChArUco 重新采图并覆盖下部视场：

1. 双臂放下让出下部视场：`cd pc && python lower_arms.py`。
2. 机器人上启动采图（直接读本机 ZMQ 55555，6×4 网格覆盖状态写到 `status.txt`；`touch <out>/STOP` 或 `--minutes` 结束）：

   ```bash
   ssh unitree "echo ~/calib_sessions/head_intr_1023 > ~/calib_sessions/head_intr_current.txt"
   ssh unitree "cd ~/calib_sessions && setsid nohup ~/miniconda3/envs/tv/bin/python -u head_intr_capture.py --out ~/calib_sessions/head_intr_1023 --minutes 20 > head_intr.log 2>&1 < /dev/null &"
   ```

3. PC 上打开实时窗口（读机器人头部流 + 覆盖网格，绿 = 已覆盖、红 = 还缺，并提示板往哪里放；只读，`q`/`Esc` 关闭）：`python pc/live_capture_view.py`。一人举板，按提示把每只眼的网格填满，**特别是下部两行**。
4. 机器人上求解（逐眼 calibrateCamera、5 折留出、按图像条带对比新旧内参，下部条带 = 行 ≥ 360）：

   ```bash
   ssh unitree "cd ~/calib_sessions && ~/miniconda3/envs/tv/bin/python head_intr_calib.py ~/calib_sessions/head_intr_1023 ~/calib_sessions/intrinsics"
   ```

   输出在采图目录：`camera_intrinsics_head_{left,right}.json`、`head_stereo_extrinsics.json`、`head_recalib_report.json`。
5. PC 上联合比较两套数据（参数标准差、交叉残差）：`python pc/joint_head_calib.py <含 stereo_*.json 的目录> joint_head.json`。

**这台机器人的结论**：新采 39 帧，主点与旧内参相差约 7 px，说明主点本身定得不好；但换用新内参对手臂–头部相对关系没有影响（轮廓与腕部检验不变）。**新头部内参没有采用**，正式结果仍用 10-16 内参（`examples/intrinsics/`）。

### 2.2 腕部

```bash
cd pc
python capture_intrinsics.py left_wrist 70      # 端口按 0.6 节新映射（55556 = 左腕）
python capture_intrinsics.py right_wrist 70
python -u calibrate_intrinsics.py all           # 留出 RMS ≤ 1.3 × 训练 RMS；std < 0.5 px
python validate_intrinsics.py
```

- 自动对焦关不掉（teleimager 用 pyuvc 打开相机）。采集限定在 0.2–0.55 m；辨识时 `--refine-intrinsics` 吸收整体焦距偏差（`intrinsics:*_wrist/fx` ≈ −16/−17 px）；评估时每个会话单独估一个焦距比例（这台机器人 0.92–1.0）。
- 用单张图逐样本估焦距再"补偿"的做法会让误差变大（`extras/abandoned/af_correct.py`），不要用。

**典型数值**：头部 fx ≈ 279.3 / 279.8，RMS 0.46 / 0.48 px，留出 0.35 / 0.34 px；左腕 fx ≈ 315.7、右腕 ≈ 313.0，RMS 0.44–0.51 px。

---

## 3. 头部双目外参与右眼安装

**问题**：相机合同 `camera_contract_v5.json` 里右眼是名义安装（与左眼平行、基线 59.6 mm），左右眼对桌面板的位姿估计相差约 5 mm。
**做法**：所有测量以左眼为参考；右眼安装 = 左眼安装 × 双目标定的 R、T，其中 T 按实测格长缩放。

1. 双目 R、T（固定内参的 stereoCalibrate，5 折标准差）：

   ```powershell
   cd $env:PC_TOOLS_DIR\replay_cups
   python stereo_extrinsics.py        # 读 calib_data/intrinsics/head 的内参采图（本包未附带图像）→ out/head_stereo_extrinsics.json
   ```

   结果按 40 mm 板计算：58 对，stereoRMS 0.49 px，T = (−61.35, 0.11, 1.16) mm，旋转约 0.58°。本包附带这个文件（`replay_cups/out/head_stereo_extrinsics.json`）。
2. 生成相机配置（每路相机的父 link、最终安装、最终 K/畸变，已叠加辨识出的 `camera:*`、`intrinsics:*` 增量）：

   ```powershell
   $env:CALIB_PARAMS = "$env:PC_TOOLS_DIR\robodojo_merge_sq382j\params_final_sq382j.json"
   $env:BOARD_SQUARE_MM = "38.2"
   python $env:PC_TOOLS_DIR\robodojo_merge\make_camera_setup.py camera_setup_ours.json
   ```

   右眼平移 × 38.2/40 → 基线 58.6 mm。输出格式 `g1d_camera_setup_v1`，样例 `examples/robodojo_merge_sq382j/camera_setup_ours.json`。
3. 检查左右眼一致性：`python pc/head_lr_consistency.py <头部双目图> ...`（逐张图比较左眼、名义右眼、双目标定右眼得到的板位姿）。

**注意**：Isaac 资产自带的 `camera_contract_v5.json` 里右眼**仍是名义安装**；仿真里用右眼时一律以 `camera_setup_ours.json` 为准。

---

## 4. 运动学数据采集

### 4.1 设置 B：腕相机看桌面板（与 10-19 版相同）

测板（头部双目 PnP，**平移乘 k**）→ 服务器 `gen_poses.py --min-clear 0.10` 生成姿态表 → 机器人后台队列 `run_queue.sh` 采集。每个样本同时记录全部编码器、5 帧腕相机、1 帧头部双目。命令与筛选规则见 10-19 版手册（原记录 10-16 ~ 10-19 节）和 `server/runs/gen_v2.sh`、`gen_1020.sh`、`gen_1021.sh`。

```bash
ssh unitree "cd ~/calib_sessions && ~/miniconda3/envs/tv/bin/python locate_board_robot.py"      # → board_locate_now/board_pose.json
# 服务器：OPENBLAS_NUM_THREADS=8 $ISAAC_PY gen_poses.py --board-json board_pose.json --table-z <z> --table-edge-x <x> --idle-zero --min-clear 0.10 --out $R/real_data/<日期>/poses
ssh unitree "setsid nohup bash ~/calib_sessions/run_queue.sh left right > /dev/null 2>&1 < /dev/null &"
ssh unitree "tail -n 20 ~/calib_sessions/queue.log"
```

这台机器人正式使用的会话：10-19 `calib_20261019_1209/1509_..._left`、`1533_..._right`（辨识训练），10-21 `calib_20261021_1106_..._right`（跨天留出）。**会话里的头部帧是第 6、7 步的数据来源**，必须保留。

### 4.2 头部定位的腕部看板会话（第 7、10 步用）

板固定在桌上、头部测板位姿；手臂从全 0 位姿做小幅腕部调整，让腕相机看到板。每个姿态同时存头部帧、两路腕部帧和实测关节角，输出 `captures.json`（`refine_wrist_mount.py` / `joint_fit.py` 读取）。

```powershell
cd $env:PC_TOOLS_DIR
# 1) 规划（标定后的 RoboDojo URDF + 我们的相机；板位姿来自头部双目，两眼平均）
python plan_board_view.py  <RoboDojo 包目录> board_pose.json board_view_plan.json      # 双臂一起
python plan_left_session.py <RoboDojo 包目录> board_pose.json left_session_plan.json   # 只动左臂，0.28–0.42 m、≥ 48 个角点
# 2) 采集（经 arm_client 驱动 calib_arm_server；每个姿态等完成；结束回全 0）
python capture_board_views.py  board_view_plan.json  board_views_<日期>
python capture_left_session.py left_session_plan.json left_session_<日期>
```

样例：`examples/board_check_20261022/`（板位姿、两个计划、`captures.json`）。这台机器人的数据：10-22 `board_views_20261022`（双臂）、`left_session_20261022`（左臂 18 姿态），10-23 `board_views_1023`、`left_session_1023`。采完把目录传到服务器 `$D/`。

---

## 5. 双臂辨识 dual_trans（导出时写入实测格长）

**目的**：从腕相机看板数据估计手臂内部几何（关节零位、rot_v、关节原点平移 3 mm 先验）、腕相机外参、腕相机内参修正、板位姿；两臂共享同一块板时，右肩相对左肩的安装也可辨识。

### 5.1 导出 + 写入实测格长

```bash
cd /dev/shm/isaac_work
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015; S=$R/real_data/20261019/sessions; W=$R/board_scale_20261023
/usr/bin/python3 export_meas.py --session $S/calib_20261019_1509_B_wrist_table_board_left \
    --header $R/real_data/20261019/poses_v2/scene_header_B.json --board-name table_pm --out $S/meas_B_left_1509_pm.json
$ISAAC_PY $W/scale_meas.py $S/meas_B_left_1509_pm.json $W/meas_B_left_1509_pm_sq382.json 38.2
```

`scale_meas.py` 把测量文件里板的 `square_length_m` 改为实测值（并记录 `scaled_from_square_m`）。同一块板、机器人和板都没动时，两臂用同一个 `--board-name`（10-19 的 1509 左臂与 1533 右臂都用 `table_pm`）。

### 5.2 辨识

```bash
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
$ISAAC_PY identify.py $W/meas_B_left_1209_sq382.json $W/meas_B_left_1509_pm_sq382.json $W/meas_B_right_1533_pm_sq382.json \
    --preset auto --refine-intrinsics \
    --estimate 'left_*_joint/d*' 'right_*_joint/d*' --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' \
    --loss soft_l1 --f-scale 1.0 --folds 5 --out $W/identify_dual_trans_sq382.json --params-out $W/params_dual_trans_sq382.json
```

一条命令完成"缩放 → 辨识 → URDF → 轮廓二次拟合 → 合成"的脚本是 `robodojo_merge/pipeline_sq.sh`（`SQ=38.2 bash pipeline_sq.sh`，见第 6 步）。

### 5.3 格长扫描（可选，用来确认尺度不可观）

```bash
bash robodojo_merge/run_dual_trans_scan.sh            # 38.0 / 38.5 / 39.0 / 40.0 mm 并行辨识
$ISAAC_PY $W/summarize_scan.py $W                      # 每个格长的残差、留出、腕相机内参修正和安装平移
$ISAAC_PY $W/diff_scan_params.py $W/params_dual_trans_sq400.json $W/params_dual_trans_sq385.json   # 哪些参数随格长变化
```

**结果**：各格长的拟合残差和 5 折留出逐位相同，关节角变化 < 0.001°；变化的是腕相机安装平移（38.2 mm 时约 5.7 mm）和几组 std 17–21 mm 的关节平移（只由 3 mm 先验决定，不可观）。所以 dual_trans **本身定不了尺度**，必须靠实测格长。

**典型数值**（10-19 数据）：残差约 5 px，留出约 6 px，零位都在 1° 以内，腕相机 fx 修正 −16/−17 px。参数样例：`examples/params_20261023/params_dual_trans_sq382.json`（第 8 步合成时也是 `camera:*`、`intrinsics:*` 的来源）。

---

## 6. 头部轮廓对齐肩部安装

**原因**：dual_trans 只用腕相机看板、板位姿自由，只约束手臂内部几何，约束不了手臂相对头部的绝对位置（整条手臂连同板一起平移不改变腕部观测）。给导出加头部看板观测（`extras/abandoned/server_heads_1020.sh`）也不行：竖直方向上手臂平移、腕相机沿光轴平移和自动对焦焦距几乎分不开，叠图反而差 20–30 px。**必须让头部相机直接看手臂。**

**方法**（`server/tools/contour_fit.py`）：把手臂网格（肩 roll 到腕 yaw，不含夹爪：URDF 夹爪与真机不同）按 FK 投影到头部左右眼，与真实图像边缘做带方向的倒角匹配（Canny 边缘按梯度方向分 8 组，截断二次代价 5 px；靠近夹爪、另一只手臂、图像边缘的轮廓点不计）。Powell 优化每只手臂肩 pitch 关节坐标系的 6 个参数（零位、rot_u、rot_v、dx、dy、dz）。数据：10-19 三次会话的头部图，训练 1509 + 1533，1209 留出；`CONTOUR_EXTRA="1106=<10-21 会话目录>"` 加跨天留出。

```bash
cd /dev/shm/isaac_work
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CONTOUR_EXTRA="1106=$R/real_data/20261021/sessions/calib_20261021_1106_B_wrist_table_board_right"
$ISAAC_PY $R/apply_calibration.py $W/params_dual_trans_sq382.json $W/urdf_dual_trans_sq382
ln -s $R/assembled_calib_20261016/meshes $W/urdf_dual_trans_sq382/meshes                      # 投影需要网格
# 第一遍：叠加 10-20 的肩部安装（examples/params_20261023/params_contour_mount_1020.json）
$ISAAC_PY $R/apply_calibration.py params_contour_mount_1020.json $W/urdf_contour_sq382 --nominal $W/urdf_dual_trans_sq382
# 第二遍：从上一次的安装出发再拟合一个增量
$ISAAC_PY -u contour_fit.py fit $W/contour_sq382c $W/urdf_contour_sq382/g1_d_upper_dex1_v4.urdf both mount
# 评分（任意多个 URDF 变体）
$ISAAC_PY -u contour_fit.py eval $W/contour_sq382c sq382c=$W/urdf_contour_sq382c/g1_d_upper_dex1_v4.urdf
$ISAAC_PY -u contour_left_eye.py sq382c=$W/urdf_contour_sq382c/g1_d_upper_dex1_v4.urdf             # 只用左眼（与右眼安装无关）
```

上面这串由 `SQ=38.2 bash robodojo_merge/pipeline_sq.sh` 一次完成（含把拟合结果写成增量参数、`apply_calibration --nominal` 叠加、`compose_params.py` 合成 `params_final_sq382c.json`、评分）。

- **二次拟合要从上一次的安装出发**：几何变了以后从零开始的 Powell 会停在更差的局部极小（38.5 mm 版的右臂就是这样，见 `contour_sq385.sh` 与 `contour_sq385c.sh`）。
- 每个视角约 57 ms，每只手臂约 3 分钟（`extras/diagnostics/contour_timing.py`）。
- `mountzeros`（再放开 5 个零位）在 10-20 训练集 1.75 → 1.64 px、留出 2.16 → 2.16 px 不变，不采用。

**典型数值**（中位轮廓偏差）：10-20（40 mm）左 训练 1.75 / 留出 2.16 px，右 1.34 / 1.75 px（名义 3.26 / 4.90、4.96 / 4.25）；两肩 rot_u 都约 −2.1°。38.2 mm 重建（sq382c）左 1.75 / 留出 2.21 px，右 1.75 px。

**局限**：只看头部轮廓时，不可观的关节平移会挪动网格，轮廓对齐再通过肩部安装把整条腕相机链带偏 1–2 cm（sq382c 的腕部–头部检验：左 13–16 px、右 14–19 px）。这就是第 7 步联合拟合要解决的问题。

---

## 7. 联合拟合（新方法，推荐）

**思路**：每只手臂同时拟合两类数据——头部图像里的手臂轮廓（第 6 步的代价）和"头部定位标定板、腕相机看板"的重投影（板位姿由头部双目测得，角点经手臂 FK 投影到腕相机；每个会话一个闭式求解的焦距比例，吸收自动对焦）。前者约束网格位置，后者约束腕相机链，两者一起才能把不可观的关节平移定下来。

**前提**（实际执行顺序是 5 → 6 → 8 → 9 → 7 → 8 → 9）：

- 基础几何：第 6 步输出的 `urdf_contour_sq382c`。
- 基础几何对应的 RoboDojo 包（第 9 步）：`CALIB_PKG=$R/robodojo_g1d_calib_sq382_20261023`，里面要有 `camera_setup_ours.json`（右眼 = 双目标定安装）和 `g1d_dex1_calib.urdf`。
- 头部定位的腕部数据：设置 B 会话（含头部帧）+ 第 4.2 节的 `captures.json` 会话。

**参数与模型**（`robodojo_merge/joint_fit.py`，增量叠加在基础 URDF 上）：

| 模型 | 参数 | 结论 |
|---|---|---|
| `mount` | 肩 pitch 坐标系 6 个 | 不够 |
| `mount_trans` | + 肩 roll..腕 yaw 6 个关节的 dx/dy/dz（18 个，3 mm 先验），共 24 个 | **采用** |
| `mount_trans_rotu` | + 同样 6 个关节的 rot_u（1° 先验） | 没有改善 |
| `mount_trans_rotu_cam` | + 腕相机安装 6 个 | 腕部再降 1–2 px，但右臂 10-21 头部轮廓变差到 3.06 px，过拟合，不采用 |

**命令**（服务器）：

```bash
MODELS=mount,mount_trans,mount_trans_rotu,mount_trans_rotu_cam NP=30 bash robodojo_merge/run_joint_fit.sh
#   内部：BOARD_SQUARE_MM=38.2 CALIB_PKG=... WRIST_TRAIN=<会话,...> WRIST_TEST=<会话,...> \
#         $ISAAC_PY -u joint_fit.py <left|right> <基础 URDF> <out.json> <进程数> <模型,...>
#   左臂训练：10-19 1509 + 10-22 left_session；左臂留出：10-19 1209、10-22 board_views、10-23 board_views、10-23 left_session
#   右臂训练：10-19 1533 + 10-22 board_views；右臂留出：10-21 1106、10-23 board_views
bash robodojo_merge/build_sq382j.sh
#   取两臂 mount_trans 的参数 → params_joint_delta_sq382.json → apply_calibration --nominal urdf_contour_sq382c
#   → compose_params.py（相机/内参增量取自 params_dual_trans_sq382.json）→ params_final_sq382j.json
#   → contour_fit.py eval（sq382c vs sq382j）→ build_assembly.py → assembled_calib_20261023_sq382j/
```

输出 `joint_left.json` / `joint_right.json`（每个模型的参数、可读值、每个会话的腕部 rms/中位数/焦距比例、头部轮廓分数），样例在 `examples/robodojo_merge_sq382j/`。

**结果**（腕相机 vs 头部定位的板，rms px；拟合前 13–19 px）：

| 手臂 | 训练 | 留出 |
|---|---|---|
| 左 | 6.7（10-19 1509）/ 3.0（10-22 18 姿态） | 6.5（10-19 1209）/ 5.8（10-22 远处）/ 5.1（10-23 远处）/ 4.5（10-23 18 姿态） |
| 右 | 5.4（10-19 1533）/ 4.9（10-22） | 5.8（10-21 1106）/ 8.1（10-23） |

在 0.3–0.4 m 工作距离上约 5–9 mm。头部轮廓（只用左眼，中位）：左 1.75 / 留出 1209 2.86 / 1106 1.75 px，右 1.75 / 1.51 / 2.26 px（sq382c：1.82 / 2.69 / 2.05、1.75 / 2.20 / 2.49）。独立复核：`refine_wrist_mount.py` 用新包重算，与联合拟合一致。

**剩余误差来源**：腕相机自动对焦（各批焦距比例 0.92–1.0，仿真固定焦距跟不上）、关节间隙、软板、头部深度不确定度。10-19 两批近距离多姿态数据仍约 6.5 px。

---

## 8. 合成参数与构建资产

### 8.1 compose_params.py（`server/tools/`）

分步构建的标定 URDF（例如 dual_trans → 轮廓安装 → 联合拟合增量，每步都是 `apply_calibration.py --nominal <上一步 URDF>`）最后要合成为**一个相对名义 URDF 的参数文件**：对每个关节求解使原点等于最终 URDF 原点的关节参数，`camera:*` / `intrinsics:*` 增量从源参数文件复制，再用 20 组随机关节角做 FK 校验（差 < 1e-9）。

```bash
export G1D_CALIB_PKG=$R            # calib_model.py 所在目录；默认是工具包里的 server/g1d_calib_20261015
$ISAAC_PY /dev/shm/isaac_work/compose_params.py $W/urdf_joint_sq382/g1_d_upper_dex1_v4.urdf \
    $W/params_dual_trans_sq382.json $W/params_final_sq382j.json
# 期望输出：106 values; max |FK(nominal + params) - FK(final URDF)| = ~1e-15
```

打包时在 Windows 上用本包文件做过往返检查：`apply_calibration.py` 由 `params_final_sq382j.json` 生成 URDF，再用 `compose_params.py` 合成，106 个值与原文件最大差 6e-16。

### 8.2 apply_calibration.py / build_assembly.py（`server/g1d_calib_20261015/`）

```bash
cd $R
$ISAAC_PY apply_calibration.py <params.json> <out_dir> [--nominal <基础 URDF 目录>]   # 只改关节 origin，生成 upper + full
nohup $ISAAC_PY build_assembly.py $R/real_data/20261023/params_final_sq382j.json assembled_calib_20261023_sq382j --gpu <N> \
    > logs/build_calib_20261023_sq382j.log 2>&1 &                                     # USD + 物理合同 + 相机合同 + 校验
```

- 约定：`q_model = q_encoder + zero` 写进关节原点，关节名、轴、限位不变，真机关节角可以直接回放。
- 回归检查（包文档 07 §3）：`test_apply_calibration.py` 6/6；USD 关节系与 URDF 差约 1e-8 m；`server/tools/regress_summary.py <asset_dir>` 看与名义资产的差异（只应有被标定的 14 个手臂关节原点、连杆位姿和 PhysX 推导的等效惯量）；`server/tools/limits_check.py <asset_dir>` 看限位与自碰撞设置；`server/tools/check_urdf_vs_params.py` 核对 URDF 与"名义 + 参数"的 FK。
- 模板：`server/runs/server_build_1023_sq382.sh`（sq382c 资产）、`robodojo_merge/build_sq382j.sh`（正式 sq382j）。不要覆盖已有资产目录（脚本发现目录已存在会退出）。

**正式结果**：参数 `params_final_sq382j.json`（相对名义 URDF 共 106 项，`examples/robodojo_merge_sq382j/`），服务器资产 `assembled_calib_20261023_sq382j/`。在 PC 上需要标定后的上身 URDF 时（例如第 11 步的 `REPLAY_URDF`），用本包重建即可：

```powershell
python server\g1d_calib_20261015\apply_calibration.py examples\robodojo_merge_sq382j\params_final_sq382j.json out_urdf_sq382j --nominal server\g1d_calib_20261015\nominal
```

---

## 9. 合并到 RoboDojo G1-D 资产与相机配置

同事的 RoboDojo G1-D（官方 G1-D URDF + 团队的 Dex1-1 + 重做的腕相机模块 + 升降柱、腰、底盘）在 `<GPU_SERVER_2>:/data/robodojo-runs/g1d-mobile-20261021/Assets/Robots/g1d`。**只读复制**一份到本地或我们的服务器后合并：

```powershell
# 1) URDF：把我们标定后上身 URDF 里存在的关节原点写进他们的 URDF（只变 14 个手臂关节；其余与名义 v4 相同）
python pc\merge_calib_into_robodojo.py <他们的资产目录> out_urdf_sq382j\g1_d_upper_dex1_v4.urdf `
    examples\robodojo_merge_sq382j\params_final_sq382j.json robodojo_g1d_calib_sq382j_<日期>
# 2) 相机：我们自己的相机配置（右眼 = 双目标定安装；第 3 步）
$env:CALIB_PARAMS = "...\params_final_sq382j.json"; $env:BOARD_SQUARE_MM = "38.2"
python robodojo_merge\make_camera_setup.py robodojo_g1d_calib_sq382j_<日期>\camera_setup_ours.json
```

- 产物：`g1d_dex1_calib.urdf`（桌面版，根 `AGV_link`，轮子锁定）、`g1d_mobile_dex1_calib.urdf`（加虚拟平面底盘关节 `base_x/base_y/base_yaw`）、`camera_setup_ours.json`、参数文件；`meshes/`、`physics_contract.json` 沿用他们的。说明见 `examples/robodojo_merge_sq382j/README.md`。
- `merge_calib_into_robodojo.py` 还会写 `{left,right}_robot_config_calib.yml`（同事格式的相机定义），**正式使用时不用它们**，相机一律用 `camera_setup_ours.json`。
- 腰、升降柱、底盘没有标定（数据都在腰 0、升降柱固定时采集）。
- Isaac 针孔相机不能表达畸变：仿真用 K 的主点（光圈偏移），与去畸变后的真机图比较。腕相机 fx 只在 0.2–0.4 m 对焦范围内有效。
- 检查工具：`pc/compare_robodojo_urdf.py`（他们的手臂链是否与我们的名义链一致）、`pc/compare_robodojo_cams.py`（他们的相机安装 vs 我们的合同）、`pc/check_robodojo_merge.py <资产目录> <输出目录>`（头部/腕部视角里的手臂、夹爪轮廓）、`robodojo_merge/render_check_ours.py`（我们的服务器上渲染四路相机并核对连杆位姿）。

这台机器人的包：`robodojo_g1d_calib_sq382j_20261023/`（`<GPU_SERVER>`）、`/data/g1d_calib_merge_20261023_sq382j/`（`<GPU_SERVER_2>`）。

---

## 10. 验收

### 10.1 腕部–头部留一检验（主要指标）

板位姿由头部双目测得（两眼、全部样本、剔除离群；板动过的会话按样本），腕相机内参 = 棋盘格 K/畸变 + 每个会话一个焦距比例；留一会话：其余会话拟合，留出会话只拟合自己的焦距比例。

```bash
cd $D
export OPENBLAS_NUM_THREADS=2 BOARD_SQUARE_MM=38.2 CALIB_PKG=$R/robodojo_g1d_calib_sq382j_20261023
S19=$R/real_data/20261019/sessions
LEFT="$S19/calib_20261019_1209_B_wrist_table_board_left $S19/calib_20261019_1509_B_wrist_table_board_left $D/board_views_20261022 $D/left_session_20261022 $D/board_views_1023 $D/left_session_1023"
$ISAAC_PY -u refine_wrist_mount.py left $D/sq382j_mount_left.json $LEFT
ARM_OFFSET=1 $ISAAC_PY -u refine_wrist_mount.py left $D/sq382j_armoff_left.json $LEFT      # 假设：整条手臂一个刚体偏移
```

模板：`robodojo_merge/run_pkg385.sh`、`run_refine_1023.sh`。输出里 `current_rms_px` 是当前包不加修正的误差，`loso` 是留一结果。

| 会话（* = 未参与拟合） | 正式 10-21（40 mm） | sq382 | **sq382j** |
|---|---|---|---|
| 左 10-19 1509 / 1209* | 23.9 / 22.5 | 14.6 / 13.4 | 6.7 / 6.5 |
| 左 10-22 远处* / 18 姿态 | 23.6 / 18.4 | 15.1 / 14.0 | 5.8 / 3.0 |
| 左 10-23 远处* / 18 姿态* | 22.4 / 17.4 | 16.2 / 13.9 | 5.1 / 4.5 |
| 右 10-19 / 10-21* | 13.5 / 12.8 | 15.2 / 15.0 | 5.4 / 5.8 |
| 右 10-22 / 10-23* | 3.6 / 6.6 | 13.7 / 18.9 | 4.9 / 8.1 |

（10-21 版右腕远处 3.6 / 6.6 px 是误差恰好抵消，不代表那一版更好。）

### 10.2 头部左眼轮廓

```bash
cd /dev/shm/isaac_work && $ISAAC_PY -u contour_left_eye.py sq382c=<urdf> sq382j=<urdf>
```

只用左眼（所有测量的参考相机），比较结果与右眼安装无关。sq382j：左 1.75 / 留出 2.86（1209）/ 1.75（1106）px，右 1.75 / 1.51 / 2.26 px。头部视角约 2 px ≈ 3 mm。

### 10.3 `<GPU_SERVER_2>` 冒烟测试（同事环境）

用同事自己的机器人配置（`env.robot_manager.robot_config.g1d.get_robot_config(mobile=True)`，不修改，只把资产路径和 USD 缓存重定向到我们的副本）加载标定后的移动版 G1-D，保持一个真机记录的姿态，检查物理稳定性、仿真连杆位姿与我们 FK 的差，并渲染。

```bash
# 在 <GPU_SERVER_2> 上，我们自己的目录里（同事代码只读 import）
SMOKE_DIR=/data/g1d_calib_merge_20261023_sq382j bash run_smoke.sh <gpu>      # 日志 $SMOKE_DIR/check/smoke.log
```

通过标准：25 个关节、FK 差 0.000 mm、物理稳定。sq382、sq382j 都已通过。

### 10.4 确认片段（可选）

`pc/confirm_motion.py`（经服务器做一段从下垂到全 0、腰回正、双臂前抬再回 0 的动作）+ `robot/passive_logger_cams.py` 记录 → `robodojo_merge/make_confirm_traj.py` → `render_confirm.py`（服务器渲染）→ `make_confirm_video.py`（真机｜仿真对比视频）→ `confirm_metrics.py`（头部轮廓指标）。10-22（params_final_1021）的结果：手臂轮廓 6.0/5.0 → 2.0/2.0 px，RoboDojo 夹爪在头部视角 5.2/3.1 → 2.8/2.2 px，腕部视角手指 12.2/4.0 → 3.9/2.8 px（右/左；交付原样 → 加我们的标定）。

### 10.5 实测精度与局限（截至 2026-10-23）

| 项 | 结果 |
|---|---|
| 头部视角手臂轮廓 | 约 1.5–2.9 px（≈ 2–4 mm） |
| 腕相机 vs 头部定位的板 | 留出 4.5–8.1 px，0.3–0.4 m 处约 5–9 mm |
| 手臂内部几何（10-19 左臂触碰交叉验证，40 mm 时代） | 名义 5.3 → dual_trans 1.6 mm |
| 叠杯任务（第 11 步） | 真机一次成功 |

局限：腕相机自动对焦（焦距比例 0.92–1.0）、关节间隙、软板、头部深度不确定度；腰、升降柱、底盘未标定；资产自带相机合同的右眼是名义安装；仿真相机无畸变。

被否决的假设（都用留一会话检验，见 `项目记录_20261020-26.md`）：整臂刚体偏移（`ARM_OFFSET=1`）、关节零位 / 连杆原点 / 重力柔性（`refine_arm_chain.py`，`run_arm_chain*.sh`）、只调腕相机安装、头部看板联合辨识（heads_1020）、轮廓 + 零位（mountzeros）、联合拟合加 rot_u 或腕相机安装。`refine_board_scale.py` 检验"板尺寸不对"这一假设（把头部推得的角点绕双目中心缩放），它提示了尺度问题，但格长数值一律以尺子实测为准。

---

## 11. 应用示例：仿真 IK 规划 + 真机回放 + 三路录像（双臂叠杯）

任务：左手捏左杯沿口放到汇合点 M，右手抓右杯举到上方插入（两只纸杯：沿口 8.2 cm、杯底 6.9 cm、高 14.2 cm）。2026-10-23 真机运行成功，杯子套上。

### 11.1 桌面平面与杯子定位（PC，`replay_cups/`）

```powershell
cd $env:PC_TOOLS_DIR\replay_cups
python measure_table_plane.py 10              # 头部看桌上的板（格长 38.2 mm、正式相机配置），打印 --board-c / --board-n
python table_plane_from_outline.py head.png --size 1.2,0.6     # 或：用已知 1.2 × 0.6 m 桌面轮廓求桌面平面
python fit_cups.py --frames head_now_1.png,head_now_2.png,head_now_3.png --board-c x,y,z --board-n nx,ny,nz `
    --stereo-scale 0.955 --seed-uv u1,v1,u2,v2      # → out/cups.json（左右约 ±3 mm，前后/高度约 ±6 mm）
python draw_cup_targets.py head.png targets.png  # 把目标杯位画在头部图上，方便摆杯
```

`--stereo-scale 0.955` = 38.2/40（10-16 的双目 R、T 是按 40 mm 板标的）；`--seed-uv` 给左眼图里两只杯身的大致像素。样例：`examples/replay_cups_20261023/cups.json`。

### 11.2 规划（numpy 部分在 PC，IK 在 GPU 服务器）

```powershell
$env:REPLAY_URDF = "<标定后上身 URDF，见 8.2>"
python check_cup_spots.py ; python check_grasp_reach.py      # 抓取可达性（IK 残差 mm + deg，< 1 可达）
python plan2.py findm                                        # → out/m_search.json
python choose_m.py                                           # 打印 "x,y yawL,yawR"
```

```bash
# 服务器：Isaac Lab DifferentialIKController（阻尼最小二乘，PhysX 雅可比，和 scene3_pour_pack 的控制器相同）代替 plan2.py 的 numpy IK
bash replay_cups/server/run_plan_ik.sh <gpu> _1023ik       # 内部：plan_sim_ik.py --urdf <sq382j upper URDF> --th ${TH:-35} ...
#   正式运行要加 --seq（两臂完全顺序执行）；把 --m x,y --yaw l,r 传给 plan_sim_ik.py 可跳过 findm
bash replay_cups/server/run_sim_1023.sh <gpu> _1023ik      # 物理仿真检查（sim_cups.py：桌面按头部测得的法向倾斜，空心锥台纸杯）
```

**必须用 `--seq`**：两臂同时动时手臂之间只有 2–5 mm 间隙。10-23 实际执行的计划是 `examples/replay_cups_20261023/plan2_1023s.json`。仿真里被捏住的杯子会绕捏点歪 15–20°（刚性薄壁杯模拟不了纸杯），这是接触/材料建模问题，不是运动学问题。

### 11.3 真机回放（机器人；回放程序是同事的 replay.py，原样运行）

```bash
# 前提：我们的 calib_arm_server 在运行并保持 ready 位姿；episode 目录已拷到机器人；有人守急停
ssh unitree "bash ~/calib_sessions/replay_cups/real_run_v2.sh start <episode_dir>"
#   启动被动记录（passive_logger_cams.py：头部 + 两路腕部各 10 Hz，并订阅 rt/lowstate、rt/lowcmd）
#   在 tmux 会话 cups 里运行 replay.py，停在 "Replay? [y/N]"（此时 replay 已在发布保持指令）
ssh unitree "bash ~/calib_sessions/replay_cups/real_run_v2.sh go <episode_dir>"
#   stop_server_for_replay.sh：只读确认 replay 的写入者在发布（夹爪 kp = 5 的特征）后，kill -9 我们的服务
#   （不能用 SIGINT/SIGTERM：服务会先回到启动位姿），再确认 replay 是唯一写入者
#   takeover_after_replay_v2.py：等到计划的终态稳定后启动我们的服务保持 ready 位姿，一报 server ready 就 kill -9 replay.py
ssh unitree "bash ~/calib_sessions/replay_cups/real_run_v2.sh status"     # 回放画面、记录、交接日志、三路帧数
ssh unitree "bash ~/calib_sessions/replay_cups/real_run_v2.sh abort"      # 在回放终端按 q（replay 保持 1 s 后停止发布！）
```

v1（`real_run.sh` + `takeover_after_replay.py`，10-21）的教训：交接脚本提前约 20 s 启动，两个写入者（重力前馈和夹爪 kp 不同）交替生效，末段手臂抖动；v1 还只录了头部。v2 把重叠缩短到 1 s 以内，并录三路相机。

### 11.4 真机 vs 仿真视频（PC + 服务器）

```powershell
python make_sim_traj.py <记录目录> sim_traj                    # 真机实测关节 + 指令夹爪 → sim_traj.npz/.json
python make_plan_sim_traj.py <记录目录> traj2.npz plan_sim_traj  # 或：计划轨迹按真机时间对齐
python frames_to_videos.py <记录目录> videos                    # 三路原始录像
```

```bash
bash replay_cups/server/run_sim_views_1023.sh <gpu>       # sim_cups_views.py：每帧渲染我们的三路相机（camera_setup_ours.json）
bash replay_cups/server/run_sim_planviews_1023.sh <gpu>
```

```powershell
python make_cups_cmp_video.py <记录目录> sim_traj.json <仿真帧目录> camera_setup_ours.json cups_cmp.mp4   # 行：头部左/左腕/右腕；列：真机｜仿真
```

---

## 12. 常见问题与教训

| 现象 / 场景 | 原因 | 做法 |
|---|---|---|
| 腕相机看板与头部测的板差 1.5–2 cm，误差随距离增大 | 板实际格长不是 40 mm | 第 1 步量整排格子；所有尺度步骤用实测值 |
| dual_trans 残差在任何格长下都一样 | 尺度被腕相机安装平移和不可观的关节平移吸收 | 不要用辨识残差判断尺度 |
| 只用头部轮廓对齐后腕部–头部仍差 13–19 px | 不可观的关节平移挪动网格，肩部安装把整链带偏 | 用第 7 步联合拟合 |
| 从零开始的轮廓拟合结果变差 | Powell 停在局部极小 | 二次拟合从上一次的安装出发 |
| 左右眼对板位姿差约 5 mm | 合同右眼是名义安装 | 右眼 = 左眼 + 双目 R、T（T × k） |
| 头部单目测距偏远约 4.7% | PnP 用了 40 mm | 平移乘 k，或改常量 |
| 新头部内参主点差 7 px | 主点定不好 | 不影响手臂–头部关系，未采用新内参 |
| 腕部端口与记忆不符 | teleimager 配置 10-21 21:25 变了 | `which_wrist_now.py` 复查 |
| 头部帧是 1280×480 一张图 | 左右拼接 | 左半 = head_left，右半 = head_right |
| 远程 `pkill -f xxx` 后 ssh 断开、别的东西也没了 | 模式匹配到 ssh 命令行本身，远端 shell 被杀 | 用 `pgrep -f '[x]xx'` 查 PID 再处理 |
| PowerShell 里 `-match` 误匹配大小写不同的字符串 | `-match` 默认不区分大小写 | 需要区分时用 `-cmatch` |
| 手臂突然掉下来 | 没有任何 rt/lowcmd 写入者（服务被 kill -9、replay 退出、abort 后 1 s） | 交接用 `takeover2.sh` / `real_run_v2.sh`，先确认新写入者在发布 |
| 回放末段手臂抖 | 两个写入者长时间并存 | v2 交接，重叠 < 1 s |
| 相机全黑或端口没数据 | 有人动了 teleimager | 不要停/改 teleimager；找机器人负责人 |
| 双臂同时动时差点相碰 | 两臂间隙 2–5 mm | 规划用 `--seq` |
| scp / OpenCV 报路径错误 | 中文路径 | 工作目录用英文路径；本地复制不受影响 |
| 腰歪着、上半身不正 | 开机后腰停在非零位置，服务启动时锁住当前位置 | 先看 `all_q[12]`，`waist_to.py 0` |
| ssh 连接 GPU 服务器被拒 | sshd 并发限制 | 串行、合成脚本一次执行、退避重试 |
| nohup 日志为空 | Python 输出缓冲 | 加 `-u` |
| Isaac 进程不退出、占 GPU | `app.close()` 卡死 | 脚本用 `os._exit(0)`，外层套 `timeout` |

## 附录 A：常用监控命令

```bash
ssh unitree "cut -c1-220 /tmp/g1d_calib/status.json; echo"
ssh unitree "pgrep -af '[c]alib_arm_server.py|[c]ollect_robot.py|[a]uto_touch.py|[r]un_queue.sh|[t]eleop.replay|[p]assive_logger'"
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/robot_state_check.py"
ssh unitree "tail -n 30 /tmp/g1d_calib_server.log"
```

## 附录 B：文件格式速查

| 格式 | 产生 | 主要字段 |
|---|---|---|
| `g1d_camera_intrinsics_v1` | `calibrate_intrinsics.py`、`head_intr_calib.py` | K, dist, intrinsics_sigma, rms_px, heldout_rms_px, zmq_port |
| `g1d_calib_measurements_v1` | `export_meas.py`、`scale_meas.py` | cameras, boards（square_length_m、scaled_from_square_m）, samples |
| `g1d_calib_params_v1` | `identify.py`、`compose_params.py` | values, std, values_deg_for_reading, sources |
| `g1d_camera_setup_v1` | `make_camera_setup.py` | views.{name}.parent / T_parent_camera_world_convention / K / dist_k1k2p1p2k3 / port, physical_ports |
| joint_fit 结果 | `joint_fit.py` | side, board_square_mm, wrist_train/test, baseline, models.{m}.params/wrist/contour/readable |
| captures.json | `capture_board_views.py`、`capture_left_session.py` | 每个姿态的关节角、头部/腕部帧文件 |
| head_stereo_extrinsics | `stereo_extrinsics.py`、`head_intr_calib.py` | R_right_from_left, T_right_from_left_m（按采图时的板尺寸）, fold_std_* |
