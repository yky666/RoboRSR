# G1-D 真机→仿真标定工具包（2026-10-26 版）

这个工具包用来标定 Unitree G1-D 机器人（轮式底盘 + 升降柱 + 两条 7 自由度手臂 + Dex1 夹爪 + 头部双目相机 + 左右腕相机），让 IsaacSim 里用的 URDF / USD 资产和真机一致：仿真里求出的关节轨迹原样发给真机，得到同样的位姿；仿真相机看到的画面和真机相机对得上。

> 先读 `docs/安全规范_zh.md` 再动机器人。`examples/` 里的数据只适用于原来那台机器人。

## 本版相对 10-19 版的变化

**新方法**

1. **标定板实测格长**：A3 ChArUco 板按 40 mm 设计，实际打印 38.2 mm/格（10 格约 382 mm）。内参与尺度无关；dual_trans 辨识对格长完全不敏感（残差、留出逐位相同），尺度误差被腕相机安装平移（约 5.7 mm）和不可观的关节平移吸收；头部双目基线 61.3 → 58.6 mm；头部单目测距偏远 4.7%，解释了 10-19/10-21 约 1 cm 的竖直偏差。所有带尺度的步骤改用实测格长（`robodojo_merge/scale_meas.py`、`pipeline_sq.sh`、环境变量 `BOARD_SQUARE_MM`）。
2. **头部内参重采（覆盖下部视场）**：`robot/head_intr_capture.py` + `pc/live_capture_view.py` + `robot/head_intr_calib.py` + `pc/joint_head_calib.py`。结论：主点定不好（新旧差约 7 px），但不影响手臂–头部关系，**新内参未采用**。
3. **头部右眼 = 左眼安装 + 双目标定 R、T**（T 按实测格长缩放）：`robodojo_merge/make_camera_setup.py` → `camera_setup_ours.json`。
4. **头部图像手臂轮廓确定肩部安装**：`server/tools/contour_fit.py`，二次拟合从上一次的安装出发。
5. **腕相机 vs 头部定位的板（留一会话检验）**：`robodojo_merge/refine_wrist_mount.py` 等，及一系列被否决的假设（整臂偏移、关节零位、连杆原点、重力柔性）。
6. **联合拟合（推荐）**：`robodojo_merge/joint_fit.py` 每臂同时拟合头部轮廓与头部定位的腕部看板数据，参数 = 肩部安装 6 + 肩 roll..腕 yaw 的 dx/dy/dz 18（3 mm 先验）。腕部误差从 13–19 px 降到训练 3.0–6.7 px、留出 4.5–8.1 px（0.3–0.4 m 处约 5–9 mm）。
7. **合成参数与资产**：`server/tools/compose_params.py`（相对名义 URDF 的单一参数文件），正式结果 `params_final_sq382j.json`（106 项）、资产 `assembled_calib_20261023_sq382j`。
8. **合并到同事的 RoboDojo G1-D 资产**：`pc/merge_calib_into_robodojo.py` + `camera_setup_ours.json`；在第二台 GPU 服务器上用同事的配置冒烟测试通过（25 关节、FK 差 0.000 mm）。
9. **应用验证：双臂叠杯**：仿真器 IK 规划（`replay_cups/server/plan_sim_ik.py`）、真机回放 + 无缝交接 + 三路录像（`replay_cups/robot/real_run_v2.sh`）。2026-10-23 真机成功，杯子套上。

**被取代 / 弃用**（文件仍附带，在 `MANIFEST.md` 标"已弃用"）

- 参数 `params_dual_trans_1019`、`params_final_1021`（40 mm）、`params_final_sq382c`（只用头部轮廓定肩部安装）→ 被 `params_final_sq382j` 取代。
- 38.5 mm 版重建（`rebuild_sq385.sh`、`contour_sq385*.sh`、`run_square385.sh`、`run_pkg385.sh`、`extras/superseded/server_build_1023_sq385.sh`）：格长量错（只量了一个黑格）。
- 头部看板联合辨识 `server_heads_1020.sh`、双目分割手臂、夹爪小板（设置 A）→ `extras/abandoned/`。
- 叠杯回放 v1（`real_run.sh` + `takeover_after_replay.py`）：两个写入者重叠约 20 s 导致末段抖动。
- 腕部端口：**2026-10-21 21:25 起 55556 = 左腕、55557 = 右腕**，10-19 版文档里的映射已过时。

## 这台机器人目前的结果（2026-10-23，正式版 sq382j）

| 指标 | 结果 |
|---|---|
| 头部视角手臂轮廓（只用左眼，中位） | 左 1.75 / 留出 2.86、1.75 px；右 1.75 / 留出 1.51、2.26 px |
| 腕相机 vs 头部定位的板（rms） | 左 训练 6.7 / 3.0，留出 6.5 / 5.8 / 5.1 / 4.5 px；右 训练 5.4 / 4.9，留出 5.8 / 8.1 px |
| 资产校验 | USD 关节系与 URDF 差 1e-8 m；单元测试 6/6；RoboDojo 冒烟测试通过 |
| 应用 | 双臂叠杯真机一次成功 |
| 剩余误差来源 | 腕相机自动对焦（焦距比例 0.92–1.0）、关节间隙、软板、头部深度 |

## 目录

```text
README_zh.md              本文件
MANIFEST.md               每个文件一行：用途、运行位置、状态（核心 / 辅助 / 诊断 / 已弃用）
SHA256SUMS.txt            所有文件的 SHA-256
docs/
  使用手册_zh.md           完整流程（第 0–12 节）：命令、通过标准、典型数值、常见问题
  安全规范_zh.md           安全规则（含控制权交接、两个写入者、kill 规则）
  环境配置_zh.md           写死的主机/路径/端口、环境变量、修改方法
  项目记录_20261020-26.md  10-20 ~ 10-26 整理版记录：试过什么、采用什么、否决什么
  项目记录_20261015-23_原始记录.md   原始工作记录（脱敏副本）
robot/                    机器人上运行：手臂控制服务、采集、头部内参采图、状态检查、被动记录
pc/                       Windows PC：内参、相机检查、头部定位的腕部看板会话、RoboDojo 合并
server/
  g1d_calib_20261015/     标定包本体：误差模型、辨识、写回 URDF、构建资产、方法文档 docs/00–07
  tools/                  服务器工具：导出、轮廓对齐 contour_fit.py、合成 compose_params.py、渲染、检查
  runs/                   实际用过的服务器运行脚本（模板）
robodojo_merge/           新方法：格长扫描与重建、腕部–头部检验、联合拟合、RoboDojo 相机配置与冒烟测试
replay_cups/              应用示例：杯子定位、规划（含 server/ 仿真 IK）、真机回放交接（robot/）、对比视频
examples/                 小 JSON 样例：正式参数、相机配置、联合拟合结果、腕部看板会话格式、叠杯计划等
extras/                   已弃用 / 被取代 / 旧版 / 诊断脚本，附说明
skills/g1d-robot-calibration/   Cursor Agent Skill（已更新为新流程）
```

## 快速开始

1. **准备**：按 `docs/环境配置_zh.md` 设置 `ISAAC_ENV`、`ISAAC_PY`、`G1D_CALIB_PKG`；PC 上配好 `ssh unitree`，按使用手册 §0.4 恢复工作区布局并设 `G1D_WORKSPACE`、`PC_TOOLS_DIR`（都用英文路径）。
2. **量板**：钢尺量整排 10 格，算实测格长（使用手册 §1）。之后所有步骤用 `BOARD_SQUARE_MM=<实测值>`。
3. **使能**：遥控器 `L2+B` → `L2+R2` 调试模式；`peek_lowstate.py`、`robot_state_check.py`（看腰部 `all_q[12]` 和 rt/lowcmd 写入者）；`start_server.sh`；`which_wrist_now.py` 复查腕部端口。
4. **标定**：内参（§2）→ 双目 R、T 与右眼（§3）→ 采集（§4）→ dual_trans（§5，写入实测格长）→ 头部轮廓（§6）→ 合成 + RoboDojo 包（§8、§9）→ **联合拟合**（§7）→ 再合成、构建资产（§8、§9）→ 验收（§10）。
5. **应用**：§11 的叠杯示例展示了"头部定位物体 → 仿真 IK 规划 → 真机回放 → 三路录像对比"的完整链路。

不动手臂、只看工具包是否完整：

```bash
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/check_env.py"
ssh unitree "~/miniconda3/envs/tv/bin/python ~/calib_sessions/robot_state_check.py"
python server/g1d_calib_20261015/apply_calibration.py examples/robodojo_merge_sq382j/params_final_sq382j.json out_urdf_sq382j --nominal server/g1d_calib_20261015/nominal
python server/tools/compose_params.py out_urdf_sq382j/g1_d_upper_dex1_v4.urdf examples/params_20261023/params_dual_trans_sq382.json composed.json   # 应复现 106 个值
```

（后两条需要 numpy、scipy；`compose_params.py` 和 `apply_calibration.py` 读名义 URDF 时用环境变量 `G1D_CALIB_NOMINAL` 指向 `server/g1d_calib_20261015/nominal`。）

## 让 AI Agent 操作

把 `skills/g1d-robot-calibration/` 拷到 `~/.cursor/skills/`（个人）或项目的 `.cursor/skills/`。Skill 里写了安全铁律（含控制权交接和进程管理规则）、新流程清单、监控与恢复方法；它要求 Agent 在任何会让手臂运动的操作前先征得用户许可。

## 没有包含的内容

- 名义资产网格（`nominal/meshes/`，约 17 MB STL）、RoboDojo 资产网格、各版仿真资产（USD）、标定后的 URDF（可用 `apply_calibration.py` 由参数重建）。
- 图像、会话、渲染、视频等大数据；头部内参重采的图像和结果（未采用）。
- 第三方 SDK（unitree_sdk2_python）、同事的仓库 g1d_infra 和 RoboDojo。
- 任何 SSH 密钥、SSH 配置、口令、公网服务器地址。

完整的排除清单和原因见 `MANIFEST.md` 末尾。
