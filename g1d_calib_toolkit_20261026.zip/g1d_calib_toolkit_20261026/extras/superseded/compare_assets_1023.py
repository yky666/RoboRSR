# compare_assets_1023.py -- assembled_calib_20261021 vs assembled_calib_20261023_sq385: validation flags and cameras
import json

import numpy as np

R = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/"
A, B = R + "assembled_calib_20261021/", R + "assembled_calib_20261023_sq385/"
for f in ("source_validation.json",):
    a, b = json.load(open(A + f)), json.load(open(B + f))
    fa = sorted(k for k, v in a["checks"].items() if not v)
    fb = sorted(k for k, v in b["checks"].items() if not v)
    print(f, "passed", a["passed"], b["passed"], "| failing checks identical:", fa == fb, len(fa), len(fb))
ca = {v["name"]: v for v in json.load(open(A + "camera_contract_v5.json"))["views"]}
cb = {v["name"]: v for v in json.load(open(B + "camera_contract_v5.json"))["views"]}
for n in ca:
    ta, tb = np.array(ca[n]["T_parent_camera_world_convention"]), np.array(cb[n]["T_parent_camera_world_convention"])
    print(f"{n:12s} pos 1021 {np.round(ta[:3, 3] * 1000, 2).tolist()} sq385 {np.round(tb[:3, 3] * 1000, 2).tolist()} "
          f"moved {np.linalg.norm(tb[:3, 3] - ta[:3, 3]) * 1000:.2f} mm")
