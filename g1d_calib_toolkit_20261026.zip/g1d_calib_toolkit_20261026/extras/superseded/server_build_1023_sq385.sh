#!/bin/bash
# official sim asset with the measured printed board square (38.5 mm, not 40): params_final_sq385c = dual_trans
# identified on the rescaled board (board_scale_20261023) + contour shoulder mounts refitted on that geometry;
# same build as server_build_1021.sh
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
P=$R/real_data/20261023/params_final_sq385c.json
mkdir -p $R/real_data/20261023
[ -e $P ] || cp $R/board_scale_20261023/params_final_sq385c.json $P
cd $R
mkdir -p logs
[ -e assembled_calib_20261023_sq385 ] && { echo "assembled_calib_20261023_sq385 exists, not overwriting"; exit 1; }
nvidia-smi --query-gpu=index,memory.used --format=csv,noheader | sed -n '5p'
$PY build_assembly.py $P assembled_calib_20261023_sq385 --gpu 4 > logs/build_calib_20261023_sq385.log 2>&1
echo "BUILD_EXIT=$?"
tail -n 5 logs/build_calib_20261023_sq385.log
