#!/bin/bash
# compose the final params (relative to the nominal URDF) and build the calibrated sim asset (doc 07)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
P=$R/real_data/20261021/params_final_1021.json
cd $R
$PY /dev/shm/isaac_work/compose_params.py $R/scratch/urdf_variants_20261020/contour/g1_d_upper_dex1_v4.urdf \
    $R/real_data/20261019/sessions/params_dual_trans_1019.json $P || exit 1
mkdir -p logs
[ -e assembled_calib_20261021 ] && { echo "assembled_calib_20261021 exists, not overwriting"; exit 1; }
nvidia-smi --query-gpu=index,memory.used --format=csv,noheader | sed -n '5p'
$PY build_assembly.py $P assembled_calib_20261021 --gpu 4 > logs/build_calib_20261021.log 2>&1
echo "BUILD_EXIT=$?"
tail -n 5 logs/build_calib_20261021.log
