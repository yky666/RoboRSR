# extras：已弃用、被取代、旧版和诊断用脚本

这里的脚本**不属于推荐流程**，保留下来是为了说明"试过什么、为什么不这样做"，或者排查时偶尔有用。运行前先看文件开头的注释，很多脚本带有当时的服务器路径和日期目录。

## abandoned/（被否决的方案）

| 文件 | 原来做什么 | 为什么弃用 |
|---|---|---|
| `server_heads_1020.sh`、`server_overlay_1020.sh` | 10-20：导出时加头部看板观测，头部外参固定、两肩安装放开联合辨识 | 交叉验证残差好看（腕部 3.1–4.1 px、头部 0.4–0.6 px），但投影叠图里手臂低 20–30 px：竖直方向手臂平移、腕相机沿光轴平移、自动对焦焦距几乎分不开。改用头部轮廓（`contour_fit.py`）和联合拟合（`joint_fit.py`） |
| `stereo_arm_mask.py` | 10-20：用双目深度分割手臂 | 银色手臂和白色桌面纹理太少，视差大片空洞 |
| `make_gripper_board.py` | 10-20：夹爪上贴 14×11 cm 小板让头部看（设置 A） | 用户指出会碰到本体，且姿态没把小板放进碰撞模型 |
| `af_lock_server.py`（机器人） | 替代 teleimager 自己打开相机锁定腕相机对焦 | 需要停系统服务，**用户明确拒绝** |
| `touch_teach.py`、`touch_identify.py`、`touch_targets_image.py` | 手动示教触碰 | 改为全自动 `robot/auto_touch.py` |
| `af_correct.py`、`per_sample_focal.py`、`server_left_afc.sh` | 逐样本估焦距"补偿"自动对焦 | 残差从 ~5 px 升到 8–10 px |
| `render_sim.py`、`setup_isaac_env.sh` | IsaacSim 5.0 自装 + URDF 导入渲染 | 机器人从未出图；改用服务器现成 Isaac Lab |
| `analyze_misalign.py` | 自动边缘匹配判断叠图错位来源 | 受底盘和地毯纹理干扰，不可靠 |

## superseded/（被 10-23 的正式版取代）

| 文件 | 被什么取代 | 说明 |
|---|---|---|
| `server_build_1021.sh` | `robodojo_merge/build_sq382j.sh` | 10-21 正式资产（板按 40 mm） |
| `server_build_1023_sq385.sh` | 同上 | 38.5 mm 版资产（只量了一个黑格，格长不准） |
| `compare_assets_1023.py` | — | 10-21 与 sq385 资产的校验项和相机比较 |

`robodojo_merge/` 里 38.5 mm 版的重建与检验脚本（`rebuild_sq385.sh`、`contour_sq385*.sh`、`run_square385.sh`、`run_pkg385.sh`）以及 10-22 的第一轮腕部修正（`run_refine_wrist.sh`、`run_refine_left2.sh`、`run_refine_both_v2.sh`）也已被取代，但因为与同目录的脚本互相引用，留在原目录，在 `MANIFEST.md` 标"已弃用"。

## legacy/（被新版本取代）

| 文件 | 被什么取代 |
|---|---|
| `collect.py`（PC） | `robot/collect_robot.py` + `run_queue.sh`（本机后台，连接断了也不受影响） |
| `go_home.py`（PC） | `robot/go_home.py`（`--via`、`--near`、`--dry`） |
| `takeover.sh`（机器人） | `robot/takeover2.sh`。旧版没确认新实例存活就结束旧进程，正是 10-19 12:05 失控事故的做法，**不要再用** |
| `add_home_ok.py` | `server/tools/gen_poses.py` |
| `swap_wrist_intrinsics.py` | 10-16 一次性修正 |
| `raise_to_zero.py`（PC） | `pc/raise_to_zero2.py` |

## diagnostics/（只读诊断）

| 文件 | 在哪跑 | 做什么 |
|---|---|---|
| `head_scale_check.py` | PC | 双目三角测量量板格距 vs 40 mm（6 cm 基线下 ±3–5%，当时没结论；后来证实板是 38.2 mm） |
| `contour_timing.py` | 服务器 | `contour_fit.py` 单视角耗时和网格大小 |
| `diag_cameras.py`、`diag_cameras.sh` | 机器人 | 三路相机流 / 设备序列号诊断；**注释里的端口是 10-21 21:25 之前的映射** |
| `inspect_teleimager.sh`、`inspect_teleimager2.sh`、`grep_teleimager.sh` | 机器人 | 只读查看 teleimager（`inspect_teleimager2.sh` 用 `sudo -n true` 只检查是否需要认证，不提权） |
| `list_cams.sh`、`usb_perm.sh` | 机器人 | 视频设备和 USB 权限 |
| `read_arm_q.py` | 机器人 | 读一次手臂关节角 |
| `residual_vs_torque.py` | 服务器 | 残差与力矩相关性（弱，\|r\| ≤ 0.3） |
| `check_charuco_legacy.py`、`detect_charuco_dict.py` | PC | 判断板的字典和 legacy 设置（需 `PC_TOOLS_DIR`） |
| `compare_motors.py` | PC | 35 个电机位置与会话开始对比 |
| `show_board.py`、`test_detect_once.py` | PC | 屏幕显示 ChArUco、单次检测测试 |
