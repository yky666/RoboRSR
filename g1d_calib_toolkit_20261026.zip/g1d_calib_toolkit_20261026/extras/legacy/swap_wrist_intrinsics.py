# swap_wrist_intrinsics.py -- fix swapped wrist camera names (verified 2026-10-16 by jogging left wrist_yaw:
# ZMQ port 55557 is the LEFT wrist camera, 55556 the RIGHT one; g1d_infra names them the other way round).
# The intrinsics labelled "left_wrist" were computed from port-55556 images, i.e. the right wrist camera.
import json
import shutil
from pathlib import Path

D = Path(__file__).parent / "calib_data" / "intrinsics"
BK = D / "backup_before_wrist_swap_20261016"
BK.mkdir(exist_ok=True)
old = {}
for name in ("left_wrist", "right_wrist"):
    p = D / f"camera_intrinsics_{name}.json"
    shutil.copy2(p, BK / p.name)
    old[name] = json.loads(p.read_text(encoding="utf-8"))

NOTE = ("2026-10-16: wrist camera names corrected. Port 55557 = LEFT wrist, 55556 = RIGHT wrist (verified by "
        "jogging left wrist_yaw). g1d_infra cam config names them the other way round. This file was computed "
        "from port {port} images, previously saved as camera_intrinsics_{old}.json.")
new = {"left_wrist": (old["right_wrist"], 55557, "right_wrist"),
       "right_wrist": (old["left_wrist"], 55556, "left_wrist")}
for name, (doc, port, oldname) in new.items():
    doc = dict(doc)
    doc["camera"] = name
    doc["zmq_port"] = port
    doc["name_fix"] = NOTE.format(port=port, old=oldname)
    (D / f"camera_intrinsics_{name}.json").write_text(json.dumps(doc, indent=1, ensure_ascii=False), encoding="utf-8")
    print(name, "<- port", port, "fx", round(doc["K"][0][0], 1), "cx", round(doc["K"][0][2], 1))
print("backup:", BK)
