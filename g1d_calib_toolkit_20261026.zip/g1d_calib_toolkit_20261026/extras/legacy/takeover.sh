#!/bin/bash
# seamless takeover: start calib_arm_server holding the same ready-pose target, then kill -9 the old holder
PY=/home/unitree/miniconda3/envs/tv/bin/python
OLD=$(pgrep -f '[c]alib_ready_pose.py' | head -1)
echo "old holder pid: ${OLD:-none}"
rm -f /tmp/g1d_calib/status.json
cd /home/unitree/g1d_infra_calib/scripts
nohup $PY -u calib_arm_server.py --yes --vmax 0.1 --init-pose /home/unitree/g1d_infra/configs/ready_pose.json \
  > /tmp/g1d_calib_server.log 2>&1 &
NEW=$!
echo "new server pid: $NEW"
for i in $(seq 1 30); do
  sleep 0.5
  grep -q "server ready" /tmp/g1d_calib_server.log && break
done
cat /tmp/g1d_calib_server.log
if ! grep -q "server ready" /tmp/g1d_calib_server.log; then
  echo "NEW SERVER NOT READY -> leaving old holder running"; kill $NEW 2>/dev/null; exit 1
fi
sleep 1
if [ -n "$OLD" ]; then kill -9 "$OLD" && echo "old holder killed (no return motion)"; fi
sleep 1.5
$PY -c "import json;s=json.load(open('/tmp/g1d_calib/status.json'));print('state',s['state'],'n_pub',s['n_pub']);print('q    ',[round(v,3) for v in s['arm_q']]);print('q_cmd',[round(v,3) for v in s['arm_q_cmd']])"
