# collect.py -- doc 02 geometric calibration collector, setup B (wrist camera looks at the fixed table board)
# usage: collect.py <left|right> [--max N] [--start K]
# Needs: robot calib_arm_server.py running (arm_client), both arms at home (all-zero pose),
#        frames_test/poses/poses_<side>.json + scene_header_B.json downloaded from the server.
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

import arm_client as arm

HERE = Path(__file__).parent
POSES = HERE / "frames_test" / "poses"
HOST = "192.168.123.164"
WRIST_PORT = {"left": 55556, "right": 55557}  # since 2026-10-21 21:25 (teleimager config): 55556 = LEFT (JR0002), 55557 = RIGHT (JR0001)
HEAD_PORT = 55555
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
ALLJ = [f"{s}_{j}_joint" for s in ("left", "right") for j in ARM]

ap = argparse.ArgumentParser()
ap.add_argument("side", choices=["left", "right"])
ap.add_argument("--max", type=int, default=0, help="stop after N captured poses (0 = all)")
ap.add_argument("--start", type=int, default=0, help="first pose index")
a = ap.parse_args()
side = a.side
off = 0 if side == "left" else 7
other = slice(7, 14) if side == "left" else slice(0, 7)

pose_file = POSES / f"poses_{side}.json"
doc = json.loads(pose_file.read_text(encoding="utf-8"))
hdr = json.loads((POSES / "scene_header_B.json").read_text(encoding="utf-8"))
S = doc["settle"]
poses = doc["setups"]["B_wrist_table_board"]["poses"]
home = np.array([doc["home"][f"{side}_{j}_joint"] for j in ARM])

sess = HERE / "sessions" / time.strftime(f"calib_%Y%m%d_%H%M_B_wrist_table_board_{side}")
(sess / "images").mkdir(parents=True)
ctx = zmq.Context.instance()
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
det = cv2.aruco.CharucoDetector(board)


def grab(port, n):
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")
    s.recv(); s.recv()                     # flush stale frames
    out = []
    for _ in range(n):
        data = s.recv()
        out.append((cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR), time.time()))
    s.close(0)
    return out


def snapshot(st):
    return {"t_robot": st["t"], "q": dict(zip(ALLJ, st["arm_q"])), "dq": dict(zip(ALLJ, st["arm_dq"])),
            "tau": dict(zip(ALLJ, st["arm_tau"])), "all_motor_q": st["all_q"]}


def wait_settle():
    time.sleep(S["min_wait_s"])
    t_end = time.time() + S["timeout_s"]
    hist = []
    while time.time() < t_end:
        st = arm.status()
        hist.append(np.array(st["arm_q"]))
        if len(hist) >= 3:
            rng = np.ptp(np.array(hist[-3:]), axis=0).max()
            if rng < 0.001 and np.abs(st["arm_dq"]).max() < 3 * S["velocity_threshold_rad_s"]:
                return True, float(rng)
        time.sleep(0.2)
    return False, None


def full_target(q7):
    t = np.array(arm.status()["arm_q_cmd"])
    t[off:off + 7] = q7
    return t


def move_line(q7, seconds):
    """straight joint-space line to q7 (the checked path), split so each command moves <= 1.5 rad
    (server rejects single moves > 1.6 rad)"""
    start = np.array(arm.status()["arm_q_cmd"])
    goal = full_target(q7)
    n = max(1, int(np.ceil(np.abs(goal - start).max() / 1.5)))
    for k in range(1, n + 1):
        arm.move(start + (goal - start) * k / n, seconds=seconds / n, timeout=120)


# ---------------- single-instance lock (on the robot; a duplicated run must never drive the arm) ----------------
import atexit
import os
import subprocess

LOCKD = "/tmp/g1d_calib/collector.lock.d"


def _pid_alive(pid):
    r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True)
    return str(pid) in r.stdout


def acquire_lock():
    info = json.dumps({"pc_pid": os.getpid(), "t": time.time(), "session": sess.name})
    for _ in range(2):
        out = arm._ssh(f"mkdir -p /tmp/g1d_calib; if mkdir {LOCKD} 2>/dev/null; then cat > {LOCKD}/info; echo LOCK_OK; "
                       f"else cat {LOCKD}/info 2>/dev/null; echo; echo LOCK_BUSY; fi", info.encode()).decode()
        if "LOCK_OK" in out:
            atexit.register(lambda: arm._ssh(f"rm -rf {LOCKD}"))
            return
        try:
            holder = json.loads(out.split("LOCK_BUSY")[0].strip() or "{}")
        except json.JSONDecodeError:
            holder = {}
        if holder.get("pc_pid") and _pid_alive(holder["pc_pid"]):
            sys.exit(f"abort: another collector is running ({holder})")
        print(f"stale lock {holder} -> removing")
        arm._ssh(f"rm -rf {LOCKD}")
    sys.exit("abort: could not acquire collector lock")


acquire_lock()

# ---------------- preflight ----------------
st0 = arm.status()
if st0["state"] != "idle":
    sys.exit(f"abort: server state {st0['state']} ({st0['msg']})")
q0 = np.array(st0["arm_q"])
if np.abs(q0[off:off + 7] - home).max() > 0.1:
    sys.exit(f"abort: {side} arm not at home (max dev {np.abs(q0[off:off + 7] - home).max():.3f} rad)")
start_all = np.array(st0["all_q"])
session = {
    "format": "g1d_calib_session_v1", "setup": "B_wrist_table_board", "side": side,
    "pose_list": {"file": pose_file.name, "sha256": hashlib.sha256(pose_file.read_bytes()).hexdigest()},
    "joint_mapping": {"file": "joint_mapping.json"},
    "intrinsics_files": {f"{side}_wrist": f"camera_intrinsics_{side}_wrist.json",
                         "head_left": "camera_intrinsics_head_left.json", "head_right": "camera_intrinsics_head_right.json"},
    "camera_ports": {f"{side}_wrist": WRIST_PORT[side], "head_stereo": HEAD_PORT},
    "boards": {"table": {k: v for k, v in hdr["boards"]["table"].items() if k != "points_m"}},
    "clock": "PC time.time() for frames; robot time.time() for joint states (t_robot)",
    "camera_timestamp_meaning": "PC receive time of the ZMQ JPEG message",
    "joint_state_start": snapshot(st0),
    "gripper": "not commanded during the session; state as at session start (visible in wrist images)",
    "server_vmax_rad_s": st0["vmax"], "operator": "on site at e-stop", "notes": [],
}
(sess / "session.json").write_text(json.dumps(session, indent=1))
print(f"session {sess.name}: {len(poses)} poses in table, {sum(p.get('skip', False) for p in poses)} flagged skip")

# ---------------- loop ----------------
# trail of reached, checked waypoints: (id, q7, direct_path_to_home_checked)
trail = [("home", home.copy(), True)]
aborted = False


def abort_and_park(where, err):
    """stop, then go back along the SAME line to the last reached waypoint and stay there"""
    global aborted
    aborted = True
    print(f"ABORT at {where}: {err}")
    session["notes"].append(f"aborted at {where}: {err}")
    try:
        arm.stop()
        s = arm.wait_idle()
        if s["state"] == "error":
            print(f"  server error latched ({s['msg']}); arm holds its measured pose. Operator check required.")
            return
        print(f"  parking back on the same line at last waypoint {trail[-1][0]}")
        move_line(trail[-1][1], 3.0)
        print("  parked. Not moving further; operator decides next step.")
    except Exception as e2:
        print(f"  parking failed: {e2}. Arm holds where it is.")


n_ok, fails_in_row = 0, 0
with open(sess / "samples.jsonl", "a") as fs:
    for p in poses[a.start:]:
        if a.max and n_ok >= a.max:
            break
        pid = p["id"]
        if p.get("skip"):
            print(f"  {pid}: SKIP (flagged: transition {p['transition_before']}, path clearance {p.get('path_clearance_cm')} cm)")
            continue
        q_t = np.array([p["joints"][f"{side}_{j}_joint"] for j in ARM])
        try:
            if p.get("transition_actual") == "via_home" and trail[-1][0] != "home":
                move_line(home, 3.0)
                trail.append(("home", home.copy(), True))
            t_cmd = time.time()
            move_line(q_t, p["move_duration_s"])
            trail.append((pid, q_t.copy(), bool(p.get("home_path_ok", False))))
        except Exception as e:
            abort_and_park(pid, e)
            break
        ok, rng = wait_settle()
        if not ok:
            print(f"  {pid}: not settled, skip"); continue
        jb = snapshot(arm.status())
        wrist = grab(WRIST_PORT[side], S["frames_per_pose"])
        head = grab(HEAD_PORT, 1)
        ja = snapshot(arm.status())
        drift = max(abs(ja["q"][k] - jb["q"][k]) for k in ALLJ)
        if drift > 0.002:
            print(f"  {pid}: moved during capture ({drift:.4f} rad), reject"); continue
        # other arm / waist drift vs session start
        oth = np.abs(np.array(ja["all_motor_q"]) - start_all)
        oth_arm = oth[15:29][other].max(); waist = oth[12]
        if oth_arm > 0.02 or waist > 0.01:      # low-gain arms: allow small coupling sway
            print(f"STOP: other arm drift {oth_arm:.4f} / waist drift {waist:.4f} rad")
            session["notes"].append(f"stopped at {pid}: drift other arm {oth_arm:.4f}, waist {waist:.4f}")
            break
        d = sess / "images" / pid
        d.mkdir(exist_ok=True)
        frames = []
        for k, (img, t) in enumerate(wrist):
            fn = f"images/{pid}/{side}_wrist_{k}.png"
            cv2.imencode(".png", img)[1].tofile(str(sess / fn))
            frames.append({"file": fn, "t": t})
        himg, ht = head[0]
        cv2.imencode(".png", himg)[1].tofile(str(d / "head_stereo.png"))
        g = cv2.resize(cv2.cvtColor(wrist[0][0], cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
        cc, ci, _, _ = det.detectBoard(g)
        ncorn = 0 if ci is None else len(ci)
        fails_in_row = fails_in_row + 1 if ncorn < 6 else 0
        rec = {"id": pid, "pose_id": pid, "t_command": t_cmd, "t_settled": time.time(),
               "q_target": {f"{side}_{j}_joint": float(v) for j, v in zip(ARM, q_t)},
               "joints_before": jb, "joints_after": ja,
               "frames": {f"{side}_wrist": frames, "head_stereo": [{"file": f"images/{pid}/head_stereo.png", "t": ht}]},
               "settle": {"q_range_rad": rng}, "live_charuco_corners": ncorn,
               "expected_corners": p["expected_nominal"][f"{side}_wrist"]["visible_corners"], "flags": []}
        fs.write(json.dumps(rec) + "\n"); fs.flush()
        n_ok += 1
        err = np.abs(np.array([jb["q"][f"{side}_{j}_joint"] for j in ARM]) - q_t).max()
        print(f"  {pid}: OK  corners {ncorn:2d} (expected {rec['expected_corners']:2d})  "
              f"track err {err:.3f} rad  path clear {p.get('path_clearance_cm')} cm")
        if fails_in_row >= 3:
            print("ABORT: 3 poses in a row without board detection (board moved?)")
            session["notes"].append("aborted: 3 consecutive detection failures")
            break

# ---------------- finish ----------------
if not aborted:
    try:
        # retreat along the travelled (checked) path until a waypoint whose direct path home was checked
        while not trail[-1][2]:
            trail.pop()
            print(f"  retreat to {trail[-1][0]}")
            move_line(trail[-1][1], 3.0)
        if trail[-1][0] != "home":
            move_line(home, 3.0)
        print("  back at home")
    except Exception as e:
        abort_and_park("return home", e)
session["joint_state_end"] = snapshot(arm.status())
session["n_samples"] = n_ok
(sess / "session.json").write_text(json.dumps(session, indent=1))
print(f"DONE {n_ok} samples -> {sess}")
