#!/bin/bash
echo "=== 1. Video4Linux & USB Camera Serials ==="
for d in /sys/class/video4linux/video*; do
    [ -e "$d" ] || continue
    dev=$(basename "$d")
    name=$(cat "$d/name" 2>/dev/null)
    usb_dir=$(readlink -f "$d/device/.." 2>/dev/null)
    serial=$(cat "$usb_dir/serial" 2>/dev/null)
    prod=$(cat "$usb_dir/product" 2>/dev/null)
    echo "  /dev/$dev : name='$name' product='$prod' serial='$serial'"
done
echo "=== 2. teleimager.service & Camera Processes ==="
systemctl is-active teleimager.service
pgrep -af 'teleimager|image_server|af_lock|uvc|g1d|replay|teleop' | cut -c1-160
echo "=== 3. Recent teleimager logs (if readable) ==="
journalctl -u teleimager.service --no-pager -n 25 2>&1 | tail -n 25
echo "=== 4. ZMQ Stream Test (55555, 55556, 55557) ==="
/home/unitree/miniconda3/envs/tv/bin/python -u /tmp/diag_cameras.py
