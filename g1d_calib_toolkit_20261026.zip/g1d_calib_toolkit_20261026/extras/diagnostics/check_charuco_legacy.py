# check_charuco_legacy.py -- which legacy-pattern setting matches the printed 10x7 board
import glob
import os

import cv2
import numpy as np

D = os.environ.get("PC_TOOLS_DIR", ".")
imgs = sorted(glob.glob(os.path.join(D, "calib_data", "**", "*.png"), recursive=True))[:30]
dic = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
for sx, sy in [(10, 7), (7, 10)]:
    for legacy in (False, True):
        board = cv2.aruco.CharucoBoard((sx, sy), 0.040, 0.030, dic)
        board.setLegacyPattern(legacy)
        det = cv2.aruco.CharucoDetector(board)
        tot, nimg, reproj = 0, 0, []
        for p in imgs:
            g = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_GRAYSCALE)
            cc, ci, mc, mi = det.detectBoard(g)
            if ci is not None and len(ci) >= 6:
                tot += len(ci); nimg += 1
        print(f"squares=({sx},{sy}) legacy={legacy!s:5s}: images_with_corners={nimg:2d}/{len(imgs)} total_corners={tot}")
