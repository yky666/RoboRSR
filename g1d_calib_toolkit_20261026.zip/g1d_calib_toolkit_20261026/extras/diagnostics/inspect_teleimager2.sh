#!/bin/bash
echo "--- non-interactive sudo allowed? (sudo -n, never prompts)"
sudo -n true 2>&1 && echo SUDO_NOPASS_OK || echo SUDO_NEEDS_AUTH
echo "--- unit file"
cat /etc/systemd/system/teleimager.service
echo "--- wrist camera config"
C=/unitree/module/unitree_eai/unitree_eai_environment/service/teleimager/cam_config_server.yaml
grep -nE '^[a-z_]+:|zmq_port|serial_number|image_shape|type:|fps|binocular' "$C" | head -40
echo "--- UVC capture code"
F=/home/unitree/unitree_eai_environment/service/teleimager/src/teleimager/image_server.py
sed -n 1040,1110p "$F"
echo "--- ZMQ publish code"
F2=/home/unitree/unitree_eai_environment/service/teleimager/src/teleimager/image_client.py
grep -nE 'class ZMQ_PublisherManager|def publish|send\(|bind|imencode|IMWRITE' "$F2" "$F" | head -20
