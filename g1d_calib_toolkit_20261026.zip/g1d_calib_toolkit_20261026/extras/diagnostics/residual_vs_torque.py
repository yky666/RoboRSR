# residual_vs_torque.py -- per-sample residual after calibration vs joint torques recorded at capture
# server, unitree_sim_env python.  usage: residual_vs_torque.py <meas.json> <params.json> <session_dir>
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam")
import compare_sim_real as csr  # noqa: E402

meas_p, params_p, sess = sys.argv[1], sys.argv[2], Path(sys.argv[3])
out = Path("/tmp/cmp_cal.json")
sys.argv = ["compare_sim_real.py", meas_p, "--params", params_p, "--out", str(out)]
try:
    csr.main()
except SystemExit:
    pass
rep = json.loads(out.read_text())
cal = rep["models"].get("calibrated") or rep["models"]["nominal"]
nom = rep["models"]["nominal"]
tau = {}
for line in open(sess / "samples.jsonl"):
    r = json.loads(line)
    tau[r["id"]] = r["joints_before"]["tau"]
names = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
rows = []
for sid, views in cal["per_sample"].items():
    v = list(views.values())[0]
    t = np.array([tau[sid][f"left_{j}_joint"] for j in names])
    rows.append((sid, v["rms_px"], v["mean_residual_px"], list(nom["per_sample"][sid].values())[0]["rms_px"], t))
rows.sort(key=lambda r: -r[1])
print("id           cal_rms  nom_rms  mean_res(du,dv)     tau[pitch roll yaw elbow wr wp wy] (Nm)")
for sid, rc, mr, rn, t in rows:
    print(f"{sid:12s} {rc:6.2f}  {rn:6.2f}   {np.round(mr, 1).tolist()!s:18s} {np.round(t, 1).tolist()}")
R = np.array([r[1] for r in rows]); T = np.array([r[4] for r in rows])
for j, n in enumerate(names):
    c = np.corrcoef(R, np.abs(T[:, j]))[0, 1]
    print(f"corr(cal_rms, |tau_{n}|) = {c:+.2f}")
