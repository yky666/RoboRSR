#!/bin/bash
# read-only: list video devices and look for focus settings in the image-server configs
for d in /sys/class/video4linux/video*; do
  echo "$(basename $d): $(cat $d/name 2>/dev/null)"
done
echo "--- configs mentioning focus / exposure"
grep -rniE 'focus|exposure|white_balance' ~/g1d_infra/teleop/teleimager/ 2>/dev/null | grep -v '\.pyc' | head -20
echo "--- image server processes"
pgrep -af 'image_server|teleimager|cam_server' | cut -c1-150 | head -5
echo "--- python uvc/v4l2 libs in tv env"
/home/unitree/miniconda3/envs/tv/bin/python -c "import importlib.util as u;print({m: bool(u.find_spec(m)) for m in ['v4l2','pyudev','uvc','linuxpy']})"
