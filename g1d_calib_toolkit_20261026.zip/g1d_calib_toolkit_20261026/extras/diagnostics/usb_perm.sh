#!/bin/bash
# read-only: can user 'unitree' open the UVC cameras without root?
id
lsusb 2>/dev/null | grep -viE 'hub|root' | head -10
echo "--- device node permissions (cameras)"
for d in $(lsusb 2>/dev/null | grep -iE 'camera|video|uvc|1bcf|0c45|05a3|32e4|2bdf|1e45' | awk '{print "/dev/bus/usb/"$2"/"substr($4,1,3)}'); do ls -l $d; done
echo "--- udev rules mentioning usb / video / uvc"
grep -lisE 'uvc|video|camera|MODE=' /etc/udev/rules.d/* 2>/dev/null | head
/home/unitree/miniconda3/envs/tv/bin/python - <<'EOF'
import uvc
for d in uvc.device_list():
    print({k: d.get(k) for k in ("name", "manufacturer", "serialNumber", "uid", "idVendor", "idProduct")})
EOF
