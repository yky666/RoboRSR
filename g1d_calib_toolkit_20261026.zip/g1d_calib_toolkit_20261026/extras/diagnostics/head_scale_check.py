# head_scale_check.py -- is the head camera metric scale right? Triangulate the table board corners with the two head
# eyes (contract baseline) and compare corner spacing with the true 40 mm; compare stereo depth with monocular PnP depth
# usage: head_scale_check.py <intrinsics_dir> <head_stereo.png> [...]
import json
import sys
from pathlib import Path

import cv2
import numpy as np

INT = Path(sys.argv[1])
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838], [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
T_L, T_R = np.array([0.04812857, 0.02963228, 0.43599143]), np.array([0.04812857, -0.02996772, 0.43599143])
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
t_rl = -(OPT @ R_HEAD.T @ (T_R - T_L))                  # X_right = X_left + t_rl (optical frames)
cam = {}
for e in ("head_left", "head_right"):
    d = json.loads((INT / f"camera_intrinsics_{e}.json").read_text())
    cam[e] = (np.array(d["K"]), np.array(d["dist"]))
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners()


def corners(img):
    big = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(big)
    if ci is None:
        return {}
    return {int(i): (p + 0.5) / 3 - 0.5 for i, p in zip(ci.ravel(), cc.reshape(-1, 2))}


for f in sys.argv[2:]:
    st = cv2.imread(f)
    w = st.shape[1] // 2
    cl, cr = corners(st[:, :w]), corners(st[:, w:])
    ids = sorted(set(cl) & set(cr))
    if len(ids) < 8:
        print(Path(f).parent.name, "too few common corners"); continue
    nl = cv2.undistortPoints(np.array([cl[i] for i in ids], np.float64).reshape(-1, 1, 2), *cam["head_left"]).reshape(-1, 2)
    nr = cv2.undistortPoints(np.array([cr[i] for i in ids], np.float64).reshape(-1, 1, 2), *cam["head_right"]).reshape(-1, 2)
    P1 = np.hstack([np.eye(3), np.zeros((3, 1))]); P2 = np.hstack([np.eye(3), t_rl.reshape(3, 1)])
    X = cv2.triangulatePoints(P1, P2, nl.T, nr.T); X = (X[:3] / X[3]).T          # left optical frame
    # spacing between horizontally / vertically adjacent corners (board corner grid 9 x 6, id = row*9 + col)
    pos = {i: X[k] for k, i in enumerate(ids)}
    sp = [np.linalg.norm(pos[i] - pos[i + 1]) for i in ids if i % 9 != 8 and i + 1 in pos] + \
         [np.linalg.norm(pos[i] - pos[i + 9]) for i in ids if i + 9 in pos]
    # monocular PnP depth (left eye) vs stereo depth of the same corners
    ok, rv, tv = cv2.solvePnP(OBJ[ids].astype(np.float64), np.array([cl[i] for i in ids], np.float64),
                              *cam["head_left"], flags=cv2.SOLVEPNP_IPPE)
    Xp = (cv2.Rodrigues(rv)[0] @ OBJ[ids].T).T + tv.ravel()
    print(f"{Path(f).parent.name}: {len(ids)} common corners | stereo corner spacing median {np.median(sp) * 1000:.2f} mm "
          f"(true 40.00) | mean depth stereo {X[:, 2].mean():.4f} m vs PnP {Xp[:, 2].mean():.4f} m "
          f"(ratio {X[:, 2].mean() / Xp[:, 2].mean():.4f})")
