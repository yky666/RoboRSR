# diag_cameras.py -- read-only diagnostic of all 3 teleimager ZMQ camera streams
# ports: 55555 = head stereo (01.00.00), 55556 = physical RIGHT wrist (JR0001, config 'left_wrist'),
#        55557 = physical LEFT wrist (JR0002, config 'right_wrist')
import time
import cv2
import numpy as np
import zmq

PORTS = [
    (55555, "head_stereo (serial 01.00.00)"),
    (55556, "physical_RIGHT_wrist (serial JR0001, teleimager config name: left_wrist)"),
    (55557, "physical_LEFT_wrist  (serial JR0002, teleimager config name: right_wrist)"),
]

ctx = zmq.Context.instance()
for port, desc in PORTS:
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.RCVTIMEO, 2500)
    s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://127.0.0.1:{port}")
    frames = []
    t0 = time.time()
    err = None
    while time.time() - t0 < 2.0:
        try:
            buf = s.recv()
            img = cv2.imdecode(np.frombuffer(buf, np.uint8), cv2.IMREAD_COLOR)
            frames.append((time.time(), len(buf), img))
        except Exception as e:
            err = repr(e)
            break
    s.close(0)
    dur = max(1e-3, time.time() - t0)
    if not frames:
        print(f"[PORT {port}] {desc}: NO FRAMES RECEIVED (err={err})")
    else:
        im0 = frames[0][2]
        im1 = frames[-1][2]
        diff = float(np.abs(im1.astype(float) - im0.astype(float)).mean()) if len(frames) > 1 else 0.0
        out_path = f"/tmp/cam_{port}.png"
        cv2.imwrite(out_path, im1)
        print(f"[PORT {port}] {desc}: OK | {len(frames)} frames in {dur:.2f}s ({len(frames)/dur:.1f} fps) | "
              f"shape={im1.shape} | jpeg_bytes={frames[-1][1]} | mean={im1.mean():.1f} std={im1.std():.1f} | "
              f"frame_diff={diff:.2f} | saved {out_path}")
