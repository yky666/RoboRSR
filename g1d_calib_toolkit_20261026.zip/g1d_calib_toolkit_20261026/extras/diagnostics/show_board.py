# show_board.py — 全屏显示 TABLE_BOARD ChArUco 标定板（无打印条件，用屏幕代替）
# 板上附带 500px 标尺，用尺子量标尺实际长度即可反推格长的物理尺寸
import ctypes

import cv2
import numpy as np

# 与 calib 包 board_setups.TABLE_BOARD 一致
SQUARES_X, SQUARES_Y = 9, 7
DICT = cv2.aruco.DICT_5X5_100
SQ_OVER_MARK = 0.035 / 0.026  # 保持 square:marker 比例 = 0.035:0.026

user32 = ctypes.windll.user32
user32.SetProcessDPIAware()
SCR_W, SCR_H = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

# 窗口占屏幕左侧 ~2/3 宽、3/4 高，右侧留给采集预览
WIN_W, WIN_H = SCR_W * 2 // 3, SCR_H * 3 // 4
# 板外至少留 1 格白边（检测需要），格像素取能放下的最大值
sq_px = min(WIN_W // (SQUARES_X + 2), (WIN_H - 90) // (SQUARES_Y + 2))
marker_px = round(sq_px / SQ_OVER_MARK)

board = cv2.aruco.CharucoBoard((SQUARES_X, SQUARES_Y), 1.0, 1.0 / SQ_OVER_MARK,
                               cv2.aruco.getPredefinedDictionary(DICT))
bw, bh = SQUARES_X * sq_px, SQUARES_Y * sq_px
img = board.generateImage((bw, bh), marginSize=0)

canvas = np.full((WIN_H, WIN_W), 255, np.uint8)
ox, oy = (WIN_W - bw) // 2, (WIN_H - bh) // 2
canvas[oy:oy + bh, ox:ox + bw] = img

# 500px 标尺 + 文字
BAR = 500
y0 = WIN_H - 40
cv2.line(canvas, (ox, y0), (ox + BAR, y0), 0, 3)
cv2.line(canvas, (ox, y0 - 12), (ox, y0 + 12), 0, 3)
cv2.line(canvas, (ox + BAR, y0 - 12), (ox + BAR, y0 + 12), 0, 3)
cv2.putText(canvas, f"{BAR}px - measure me", (ox, y0 - 20),
            cv2.FONT_HERSHEY_SIMPLEX, 1.0, 0, 2)
cv2.putText(canvas, f"square={sq_px}px marker={marker_px}px  board={SQUARES_X}x{SQUARES_Y} DICT_5X5_100",
            (ox, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, 0, 2)

cv2.imencode(".png", canvas)[1].tofile(str((__file__ and __import__("pathlib").Path(__file__).parent / "board_screen.png")))
print(f"screen {SCR_W}x{SCR_H}, window {WIN_W}x{WIN_H}, square={sq_px}px, marker={marker_px}px, bar={BAR}px")
print(f"board offset=({ox},{oy}) size=({bw},{bh})")
print("按任意键关闭")

cv2.namedWindow("board", cv2.WINDOW_NORMAL)
cv2.resizeWindow("board", WIN_W, WIN_H)
cv2.moveWindow("board", 0, 0)
cv2.imshow("board", canvas)
cv2.waitKey(0)
cv2.destroyAllWindows()
