# read_arm_q.py — 一次性读取当前臂关节角（机器人上运行）
import os
import sys
import time

os.environ["CYCLONEDDS_URI"] = (
    '<CycloneDDS><Domain Id="any"><General><Interfaces>'
    '<NetworkInterface name="eth0" priority="default" multicast="default"/>'
    '</Interfaces></General></Domain></CycloneDDS>')

from cyclonedds.domain import DomainParticipant
from cyclonedds.sub import DataReader
from cyclonedds.topic import Topic
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_

dp = DomainParticipant(0)
rd = DataReader(dp, Topic(dp, "rt/lowstate", LowState_))
t0 = time.time()
while time.time() - t0 < 5:
    ss = rd.take()
    if ss:
        m = ss[-1]
        print("mode_machine:", m.mode_machine)
        print("arm q:", [round(m.motor_state[i].q, 3) for i in range(15, 29)])
        print("waist:", round(m.motor_state[12].q, 4))
        sys.exit(0)
    time.sleep(0.01)
print("TIMEOUT no lowstate")
sys.exit(1)
