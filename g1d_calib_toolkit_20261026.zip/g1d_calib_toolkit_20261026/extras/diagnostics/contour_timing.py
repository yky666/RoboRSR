# contour_timing.py -- time one view of contour_fit.py and report mesh sizes
import sys
import time

sys.argv = ["contour_fit.py", "x", "/dev/shm/isaac_work/contour_out"]
import contour_fit as cf  # noqa: E402

cf.set_model(sys.argv[2] if len(sys.argv) > 3 else
             "/root/unitree_sim_isaaclab/real2sim_calib_20261015/scratch/urdf_variants_20261019/dual_trans/"
             "g1_d_upper_dex1_v4.urdf")
for s in ("left", "right"):
    print(s, "arm triangles", {k: len(v) // 3 for k, v in cf.MODEL["arm"][s].items()},
          "grip", sum(len(v) // 3 for v in cf.MODEL["grip"][s].values()))
for up in (2, 1):
    cf.UP = up
    t0 = time.time()
    for i in range(10):
        cf.view_cost((i, "left", {}))
    print(f"UP={up}: {(time.time() - t0) / 10 * 1000:.0f} ms per view")
