# test_detect_once.py — 抓一帧做一次 ChArUco 检测试验（无GUI），验证屏幕板可被检测
import sys
from pathlib import Path

import cv2
import numpy as np
import zmq

HOST = "192.168.123.164"
CAMS = {"head": (55555, True), "left_wrist": (55556, False), "right_wrist": (55557, False)}  # since 2026-10-21 21:25 (teleimager config): 55556 = LEFT (JR0002), 55557 = RIGHT (JR0001)

board = cv2.aruco.CharucoBoard((9, 7), 1.0, 0.026 / 0.035,
                               cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_100))
detector = cv2.aruco.CharucoDetector(board)

name = sys.argv[1] if len(sys.argv) > 1 else "head"
port, bino = CAMS[name]

s = zmq.Context.instance().socket(zmq.SUB)
s.setsockopt(zmq.CONFLATE, 1)
s.setsockopt(zmq.RCVTIMEO, 3000)
s.setsockopt(zmq.SUBSCRIBE, b"")
s.connect(f"tcp://{HOST}:{port}")
data = s.recv()
s.close(0)

frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
views = [("L", gray[:, : gray.shape[1] // 2]), ("R", gray[:, gray.shape[1] // 2:])] if bino else [("", gray)]
outdir = Path(__file__).parent / "calib_data" / "detect_test"
outdir.mkdir(parents=True, exist_ok=True)
for tag, g in views:
    corners, ids, mc, mi = detector.detectBoard(g)
    n = 0 if ids is None else len(ids)
    sharp = cv2.Laplacian(g, cv2.CV_64F).var()
    print(f"{name}{tag}: 角点 {n} 个, 清晰度 {sharp:.1f}, markers={0 if mi is None else len(mi)}")
    vis = cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)
    if n:
        for c in corners[:, 0]:
            cv2.circle(vis, tuple(np.round(c).astype(int)), 3, (0, 255, 0), -1)
    cv2.imencode(".png", vis)[1].tofile(str(outdir / f"{name}{tag}.png"))
print("检测图已存 calib_data/detect_test/")
