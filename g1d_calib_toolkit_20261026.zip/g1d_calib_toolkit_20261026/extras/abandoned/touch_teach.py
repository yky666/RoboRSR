# touch_teach.py -- hand-guided touch calibration, run by the OPERATOR in a terminal on the robot:
#   python ~/calib_sessions/touch_teach.py left
# Enter -> arm goes soft (hand guiding);  put the probe tip on the target corner, hold still, Enter -> encoders are
# recorded (only if the arm is still) and the arm stiffens immediately where it is.
# keys at the record prompt:  Enter = record   s = skip this target   r = undo last record   q = quit (arm stiffens)
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

CALIB = Path("/tmp/g1d_calib")
CMD, STATUS = CALIB / "cmd.json", CALIB / "status.json"
OUT = Path.home() / "calib_sessions"

# ChArUco inner corner id = row * 9 + col (rows 0..5, cols 0..8); labels match the annotated image
# board columns increase toward the robot's LEFT (measured 10-19: id 10 at y=-0.15, id 16 at y=+0.09)
TARGETS = {"left": [("B", 16), ("D", 43), ("E", 22), ("F", 31), ("G", 13), ("H", 40)],
           "right": [("A", 10), ("C", 37), ("E", 22), ("F", 31), ("G", 13), ("H", 40)]}
POSTURES = ["探针大致竖直向下", "手腕向前倾，探针斜着朝前", "手腕向外侧倾", "肘部抬高、手腕往下压"]
STILL_DQ = 0.02      # rad/s
WINDOW = 0.5         # s


def status():
    for _ in range(5):
        try:
            return json.loads(STATUS.read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            time.sleep(0.05)
    return json.loads(STATUS.read_text())


def send(cmd, expect, timeout=5.0):
    seq = int(time.time() * 1000)
    tmp = CMD.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(dict(cmd, seq=seq)))
    os.replace(tmp, CMD)
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["seq_done"] >= seq:
            if expect not in s["msg"]:
                print(f"  !! 服务端回复: {s['msg']}")
                return False
            return True
        time.sleep(0.05)
    print("  !! 服务端没有响应")
    return False


def still_window(side):
    off = 0 if side == "left" else 7
    qs, dqmax = [], 0.0
    t0 = time.time()
    while time.time() - t0 < WINDOW:
        s = status()
        qs.append(s["arm_q"])
        dqmax = max(dqmax, float(np.abs(np.array(s["arm_dq"])[off:off + 7]).max()))
        time.sleep(0.02)
    qs = np.array(qs)
    return qs.mean(axis=0), qs[:, off:off + 7].std(axis=0).max(), dqmax


def main():
    side = sys.argv[1]
    s0 = status()
    if s0["state"] != "idle" or s0.get("free_side"):
        sys.exit(f"服务端状态不对: {s0['state']} / free={s0.get('free_side')}")
    fn = OUT / time.strftime(f"touch_{side}_%Y%m%d_%H%M.jsonl")
    plan = [(lab, cid, k) for lab, cid in TARGETS[side] for k in range(len(POSTURES))]
    print(f"触碰示教：{side} 臂，共 {len(plan)} 次（{len(TARGETS[side])} 个目标点 x {len(POSTURES)} 种姿态），记录写入 {fn}")
    print("每一步：回车 -> 手臂变软；对准后回车 -> 记录并变硬。记录提示处可输入 s 跳过 / r 撤销上一次 / q 退出\n")
    recs = []
    i = 0
    while i < len(plan):
        lab, cid, k = plan[i]
        input(f"[{i + 1}/{len(plan)}] 目标 {lab}（格角 {cid}），姿态 {k + 1}：{POSTURES[k]}。按回车让手臂变软 ")
        if not send({"cmd": "free", "side": side}, "FREE"):
            continue
        while True:
            a = input("    把探针尖抵住目标格角，扶稳后按回车记录（s 跳过 / r 撤销上一次 / q 退出）: ").strip().lower()
            if a == "q":
                send({"cmd": "hold"}, "stiffened")
                print(f"已退出，共记录 {len(recs)} 次 -> {fn}")
                return
            if a == "s":
                send({"cmd": "hold"}, "stiffened")
                i += 1
                break
            if a == "r":
                if recs:
                    recs.pop()
                    fn.write_text("".join(json.dumps(x) + "\n" for x in recs))
                    print(f"    已撤销上一次，现在共 {len(recs)} 次")
                continue
            q, qstd, dqmax = still_window(side)
            if dqmax > STILL_DQ:
                print(f"    手臂还在动（关节速度 {dqmax:.3f} rad/s），扶稳一点再按回车")
                continue
            send({"cmd": "hold"}, "stiffened")
            rec = {"side": side, "label": lab, "corner_id": cid, "posture": k, "arm_q": q.tolist(),
                   "q_std_rad": float(qstd), "dq_max": dqmax, "t": time.time()}
            recs.append(rec)
            with open(fn, "a") as f:
                f.write(json.dumps(rec) + "\n")
            print(f"    已记录（第 {len(recs)} 次），手臂已变硬，可以松手")
            i += 1
            break
    print(f"\n全部完成，共记录 {len(recs)} 次 -> {fn}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        send({"cmd": "hold"}, "")
        print("\n中断，手臂已变硬")
