# make_gripper_board.py -- printable ChArUco for setup A (board taped on the gripper, seen by the head stereo)
# 5x4 squares, 28 mm squares, 21 mm markers; marker ids must not collide with the table board (DICT_4X4_50, 0..34)
# or with the other gripper: left = DICT_4X4_50 ids 35..44, right = DICT_4X4_100 ids 50..59
# (DICT_4X4_100 ids 0..49 are identical to DICT_4X4_50). One PDF page per board at true scale (print at 100%)
# usage: python make_gripper_board.py <out_dir>
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw

DPI = 600
MM = DPI / 25.4
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
pages = []
SPEC = {"left": (cv2.aruco.DICT_4X4_50, "DICT_4X4_50", np.arange(35, 45)),
        "right": (cv2.aruco.DICT_4X4_100, "DICT_4X4_100", np.arange(50, 60))}
for side, (dict_id, dict_name, ids) in SPEC.items():
    board = cv2.aruco.CharucoBoard((5, 4), 0.028, 0.021, cv2.aruco.getPredefinedDictionary(dict_id),
                                   ids.astype(np.int32))
    w, h = int(round(5 * 28 * MM)), int(round(4 * 28 * MM))
    img = board.generateImage((w, h), marginSize=0, borderBits=1)
    page = Image.new("L", (int(round(210 * MM)), int(round(297 * MM))), 255)       # A4 portrait
    x0, y0 = int(round(35 * MM)), int(round(40 * MM))
    page.paste(Image.fromarray(img), (x0, y0))
    d = ImageDraw.Draw(page)
    d.rectangle([x0 - 2, y0 - 2, x0 + w + 2, y0 + h + 2], outline=160, width=2)       # cut line
    ruler_y = y0 + h + int(15 * MM)
    d.line([x0, ruler_y, x0 + int(100 * MM), ruler_y], fill=0, width=6)              # 100 mm scale check
    for k in range(11):
        xk = x0 + int(k * 10 * MM)
        d.line([xk, ruler_y - int(3 * MM), xk, ruler_y + int(3 * MM)], fill=0, width=4)
    d.text((x0, ruler_y + int(6 * MM)), f"{side.upper()} gripper board: 5x4 ChArUco, 28 mm squares, 21 mm markers, "
                                         f"{dict_name} ids {ids[0]}-{ids[-1]}. Bar = 100 mm (check after printing)",
           fill=0, font_size=int(4 * MM))
    d.text((x0, y0 - int(14 * MM)), side.upper(), fill=0, font_size=int(10 * MM))
    pages.append(page)
    page.save(out / f"gripper_board_{side}.png", dpi=(DPI, DPI))
pages[0].save(out / "gripper_boards_A4.pdf", save_all=True, append_images=pages[1:], resolution=DPI)
print("written", out / "gripper_boards_A4.pdf")
