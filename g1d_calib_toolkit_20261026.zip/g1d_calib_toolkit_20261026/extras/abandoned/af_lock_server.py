# af_lock_server.py -- calibration replacement for teleimager (run only while teleimager.service is stopped):
# same cameras, modes and ZMQ ports (raw MJPG/JPEG bytes on PUB sockets), plus focus control for the wrist cameras.
#   ports: head 01.00.00 -> 55555 (1280x480), JR0001 -> 55556 (RIGHT wrist), JR0002 -> 55557 (LEFT wrist), 640x480 @30
# control:  /tmp/g1d_calib/cam_cmd.json  {"seq": n, "cmd": "lock"|"auto"|"set", "cam": "left_wrist"|"right_wrist", "value": v}
# status:   /tmp/g1d_calib/cam_status.json   (focus controls, fps, last command result)
# usage:    python -u af_lock_server.py      (as user unitree; libuvc udev rule grants access)
import json
import os
import threading
import time
from pathlib import Path

import uvc
import zmq

CAMS = {"head": ("01.00.00", 55555, 1280, 480), "right_wrist": ("JR0001", 55557, 640, 480),  # ports as teleimager since 2026-10-21 21:25
        "left_wrist": ("JR0002", 55556, 640, 480)}
FPS = 30
D = Path("/tmp/g1d_calib"); D.mkdir(exist_ok=True)
CMD, STATUS = D / "cam_cmd.json", D / "cam_status.json"
LOCKFILE = Path.home() / "calib_sessions" / "focus_lock.json"

devs = {d["serialNumber"]: d["uid"] for d in uvc.device_list()}
ctx = zmq.Context.instance()
caps, socks, stats, locks = {}, {}, {}, {}
st = {"seq_done": 0, "msg": "", "focus": {}}


def ctrl_table(cap):
    return {c.display_name: {"value": c.value, "min": c.min_val, "max": c.max_val, "def": c.def_val} for c in cap.controls}


def find_ctrl(cap, *words):
    for c in cap.controls:
        n = c.display_name.lower()
        if all(w in n for w in words):
            return c
    return None


for name, (serial, port, w, h) in CAMS.items():
    cap = uvc.Capture(devs[serial])
    mode = [m for m in cap.available_modes if m.width == w and m.height == h and m.fps == FPS and m.format_name == "MJPG"]
    cap.frame_mode = mode[0]
    caps[name] = cap
    s = ctx.socket(zmq.PUB); s.setsockopt(zmq.SNDHWM, 2); s.bind(f"tcp://*:{port}")
    socks[name] = s
    stats[name] = {"n": 0, "t0": time.time()}
    locks[name] = threading.Lock()
    print(f"[{name}] serial {serial} port {port} mode {w}x{h}@{FPS} MJPG", flush=True)
    for k, v in ctrl_table(cap).items():
        print(f"    control {k!r}: {v}", flush=True)


def stream(name):
    cap, s = caps[name], socks[name]
    while True:
        with locks[name]:
            f = cap.get_frame_robust()
        if f is not None and f.jpeg_buffer is not None:
            try:
                s.send(bytes(f.jpeg_buffer), zmq.NOBLOCK)
            except zmq.Again:
                pass
            stats[name]["n"] += 1


for n in caps:
    threading.Thread(target=stream, args=(n,), daemon=True).start()


def focus_state(name):
    cap = caps[name]
    a = find_ctrl(cap, "auto", "focus"); f = find_ctrl(cap, "absolute", "focus") or find_ctrl(cap, "focus")
    return {"auto": None if a is None else a.value, "absolute": None if f is None else f.value,
            "range": None if f is None else [f.min_val, f.max_val]}


def handle(c):
    name = c.get("cam"); cap = caps.get(name)
    if cap is None:
        return f"unknown cam {name}"
    a = find_ctrl(cap, "auto", "focus"); f = find_ctrl(cap, "absolute", "focus") or find_ctrl(cap, "focus")
    if a is None or f is None or f is a:
        return f"{name}: no focus controls ({[x.display_name for x in cap.controls]})"
    with locks[name]:
        if c["cmd"] == "lock":
            v = f.value
            a.value = 0
            time.sleep(0.2)
            f.value = v
            locks_doc = json.loads(LOCKFILE.read_text()) if LOCKFILE.exists() else {}
            locks_doc[name] = {"absolute_focus": v, "t": time.time()}
            LOCKFILE.write_text(json.dumps(locks_doc, indent=1))
            return f"{name}: autofocus OFF, focus locked at {v}"
        if c["cmd"] == "set":
            a.value = 0; f.value = int(c["value"])
            return f"{name}: autofocus OFF, focus set to {f.value}"
        if c["cmd"] == "auto":
            a.value = 1
            return f"{name}: autofocus ON"
    return f"unknown cmd {c['cmd']}"


print("af_lock_server ready", flush=True)
while True:
    try:
        c = json.loads(CMD.read_text())
        if int(c.get("seq", 0)) > st["seq_done"]:
            st["msg"] = handle(c); st["seq_done"] = int(c["seq"])
            print("cmd:", st["msg"], flush=True)
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        pass
    except Exception as e:      # keep streaming even if a control call fails
        st["msg"] = f"error: {e}"; print(st["msg"], flush=True)
    now = time.time()
    st["fps"] = {n: round(v["n"] / max(now - v["t0"], 1e-3), 1) for n, v in stats.items()}
    st["focus"] = {n: focus_state(n) for n in ("left_wrist", "right_wrist")}
    st["t"] = now
    tmp = STATUS.with_suffix(f".{os.getpid()}.tmp"); tmp.write_text(json.dumps(st)); os.replace(tmp, STATUS)
    time.sleep(0.5)
