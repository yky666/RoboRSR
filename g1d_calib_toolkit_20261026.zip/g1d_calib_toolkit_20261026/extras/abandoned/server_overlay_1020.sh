#!/bin/bash
# URDF for params_heads_1020 + projected head_left overlays: nominal (red) / dual_trans (green) / heads (orange)
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015
S=$R/real_data/20261019/sessions
V=$R/scratch/urdf_variants_20261020
mkdir -p $V
cd $R
[ -d $V/heads ] || $PY apply_calibration.py $S/params_heads_1020.json $V/heads
[ -e $V/heads/meshes ] || ln -s $R/assembled_calib_20261016/meshes $V/heads/meshes
cd /dev/shm/isaac_work
I=$R/real_data/20261016/intrinsics/camera_intrinsics_head_left.json
C=$R/assembled_calib_20261016/camera_contract_v5.json
NOM=$R/assembled_calib_20261016/g1_d_upper_dex1_v4.urdf
DT=$R/scratch/urdf_variants_20261019/dual_trans/g1_d_upper_dex1_v4.urdf
HD=$V/heads/g1_d_upper_dex1_v4.urdf
$PY overlay_projected.py ov_left_1509 $S/calib_20261019_1509_B_wrist_table_board_left $I $C left 4 \
  nominal=$NOM=0,0,255 dual_trans=$DT=0,200,0 heads=$HD=0,140,255 2>&1 | grep -v realcam
$PY overlay_projected.py ov_right_1533 $S/calib_20261019_1533_B_wrist_table_board_right $I $C right 4 \
  nominal=$NOM=0,0,255 dual_trans=$DT=0,200,0 heads=$HD=0,140,255 2>&1 | grep -v realcam
