# touch_targets_image.py -- annotate the touch targets A..H on a fresh head-camera image (projected via board PnP)
from pathlib import Path

import cv2
import numpy as np
import zmq

HERE = Path(__file__).parent
import json
doc = json.loads((HERE / "calib_data" / "intrinsics" / "camera_intrinsics_head_left.json").read_text(encoding="utf-8"))
K, dist = np.array(doc["K"]), np.array(doc["dist"])
TARGETS = {"A": 10, "B": 16, "C": 37, "D": 43, "E": 22, "F": 31, "G": 13, "H": 40}
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters(); dp.minMarkerPerimeterRate = 0.01
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners()

s = zmq.Context.instance().socket(zmq.SUB)
s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
s.connect("tcp://192.168.123.164:55555")
for _ in range(5):
    data = s.recv()
img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
img = img[:, : img.shape[1] // 2].copy()
g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
cc, ci, _, _ = det.detectBoard(g)
imgp = ((cc.reshape(-1, 2) + 0.5) / 2 - 0.5).astype(np.float64)
ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()].astype(np.float64), imgp, K, dist, flags=cv2.SOLVEPNP_IPPE)
big = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
for lab, cid in TARGETS.items():
    p, _ = cv2.projectPoints(OBJ[cid].reshape(1, 3).astype(np.float64), rv, tv, K, dist)
    u, v = (p.ravel() * 2).astype(int)
    col = (0, 0, 255) if lab in "BD" else ((255, 0, 0) if lab in "AC" else (0, 200, 0))
    cv2.circle(big, (u, v), 9, col, 3)
    cv2.putText(big, lab, (u + 10, v - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.2, col, 3)
cv2.putText(big, "RED: left arm only   BLUE: right arm only   GREEN: both arms", (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 3)
out = HERE.parent / "触碰目标点.jpg"
cv2.imencode(".jpg", big, [cv2.IMWRITE_JPEG_QUALITY, 92])[1].tofile(str(out))
print(out)
