#!/bin/bash
# arm mount relative to the head cameras: re-export the 10-19 sessions WITH head_left/head_right observations of the
# table board, then identify with the head camera extrinsics FIXED (validated by the torso overlay) and the full
# shoulder_pitch frame (zero, rot_u, rot_v, dx, dy, dz) of BOTH arms free; rest as params_dual_trans_1019
PY=${ISAAC_ENV:?set ISAAC_ENV to the unitree_sim_env conda env, see docs/环境配置_zh.md}/bin/python
R=/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261019
S=$R/sessions
H=$R/poses_v2/scene_header_B.json
LOG=/dev/shm/isaac_work/heads_1020.log
cd /dev/shm/isaac_work
{
echo "===== export with heads $(date '+%T')"
/usr/bin/python3 export_meas.py --heads --session $S/calib_20261019_1209_B_wrist_table_board_left --header $H \
  --board-name table_1209 --out $S/meas_B_left_1209_heads.json | head -1
/usr/bin/python3 export_meas.py --heads --session $S/calib_20261019_1509_B_wrist_table_board_left --header $H \
  --board-name table_pm --out $S/meas_B_left_1509_pm_heads.json | head -1
/usr/bin/python3 export_meas.py --heads --session $S/calib_20261019_1533_B_wrist_table_board_right --header $H \
  --board-name table_pm --out $S/meas_B_right_1533_pm_heads.json | head -1
for f in meas_B_left_1209_heads meas_B_left_1509_pm_heads meas_B_right_1533_pm_heads; do
  echo "$f: $(grep -o '"camera": "head_left"' $S/$f.json | wc -l) head_left, $(grep -o '"camera": "head_right"' $S/$f.json | wc -l) head_right obs"
done
cd /root/unitree_sim_isaaclab/real2sim_calib_20261015_realcam
export OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8
echo "===== identify: heads fixed, both shoulder mounts free $(date '+%T')"
$PY identify.py $S/meas_B_left_1209_heads.json $S/meas_B_left_1509_pm_heads.json $S/meas_B_right_1533_pm_heads.json \
  --preset auto --refine-intrinsics \
  --estimate 'left_*_joint/d*' 'right_*_joint/d*' \
             'left_shoulder_pitch_joint/zero' 'left_shoulder_pitch_joint/rot_u' 'left_shoulder_pitch_joint/rot_v' \
             'right_shoulder_pitch_joint/zero' 'right_shoulder_pitch_joint/rot_u' 'right_shoulder_pitch_joint/rot_v' \
  --exclude 'camera:head_*' \
  --prior 'left_*_joint/d*=0.003' 'right_*_joint/d*=0.003' '*_shoulder_pitch_joint/d*=0.02' \
  --loss soft_l1 --f-scale 1.0 --folds 5 \
  --out $S/identify_heads_1020.json --params-out $S/params_heads_1020.json 2>&1 | grep -v realcam | tail -60
echo "HEADS_DONE $(date '+%T')"
} > $LOG 2>&1
