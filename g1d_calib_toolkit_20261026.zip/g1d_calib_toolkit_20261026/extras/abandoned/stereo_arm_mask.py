# stereo_arm_mask.py -- feasibility: segment the real arms in head_stereo frames by stereo depth (things standing
# above the table plane), to fit the arm silhouette later without markers
# usage: stereo_arm_mask.py <session_dir> <intrinsics_dir> <board_pose_measured.json> <out_dir> <pose_id> [...]
import json
import sys
from pathlib import Path

import cv2
import numpy as np

SES, INT, BP, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
OUT.mkdir(parents=True, exist_ok=True)
# head cameras: camworld (+X fwd, +Y left, +Z up) poses in the torso frame (contract v5 + URDF, head fixed to torso)
R_HEAD = np.array([[0.6743023875837233, 0.0, 0.7384553406258838], [0.0, 1.0, 0.0],
                   [-0.7384553406258838, 0.0, 0.6743023875837233]])
T_L, T_R = np.array([0.04812857, 0.02963228, 0.43599143]), np.array([0.04812857, -0.02996772, 0.43599143])
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)          # optical <- camworld
intr = {e: json.loads((INT / f"camera_intrinsics_{e}.json").read_text()) for e in ("head_left", "head_right")}
K1, D1 = np.array(intr["head_left"]["K"]), np.array(intr["head_left"]["dist"])
K2, D2 = np.array(intr["head_right"]["K"]), np.array(intr["head_right"]["dist"])
W, H = 640, 480
# right-camera pose expressed in the left optical frame: X_r = R X_l + t
R_lo = OPT @ R_HEAD.T                                      # torso -> left optical (rotation)
R = np.eye(3)                                              # same orientation
t = -(R_lo @ (T_R - T_L))                                  # left optical coords of the right centre, negated
R1, R2, P1, P2, Q, _, _ = cv2.stereoRectify(K1, D1, K2, D2, (W, H), R, t, alpha=0)
m1 = cv2.initUndistortRectifyMap(K1, D1, R1, P1, (W, H), cv2.CV_32FC1)
m2 = cv2.initUndistortRectifyMap(K2, D2, R2, P2, (W, H), cv2.CV_32FC1)
sgbm = cv2.StereoSGBM_create(minDisparity=0, numDisparities=96, blockSize=5, P1=8 * 3 * 25, P2=32 * 3 * 25,
                             uniquenessRatio=5, speckleWindowSize=100, speckleRange=2,
                             mode=cv2.STEREO_SGBM_MODE_HH)
bp = json.loads(BP.read_text())
Tb = np.array(bp["head_left"]["T_torso_board"])
n_up = -Tb[:3, 2]; p0 = Tb[:3, :3] @ np.array([0.2, 0.14, 0.0]) + Tb[:3, 3]
print(f"baseline {np.linalg.norm(t) * 1000:.1f} mm, rectified f {P1[0, 0]:.1f}")
for pid in sys.argv[5:]:
    st = cv2.imread(str(SES / "images" / pid / "head_stereo.png"))
    L, Rr = st[:, :W], st[:, W:]
    Lr, Rrr = cv2.remap(L, *m1, cv2.INTER_LINEAR), cv2.remap(Rr, *m2, cv2.INTER_LINEAR)
    disp = sgbm.compute(cv2.cvtColor(Lr, cv2.COLOR_BGR2GRAY), cv2.cvtColor(Rrr, cv2.COLOR_BGR2GRAY)).astype(np.float32) / 16
    pts = cv2.reprojectImageTo3D(disp, Q)                  # rectified-left frame
    ok = disp > 1
    # rectified-left -> left optical -> torso
    X = pts.reshape(-1, 3) @ R1                             # R1: optical -> rectified, so R1^T maps back
    Xt = (X @ OPT) @ R_HEAD.T + T_L                         # optical -> camworld -> torso
    h = (Xt - p0) @ n_up
    depth = pts[..., 2]
    above = (ok.ravel() & (h > 0.025) & (h < 0.6) & (depth.ravel() < 1.2)).reshape(H, W)
    above = cv2.morphologyEx(above.astype(np.uint8) * 255, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    vis = Lr.copy()
    vis[above > 0] = (0.5 * vis[above > 0] + 0.5 * np.array([0, 0, 255])).astype(np.uint8)
    dv = cv2.applyColorMap(np.clip(disp * 4, 0, 255).astype(np.uint8), cv2.COLORMAP_JET)
    dv[~ok] = 0
    cv2.imwrite(str(OUT / f"seg_{pid}.png"), np.hstack([vis, dv]))
    print(pid, f"valid disparity {ok.mean() * 100:.0f}%  above-table pixels {np.count_nonzero(above)}")
