# render_sim.py -- IsaacSim 5.0 headless: load real G1-D URDF, set real joint angles,
# render 4 cameras using contract extrinsics + our calibrated intrinsics
# run: /dev/shm/isaac_work/venv311/bin/python /dev/shm/isaac_work/render_sim.py
import json
import os
import sys

import numpy as np

DATA = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/body_overlay/frames"
INTR = "/root/unitree_sim_isaaclab/real2sim_calib_20261015/real_data/20261016/intrinsics"
URDF = "/dev/shm/isaac_work/assembled/g1_d_upper_dex1_v4.urdf"
CONTRACT = "/dev/shm/isaac_work/assembled/camera_contract_v5.json"
OUT = "/dev/shm/isaac_work/render_out"
os.makedirs(OUT, exist_ok=True)

from isaacsim import SimulationApp

simulation_app = SimulationApp({"headless": True})

import omni.kit.commands
import omni.usd
from pxr import Usd, UsdGeom

# ---------- 1) import URDF ----------
from isaacsim.asset.importer.urdf import _urdf

cfg = _urdf.ImportConfig()
cfg.merge_fixed_joints = False   # keep fixed-joint links (head_link, dex1_base_link...)
cfg.fix_base = True
cfg.self_collision = False
cfg.make_default_prim = False

ok, robot_path = omni.kit.commands.execute(
    "URDFParseAndImportFile",
    urdf_path=URDF,
    import_config=cfg,
)
print("[import]", ok, robot_path, flush=True)
if not ok:
    sys.exit(1)

# ---------- 2) world + lights ----------
from isaacsim.core.api import World
import isaacsim.core.utils.prims as prim_utils

world = World(stage_units_in_meters=1.0)
world.get_physics_context().set_gravity(0.0)
# DomeLight = the only light that illuminates these STL materials properly,
# but it also paints the sky white. We composite onto black using the rgba
# alpha channel (alpha=0 on sky, 1 on geometry) when saving.
prim_utils.create_prim("/World/DomeLight", "DomeLight",
                       attributes={"inputs:intensity": float(os.environ.get("DOME_INT", "350"))})
prim_utils.create_prim(
    "/World/KeyLight", "DistantLight",
    attributes={"inputs:intensity": 400.0, "inputs:angle": 2.0},
    orientation=(0.9397, -0.342, 0.0, 0.0),
)

# ---------- 2.5) stage helpers + fix detached /visuals ----------
stage = omni.usd.get_context().get_stage()

def world_T(prim):
    m = UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    return np.array(m, dtype=float).T  # row-vector matrix -> column-vector convention

def set_prim_world_matrix(prim, T_col):
    """write 4x4 (column-vector convention) into prim xform"""
    from pxr import Gf
    S = np.array(T_col, dtype=float).T  # Gf stores row-vector matrix
    xf = UsdGeom.Xformable(prim)
    for op in xf.GetOrderedXformOps():
        xf.ClearXformOpOrder()
        break
    op = xf.AddTransformOp(UsdGeom.XformOp.PrecisionDouble)
    op.Set(Gf.Matrix4d(*[float(v) for v in S.flatten()]))

def find_prim(name):
    hits = [p for p in stage.Traverse() if p.GetName() == name]
    return hits[0] if hits else None

def find_link_prim(name):
    root = stage.GetPrimAtPath(robot_path)
    for p in Usd.PrimRange(root):
        if p.GetName() == name:
            return p
    return None

# URDF importer quirk: visual meshes land in detached /visuals group, invisible.
vis_root_prim = stage.GetPrimAtPath("/visuals")
assert vis_root_prim, "/visuals group missing"
print("[visuals] prim types:", vis_root_prim.GetTypeName(),
      [ (c.GetName(), c.GetTypeName()) for c in list(vis_root_prim.GetChildren())[:3] ], flush=True)
n_inv = 0
for p in stage.Traverse():
    if p.GetPath().pathString.startswith("/visuals"):
        imgp = UsdGeom.Imageable(p)
        if imgp.GetVisibilityAttr().Get() == "invisible":
            imgp.GetVisibilityAttr().Set("inherited")
            n_inv += 1
img = UsdGeom.Imageable(vis_root_prim)
img.MakeVisible()
print(f"[visuals] cleared invisible on {n_inv} prims, root -> {img.ComputeVisibility()}", flush=True)

# ---------- 3) set joints ----------
from isaacsim.core.prims import SingleArticulation

art = SingleArticulation(prim_path=robot_path if isinstance(robot_path, str) else "/World/g1d")
world.scene.add(art)
world.reset()

# capture import-pose offsets between robot links and detached visual prims:
# T_visual(t) = world_T_link(t) @ inv(world_T_link(0)) @ world_T_visual(0)
visual_links = []
for child in vis_root_prim.GetChildren():
    lp = find_link_prim(child.GetName())
    if lp is None:
        continue
    visual_links.append((lp, child, np.linalg.inv(world_T(lp)), world_T(child)))
print(f"[visuals] articulated {len(visual_links)} link visuals", flush=True)

qraw = json.load(open(os.path.join(DATA, "q.json")))
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow",
       "wrist_roll", "wrist_pitch", "wrist_yaw"]
q_target, names = [], []
dof_names = list(art.dof_names)
print("[dofs]", dof_names, flush=True)
for side in ["left", "right"]:
    for jn, v in zip(ARM, qraw[side]):
        full = f"{side}_{jn}_joint"
        if full in dof_names:
            names.append(full)
            q_target.append(float(v))
idx = [art.get_dof_index(n) for n in names]
print("[set]", len(names), "joints", flush=True)
art.set_joint_positions(np.array(q_target), joint_indices=np.array(idx))
for _ in range(10):
    world.step(render=True)
qnow = art.get_joint_positions(joint_indices=np.array(idx))
print("[q err max]", float(np.max(np.abs(qnow - np.array(q_target)))), flush=True)

# ---------- 4) cameras ----------
def mat_to_quat_wxyz(R):
    t = np.trace(R)
    if t > 0:
        s = np.sqrt(t + 1.0) * 2
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    q = np.array([w, x, y, z])
    return q / np.linalg.norm(q)

OPTICAL_FROM_CAMERA = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], dtype=float)
D = np.diag([1.0, -1.0, -1.0])
B = np.eye(4)
B[:3, :3] = OPTICAL_FROM_CAMERA.T @ D   # camworld -> optical -> usd-camera(-Z fwd,+Y up)

from isaacsim.sensors.camera import Camera
from PIL import Image

contract = json.load(open(CONTRACT))
views = {v["name"]: v for v in contract["views"]}
report = {}
cams = {}

for cam_name in ["head_left", "head_right", "left_wrist", "right_wrist"]:
    doc = json.load(open(os.path.join(INTR, f"camera_intrinsics_{cam_name}.json")))
    K = np.array(doc["K"], dtype=float)
    W, H = doc["resolution"]
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]

    view = views[cam_name]
    parent_prim = find_prim(view["parent"])
    assert parent_prim is not None, f"parent link {view['parent']} not found"
    T_w_link = world_T(parent_prim)
    T_parent_cam = np.array(view["T_parent_camera_world_convention"], dtype=float)
    T_w_cam = T_w_link @ T_parent_cam @ B   # usd-camera frame pose

    cam = Camera(prim_path=f"/World/cam_{cam_name}", resolution=(int(W), int(H)))
    cam.initialize()
    # set pose via the WRAPPER (it keeps its own render state; raw USD writes
    # alone leave the wrapper at identity -> renders from origin inside torso)
    q_usd = mat_to_quat_wxyz(T_w_cam[:3, :3])
    T_w_camworld = T_w_link @ T_parent_cam
    q_world = mat_to_quat_wxyz(T_w_camworld[:3, :3])
    try:
        cam.set_world_pose(position=T_w_cam[:3, 3], orientation=q_usd, camera_axes="usd")
        axes_used = "usd"
    except Exception as e:
        cam.set_world_pose(position=T_w_cam[:3, 3], orientation=q_world, camera_axes="world")
        axes_used = "world(except)"
    set_prim_world_matrix(cam.prim, T_w_cam)  # keep USD consistent
    # readback checks: USD matrix AND wrapper pose must agree with target
    Rb = world_T(cam.prim)
    assert np.max(np.abs(Rb - T_w_cam)) < 1e-6, f"{cam_name} pose write mismatch"
    wp, wq = cam.get_world_pose(camera_axes=axes_used.split("(")[0])
    wRb = np.eye(4)
    wRb[:3, 3] = wp
    pos = T_w_cam[:3, 3]
    print(f"[{cam_name}] axes={axes_used} wrapper_pos_err={np.linalg.norm(wp - pos)*1000:.2f}mm",
          flush=True)
    cams[cam_name] = cam

    # intrinsics: focal/aperture
    f0 = cam.get_focal_length()
    hap = f0 * W / fx
    vap = f0 * H / fy
    cam.set_horizontal_aperture(hap)
    cam.set_vertical_aperture(vap)
    # principal point via USD film-window offset
    # horizontal: cx_pix = W/2 - off_h*W/hap ; vertical film axis is flipped: cy_pix = H/2 + off_v*H/vap
    # (empirically verified with probe spheres 2026-10-16)
    off_h = (W / 2.0 - cx) * hap / W
    off_v = (cy - H / 2.0) * vap / H
    prim = cam.prim
    prim.GetAttribute("horizontalApertureOffset").Set(float(off_h))
    prim.GetAttribute("verticalApertureOffset").Set(float(off_v))
    Kr = cam.get_intrinsics_matrix()  # getter ignores apertureOffset; check fx/fy only
    err = max(abs(Kr[0, 0] - fx), abs(Kr[1, 1] - fy))
    print(f"[{cam_name}] fx/fy err={err:.4f}px  off_h={off_h:.4f} off_v={off_v:.4f} "
          f"(cx-W/2={cx - W / 2:.1f} cy-H/2={cy - H / 2:.1f})", flush=True)
    report[cam_name] = {"K_target": K.tolist(), "fxfy_err_px": float(err),
                        "off_h": float(off_h), "off_v": float(off_v),
                        "pos": pos.tolist()}

# ---------- 4.5) probe spheres for head_left (validation, DISABLED for final renders) ----------
if os.environ.get("RENDER_PROBES", "0") == "1":
    cam0 = cams["head_left"]
    view0 = views["head_left"]
    T_w_link0 = world_T(find_prim(view0["parent"]))
    T_w_camworld0 = T_w_link0 @ np.array(view0["T_parent_camera_world_convention"], dtype=float)
    fwd0 = -world_T(cam0.prim)[:3, 2]
    print("[head_left fwd(usd -z)]", np.round(fwd0, 3).tolist(), "expect ~[0.674,0,-0.738]", flush=True)
    from pxr import Gf as _Gf
    probe_colors = [(1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.2, 1.0)]
    # probe_0 red -> expect (cx,cy)=(315,234); probe_1 green -> (399,234); probe_2 blue -> (315,150)
    for i, p_c in enumerate([[1.0, 0.0, 0.0], [1.0, -0.3, 0.0], [1.0, 0.0, 0.3]]):
        p_w = T_w_camworld0[:3, :3] @ np.array(p_c) + T_w_camworld0[:3, 3]
        sp = prim_utils.create_prim(f"/World/probe_{i}", "Sphere", position=p_w.tolist())
        UsdGeom.Sphere(sp).GetRadiusAttr().Set(0.03)
        UsdGeom.Gprim(sp).CreateDisplayColorAttr().Set([_Gf.Vec3f(*probe_colors[i])])
        print(f"[probe_{i}] camworld={p_c} world={np.round(p_w,3).tolist()}", flush=True)

# ---------- 5) drive detached visuals to posed links, then render ----------
for lp, vp, Zinv, V0 in visual_links:
    set_prim_world_matrix(vp, world_T(lp) @ Zinv @ V0)
print("[visuals] driven to posed links", flush=True)

for _ in range(30):
    simulation_app.update()

for cam_name, cam in cams.items():
    rgba = cam.get_rgba(device="cpu")
    rgba = np.asarray(rgba, dtype=np.float32)
    if rgba.max() <= 1.0 + 1e-3:
        rgba = rgba * 255.0
    rgb = rgba[..., :3].astype(np.uint8)
    graw = rgb.mean(axis=2)
    print(f"[raw] {cam_name} mean={graw.mean():.1f} std={graw.std():.1f} "
          f"corner={rgb[0,0].tolist()} uniq={len(np.unique(graw[::8, ::8]))}", flush=True)
    Image.fromarray(rgb).save(os.path.join(OUT, f"sim_raw_{cam_name}.png"))
    # segment sky (uniform corner color) -> black background
    sky = rgb[0, 0].astype(np.int32)
    diff = np.abs(rgb.astype(np.int32) - sky).max(axis=2)
    mask = diff > 4
    rgb[~mask] = 0
    Image.fromarray(rgb).save(os.path.join(OUT, f"sim_{cam_name}.png"))
    g = rgb.mean(axis=2)
    gr = g[mask] if mask.any() else g
    print(f"[saved] sim_{cam_name}.png robot%={100.0 * mask.mean():.0f} "
          f"robot_mean={gr.mean():.1f} robot_std={gr.std():.1f}", flush=True)

json.dump(report, open(os.path.join(OUT, "sim_camera_report.json"), "w"), indent=1)
print("[done]", flush=True)
simulation_app.close()
