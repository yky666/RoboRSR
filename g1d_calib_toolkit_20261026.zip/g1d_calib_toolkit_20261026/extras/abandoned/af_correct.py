# af_correct.py -- compensate wrist-camera autofocus (per-sample focal length) before identification.
# 1) per observation: single-view fit of fx (=fy) with principal point + distortion fixed (image-only, no kinematics)
# 2) empirical-Bayes shrinkage of each fx toward the population mean using its single-view std
# 3) re-map pixels to one common focal length: undistort with K_i, re-project with K_ref (same distortion)
# usage: af_correct.py <meas.json> [...]   -> writes <meas>_afc.json + prints the focal statistics
# server, /usr/bin/python3
import json
import sys
from pathlib import Path

import cv2
import numpy as np

FLAGS = (cv2.CALIB_USE_INTRINSIC_GUESS | cv2.CALIB_FIX_PRINCIPAL_POINT | cv2.CALIB_FIX_ASPECT_RATIO |
         cv2.CALIB_FIX_K1 | cv2.CALIB_FIX_K2 | cv2.CALIB_FIX_K3 | cv2.CALIB_FIX_TANGENT_DIST)

docs = [(Path(p), json.loads(Path(p).read_text())) for p in sys.argv[1:]]
fits = []   # (doc_idx, sample_idx, obs_idx, fx, std)
for di, (_, m) in enumerate(docs):
    for si, s in enumerate(m["samples"]):
        for oi, o in enumerate(s["observations"]):
            c = m["cameras"][o["camera"]]
            P = {int(p[0]): p[1:] for p in m["boards"][o["board"]]["points_m"]}
            obj = np.array([P[i] for i in o["corner_ids"]], np.float32)
            img = np.array(o["pixels"], np.float32)
            K = np.array(c["K"], np.float64); d = np.array(c["dist"], np.float64)
            res = cv2.calibrateCameraExtended([obj], [img], tuple(c["resolution"]), K.copy(), d.copy(), flags=FLAGS)
            K_i, std_i = res[1], res[5].ravel()
            fits.append((di, si, oi, float(K_i[0, 0]), max(float(std_i[0]), 0.5)))

fx = np.array([f[3] for f in fits]); sd = np.array([f[4] for f in fits])
w = 1.0 / sd ** 2
mu = float(np.sum(w * fx) / np.sum(w))
# between-sample (true AF) variance: method of moments
tau2 = max(0.0, float(np.sum(w * (fx - mu) ** 2) - (len(fx) - 1)) / float(np.sum(w) - np.sum(w ** 2) / np.sum(w)))
shrunk = (fx / sd ** 2 + mu / max(tau2, 1e-9)) / (1 / sd ** 2 + 1 / max(tau2, 1e-9))
print(f"{len(fx)} observations: weighted mean fx {mu:.1f} px, single-view std median {np.median(sd):.1f} px, "
      f"estimated true AF spread {np.sqrt(tau2):.1f} px; shrunk fx range {shrunk.min():.1f}..{shrunk.max():.1f}")

for k, (di, si, oi, f_raw, s_raw) in enumerate(fits):
    m = docs[di][1]
    o = m["samples"][si]["observations"][oi]
    c = m["cameras"][o["camera"]]
    K = np.array(c["K"], np.float64); d = np.array(c["dist"], np.float64)
    K_i = K.copy(); K_i[0, 0] = K_i[1, 1] = shrunk[k]
    K_ref = K.copy(); K_ref[0, 0] = K_ref[1, 1] = mu
    pts = np.array(o["pixels"], np.float64).reshape(-1, 1, 2)
    xn = cv2.undistortPoints(pts, K_i, d).reshape(-1, 2)
    xyz = np.hstack([xn, np.ones((len(xn), 1))])
    p2, _ = cv2.projectPoints(xyz, np.zeros(3), np.zeros(3), K_ref, d)
    o["pixels"] = np.round(p2.reshape(-1, 2), 3).tolist()
    o["af_fx_single"] = round(f_raw, 2); o["af_fx_used"] = round(float(shrunk[k]), 2)

for p, m in docs:
    for cname, c in m["cameras"].items():
        if cname.endswith("wrist"):
            c["K"][0][0] = c["K"][1][1] = mu
            c.setdefault("notes", []).append(f"af_correct: pixels re-mapped to common fx={mu:.2f} (per-sample AF compensated)")
    out = p.with_name(p.stem + "_afc.json")
    out.write_text(json.dumps(m, indent=1))
    print("written", out)
