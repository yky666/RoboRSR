# merge_calib_into_robodojo.py -- put our calibration (params_final_1021.json) onto the RoboDojo G1-D asset.
#   URDFs: every joint origin that exists in our calibrated upper-body URDF is copied into theirs (the 14 arm joints
#          change; the others are identical to the shared nominal v4 model). Writes <name>_calib.urdf.
#   robot_config yml: wrist camera pos/ori = their nominal mount (== our contract) right-multiplied by our identified
#          camera:<side>_wrist delta; head cameras are unchanged (the head-arm offset is in the shoulder mounts).
#          Writes {left,right}_robot_config_calib.yml with urdf_path -> g1d_dex1_calib.urdf.
# usage: merge_calib_into_robodojo.py <their_asset_dir> <our_calibrated_upper.urdf> <params.json> <out_dir>
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
sys.path.insert(0, str(ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"))
from calib_model import load_params, se3, se3_of  # noqa: E402

SRC, CAL_URDF, PARAMS, OUT = (Path(a) for a in sys.argv[1:5])
OUT.mkdir(parents=True, exist_ok=True)
R_WORLD_USD = np.array([[0, 0, -1], [-1, 0, 0], [0, 1, 0]], float)  # USD camera (-z fwd, +y up) in x-fwd/z-up axes

cal = {j.get("name"): j.find("origin") for j in ET.parse(CAL_URDF).getroot().findall("joint")}
for name in ("g1d_dex1.urdf", "g1d_mobile_dex1.urdf"):
    tree = ET.parse(SRC / name)
    changed = []
    for j in tree.getroot().findall("joint"):
        o_cal = cal.get(j.get("name"))
        if o_cal is None:
            continue
        o = j.find("origin")
        old = (o.get("xyz"), o.get("rpy"))
        o.set("xyz", o_cal.get("xyz", "0 0 0"))
        o.set("rpy", o_cal.get("rpy", "0 0 0"))
        if (o.get("xyz"), o.get("rpy")) != old:
            changed.append(j.get("name"))
    out = OUT / name.replace(".urdf", "_calib.urdf")
    tree.write(out, encoding="utf-8", xml_declaration=True)
    print(f"{out.name}: {len(changed)} joint origins changed: {changed}")

P = load_params(PARAMS)["values"]
for side in ("left", "right"):
    txt = (SRC / f"{side}_robot_config.yml").read_text(encoding="utf-8")
    txt = txt.replace('urdf_path: "./g1d_dex1.urdf"', 'urdf_path: "./g1d_dex1_calib.urdf"')
    block = re.search(r'(name: "cam_wrist".*?pos: \[)([^\]]+)(\].*?ori: \[)([^\]]+)(\])', txt, re.S)
    pos = np.array([float(v) for v in block.group(2).split(",")])
    w, x, y, z = (float(v) for v in block.group(4).split(","))
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([x, y, z, w]).as_matrix() @ R_WORLD_USD.T  # link -> x-fwd camera
    T[:3, 3] = pos
    Tc = T @ se3(se3_of(P, f"camera:{side}_wrist"))
    q = Rotation.from_matrix(Tc[:3, :3] @ R_WORLD_USD).as_quat()  # back to link -> USD camera, xyzw
    q = q if q[3] >= 0 else -q
    new_pos = ", ".join(f"{v:.4f}" for v in Tc[:3, 3])
    new_ori = ", ".join(f"{v:.4f}" for v in (q[3], q[0], q[1], q[2]))
    txt = txt[:block.start(2)] + new_pos + txt[block.end(2):block.start(4)] + new_ori + txt[block.end(4):]
    txt = txt.replace(new_pos + "]", new_pos + "]  # calibrated (params_final_1021 camera delta); nominal [" +
                      block.group(2) + "]", 1)
    hdr = f"# CALIBRATED copy: arm joint origins + {side} wrist camera mount from our params_final_1021.json\n"
    (OUT / f"{side}_robot_config_calib.yml").write_text(hdr + txt, encoding="utf-8")
    dpos = (Tc[:3, 3] - T[:3, 3]) * 1000
    drot = np.degrees(Rotation.from_matrix(T[:3, :3].T @ Tc[:3, :3]).magnitude())
    print(f"{side}_robot_config_calib.yml: cam_wrist pos [{block.group(2)}] -> [{new_pos}] "
          f"(moved {np.round(dpos, 1)} mm, {drot:.2f} deg), ori [{block.group(4)}] -> [{new_ori}]")
