# plan_board_view.py -- small wrist adjustments (from the all-zero pose) that show the table board to each wrist camera.
# Calibrated RoboDojo URDF + our cameras; board pose from the head stereo (board_pose.json, both eyes averaged).
# Score: board corners inside the image and outside the (fixed) finger mask; fingertips >= 6 cm above the board plane.
# usage: plan_board_view.py <asset_dir> <board_pose.json> <out.json>
import itertools
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

ASSET, BOARD, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.argv = sys.argv[:1] + [str(ASSET), os.environ.get("TEMP", "/tmp")]
src = open(Path(__file__).parent / "check_robodojo_merge.py", encoding="utf-8").read().split("# ---------------- run ----------------")[0]
mod = {}
exec(compile(src, "check_robodojo_merge.py", "exec"), mod)
Urdf, raster, project, OPT = mod["Urdf"], mod["raster"], mod["project"], mod["OPT_FROM_CAM"]
U = Urdf(ASSET / "g1d_dex1_calib.urdf")
cams = json.loads((Path(__file__).parent / "robodojo_merge/camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
bp = json.loads(BOARD.read_text(encoding="utf-8"))
Ts = [np.array(bp[e]["T_torso_board"]) for e in ("head_left", "head_right") if bp.get(e)]
T_tb = np.eye(4)
T_tb[:3, 3] = np.mean([T[:3, 3] for T in Ts], 0)
T_tb[:3, :3] = Rotation.from_matrix([T[:3, :3] for T in Ts]).mean().as_matrix()
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
OBJ = board.getChessboardCorners().astype(float)
P_corners = OBJ @ T_tb[:3, :3].T + T_tb[:3, 3]
n_up = -T_tb[:3, 2]  # board z points into the table
ARMJ = {s: [f"{s}_{n}_joint" for n in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll",
                                       "wrist_pitch", "wrist_yaw")] for s in ("left", "right")}
TIPS = {s: [f"{s}_dex1_finger_link_{i}_tip" for i in (1, 2)] for s in ("left", "right")}
plan = {}
for side in ("left", "right"):
    c = cams[f"{side}_wrist"]
    K, D = np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
    Tm = np.array(c["T_parent_camera_world_convention"])
    q0 = {n: 0.0 for n in ARMJ[side]}
    q0[f"{side}_dex1_finger_joint_1"] = q0[f"{side}_dex1_finger_joint_2"] = -0.0195  # open, as now
    Tcam0 = np.linalg.inv(U.fk(f"{side}_dex1_base_link", q0) @ Tm)
    fingers = raster(U, [f"{side}_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")], q0, Tcam0, K, D)
    fingers = cv2.dilate(fingers, np.ones((15, 15), np.uint8))
    cands = []
    sgn = 1 if side == "left" else -1
    for sp, wp, wy, wr in itertools.product((0.0, -0.15, -0.3), (-0.2, 0.0, 0.2, 0.4, 0.6), (-0.4, -0.2, 0.0, 0.2, 0.4),
                                            (0.0,)):
        q = dict(q0)
        q[ARMJ[side][0]], q[ARMJ[side][5]], q[ARMJ[side][6]], q[ARMJ[side][4]] = sp, wp, wy * sgn, wr
        Tw = U.fk(f"{side}_dex1_base_link", q) @ Tm
        pc = (P_corners - Tw[:3, 3]) @ Tw[:3, :3] @ OPT.T
        uv, ok = project(pc, K, D)
        ins = ok & (uv[:, 0] > 10) & (uv[:, 0] < 630) & (uv[:, 1] > 10) & (uv[:, 1] < 470)
        vis = ins.copy()
        vis[ins] = fingers[uv[ins, 1].astype(int), uv[ins, 0].astype(int)] == 0
        tip_h = min(float((U.fk(t, q)[:3, 3] - T_tb[:3, 3]) @ n_up) for t in TIPS[side])
        if tip_h < 0.06:
            continue
        ctr = uv[vis].mean(0) if vis.any() else np.array([0, 0])
        cands.append({"q": [q[n] for n in ARMJ[side]], "visible": int(vis.sum()), "tip_above_board_m": round(tip_h, 3),
                      "board_px_centre": np.round(ctr, 0).tolist(), "dist_from_zero": float(np.abs([sp, wp, wy]).sum())})
    cands.sort(key=lambda r: (-r["visible"], r["dist_from_zero"]))
    pick = [next(r for r in cands if r["dist_from_zero"] == 0.0)] if any(r["dist_from_zero"] == 0.0 for r in cands) else []
    for r in cands:  # diverse: board centre at least 90 px from the picks so far, >= 30 corners
        if len(pick) >= 4:
            break
        if r["visible"] >= 30 and all(np.linalg.norm(np.subtract(r["board_px_centre"], p["board_px_centre"])) > 90 for p in pick):
            pick.append(r)
    plan[side] = pick
    print(f"{side}: {len(cands)} safe candidates")
    for p in pick:
        print(f"  q {np.round(p['q'], 2).tolist()}  visible corners {p['visible']:2d}  tips {p['tip_above_board_m'] * 100:.1f} cm "
              f"above board  board centre px {p['board_px_centre']}")
OUT.write_text(json.dumps({"T_torso_board": T_tb.tolist(), "plan": plan}, indent=1), encoding="utf-8")
