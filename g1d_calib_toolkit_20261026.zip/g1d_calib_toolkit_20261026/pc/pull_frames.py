# pull_frames.py — 从 G1-D 相机 ZMQ 流各抓一帧并统计帧率（流程跑通用，只读不控制）
# 协议参考机器人 ~/g1d_infra/teleop/teleimager（别人的工作区，仅参考不改动）：
#   SUB 连接 tcp://192.168.123.164:<port>，收 JPEG 字节流，cv2.imdecode 解码
import time
from pathlib import Path

import cv2
import numpy as np
import zmq

HOST = "192.168.123.164"
CAMS = {  # 名称: (端口, 是否双目)
    "head": (55555, True),
    "left_wrist": (55556, False),   # 2026-10-21 21:25 起 teleimager 配置已改：55556 = 左腕（JR0002）
    "right_wrist": (55557, False),  # 55557 = 右腕（JR0001）；10-16~10-21 的历史数据是反的
}
OUT = Path(__file__).parent / "frames_test"


def imwrite_unicode(path: Path, img) -> None:
    """cv2.imwrite 在 Windows 不支持中文路径，改用 imencode + 字节写盘"""
    ok, buf = cv2.imencode(".png", img)
    if not ok:
        raise RuntimeError(f"imencode failed: {path}")
    path.write_bytes(buf.tobytes())


def pull_one(name, port, binocular, seconds=3.0):
    ctx = zmq.Context.instance()
    s = ctx.socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1)
    s.setsockopt(zmq.RCVTIMEO, 3000)
    s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")

    first = None
    n, t0 = 0, time.perf_counter()
    deadline = t0 + seconds
    while time.perf_counter() < deadline:
        try:
            data = s.recv()
        except zmq.Again:
            break
        if first is None:
            first = data
        n += 1
    dt = time.perf_counter() - t0
    s.close(0)

    if first is None:
        print(f"[{name}] port {port}: 无帧（{dt:.1f}s 超时）")
        return

    img = cv2.imdecode(np.frombuffer(first, np.uint8), cv2.IMREAD_COLOR)
    fps = n / dt if dt > 0 else 0
    print(f"[{name}] port {port}: shape={img.shape}, 实测 {fps:.1f} fps ({n} 帧/{dt:.1f}s)")

    OUT.mkdir(exist_ok=True)
    if binocular:
        h, w = img.shape[:2]
        left, right = img[:, : w // 2], img[:, w // 2 :]
        imwrite_unicode(OUT / f"{name}_left.png", left)
        imwrite_unicode(OUT / f"{name}_right.png", right)
        print(f"  -> 已存 {name}_left.png / {name}_right.png（各 {left.shape[1]}x{left.shape[0]}）")
    else:
        imwrite_unicode(OUT / f"{name}.png", img)
        print(f"  -> 已存 {name}.png")


if __name__ == "__main__":
    for name, (port, bino) in CAMS.items():
        pull_one(name, port, bino)
