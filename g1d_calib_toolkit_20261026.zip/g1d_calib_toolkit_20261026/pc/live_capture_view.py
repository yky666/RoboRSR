# live_capture_view.py -- PC-side live window for the head intrinsics capture: the robot's head stereo stream (ZMQ,
# direct), ChArUco corners detected live, the coverage grid from the robot's capture status (green = covered in that
# eye, red = still missing), saved count and a hint where to hold the board next. Read-only; q / Esc closes the window
# (the capture on the robot keeps running).
import os
import re
import subprocess
import threading
import time

import cv2
import numpy as np
import zmq
from PIL import Image, ImageDraw, ImageFont

ROBOT = "192.168.123.164"
GX, GY = 6, 4
FONT = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 24)
FONT_S = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 18)
latest = {"img": None}
status = {"saved": 0, "L": np.zeros((GY, GX), bool), "R": np.zeros((GY, GX), bool), "t": 0.0, "ok": False}


def frames():
    s = zmq.Context.instance().socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 2000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{ROBOT}:55555")
    while True:
        try:
            latest["img"] = cv2.imdecode(np.frombuffer(s.recv(), np.uint8), cv2.IMREAD_COLOR)
        except Exception:
            pass


def poll_status():
    while True:
        try:
            r = subprocess.run(["ssh", "unitree", "cat $(cat ~/calib_sessions/head_intr_current.txt)/status.txt"],
                               capture_output=True, text=True, timeout=10)
            lines = r.stdout.splitlines()
            m = re.search(r"saved (\d+)", r.stdout)
            rows = [l for l in lines if re.fullmatch(r"[#. ]+\s+[#. ]+", l.strip() or "x")]
            if m and len(rows) >= GY:
                status["saved"] = int(m.group(1))
                for k, l in enumerate(rows[:GY]):
                    cells = l.split()
                    status["L"][k] = [c == "#" for c in cells[:GX]]
                    status["R"][k] = [c == "#" for c in cells[GX:2 * GX]]
                status["t"], status["ok"] = time.time(), True
        except Exception:
            status["ok"] = False
        time.sleep(1.5)


board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.minMarkerPerimeterRate = 0.01
cp = cv2.aruco.CharucoParameters(); cp.minMarkers = 1
det = cv2.aruco.CharucoDetector(board, cp, dp)


def detect(gray):
    g = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_LINEAR)
    cc, ci, _, _ = det.detectBoard(g)
    return [] if ci is None else ((cc.reshape(-1, 2) + 0.5) / 2 - 0.5)


def hint(L, R):
    miss = ~(L & R)
    if not miss.any():
        return "全部区域已覆盖。继续换不同倾斜角度再拍 10 个左右，或告诉助手可以结束"
    r, c = np.argwhere(miss)[np.argmax([rr for rr, _ in np.argwhere(miss)])]  # lowest missing cell first
    rows = ["最上方", "中上部", "中下部", "最下方（靠近机器人脚前地面）"]
    side = "你的右手边（画面左侧）" if c < 2 else "你的左手边（画面右侧）" if c > 3 else "正中间"
    return f"下一步：把板放到 {rows[r]}、{side}，停 2 秒"


threading.Thread(target=frames, daemon=True).start()
threading.Thread(target=poll_status, daemon=True).start()
cv2.namedWindow("head intrinsics capture", cv2.WINDOW_NORMAL)
cv2.resizeWindow("head intrinsics capture", 1280, 600)
while True:
    img = latest["img"]
    if img is None:
        time.sleep(0.05)
        continue
    h, w2 = img.shape[:2]
    w = w2 // 2
    out = img.copy()
    over = out.copy()
    for e, x0 in (("L", 0), ("R", w)):
        cov = status[e]
        for r in range(GY):
            for c in range(GX):
                p0 = (x0 + int(c * w / GX), int(r * h / GY))
                p1 = (x0 + int((c + 1) * w / GX) - 1, int((r + 1) * h / GY) - 1)
                if cov[r, c]:
                    cv2.rectangle(over, p0, p1, (60, 200, 60), -1)
                else:
                    cv2.rectangle(out, p0, p1, (40, 40, 230), 2)
    out = cv2.addWeighted(over, 0.25, out, 0.75, 0)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    nL, nR = 0, 0
    for k, x0 in enumerate((0, w)):
        pts = detect(gray[:, x0:x0 + w])
        for u, v in pts:
            cv2.circle(out, (int(u) + x0, int(v)), 3, (0, 255, 255), -1)
        if k == 0:
            nL = len(pts)
        else:
            nR = len(pts)
    bar = Image.new("RGB", (w2, 110), (24, 38, 56))
    d = ImageDraw.Draw(bar)
    both = nL >= 12 and nR >= 12
    d.text((14, 8), f"已保存 {status['saved']} 帧    当前角点：左眼 {nL}  右眼 {nR}    "
                    f"{'两眼都看到了，保持不动 2 秒' if both else '两眼没有同时看到足够的角点'}",
           font=FONT, fill=(120, 255, 140) if both else (255, 200, 120))
    d.text((14, 44), hint(status["L"], status["R"]), font=FONT, fill=(255, 255, 255))
    d.text((14, 80), f"绿色格 = 该区域已覆盖（两只眼分别统计）   红框 = 还缺   "
                     f"{'状态更新于 %.0f 秒前' % (time.time() - status['t']) if status['ok'] else '正在读取采集状态…'}",
           font=FONT_S, fill=(190, 205, 220))
    frame = np.vstack([cv2.cvtColor(np.array(bar), cv2.COLOR_RGB2BGR), out])
    cv2.imshow("head intrinsics capture", frame)
    if cv2.waitKey(30) & 0xFF in (ord("q"), 27):
        break
cv2.destroyAllWindows()
os._exit(0)
