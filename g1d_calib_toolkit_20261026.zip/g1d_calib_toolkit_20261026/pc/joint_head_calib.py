# joint_head_calib.py -- head intrinsics: 2026-10-16 chessboard set (calib_data/intrinsics/head, original detector) vs
# 2026-10-23 hand-held ChArUco set (full field incl. the lower quarter) vs both together; parameter std devs from
# calibrateCameraExtended and cross-set residuals (each set's frames with the other set's intrinsics, pose refitted).
# usage: joint_head_calib.py <dir with stereo_*.json from head_intr_capture.py> <out.json>
import glob
import json
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from calibrate_intrinsics import load_views  # noqa: E402

NEW, OUT = Path(sys.argv[1]), Path(sys.argv[2])
SIZE = (640, 480)
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
OBJ = board.getChessboardCorners().astype(np.float32)
old = load_views("head", 0.040)
new_frames = [json.load(open(f)) for f in sorted(glob.glob(str(NEW / "stereo_*.json")))]


def new_views(eye):
    o, p = [], []
    for fr in new_frames:
        ids = sorted(fr[eye], key=int)
        o.append(OBJ[[int(i) for i in ids]])
        p.append(np.array([fr[eye][i] for i in ids], np.float32))
    return o, p


def calib(obj, img):
    rms, K, D, _, _, sd, _, pv = cv2.calibrateCameraExtended(obj, img, SIZE, None, None, flags=0)
    return {"rms": float(rms), "K": K, "D": D.ravel(), "sd": sd.ravel()[:9]}


def resid(obj, img, K, D, band=None):
    e = []
    for o, p in zip(obj, img):
        ok, rv, tv = cv2.solvePnP(o, p, K, D, flags=cv2.SOLVEPNP_IPPE)
        ok, rv, tv = cv2.solvePnP(o, p, K, D, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
        pr, _ = cv2.projectPoints(o, rv, tv, K, D)
        d = np.linalg.norm(pr.reshape(-1, 2) - p.reshape(-1, 2), axis=1)
        e.append(d[band(p.reshape(-1, 2))] if band else d)
    e = np.concatenate(e)
    return round(float(np.sqrt(np.mean(e ** 2))), 3) if len(e) else None


res = {}
for eye, name in (("L", "head_left"), ("R", "head_right")):
    oo = [old[eye]["objp"]] * len(old[eye]["pts"])
    op = [p.reshape(-1, 2) for p in old[eye]["pts"]]
    no, npts = new_views(eye)
    fits = {"old_1016": calib(oo, op), "new_1023": calib(no, npts), "joint": calib(oo + no, op + npts)}
    low = lambda p: p[:, 1] >= 360
    row = {}
    for tag, f in fits.items():
        K, D, sd = f["K"], f["D"], f["sd"]
        row[tag] = {"fx": round(K[0, 0], 2), "fy": round(K[1, 1], 2), "cx": round(K[0, 2], 2), "cy": round(K[1, 2], 2),
                    "sd_fx_fy_cx_cy": np.round(sd[:4], 2).tolist(), "dist": np.round(D, 4).tolist(), "train_rms": round(f["rms"], 3),
                    "rms_on_old_frames": resid(oo, op, K, D), "rms_on_new_frames": resid(no, npts, K, D),
                    "rms_on_new_lower_band": resid(no, npts, K, D, low)}
    res[name] = row
    print(f"== {name}  (old frames {len(op)}, new frames {len(npts)})")
    for tag, r in row.items():
        print(f"  {tag:9s} fx {r['fx']:7.2f} fy {r['fy']:7.2f} cx {r['cx']:6.2f} cy {r['cy']:6.2f}  sd {r['sd_fx_fy_cx_cy']}  "
              f"rms old-frames {r['rms_on_old_frames']}  new-frames {r['rms_on_new_frames']}  new lower band {r['rms_on_new_lower_band']}")
OUT.write_text(json.dumps(res, indent=1), encoding="utf-8")
