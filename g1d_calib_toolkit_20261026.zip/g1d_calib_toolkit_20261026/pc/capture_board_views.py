# capture_board_views.py -- visit the planned wrist poses (both arms together), grab head + both wrist frames and the
# measured joint angles at each, return to all-zero. Ports as of 2026-10-21 21:25 (teleimager config changed):
# 55556 = LEFT wrist (JR0002), 55557 = RIGHT wrist (JR0001).
# usage: capture_board_views.py <board_view_plan.json> <out_dir>
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

import arm_client as arm

PLAN, OUT = json.load(open(sys.argv[1])), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
PORTS = {"head": 55555, "left_wrist": 55556, "right_wrist": 55557}
L, R = PLAN["plan"]["left"], PLAN["plan"]["right"]
records = []
try:
    for k in range(min(len(L), len(R))):
        q = np.r_[L[k]["q"], R[k]["q"]]
        s = arm.move(q, seconds=3.0, timeout=60)
        time.sleep(1.5)
        s = arm.status()
        rec = {"pose": f"P{k}", "q_cmd": q.tolist(), "q_meas": s["arm_q"], "waist": s["all_q"][12], "t": time.time(), "frames": {}}
        for name, port in PORTS.items():
            for j in range(2):
                fn = f"P{k}_{name}_{j}.png"
                subprocess.run(["ssh", "unitree", f"~/miniconda3/envs/tv/bin/python ~/calib_sessions/grab_one.py {port} /tmp/{fn}"],
                               check=True, capture_output=True)
                subprocess.run(["scp", f"unitree:/tmp/{fn}", str(OUT / fn)], check=True, capture_output=True)
                rec["frames"].setdefault(name, []).append(fn)
        s2 = arm.status()
        rec["q_meas_after"] = s2["arm_q"]
        records.append(rec)
        print(f"P{k}: q_meas {np.round(s['arm_q'], 3).tolist()}  drift during capture {np.abs(np.subtract(s2['arm_q'], s['arm_q'])).max():.4f}",
              flush=True)
finally:
    arm.move(np.zeros(14), seconds=3.0, timeout=60)
    print("back at all-zero", flush=True)
    (OUT / "captures.json").write_text(json.dumps({"plan": PLAN, "records": records}, indent=1), encoding="utf-8")
