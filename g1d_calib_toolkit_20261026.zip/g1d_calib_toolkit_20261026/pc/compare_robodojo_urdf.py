# compare_robodojo_urdf.py -- does RoboDojo's g1d_mobile_dex1.urdf share our nominal arm chain (the frame our
# params_final_1021.json is defined against)?  Compares joint origins/axes of every joint present in both URDFs and the
# FK of key links relative to torso_link (all joints at 0).
# usage: python compare_robodojo_urdf.py <theirs.urdf> <our_nominal.urdf> [<our_calibrated.urdf>]
import sys
import xml.etree.ElementTree as ET

import numpy as np
from scipy.spatial.transform import Rotation


def joints(path):
    out = {}
    for j in ET.parse(path).getroot().findall("joint"):
        o = j.find("origin")
        xyz = np.array([float(v) for v in (o.get("xyz", "0 0 0") if o is not None else "0 0 0").split()])
        rpy = np.array([float(v) for v in (o.get("rpy", "0 0 0") if o is not None else "0 0 0").split()])
        ax = j.find("axis")
        axis = np.array([float(v) for v in ax.get("xyz").split()]) if ax is not None else np.zeros(3)
        T = np.eye(4); T[:3, :3] = Rotation.from_euler("xyz", rpy).as_matrix(); T[:3, 3] = xyz
        out[j.get("name")] = dict(parent=j.find("parent").get("link"), child=j.find("child").get("link"),
                                  type=j.get("type"), T=T, axis=axis)
    return out


def fk(J, link, root="torso_link"):
    by_child = {v["child"]: v for v in J.values()}
    T = np.eye(4)
    while link != root:
        j = by_child[link]
        T = j["T"] @ T
        link = j["parent"]
    return T


def diff(Ta, Tb):
    dt = np.linalg.norm(Ta[:3, 3] - Tb[:3, 3]) * 1000
    dr = np.degrees(Rotation.from_matrix(Ta[:3, :3].T @ Tb[:3, :3]).magnitude())
    return dt, dr


theirs, nom = joints(sys.argv[1]), joints(sys.argv[2])
cal = joints(sys.argv[3]) if len(sys.argv) > 3 else None
common = [n for n in nom if n in theirs]
only_nom = [n for n in nom if n not in theirs]
print(f"joints: theirs {len(theirs)}, our nominal {len(nom)}, common {len(common)}")
print("only in our nominal:", only_nom)
print("only in theirs:", [n for n in theirs if n not in nom])
print("\njoint origin differences theirs vs our nominal (only non-zero shown):")
nz = 0
for n in common:
    a, b = theirs[n], nom[n]
    dt, dr = diff(a["T"], b["T"])
    same = a["parent"] == b["parent"] and a["child"] == b["child"] and a["type"] == b["type"] and np.allclose(a["axis"], b["axis"])
    if dt > 1e-3 or dr > 1e-4 or not same:
        nz += 1
        print(f"  {n:34s} dt {dt:8.4f} mm  dR {dr:7.4f} deg  same parent/child/type/axis={same}")
print(f"  -> {nz} of {len(common)} common joints differ")
print("\nFK relative to torso_link at q=0 (theirs vs our nominal | ours calibrated vs nominal):")
for link in ("head_link", "left_shoulder_pitch_link", "left_wrist_yaw_link", "left_dex1_base_link",
             "right_shoulder_pitch_link", "right_wrist_yaw_link", "right_dex1_base_link"):
    if all(link in {v["child"] for v in J.values()} for J in (theirs, nom)):
        dt, dr = diff(fk(theirs, link), fk(nom, link))
        s = f"  {link:28s} theirs-nom {dt:7.3f} mm {dr:6.3f} deg"
        if cal is not None:
            dt2, dr2 = diff(fk(cal, link), fk(nom, link))
            s += f" | cal-nom {dt2:6.2f} mm {dr2:5.2f} deg"
        print(s)
print("\nchain above torso_link in theirs:")
link = "torso_link"
by_child = {v["child"]: (k, v) for k, v in theirs.items()}
while link in by_child:
    k, v = by_child[link]
    print(f"  {v['parent']:18s} --{k} ({v['type']})--> {link}")
    link = v["parent"]
cams = [k for k in theirs if any(s in k.lower() for s in ("cam", "d435", "head"))]
print("\ncamera/head joints in theirs:", cams)
for k in cams:
    print(f"  {k}: {theirs[k]['parent']} -> {theirs[k]['child']}  xyz {np.round(theirs[k]['T'][:3, 3], 4)} "
          f"rpy {np.round(Rotation.from_matrix(theirs[k]['T'][:3, :3]).as_euler('xyz'), 4)}")
