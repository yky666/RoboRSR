# compare_models.py — 标准(5参) vs 有理(8参) vs 鱼眼模型，用留出重投影误差裁决（文档01）
# 用法: python -u pc_tools/compare_models.py <head|left_wrist|right_wrist> [--square-mm 35]
import argparse
import random
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from calibrate_intrinsics import load_views, CAMS


def split(pts, seed=42):
    order = list(range(len(pts)))
    random.Random(seed).shuffle(order)
    n_hold = max(3, int(round(len(pts) * 0.2)))
    hold_i = set(order[:n_hold])
    return [pts[i] for i in order if i not in hold_i], [pts[i] for i in sorted(hold_i)]


def reproj_err(objp, pts_list, project):
    errs = []
    for p in pts_list:
        proj = project(p)
        errs.append(np.sqrt(((proj.reshape(-1, 2) - p.reshape(-1, 2)) ** 2).sum(1)).mean())
    return float(np.mean(errs))


def run_pinhole(objp, fit_pts, hold_pts, size, flags, tag):
    rms, K, dist, rv, tv = cv2.calibrateCamera([objp] * len(fit_pts), fit_pts, size, None, None, flags=flags)
    tr = reproj_err(objp, fit_pts, lambda p: cv2.projectPoints(
        objp, *cv2.solvePnP(objp, p, K, dist)[1:], K, dist)[0])
    ho = reproj_err(objp, hold_pts, lambda p: cv2.projectPoints(
        objp, *cv2.solvePnP(objp, p, K, dist)[1:], K, dist)[0])
    print(f"  {tag}: 训练 {tr:.4f}px  留出 {ho:.4f}px   K=[{K[0,0]:.1f},{K[1,1]:.1f},{K[0,2]:.1f},{K[1,2]:.1f}]  dist={np.array2string(dist.ravel(), precision=4)}")
    return ho


def run_fisheye(objp, fit_pts, hold_pts, size):
    obj = [objp.reshape(1, -1, 3).astype(np.float64)] * len(fit_pts)
    pts = [p.reshape(1, -1, 2).astype(np.float64) for p in fit_pts]
    K = np.array([[280., 0, size[0] / 2], [0, 280., size[1] / 2], [0, 0, 1]])
    D = np.zeros((4, 1))
    flags = cv2.CALIB_RECOMPUTE_EXTRINSIC + cv2.CALIB_CHECK_COND + cv2.CALIB_FIX_SKEW
    rms, K, D, rv, tv = cv2.fisheye.calibrate(
        obj, pts, size, K, D, None, None, flags,
        (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6))
    D = D.ravel()

    def project(p):
        ok, rv, tv = cv2.fisheye.solvePnP(objp.reshape(1, -1, 3).astype(np.float64),
                                          p.reshape(1, -1, 2).astype(np.float64), K, D)
        return cv2.fisheye.projectPoints(objp.reshape(1, -1, 3).astype(np.float64), rv, tv, K, D)[0]
    tr = reproj_err(objp, fit_pts, project)
    ho = reproj_err(objp, hold_pts, project)
    print(f"  鱼眼(4参): 训练 {tr:.4f}px  留出 {ho:.4f}px   K=[{K[0,0]:.1f},{K[1,1]:.1f},{K[0,2]:.1f},{K[1,2]:.1f}]  dist={np.array2string(D, precision=4)}")
    return ho


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("which")
    ap.add_argument("--square-mm", type=float, default=35.0)
    args = ap.parse_args()
    views = load_views(args.which, args.square_mm / 1000.0)
    for tag, view in views.items():
        cam = CAMS[args.which][0] if tag in ("L", "") else CAMS[args.which][1]
        fit_pts, hold_pts = split(view["pts"])
        print(f"\n===== {cam} ({len(fit_pts)} 训练 / {len(hold_pts)} 留出) =====")
        ho_std = run_pinhole(view["objp"], fit_pts, hold_pts, view["size"], 0, "标准(5参)")
        try:
            ho_rat = run_pinhole(view["objp"], fit_pts, hold_pts, view["size"], cv2.CALIB_RATIONAL_MODEL, "有理(8参)")
        except cv2.error as e:
            ho_rat = 1e9; print(f"  有理(8参) 失败: {e}")
        try:
            ho_f = run_fisheye(view["objp"], fit_pts, hold_pts, view["size"])
        except cv2.error as e:
            ho_f = 1e9; print(f"  鱼眼失败: {e}")
        best = min((ho_std, "标准"), (ho_rat, "有理"), (ho_f, "鱼眼"))[1]
        print(f"  -> 按留出误差裁决: {best}")


if __name__ == "__main__":
    main()
