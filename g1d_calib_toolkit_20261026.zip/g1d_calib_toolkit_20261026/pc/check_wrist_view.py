# check_wrist_view.py -- can the wrist cameras see the table ChArUco board at the current (ready) pose?
from pathlib import Path

import cv2
import numpy as np
import zmq

HERE = Path(__file__).parent
OUT = HERE / "frames_test" / "dircheck"
OUT.mkdir(parents=True, exist_ok=True)
HOST = "192.168.123.164"
PORTS = {"left_wrist": 55556, "right_wrist": 55557}  # since 2026-10-21 21:25 (teleimager config): 55556 = LEFT (JR0002), 55557 = RIGHT (JR0001)

board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
det = cv2.aruco.CharucoDetector(board)

for cam, port in PORTS.items():
    s = zmq.Context.instance().socket(zmq.SUB)
    s.setsockopt(zmq.CONFLATE, 1); s.setsockopt(zmq.RCVTIMEO, 3000); s.setsockopt(zmq.SUBSCRIBE, b"")
    s.connect(f"tcp://{HOST}:{port}")
    for _ in range(5):
        data = s.recv()
    s.close(0)
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    cc, ci, mc, mi = det.detectBoard(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    n = 0 if ci is None else len(ci)
    vis = img.copy()
    if cc is not None:
        for p in cc.reshape(-1, 2):
            cv2.circle(vis, (int(p[0]), int(p[1])), 3, (0, 255, 0), -1)
    cv2.imencode(".png", vis)[1].tofile(str(OUT / f"view_{cam}.png"))
    print(f"[{cam}] charuco corners visible: {n}")
