# which_wrist_now.py -- which ZMQ port is the physical right wrist camera today? Jog the RIGHT wrist yaw (motor 28)
# by +0.15 rad and back through calib_arm_server, grab both wrist ports before / during, report the image change.
import subprocess

import cv2
import numpy as np

import arm_client as arm


def grab(tag):
    out = {}
    for port in (55556, 55557):
        subprocess.run(["ssh", "unitree", f"~/miniconda3/envs/tv/bin/python ~/calib_sessions/grab_one.py {port} /tmp/w_{tag}_{port}.png"],
                       check=True, capture_output=True)
        dst = __import__("os").path.join(__import__("os").environ.get("TEMP", "/tmp"), f"w_{tag}_{port}.png")
        subprocess.run(["scp", f"unitree:/tmp/w_{tag}_{port}.png", dst], check=True, capture_output=True)
        out[port] = cv2.cvtColor(cv2.imread(dst), cv2.COLOR_BGR2GRAY).astype(float)
    return out


q0 = np.array(arm.status()["arm_q_cmd"])
a = grab("before")
q1 = q0.copy(); q1[13] += 0.2  # right wrist yaw
s = arm.move(q1, seconds=2.0)
print("right wrist yaw moved to", round(s["arm_q"][13], 3), "|", s["msg"])
b = grab("jogged")
arm.move(q0, seconds=2.0)
for port in (55556, 55557):
    d = np.abs(a[port] - b[port])
    print(f"port {port}: mean |diff| {d.mean():5.1f}, pixels changed > 25: {100 * (d > 25).mean():5.1f} %")
print("right wrist yaw back:", round(arm.status()["arm_q"][13], 3))
