# plan_left_session.py -- left-arm poses for the left wrist camera check against the fixed table board.
# Calibrated RoboDojo URDF + our left wrist camera (checkerboard K), board from the head stereo (board_pose.json).
# Constraints per pose: camera-board centre 0.28-0.42 m, >= 48 of 54 corners inside the image and off the finger mask,
# view angle <= 55 deg, gripper / wrist / elbow mesh points >= 5 cm above the board plane, upper-arm torso guard,
# gripper left of the midline (y >= 0.05). 18 poses by farthest-point sampling in joint space; transitions are
# linear in joint space and checked; unsafe ones go through all-zero.
# usage: plan_left_session.py <asset_dir> <board_pose.json> <out.json>
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

ASSET, BOARD, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.argv = sys.argv[:1] + [str(ASSET), os.environ.get("TEMP", "/tmp")]
src = open(Path(__file__).parent / "check_robodojo_merge.py", encoding="utf-8").read().split("# ---------------- run ----------------")[0]
mod = {}
exec(compile(src, "check_robodojo_merge.py", "exec"), mod)
Urdf, raster, project, OPT, mesh, intr = (mod[k] for k in ("Urdf", "raster", "project", "OPT_FROM_CAM", "mesh", "intr"))
U = Urdf(ASSET / "g1d_dex1_calib.urdf")
cam = json.loads((Path(__file__).parent / "robodojo_merge/camera_setup_ours.json").read_text(encoding="utf-8"))["views"]["left_wrist"]
Tm = np.array(cam["T_parent_camera_world_convention"])
K, D = intr("left_wrist", "checker")
bp = json.loads(BOARD.read_text(encoding="utf-8"))
Ts = [np.array(bp[e]["T_torso_board"]) for e in ("head_left", "head_right") if bp.get(e)]
T_tb = np.eye(4)
T_tb[:3, 3] = np.mean([T[:3, 3] for T in Ts], 0)
T_tb[:3, :3] = Rotation.from_matrix([T[:3, :3] for T in Ts]).mean().as_matrix()
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
P_corners = board.getChessboardCorners().astype(float) @ T_tb[:3, :3].T + T_tb[:3, 3]
centre = T_tb[:3, :3] @ np.array([0.20, 0.14, 0.0]) + T_tb[:3, 3]
n_up = -T_tb[:3, 2]
ARMJ = [f"left_{n}_joint" for n in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
LIM = np.array([[-3.089, 2.670], [-1.588, 2.252], [-2.618, 2.618], [-1.047, 2.094], [-1.972, 1.972], [-1.614, 1.614], [-1.614, 1.614]])
LO = np.array([-0.6, 0.05, -0.4, -0.6, -0.5, -0.3, -0.6])
HI = np.array([0.2, 0.45, 0.4, 0.5, 0.5, 0.7, 0.6])
CLEAR_LINKS = ["left_elbow_link", "left_wrist_roll_link", "left_wrist_pitch_link", "left_wrist_yaw_link", "left_dex1_model_base_link"] + \
              [f"left_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")]
PTS = {ln: np.concatenate([mesh(r).reshape(-1, 3)[::7] for r in U.vis.get(ln, [])]) for ln in CLEAR_LINKS if U.vis.get(ln)}
OPEN = -0.0195


def qd(q7):
    q = {n: float(v) for n, v in zip(ARMJ, q7)}
    q["left_dex1_finger_joint_1"] = q["left_dex1_finger_joint_2"] = OPEN
    return q


def clearance(q):
    h = np.inf
    for ln, P in PTS.items():
        T = U.fk(ln, q)
        h = min(h, float(((P @ T[:3, :3].T + T[:3, 3] - T_tb[:3, 3]) @ n_up).min()))
    return h


def guard_ok(q7):
    return q7[1] >= (0.05 if q7[0] > -0.4 else -0.10)


fingers = None
rng = np.random.default_rng(7)
cands = []
for it in range(6000):
    q7 = LO + (HI - LO) * rng.random(7)
    if not guard_ok(q7):
        continue
    q = qd(q7)
    Tw = U.fk("left_dex1_base_link", q) @ Tm
    if Tw[1, 3] < 0.05 or U.fk("left_dex1_base_link", q)[1, 3] < 0.05:
        continue
    dist = float(np.linalg.norm(centre - Tw[:3, 3]))
    if not 0.28 <= dist <= 0.42:
        continue
    view = np.degrees(np.arccos(abs(float(Tw[:3, 0] @ n_up))))  # angle between the optical axis and the board normal
    if view > 55:
        continue
    if fingers is None:
        Tc = np.linalg.inv(Tw)
        fingers = cv2.dilate(raster(U, [f"left_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")], q, Tc, K, D),
                             np.ones((17, 17), np.uint8))
    uv, ok = project((P_corners - Tw[:3, 3]) @ Tw[:3, :3] @ OPT.T, K, D)
    ins = ok & (uv[:, 0] > 15) & (uv[:, 0] < 625) & (uv[:, 1] > 15) & (uv[:, 1] < 465)
    vis = ins.copy()
    vis[ins] = fingers[uv[ins, 1].astype(int), uv[ins, 0].astype(int)] == 0
    if vis.sum() < 48:
        continue
    h = clearance(q)
    if h < 0.05:
        continue
    cands.append({"q": q7.tolist(), "dist": round(dist, 3), "view_deg": round(view, 1), "visible": int(vis.sum()),
                  "clearance_m": round(h, 3), "cam_pos": Tw[:3, 3].round(3).tolist()})
print(f"{len(cands)} valid candidates out of 6000 samples")
Q = np.array([c["q"] for c in cands])
scale = HI - LO
pick = [int(np.argmin(np.abs(Q / scale).sum(1)))]  # start near zero
while len(pick) < min(18, len(cands)):
    d = np.min(np.linalg.norm((Q[:, None, :] - Q[pick][None]) / scale, axis=2), axis=1)
    pick.append(int(np.argmax(d)))
# order: nearest neighbour from zero
order, cur, rest = [], np.zeros(7), list(pick)
while rest:
    k = min(rest, key=lambda i: np.abs(Q[i] - cur).max())
    order.append(k); rest.remove(k); cur = Q[k]


def segment_ok(qa, qb):
    for s in np.linspace(0, 1, 12):
        q7 = qa + (qb - qa) * s
        if not guard_ok(q7) and np.abs(q7).max() > 0.08:
            return False
        if clearance(qd(q7)) < 0.04:
            return False
    return True


seq, cur = [], np.zeros(7)
for k in order:
    via_zero = not segment_ok(cur, Q[k])
    if via_zero:
        assert segment_ok(cur, np.zeros(7)) and segment_ok(np.zeros(7), Q[k])
    seq.append({**cands[k], "via_zero": via_zero})
    cur = Q[k]
assert segment_ok(cur, np.zeros(7))
OUT.write_text(json.dumps({"T_torso_board": T_tb.tolist(), "board_centre": centre.tolist(), "poses": seq}, indent=1), encoding="utf-8")
for i, p in enumerate(seq):
    print(f"L{i:02d} q {np.round(p['q'], 2).tolist()} dist {p['dist']:.2f} m view {p['view_deg']:4.1f} deg corners {p['visible']} "
          f"clear {p['clearance_m'] * 100:4.1f} cm{'  (via zero)' if p['via_zero'] else ''}")
qa = np.array([p["q"] for p in seq])
print("joint ranges covered (rad):", np.round(qa.max(0) - qa.min(0), 2).tolist())
