# compare_robodojo_cams.py -- RoboDojo camera mounts (robot_config.yml: link, pos, wxyz quat link->USD camera with
# -z forward/+y up) vs our camera_contract_v5 (T_parent_camera_world_convention: +x forward/+y left/+z up), expressed in
# the same parent link via the shared nominal URDF; plus what our calibrated deltas would change.
import json
import sys
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
PKG = ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"
sys.path.insert(0, str(PKG))
from calib_model import Robot, load_params, se3, se3_of  # noqa: E402

R_WORLD_USD = np.array([[0, 0, -1], [-1, 0, 0], [0, 1, 0]], float)  # USD camera axes in world-convention camera axes
theirs = {  # name: (link, pos, wxyz) from left/right_robot_config.yml
    "head_left": ("head_link", [0.0442, 0.0296, 0.4900], [0.6593, 0.2557, -0.2557, -0.6593]),
    "head_right": ("head_link", [0.0442, -0.0300, 0.4900], [0.6593, 0.2557, -0.2557, -0.6593]),
    "left_wrist": ("left_dex1_base_link", [0.0627, 0, 0.0555], [0.6124, 0.3536, -0.3536, -0.6124]),
    "right_wrist": ("right_dex1_base_link", [0.0627, 0, 0.0555], [0.6124, 0.3536, -0.3536, -0.6124]),
}
views = {v["name"]: v for v in json.loads((PKG / "nominal/camera_contract_v5.json").read_text(encoding="utf-8"))["views"]}
P = load_params(ROOT / "pc_tools/replay_cups/model/params_final_1021.json")["values"]
robot = Robot(PKG / "nominal" / "g1_d_upper_dex1_v4.urdf")


def in_link(link_from, link_to, T):
    """re-express a mount given in link_from in link_to (nominal FK at q=0, both on fixed/zero chains)"""
    Tf = robot.fk(link_from, {}, {}, None, 1)[0]
    Tt = robot.fk(link_to, {}, {}, None, 1)[0]
    return np.linalg.inv(Tt) @ Tf @ T


for name, (link, pos, wxyz) in theirs.items():
    Tt = np.eye(4)
    Tt[:3, :3] = Rotation.from_quat([wxyz[1], wxyz[2], wxyz[3], wxyz[0]]).as_matrix() @ R_WORLD_USD.T
    Tt[:3, 3] = pos
    v = views[name]
    To = np.array(v["T_parent_camera_world_convention"], float)
    if v["parent"] != link:
        To = in_link(v["parent"], link, To)
    dt = (Tt[:3, 3] - To[:3, 3]) * 1000
    dr = Rotation.from_matrix(To[:3, :3].T @ Tt[:3, :3])
    fwd_t, fwd_o = Tt[:3, 0], To[:3, 0]
    down_t = np.degrees(np.arcsin(-fwd_t[2])); down_o = np.degrees(np.arcsin(-fwd_o[2]))
    print(f"{name:11s} (parent ours {v['parent']}, theirs {link}): position diff {np.round(dt, 1)} mm (|{np.linalg.norm(dt):.1f}|), "
          f"rotation diff {np.degrees(dr.magnitude()):.2f} deg; looks down theirs {down_t:.1f} / ours {down_o:.1f} deg")
    d = se3_of(P, f"camera:{name}")
    if np.any(d):
        Tc = To @ se3(d)
        print(f"{'':11s} our calibration moves it by {np.round((Tc[:3, 3] - To[:3, 3]) * 1000, 1)} mm, "
              f"{np.degrees(Rotation.from_matrix(To[:3, :3].T @ Tc[:3, :3]).magnitude()):.2f} deg")
