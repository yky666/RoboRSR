# touch_plan.py -- predict where the fingertip-corner ray of each pose-table hover pose hits the table board
# usage: python touch_plan.py <left|right> <tip_u> <tip_v>
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np

ROBOT_BASE = Path.home() / "calib_sessions"
if (ROBOT_BASE / "model").is_dir():
    PKG, NOM = ROBOT_BASE / "model", ROBOT_BASE / "model"
    POSES = ROBOT_BASE / os.environ.get("G1D_POSES", "poses_current")
else:
    PKG = Path(__file__).resolve().parent.parent / "g1d_calib_20261015" / "g1d_calib_20261015"
    NOM, POSES = PKG / "nominal", Path(__file__).resolve().parent / "frames_test" / "poses_v2"
sys.path.insert(0, str(PKG))
from calib_model import OPTICAL_FROM_CAMERA, Robot, arm_joints  # noqa: E402

side, tu, tv = sys.argv[1], float(sys.argv[2]), float(sys.argv[3])
ARM = ["shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw"]
ALLJ = arm_joints("left") + arm_joints("right")
off = 0 if side == "left" else 7
robot = Robot(NOM / "g1_d_upper_dex1_v4.urdf")
contract = {v["name"]: v for v in json.loads((NOM / "camera_contract_v5.json").read_text())["views"]}
cam = json.loads((POSES / "scene_header_B.json").read_text())["cameras"][f"{side}_wrist"]
K, dist = np.array(cam["K"]), np.array(cam["dist"])
K[0, 0] *= 0.963; K[1, 1] *= 0.963
T_pc = np.array(contract[f"{side}_wrist"]["T_parent_camera_world_convention"])
parent = contract[f"{side}_wrist"]["parent"]
T_tb = np.array(json.loads((POSES / "board_pose_measured.json").read_text())["head_left"]["T_torso_board"])
doc = json.loads((POSES / f"poses_{side}.json").read_text())
d = cv2.undistortPoints(np.array([[[tu, tv]]], np.float64), K, dist).ravel()
ray_c = OPTICAL_FROM_CAMERA.T @ np.array([d[0], d[1], 1.0]); ray_c /= np.linalg.norm(ray_c)
n_t, p0 = T_tb[:3, 2], T_tb[:3, 3]
M = 0.06
rows = []
for p in doc["setups"]["B_wrist_table_board"]["poses"]:
    q = np.zeros(14)
    q[off:off + 7] = [p["joints"][f"{side}_{j}_joint"] for j in ARM]
    Tc = robot.fk(parent, {n: np.array([v]) for n, v in zip(ALLJ, q)}, {}, None, 1)[0] @ T_pc
    r = Tc[:3, :3] @ ray_c
    s = ((p0 - Tc[:3, 3]) @ n_t) / (r @ n_t)
    xy = (T_tb[:3, :3].T @ (Tc[:3, 3] + s * r - p0))[:2]
    inc = np.degrees(np.arccos(abs(r @ n_t)))
    shift = np.linalg.norm(xy - np.clip(xy, [M, M], [0.40 - M, 0.28 - M]))
    rows.append((p["id"], xy, s, inc, shift, p.get("home_path_ok"), p.get("skip")))
for pid, xy, s, inc, shift, ok, skip in sorted(rows, key=lambda r: r[4]):
    print(f"{pid}  hit [{xy[0]:+.3f} {xy[1]:+.3f}]  D {s:.3f}  incidence {inc:4.1f} deg  "
          f"shift-needed {shift * 100:4.1f} cm  home_ok={ok} skip={skip}")
