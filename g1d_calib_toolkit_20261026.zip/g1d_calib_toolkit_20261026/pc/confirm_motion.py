# confirm_motion.py -- confirmation clip for the calibrated sim: hanging arms -> all-zero (raise_to_zero2 steps),
# waist yaw -> 0, both arms raised forward (shoulder pitch -0.9, elbow -0.5, shoulder roll +-0.15), hold, back to zero.
# Runs through calib_arm_server (arm_client); every step waits for completion; Ctrl+C sends stop.
import sys
import time

import numpy as np

import arm_client as arm

ROLL_L, ROLL_R = 0.35, -0.25
UP = np.zeros(14)
UP[[0, 7]] = -0.9           # shoulder pitch: forward / up
UP[1], UP[8] = 0.15, -0.15  # slight abduction, hands away from the head
UP[[3, 10]] = -0.5          # elbow: forearms raised further


def log(tag, s):
    print(f"{time.strftime('%H:%M:%S')} {tag:16s} q {np.round(s['arm_q'], 3).tolist()}", flush=True)


def move_split(target, seconds=3.0):
    cur = np.array(arm.status()["arm_q_cmd"])
    n = max(1, int(np.ceil(np.abs(target - cur).max() / 1.3)))
    s = None
    for k in range(1, n + 1):
        s = arm.move(cur + (target - cur) * k / n, seconds=seconds, timeout=120)
    return s


try:
    s = arm.status()
    log("start", s)
    t1 = np.array(s["arm_q_cmd"]); t1[1] = ROLL_L; t1[8] = ROLL_R
    log("1 abduct", move_split(t1))
    t2 = t1.copy(); t2[2] = 0.0; t2[9] = 0.0
    log("2 yaw unwound", move_split(t2))
    t3 = np.zeros(14); t3[1] = ROLL_L; t3[8] = ROLL_R
    log("3 forearms up", move_split(t3))
    log("4 zero", move_split(np.zeros(14)))
    s = arm.wait_done(arm.send({"cmd": "waist", "q": 0.0}), timeout=60)
    print(f"{time.strftime('%H:%M:%S')} 5 waist          {s['all_q'][12]:+.4f}", flush=True)
    time.sleep(2.0)
    log("6 arms up", move_split(UP, seconds=4.0))
    time.sleep(2.0)
    log("7 arms down", move_split(np.zeros(14), seconds=4.0))
    time.sleep(2.0)
    print("done; holding the all-zero pose", flush=True)
except KeyboardInterrupt:
    arm.stop()
    print("STOP sent", flush=True)
    sys.exit(1)
