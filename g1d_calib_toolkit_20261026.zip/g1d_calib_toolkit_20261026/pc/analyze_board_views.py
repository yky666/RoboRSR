# analyze_board_views.py -- wrist-camera accuracy on today's board captures.
#   detected ChArUco corners in each wrist frame vs the board (pose measured by the head stereo) projected through
#   A  calibrated RoboDojo URDF + our wrist mount + our intrinsics            (camera_setup_ours.json)
#   B  RoboDojo as delivered: URDF + nominal mount (robot_config.yml) + centred pinhole fx 314.4, no distortion
#   A_free: A with one board pose per arm fitted to all of that arm's frames (relative accuracy, removes the head
#   measurement's ~1 cm bias). Writes overlays (white = detected, green = A grid, red = B grid) and metrics.
# usage: analyze_board_views.py <asset_dir> <capture_dir> <out_dir>
import json
import os
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

ASSET, CAP, OUT = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
OUT.mkdir(parents=True, exist_ok=True)
sys.argv = sys.argv[:1] + [str(ASSET), os.environ.get("TEMP", "/tmp")]
src = open(Path(__file__).parent / "check_robodojo_merge.py", encoding="utf-8").read().split("# ---------------- run ----------------")[0]
mod = {}
exec(compile(src, "check_robodojo_merge.py", "exec"), mod)
Urdf, project, OPT, cam_mount, intr = mod["Urdf"], mod["project"], mod["OPT_FROM_CAM"], mod["cam_mount"], mod["intr"]
U = {"A": Urdf(ASSET / "g1d_dex1_calib.urdf"), "B": Urdf(ASSET / "g1d_dex1.urdf")}
U["C"] = U["A"]
cams = json.loads((Path(__file__).parent / "robodojo_merge/camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
cap = json.loads((CAP / "captures.json").read_text(encoding="utf-8"))
T_tb = np.array(cap["plan"]["T_torso_board"])
board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
det = cv2.aruco.CharucoDetector(board, cv2.aruco.CharucoParameters(), dp)
OBJ = board.getChessboardCorners().astype(float)
ARMJ = {s: [f"{s}_{n}_joint" for n in ("shoulder_pitch", "shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll",
                                       "wrist_pitch", "wrist_yaw")] for s in ("left", "right")}


def detect(img):
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(g)
    if ci is None or len(ci) < 6:
        return None, None
    return ci.ravel(), (cc.reshape(-1, 2) + 0.5) / 2 - 0.5


def model(side, tag):
    if tag == "A":
        c = cams[f"{side}_wrist"]
        return np.array(c["T_parent_camera_world_convention"]), np.array(c["K"]), np.array(c["dist_k1k2p1p2k3"])
    if tag == "C":  # calibrated mount, checkerboard intrinsics (no near-range autofocus delta)
        c = cams[f"{side}_wrist"]
        K, D = intr(f"{side}_wrist", "checker")
        return np.array(c["T_parent_camera_world_convention"]), K, D
    _, Tm = cam_mount(ASSET / f"{side}_robot_config.yml", "cam_wrist")
    K, D = intr(f"{side}_wrist", "theirs")
    return Tm, K, D


def proj(side, tag, q, T_board, pts):
    Tm, K, D = model(side, tag)
    Tw = U[tag].fk(f"{side}_dex1_base_link", q) @ Tm
    P = pts @ T_board[:3, :3].T + T_board[:3, 3]
    uv, ok = project((P - Tw[:3, 3]) @ Tw[:3, :3] @ OPT.T, K, D)
    return uv, ok


obs = {"left": [], "right": []}
for rec in cap["records"]:
    for side in ("left", "right"):
        q = {n: rec["q_meas"][(0 if side == "left" else 7) + i] for i, n in enumerate(ARMJ[side])}
        q[f"{side}_dex1_finger_joint_1"] = q[f"{side}_dex1_finger_joint_2"] = -0.0195
        img = cv2.imread(str(CAP / rec["frames"][f"{side}_wrist"][0]))
        ci, uv = detect(img)
        obs[side].append((rec["pose"], q, img, ci, uv))

# *_free: per-arm board pose fitted on all frames (6 dof, start = head measurement)
T_free = {}
for side in ("left", "right"):
    rows = [(q, ci, uv) for _, q, _, ci, uv in obs[side] if ci is not None]
    for tag in ("A", "B", "C"):
        def res(x, tag=tag):
            T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(x[:3]).as_matrix() @ T_tb[:3, :3]; T[:3, 3] = T_tb[:3, 3] + x[3:]
            return np.concatenate([(proj(side, tag, q, T, OBJ[ci])[0] - uv).ravel() for q, ci, uv in rows])
        x = least_squares(res, np.zeros(6), loss="soft_l1", f_scale=2.0).x
        T = np.eye(4); T[:3, :3] = Rotation.from_rotvec(x[:3]).as_matrix() @ T_tb[:3, :3]; T[:3, 3] = T_tb[:3, 3] + x[3:]
        T_free[(side, tag)] = (T, x)
        print(f"{side} {tag}: board pose fitted from the wrist frames differs from the head measurement by "
              f"{np.round(x[3:] * 1000, 1).tolist()} mm, {np.degrees(np.linalg.norm(x[:3])):.2f} deg")
    T_free[side] = T_free[(side, "A")]

metrics = {"per_frame": [], "summary": {}}
tiles = {"left": [], "right": []}
for side in ("left", "right"):
    acc = {"A": [], "B": [], "C": [], "A_free": [], "B_free": [], "C_free": []}
    for pose, q, img, ci, uv in obs[side]:
        ov = img.copy()
        row = {"side": side, "pose": pose, "corners": 0 if ci is None else int(len(ci))}
        for tag, col, T in (("B", (40, 40, 240), T_tb), ("C", (40, 220, 60), T_tb)):
            g, ok = proj(side, tag, q, T, OBJ)
            g = g.reshape(6, 9, 2)
            for r in range(6):
                cv2.polylines(ov, [np.round(g[r]).astype(np.int32)], False, col, 2, cv2.LINE_AA)
            for cc in range(9):
                cv2.polylines(ov, [np.round(g[:, cc]).astype(np.int32)], False, col, 2, cv2.LINE_AA)
        if ci is not None:
            for tag, T in (("A", T_tb), ("B", T_tb), ("C", T_tb), ("A_free", T_free[(side, "A")][0]),
                           ("B_free", T_free[(side, "B")][0]), ("C_free", T_free[(side, "C")][0])):
                p, _ = proj(side, tag[0], q, T, OBJ[ci])
                e = float(np.sqrt(np.mean(np.sum((p - uv) ** 2, 1))))
                row[f"rms_{tag}"] = round(e, 2)
                acc[tag].append(e)
            for u, v in uv:
                cv2.circle(ov, (int(round(u)), int(round(v))), 4, (0, 0, 0), -1, cv2.LINE_AA)
                cv2.circle(ov, (int(round(u)), int(round(v))), 3, (255, 255, 255), -1, cv2.LINE_AA)
        metrics["per_frame"].append(row)
        lab = (f"{side} wrist {pose}: green calibrated {row.get('rms_C', float('nan')):.1f} px   "
               f"red delivered {row.get('rms_B', float('nan')):.1f} px   white = detected")
        cv2.rectangle(ov, (0, 0), (640, 30), (20, 26, 34), -1)
        cv2.putText(ov, lab, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (240, 240, 240), 1, cv2.LINE_AA)
        cv2.imwrite(str(OUT / f"board_{side}_{pose}.png"), ov)
        tiles[side].append(ov)
        print(lab)
    metrics["summary"][side] = {k: {"mean_px": round(float(np.mean(v)), 2), "max_px": round(float(np.max(v)), 2)} for k, v in acc.items() if v}
    for tag in ("A", "B", "C"):
        metrics["summary"][side][f"board_fit_offset_mm_{tag}"] = np.round(T_free[(side, tag)][1][3:] * 1000, 1).tolist()
grid = np.vstack([np.hstack(tiles["left"]), np.hstack(tiles["right"])])
cv2.imwrite(str(OUT / "board_views_montage.png"), cv2.resize(grid, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA))
(OUT / "board_metrics.json").write_text(json.dumps(metrics, indent=1), encoding="utf-8")
print(json.dumps(metrics["summary"], indent=1))
