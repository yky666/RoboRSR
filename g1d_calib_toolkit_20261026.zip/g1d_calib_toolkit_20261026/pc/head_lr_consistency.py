# head_lr_consistency.py -- does the head left/right eye disagreement on the board pose come from the right-eye mount?
# Per head image: board pose in torso from the left eye (our contract mount) and from the right eye with
#   nominal:  the contract's right-eye mount (parallel eyes, 59.6 mm baseline)
#   stereo:   left-eye mount composed with the stereoCalibrate R,T (X_right = R X_left + T)
# usage: head_lr_consistency.py <head image> ...
import json
import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__import__("os").environ.get("PC_TOOLS_DIR", "."))
cams = json.loads((ROOT / "robodojo_merge/camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
st = json.loads((ROOT / "replay_cups/out/head_stereo_extrinsics.json").read_text(encoding="utf-8"))
OPT = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)
C2O = np.eye(4); C2O[:3, :3] = OPT.T  # optical -> x-fwd camera
T_RL = np.eye(4); T_RL[:3, :3] = np.array(st["R_right_from_left"]); T_RL[:3, 3] = st["T_right_from_left_m"]
# head_link is fixed to the torso: take its pose from the calibrated URDF chain (head_joint, no movable joints)
import xml.etree.ElementTree as ET  # noqa: E402
j = next(j for j in ET.parse(ROOT / "robodojo_merge/g1d_dex1_calib.urdf").getroot().findall("joint") if j.get("name") == "head_joint")
o = j.find("origin")
T_th = np.eye(4)
T_th[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
T_th[:3, 3] = [float(v) for v in o.get("xyz").split()]
T_tLo = T_th @ np.array(cams["head_left"]["T_parent_camera_world_convention"]) @ C2O
T_tRo = {"nominal": T_th @ np.array(cams["head_right"]["T_parent_camera_world_convention"]) @ C2O,
         "stereo": T_tLo @ np.linalg.inv(T_RL)}
d = T_tRo["nominal"][:3, 3] - T_tRo["stereo"][:3, 3]
dr = np.degrees(Rotation.from_matrix(T_tRo["nominal"][:3, :3].T @ T_tRo["stereo"][:3, :3]).magnitude())
print(f"right-eye mount, nominal vs stereo-derived: {np.round(d * 1000, 2).tolist()} mm, {dr:.3f} deg")

board = cv2.aruco.CharucoBoard((10, 7), 0.040, 0.030, cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50))
dp = cv2.aruco.DetectorParameters()
dp.minMarkerPerimeterRate = 0.01
dp.adaptiveThreshWinSizeMin, dp.adaptiveThreshWinSizeMax, dp.adaptiveThreshWinSizeStep = 3, 53, 4
dp.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
cp = cv2.aruco.CharucoParameters(); cp.minMarkers = 1
det = cv2.aruco.CharucoDetector(board, cp, dp)
OBJ = board.getChessboardCorners().astype(float)
CTR = np.array([0.20, 0.14, 0.0])


def board_in_optical(img, eye):
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    cc, ci, _, _ = det.detectBoard(g)
    if ci is None or len(ci) < 15:
        return None
    uv = (cc.reshape(-1, 2) + 0.5) / 3 - 0.5
    K, D = np.array(cams[eye]["K"]), np.array(cams[eye]["dist_k1k2p1p2k3"])
    ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()], uv, K, D, flags=cv2.SOLVEPNP_IPPE)
    ok, rv, tv = cv2.solvePnP(OBJ[ci.ravel()], uv, K, D, rv, tv, True, cv2.SOLVEPNP_ITERATIVE)
    T = np.eye(4); T[:3, :3] = cv2.Rodrigues(rv)[0]; T[:3, 3] = tv.ravel()
    return T


res = {"nominal": [], "stereo": []}
for f in sys.argv[1:]:
    img = cv2.imread(f)
    w = img.shape[1] // 2
    TL, TR = board_in_optical(img[:, :w], "head_left"), board_in_optical(img[:, w:], "head_right")
    if TL is None or TR is None:
        continue
    cL = (T_tLo @ TL)[:3, :3] @ CTR + (T_tLo @ TL)[:3, 3]
    for k in res:
        TB = T_tRo[k] @ TR
        cR = TB[:3, :3] @ CTR + TB[:3, 3]
        res[k].append((cR - cL) * 1000)
for k, v in res.items():
    v = np.array(v)
    print(f"{k:8s} right - left eye board centre over {len(v)} images: mean {np.round(v.mean(0), 1).tolist()} mm, "
          f"|mean| {np.linalg.norm(v.mean(0)):.1f} mm, per-image |diff| median {np.median(np.linalg.norm(v, axis=1)):.1f} mm")
