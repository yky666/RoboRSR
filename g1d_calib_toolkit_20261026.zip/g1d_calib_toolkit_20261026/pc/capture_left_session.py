# capture_left_session.py -- run the planned left-arm poses (right arm stays at all-zero), grab head + left wrist frames
# (left wrist = port 55556 since 2026-10-21 21:25) and the measured joint angles at each, return to all-zero.
# Output: captures.json in the format of capture_board_views.py (read by refine_wrist_mount.py).
# usage: capture_left_session.py <left_session_plan.json> <out_dir>
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np

import arm_client as arm

PLAN, OUT = json.load(open(sys.argv[1])), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
PORTS = {"head": 55555, "left_wrist": 55556}
records = []


def grab(name, port, fn):
    subprocess.run(["ssh", "unitree", f"~/miniconda3/envs/tv/bin/python ~/calib_sessions/grab_one.py {port} /tmp/{fn}"],
                   check=True, capture_output=True)
    subprocess.run(["scp", f"unitree:/tmp/{fn}", str(OUT / fn)], check=True, capture_output=True)


try:
    s0 = arm.status()
    assert np.abs(s0["arm_q"]).max() < 0.08, f"not at all-zero: {np.round(s0['arm_q'], 3)}"
    for k, p in enumerate(PLAN["poses"]):
        if p["via_zero"]:
            arm.move(np.zeros(14), seconds=3.0, timeout=60)
        q = np.r_[p["q"], np.zeros(7)]
        arm.move(q, seconds=3.0, timeout=60)
        time.sleep(1.5)
        s = arm.status()
        rec = {"pose": f"L{k:02d}", "q_cmd": q.tolist(), "q_meas": s["arm_q"], "waist": s["all_q"][12], "t": time.time(), "frames": {}}
        for name, port in PORTS.items():
            for j in range(2):
                fn = f"L{k:02d}_{name}_{j}.png"
                grab(name, port, fn)
                rec["frames"].setdefault(name, []).append(fn)
        rec["q_meas_after"] = arm.status()["arm_q"]
        records.append(rec)
        print(f"L{k:02d}: q_meas {np.round(s['arm_q'][:7], 3).tolist()}  drift {np.abs(np.subtract(rec['q_meas_after'], s['arm_q'])).max():.4f}",
              flush=True)
finally:
    arm.move(np.zeros(14), seconds=4.0, timeout=60)
    print("back at all-zero", flush=True)
    (OUT / "captures.json").write_text(json.dumps({"plan": PLAN, "records": records}, indent=1), encoding="utf-8")
