# check_robodojo_merge.py -- does the RoboDojo G1-D asset + our calibration line up with the real robot images?
#   wrist view: their gripper meshes (fingers; camera-module geometry is behind/below the lens) projected into the real
#               wrist frames with (B) their config as-is: nominal mount + their pinhole (fx 314.4, centred, no
#               distortion), (C) our calibrated mount + their pinhole, (A) our calibrated mount + our intrinsics
#               (checkerboard K/dist + identified AF delta). Fingers and camera both ride on dex1_base_link, so this
#               tests gripper geometry + camera mount + intrinsics, independent of the arm calibration.
#   head view:  their arm and gripper meshes with their original URDF vs the calibrated URDF, our head intrinsics.
#   metric: orientation-aware chamfer (8 bins, capped 20 px) from the projected outline to Canny edges of the raw image.
# usage: check_robodojo_merge.py <asset_dir with meshes/, g1d_dex1.urdf, g1d_dex1_calib.urdf, *_robot_config*.yml> <out>
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
from scipy.ndimage import map_coordinates
from scipy.spatial.transform import Rotation

ROOT = Path(__import__("os").environ.get("G1D_WORKSPACE", "."))
sys.path.insert(0, str(ROOT / "g1d_calib_20261015" / "g1d_calib_20261015"))
from calib_model import load_params  # noqa: E402

ASSET, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
SESSIONS = {"right": ROOT / "pc_tools/sessions/calib_20261021_1106_B_wrist_table_board_right",
            "left": ROOT / "pc_tools/sessions/calib_20261019_1209_B_wrist_table_board_left"}
INTR = ROOT / "pc_tools/calib_data/intrinsics"
P = load_params(ROOT / "pc_tools/replay_cups/model/params_final_1021.json")["values"]
R_WORLD_USD = np.array([[0, 0, -1], [-1, 0, 0], [0, 1, 0]], float)
OPT_FROM_CAM = np.array([[0, -1, 0], [0, 0, -1], [1, 0, 0]], float)  # x-fwd/y-left/z-up -> optical (z fwd, y down)
W, H, NBIN = 640, 480, 8


# ---------------- URDF ----------------
class Urdf:
    def __init__(self, path):
        r = ET.parse(path).getroot()
        self.j = {}
        for j in r.findall("joint"):
            o = j.find("origin")
            T = np.eye(4)
            T[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
            T[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
            ax = j.find("axis")
            self.j[j.find("child").get("link")] = dict(name=j.get("name"), parent=j.find("parent").get("link"),
                                                      type=j.get("type"), T=T,
                                                      axis=np.array([float(v) for v in (ax.get("xyz") if ax is not None else "1 0 0").split()]))
        self.vis = {}
        for l in r.findall("link"):
            for v in l.findall("visual"):
                m = v.find("geometry/mesh")
                if m is not None:
                    self.vis.setdefault(l.get("name"), []).append(m.get("filename"))

    def fk(self, link, q, root="torso_link"):
        T = np.eye(4)
        while link != root:
            j = self.j[link]
            M = j["T"].copy()
            v = q.get(j["name"], 0.0)
            if j["type"] in ("revolute", "continuous") and v:
                M = M @ np.block([[Rotation.from_rotvec(j["axis"] * v).as_matrix(), np.zeros((3, 1))], [np.zeros((1, 3)), 1]])
            elif j["type"] == "prismatic" and v:
                D = np.eye(4); D[:3, 3] = j["axis"] * v; M = M @ D
            T = M @ T
            link = j["parent"]
        return T


MESH_CACHE = {}


def mesh(rel):
    if rel not in MESH_CACHE:
        b = (ASSET / rel).read_bytes()
        n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
        tris = np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)["v"].astype(float)
        g = 0.001
        V = tris.reshape(-1, 3)
        uk, inv = np.unique(np.floor(V / g).astype(np.int64), axis=0, return_inverse=True)
        inv = inv.ravel()
        rep = np.zeros((len(uk), 3)); np.add.at(rep, inv, V); rep /= np.bincount(inv)[:, None]
        F = inv.reshape(-1, 3)
        F = F[(F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])]
        MESH_CACHE[rel] = rep[np.unique(np.sort(F, 1), axis=0)]
    return MESH_CACHE[rel]


# ---------------- cameras ----------------
def cam_mount(yml, name):
    txt = yml.read_text(encoding="utf-8")
    m = re.search(rf'link: "([^"]+)"\s*name: "{name}".*?pos: \[([^\]]+)\].*?ori: \[([^\]]+)\]', txt, re.S)
    w, x, y, z = (float(v) for v in m.group(3).split(","))
    T = np.eye(4)
    T[:3, :3] = Rotation.from_quat([x, y, z, w]).as_matrix() @ R_WORLD_USD.T
    T[:3, 3] = [float(v) for v in m.group(2).split(",")]
    return m.group(1), T


def intr(cam, mode):
    d = json.loads((INTR / f"camera_intrinsics_{cam}.json").read_text(encoding="utf-8"))
    K, D = np.array(d["K"], float), np.array(d["dist"], float)
    if mode == "theirs":  # RoboDojo env_cfg/camera/template.py: square pixels, centred, no distortion
        f = 640 * 10.0 / (22.898 if cam == "head_left" else 20.356)
        return np.array([[f, 0, 319.5], [0, f, 239.5], [0, 0, 1.0]]), np.zeros(5)
    if mode == "cal":
        for i, k in enumerate(("fx", "fy", "cx", "cy")):
            K[[0, 1, 0, 1][i], [0, 1, 2, 2][i]] += P.get(f"intrinsics:{cam}/{k}", 0.0)
        D = D + np.array([P.get(f"intrinsics:{cam}/{k}", 0.0) for k in ("k1", "k2", "p1", "p2", "k3")])
    return K, D


def project(pc, K, D):
    z = pc[:, 2]
    ok = z > 0.03
    x, y = pc[:, 0] / np.where(ok, z, 1), pc[:, 1] / np.where(ok, z, 1)
    if np.any(D):
        k1, k2, p1, p2, k3 = D
        r2 = x * x + y * y
        ok &= r2 < 1.7 ** 2
        rad = 1 + k1 * r2 + k2 * r2 ** 2 + k3 * r2 ** 3
        x, y = x * rad + 2 * p1 * x * y + p2 * (r2 + 2 * x * x), y * rad + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
    return np.stack([K[0, 0] * x + K[0, 2], K[1, 1] * y + K[1, 2]], 1), ok


def raster(urdf, links, q, T_cam_torso, K, D):
    m = np.zeros((H, W), np.uint8)
    for ln in links:
        T = T_cam_torso @ urdf.fk(ln, q)
        for rel in urdf.vis.get(ln, []):
            v = mesh(rel).reshape(-1, 3)
            pc = (v @ T[:3, :3].T + T[:3, 3]) @ OPT_FROM_CAM.T
            uv, ok = project(pc, K, D)
            uv, ok = uv.reshape(-1, 3, 2), ok.reshape(-1, 3).all(1)
            uv = uv[ok]
            uv = uv[(uv.max(1) > -200).all(1) & (uv.min(1) < [W + 200, H + 200]).all(1)]
            for t in np.round(uv * 8).astype(np.int32):
                cv2.fillConvexPoly(m, t, 255, cv2.LINE_8, 3)
    return m


def edge_dts(gray):
    g = cv2.GaussianBlur(gray, (5, 5), 0)
    e = cv2.Canny(g, 30, 90) > 0
    ang = np.arctan2(cv2.Sobel(g, cv2.CV_32F, 0, 1), cv2.Sobel(g, cv2.CV_32F, 1, 0)) % np.pi
    b = np.floor(ang / np.pi * NBIN + 0.5).astype(int) % NBIN
    return [np.minimum(cv2.distanceTransform((~(e & ((b == k) | (b == (k + 1) % NBIN) | (b == (k - 1) % NBIN)))).astype(np.uint8),
                                             cv2.DIST_L2, 5), 20).astype(np.float32) for k in range(NBIN)]


def chamfer(mask, dts, block=None, border=8):
    cs, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    pts, tan = [], []
    for c in cs:
        p = c.reshape(-1, 2).astype(float)
        if len(p) < 20:
            continue
        pts.append(p[::2]); tan.append((np.roll(p, -3, 0) - np.roll(p, 3, 0))[::2])
    if not pts:
        return np.zeros(0), cs
    p, t = np.concatenate(pts), np.concatenate(tan)
    keep = (p[:, 0] > border) & (p[:, 0] < W - 1 - border) & (p[:, 1] > border) & (p[:, 1] < H - 1 - border)
    if block is not None:
        keep &= block[p[:, 1].astype(int).clip(0, H - 1), p[:, 0].astype(int).clip(0, W - 1)] == 0
    p, t = p[keep], t[keep]
    b = np.floor((np.arctan2(t[:, 0], -t[:, 1]) % np.pi) / np.pi * NBIN + 0.5).astype(int) % NBIN
    d = np.empty(len(p))
    for k in range(NBIN):
        s = b == k
        if s.any():
            d[s] = map_coordinates(dts[k], [p[s, 1], p[s, 0]], order=1)
    return d, cs


# ---------------- run ----------------
U_orig, U_cal = Urdf(ASSET / "g1d_dex1.urdf"), Urdf(ASSET / "g1d_dex1_calib.urdf")
grip_closed = 0.024  # Dex1-1 finger joint at gripper command 0 (closed; sessions do not command the gripper)
res = {"wrist": {}, "head": {}}
for side, ses in SESSIONS.items():
    cam = f"{side}_wrist"
    fingers = [f"{side}_dex1_finger_link_{i}{t}" for i in (1, 2) for t in ("", "_mid", "_tip")]
    module = [f"{side}_dex1_model_base_link"]
    arm = [f"{side}_{n}_link" for n in ("shoulder_roll", "shoulder_yaw", "elbow", "wrist_roll", "wrist_pitch", "wrist_yaw")]
    _, T_wnom = cam_mount(ASSET / f"{side}_robot_config.yml", "cam_wrist")
    _, T_wcal = cam_mount(ASSET / f"{side}_robot_config_calib.yml", "cam_wrist")
    _, T_head = cam_mount(ASSET / "left_robot_config.yml", "cam_head")
    Kh, Dh = intr("head_left", "checker")
    wrist_cfg = {"B_theirs": (T_wnom, *intr(cam, "theirs")), "C_calmount_theirsK": (T_wcal, *intr(cam, "theirs")),
                 "A_calibrated": (T_wcal, *intr(cam, "cal"))}
    samples = [json.loads(l) for l in open(ses / "samples.jsonl", encoding="utf-8") if l.strip()]
    rw = {k: [] for k in wrist_cfg}
    rh = {"orig_arm": [], "cal_arm": [], "orig_grip": [], "cal_grip": []}
    for n, s in enumerate(samples):
        q = dict(s["joints_before"]["q"])
        q.update({f"{side}_dex1_finger_joint_1": grip_closed, f"{side}_dex1_finger_joint_2": grip_closed})
        wimg = cv2.imdecode(np.fromfile(str(ses / s["frames"][cam][0]["file"]), np.uint8), cv2.IMREAD_COLOR)
        wd = edge_dts(cv2.cvtColor(wimg, cv2.COLOR_BGR2GRAY))
        ov = wimg.copy()
        for tag, (Tm, K, D) in wrist_cfg.items():
            Tc = np.linalg.inv(U_cal.fk(f"{side}_dex1_base_link", q) @ Tm)  # arm model irrelevant: same rigid body
            mk = raster(U_cal, fingers, q, Tc, K, D)
            d, cs = chamfer(mk, wd)
            if len(d) > 30:
                rw[tag].append(float(np.median(d)))
            if tag != "C_calmount_theirsK":
                cv2.drawContours(ov, cs, -1, (0, 230, 0) if tag.startswith("A") else (0, 0, 255), 2, cv2.LINE_AA)
        if n % 11 == 0:
            cv2.putText(ov, f"{s['id']}  red: their config  green: calibrated", (8, 22), 0, 0.6, (255, 255, 255), 2)
            cv2.imencode(".png", ov)[1].tofile(str(OUT / f"wrist_{side}_{s['id']}.png"))
        himg = cv2.imdecode(np.fromfile(str(ses / s["frames"]["head_stereo"][0]["file"]), np.uint8), cv2.IMREAD_COLOR)[:, :W]
        hd = edge_dts(cv2.cvtColor(himg, cv2.COLOR_BGR2GRAY))
        hov = himg.copy()
        for tag, U, col in (("orig", U_orig, (0, 0, 255)), ("cal", U_cal, (0, 230, 0))):
            Tc = np.linalg.inv(U.fk("head_link", q) @ T_head)
            ma = raster(U, arm, q, Tc, Kh, Dh)
            mg = raster(U, fingers + module, q, Tc, Kh, Dh)
            da, ca = chamfer(ma, hd, block=cv2.dilate(mg, np.ones((15, 15), np.uint8)))
            dg, cg = chamfer(mg, hd, block=cv2.dilate(ma, np.ones((9, 9), np.uint8)))
            if len(da) > 30:
                rh[f"{tag}_arm"].append(float(np.median(da)))
            if len(dg) > 30:
                rh[f"{tag}_grip"].append(float(np.median(dg)))
            cv2.drawContours(hov, ca + cg, -1, col, 1, cv2.LINE_AA)
        if n % 11 == 0:
            cv2.putText(hov, f"{s['id']}  red: original URDF  green: calibrated URDF", (8, 22), 0, 0.55, (255, 255, 255), 2)
            cv2.imencode(".png", hov)[1].tofile(str(OUT / f"head_{side}_{s['id']}.png"))
    res["wrist"][side] = {k: {"median_px": float(np.median(v)), "n": len(v)} for k, v in rw.items() if v}
    res["head"][side] = {k: {"median_px": float(np.median(v)), "n": len(v)} for k, v in rh.items() if v}
    print(side, "wrist view (finger outline chamfer, median over frames, px):",
          {k: round(v["median_px"], 2) for k, v in res["wrist"][side].items()})
    print(side, "head view  (outline chamfer, px):", {k: round(v["median_px"], 2) for k, v in res["head"][side].items()})
(OUT / "check_robodojo_merge.json").write_text(json.dumps(res, indent=1), encoding="utf-8")
