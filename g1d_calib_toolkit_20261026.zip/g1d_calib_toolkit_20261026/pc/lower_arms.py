# lower_arms.py -- all-zero -> arms hanging at the sides (out of the head camera's lower field), the reverse of
# raise_to_zero2.py: abduct, forearms down / upper arms slightly back, roll back to a small abduction. Held by the server.
import numpy as np

import arm_client as arm

ROLL_L, ROLL_R = 0.35, -0.25


def move_split(target, seconds=3.0):
    cur = np.array(arm.status()["arm_q_cmd"])
    n = max(1, int(np.ceil(np.abs(target - cur).max() / 1.3)))
    s = None
    for k in range(1, n + 1):
        s = arm.move(cur + (target - cur) * k / n, seconds=seconds, timeout=120)
    return s


q = np.array(arm.status()["arm_q_cmd"])
print("start      :", np.round(q, 3).tolist())
assert np.abs(q).max() < 0.1, "not at all-zero"
t1 = np.zeros(14); t1[1], t1[8] = ROLL_L, ROLL_R
s = move_split(t1); print("1 abduct   :", np.round(s["arm_q"], 3).tolist())
t2 = t1.copy(); t2[[0, 7]] = 0.15; t2[[3, 10]] = 1.25
s = move_split(t2); print("2 down     :", np.round(s["arm_q"], 3).tolist())
t3 = t2.copy(); t3[1], t3[8] = 0.08, -0.08
s = move_split(t3); print("3 roll back:", np.round(s["arm_q"], 3).tolist())
