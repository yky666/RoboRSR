# raise_to_zero2.py -- hanging (and possibly twisted) arms -> all-zero pose:
# 1) abduct shoulders so the hands clear the chassis / lift column
# 2) unwind shoulder yaw (split into <= 1.3 rad commands)
# 3) everything else to 0 while abducted
# 4) roll back to 0
import numpy as np

import arm_client as arm

ROLL_L, ROLL_R = 0.35, -0.25


def move_split(target, seconds=3.0):
    cur = np.array(arm.status()["arm_q_cmd"])
    n = max(1, int(np.ceil(np.abs(target - cur).max() / 1.3)))
    s = None
    for k in range(1, n + 1):
        s = arm.move(cur + (target - cur) * k / n, seconds=seconds, timeout=120)
    return s


q = np.array(arm.status()["arm_q_cmd"])
print("start            :", np.round(q, 3).tolist())
t1 = q.copy(); t1[1] = ROLL_L; t1[8] = ROLL_R
s = move_split(t1); print("1 abduct         :", np.round(s["arm_q"], 3).tolist())
t2 = t1.copy(); t2[2] = 0.0; t2[9] = 0.0
s = move_split(t2); print("2 yaw unwound    :", np.round(s["arm_q"], 3).tolist())
t3 = np.zeros(14); t3[1] = ROLL_L; t3[8] = ROLL_R
s = move_split(t3); print("3 forearms up    :", np.round(s["arm_q"], 3).tolist())
s = move_split(np.zeros(14)); print("4 roll back      :", np.round(s["arm_q"], 3).tolist())
print("max |q| =", round(float(np.abs(s["arm_q"]).max()), 3))
