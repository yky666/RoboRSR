# sub_lowstate.py — DDS 订阅 rt/lowstate 连通性试验（只读，不发送任何指令）
# 用自定义 cyclonedds 配置（无 Linux 风格日志路径），网卡可用 IP 指定
# 用法: python sub_lowstate.py [网卡IP] [秒数]
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "3rd" / "unitree_sdk2_python"))

from cyclonedds.domain import Domain, DomainParticipant
from cyclonedds.sub import DataReader
from cyclonedds.topic import Topic
from unitree_sdk2py.idl.unitree_hg.msg.dds_ import LowState_

# cyclonedds python 会把配置按 ascii 编码，中文网卡名 "以太网 2" 用 XML 数字字符引用绕过
IFACE = sys.argv[1] if len(sys.argv) > 1 else "&#20197;&#22826;&#32593; 2"
SECONDS = float(sys.argv[2]) if len(sys.argv) > 2 else 5.0

CONFIG = f"""<?xml version="1.0" encoding="UTF-8" ?>
<CycloneDDS>
  <Domain Id="any">
    <General>
      <Interfaces>
        <NetworkInterface name="{IFACE}" priority="default" multicast="default"/>
      </Interfaces>
      <AllowMulticast>spdp</AllowMulticast>
    </General>
  </Domain>
</CycloneDDS>"""

print(f"interface={IFACE}, domain=0, topic=rt/lowstate, {SECONDS}s")
domain = Domain(0, CONFIG)
participant = DomainParticipant(0)
topic = Topic(participant, "rt/lowstate", LowState_)
reader = DataReader(participant, topic)

n = 0
t0 = time.perf_counter()
first = None
last_t = None
gaps = []
while time.perf_counter() - t0 < SECONDS:
    msgs = reader.take(N=100)
    now = time.perf_counter()
    for msg in msgs:
        if last_t is not None:
            gaps.append(now - last_t)
        last_t = now
        if first is None:
            first = msg
        n += 1
    if not msgs:
        time.sleep(0.001)

if n == 0:
    print("FAIL: 一条都没收到（网卡/域/组播不通）")
    sys.exit(1)

dt = time.perf_counter() - t0
gaps.sort()
print(f"OK: 收到 {n} 条 / {dt:.1f}s = {n/dt:.1f} Hz")
print(f"间隔: 中位 {gaps[len(gaps)//2]*1000:.2f} ms, p95 {gaps[int(len(gaps)*0.95)]*1000:.2f} ms")

ms = first.motor_state
print(f"motor_state 数量: {len(ms)}")
nz = [i for i, m in enumerate(ms) if abs(m.q) > 1e-6]
print(f"q 非零的电机 {len(nz)} 个: {nz[:40]}")
arm = {  # G1_29_JointArmIndex（来自 g1d_infra，需真机验证）
    "L_sh_pitch": 15, "L_sh_roll": 16, "L_sh_yaw": 17, "L_elbow": 18,
    "L_wr_roll": 19, "L_wr_pitch": 20, "L_wr_yaw": 21,
    "R_sh_pitch": 22, "R_sh_roll": 23, "R_sh_yaw": 24, "R_elbow": 25,
    "R_wr_roll": 26, "R_wr_pitch": 27, "R_wr_yaw": 28, "waist_yaw": 12,
}
print("臂/腰关节读数 (rad):")
for name, i in arm.items():
    m = ms[i]
    tau = getattr(m, "tau_est", None)
    print(f"  [{i:2d}] {name:12s} q={m.q:+.4f}  dq={m.dq:+.4f}  tau_est={tau if tau is None else f'{tau:+.3f}'}")
print(f"mode_machine={getattr(first, 'mode_machine', None)}")
