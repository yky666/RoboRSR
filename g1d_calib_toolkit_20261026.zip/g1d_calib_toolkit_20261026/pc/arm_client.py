# arm_client.py -- PC-side client for robot ~/g1d_infra_calib/scripts/calib_arm_server.py (via ssh unitree)
import json
import subprocess
import time

CMD = "/tmp/g1d_calib/cmd.json"
STATUS = "/tmp/g1d_calib/status.json"


def _ssh(cmd, data=None, timeout=30, retries=3):
    last = None
    for k in range(retries):
        try:
            r = subprocess.run(["ssh", "unitree", cmd], input=data, capture_output=True, timeout=timeout)
            if r.returncode == 0:
                return r.stdout
            last = RuntimeError(f"ssh failed: {r.stderr.decode(errors='replace')}")
        except subprocess.TimeoutExpired as e:
            last = e
        time.sleep(1.0 + k)
    raise last


def status():
    for k in range(3):
        try:
            return json.loads(_ssh(f"cat {STATUS}"))
        except json.JSONDecodeError:
            time.sleep(0.2)              # caught the file mid-replace
    return json.loads(_ssh(f"cat {STATUS}"))


def send(cmd: dict) -> int:
    seq = int(time.time() * 1000)
    cmd = dict(cmd, seq=seq)
    _ssh(f"mkdir -p /tmp/g1d_calib && cat > {CMD}.tmp && mv {CMD}.tmp {CMD}", json.dumps(cmd).encode())
    return seq


def wait_idle(timeout=120.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] in ("idle", "error"):
            return s
        time.sleep(0.3)
    raise TimeoutError("server did not become idle")


def wait_done(seq, timeout=60.0, poll=0.3):
    t0 = time.time()
    while time.time() - t0 < timeout:
        s = status()
        if s["state"] == "error":
            raise RuntimeError(f"robot error: {s['msg']}")
        if s["seq_done"] >= seq and s["state"] == "idle":
            if s["msg"].startswith("REJECTED") or s["msg"].startswith("refused"):
                raise RuntimeError(f"command rejected: {s['msg']}")
            return s
        time.sleep(poll)
    raise TimeoutError(f"seq {seq} not done after {timeout}s")


def move(arm_q, seconds=3.0, timeout=90.0):
    return wait_done(send({"cmd": "move", "arm_q": [float(v) for v in arm_q], "seconds": seconds}), timeout)


def jog(motor, delta, seconds=1.0, timeout=30.0):
    return wait_done(send({"cmd": "jog", "motor": int(motor), "delta": float(delta), "seconds": seconds}), timeout)


def stop():
    return send({"cmd": "stop"})
