# waist_to.py -- turn the waist yaw (motor 12) to a target through calib_arm_server's 'waist' command
# usage: python waist_to.py [target_rad=0.0]
import sys

import arm_client as arm

tgt = float(sys.argv[1]) if len(sys.argv) > 1 else 0.0
s = arm.status()
print("before: waist", round(s["all_q"][12], 4), "cmd", round(s.get("waist_q_cmd", float("nan")), 4))
s = arm.wait_done(arm.send({"cmd": "waist", "q": tgt}), timeout=60)
print("server:", s["msg"])
print("after : waist", round(s["all_q"][12], 4), "| max |arm q| =", round(max(abs(v) for v in s["arm_q"]), 3))
