# 数据样例（只适用于原来那台 G1-D）

> **这里的所有数据都来自一台具体的 G1-D（2026-10-16 ~ 10-23）。** 参数、相机配置、内参、板位姿、计划在另一台机器人上都不能直接用。用途：看清文件格式、作为第一次运行的参照、核对你得到的数值是否在同一量级。只放了小 JSON，没有图像和大数据。

## 正式结果（2026-10-23，sq382j）

| 文件 | 格式 | 内容 | 用在哪 |
|---|---|---|---|
| `robodojo_merge_sq382j/params_final_sq382j.json` | `g1d_calib_params_v1` | **正式参数**：相对名义 v4 URDF 共 106 项（关节零位 / 轴扭转 / 原点平移、相机安装增量、内参增量）。`sources` 里是服务器路径，只作溯源 | `apply_calibration.py`、`build_assembly.py`、`merge_calib_into_robodojo.py`、`make_camera_setup.py`（`CALIB_PARAMS`） |
| `robodojo_merge_sq382j/camera_setup_ours.json` | `g1d_camera_setup_v1` | **正式相机配置**：head_left / head_right / left_wrist / right_wrist 的父 link、最终安装（+x 前、+y 左、+z 上）、最终 K/畸变；右眼 = 左眼 + 双目 R、T（基线 58.6 mm）；`physical_ports` 为 10-21 21:25 后的映射 | 仿真相机、`refine_wrist_mount.py`、`joint_fit.py`（经 `CALIB_PKG`）、叠杯脚本 |
| `robodojo_merge_sq382j/README.md` | 文本（英文） | RoboDojo 包说明、腕部–头部检验表、头部轮廓分数 | 阅读 |
| `robodojo_merge_sq382j/params_joint_delta_sq382.json` | `g1d_calib_params_v1` | 联合拟合（mount_trans）增量，叠加在 `urdf_contour_sq382c` 上 | `build_sq382j.sh` 的中间产物 |
| `robodojo_merge_sq382j/joint_left.json`、`joint_right.json` | joint_fit 结果 | 每臂 4 种模型的参数、可读值（mm / 度）、每会话腕部 rms / 焦距比例、头部轮廓分数 | 对照 §7 的数字 |

## 中间参数与被取代的参数

| 文件 | 状态 | 说明 |
|---|---|---|
| `params_20261023/params_dual_trans_sq382.json` | 核心 | 38.2 mm 的 dual_trans 辨识结果；`compose_params.py` 合成正式参数时 `camera:*`、`intrinsics:*` 取自这里 |
| `params_20261023/params_contour_mount_1020.json` | 辅助 | 10-20 轮廓对齐的肩部安装增量（相对 dual_trans URDF），`pipeline_sq.sh` 第一遍叠加它 |
| `params_20261023/params_final_sq382c.json` | 已弃用 | 38.2 mm + 只用头部轮廓定肩部安装；联合拟合的基础几何 |
| `params_20261023/params_final_1021.json` | 已弃用 | 10-21 正式参数（板按 40 mm） |
| `params_1019/*.json` | 已弃用 | 10-19 辨识参数（40 mm），触碰交叉验证用过 |

## 内参与映射

| 文件 | 内容 | 注意 |
|---|---|---|
| `intrinsics/camera_intrinsics_head_left.json`、`_head_right.json` | 头部内参（10-16，正式；10-23 重采结果未采用） | 双目 R、T 见 `replay_cups/out/head_stereo_extrinsics.json`（按 40 mm，T 需乘格长/40） |
| `intrinsics/camera_intrinsics_left_wrist.json`、`_right_wrist.json` | 腕部内参（属于物理相机） | `zmq_port` 字段是 10-16 映射（55557 = 左腕）；**10-21 21:25 起 55556 = 左腕** |
| `joint_mapping.json` | 14 个手臂关节的电机序号、sign（全 +1） | 相机端口字段同样是 10-16 映射 |
| `head_cam_T.json` | 头部左右目在躯干系的位姿（名义合同） | 右眼为名义安装 |
| `dircheck_plan.json` | 方向检查计划 | — |

## 头部定位的腕部看板会话（第 4.2、7、10 步）

| 文件 | 内容 |
|---|---|
| `board_check_20261022/board_pose.json` | 头部双目测得的板位姿（两眼） |
| `board_check_20261022/board_view_plan.json` | `plan_board_view.py` 输出：双臂小幅腕部调整计划 |
| `board_check_20261022/left_session_plan.json` | `plan_left_session.py` 输出：左臂 18 姿态 |
| `board_check_20261022/captures.json` | `capture_*` 的记录格式（每个姿态的实测关节角与帧文件名；图像未附带） |
| `board_check_20261022/refine_left_1023.json`、`refine_right_1023.json` | `refine_wrist_mount.py` 输出格式（当前误差、焦距比例、留一结果；对应 10-22 包，40 mm 时代） |

## 叠杯应用（第 11 步）

| 文件 | 内容 |
|---|---|
| `replay_cups_20261023/cups.json` | `fit_cups.py` 输出：两只杯子在躯干系的位置、桌面平面 |
| `replay_cups_20261023/m_search.json` | `plan2.py findm` 输出：候选汇合点 |
| `replay_cups_20261023/plan2_1023s.json` | 10-23 真机执行的计划（两臂顺序执行 `--seq`） |

## 10-19 数据（格式参照）

| 文件 | 内容 |
|---|---|
| `poses_20261019/*.json` | 10-19 姿态表、场景表头、板位姿、统计 |
| `touch_auto_left_20261019_1757/touches.jsonl`、`log.txt` | 一次触碰批次的记录和日志 |

注意：10-19 的板位姿、触碰板面坐标都是按 40 mm 计算的；换算到实测格长要乘 0.955（38.2/40）。
