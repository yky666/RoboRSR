# robodojo_g1d_calib_sq382j_20261023

The colleague's RoboDojo G1-D robot (official G1-D URDF with the team's Dex1-1 + rebuilt wrist-camera module,
lift column, waist, chassis) with OUR calibration attached. Current official version; supersedes
`robodojo_g1d_calib_20261022` (board assumed 40 mm) and `robodojo_g1d_calib_sq382_20261023` / `sq385` (board size
corrected, arm placement from the head outline only).

| file | content |
|---|---|
| `g1d_dex1_calib.urdf` | tabletop version (root `AGV_link`, wheels locked), 14 arm joint origins from `params_final_sq382j.json` |
| `g1d_mobile_dex1_calib.urdf` | same + virtual planar chassis joints `base_x/base_y/base_yaw` (root `base_world`) |
| `meshes/`, `physics_contract.json` | unchanged from the RoboDojo asset (self-collision filter pairs) |
| `camera_setup_ours.json` | OUR cameras: head_left/right, left/right_wrist; parent link, final mount (identified camera deltas already applied), final K/dist (identified intrinsics deltas applied) |
| `params_final_sq382j.json` | the calibration (relative to the nominal v4 URDF, 106 values) |

How it was obtained:
1. Board: the A3 ChArUco board (and the 10-16 chessboard, same print) measures ~382 mm over 10 squares -> 38.2 mm per
   square (not 40). Intrinsics are scale-free; the stereo translation is rescaled (baseline 58.6 mm).
2. dual_trans identification (wrist cameras on the table board, board pose free) re-run with 38.2 mm.
3. Joint fit (`joint_fit.py`, model mount_trans): per arm the shoulder mount (6) and the joint-origin translations of
   shoulder_roll..wrist_yaw (18, 3 mm prior) fitted to BOTH the arm outline in the head images (10-19 views) and the
   head-anchored wrist board data (board pose from the head stereo). The wrist-only data cannot see several of these
   translations, and fitting the head outline alone had pushed the whole camera chain off by 1-2 cm.

Wrist camera vs head (board anchored by the head stereo, px rms, one focal scale per session for autofocus;
sessions not used in the fit marked *):

| | official 10-21 (40 mm) | sq382 | sq382j (this) |
|---|---|---|---|
| left 10-19 1509 / 1209* | 23.9 / 22.5 | 14.6 / 13.4 | 6.7 / 6.5 |
| left 10-22 far* / 18 poses | 23.6 / 18.4 | 15.1 / 14.0 | 5.8 / 3.0 |
| left 10-23 far* / 18 poses* | 22.4 / 17.4 | 16.2 / 13.9 | 5.1 / 4.5 |
| right 10-19 / 10-21* | 13.5 / 12.8 | 15.2 / 15.0 | 5.4 / 5.8 |
| right 10-22 / 10-23* | 3.6 / 6.6 | 13.7 / 18.9 | 4.9 / 8.1 |

Head-view arm outline (left eye only, median px; train 10-19 1509+1533, held-out 1209 and 10-21 1106):
left 1.75 / 2.86 / 1.75, right 1.75 / 1.51 / 2.26 (sq382: 1.82 / 2.69 / 2.05, 1.75 / 2.20 / 2.49).

- Source: 5090-2 `/data/robodojo-runs/g1d-mobile-20261021/Assets/Robots/g1d` (copied read-only on 2026-10-22).
- The colleague's camera definitions (`*_robot_config.yml`, `env_cfg/camera/template.py`) are NOT used.
- Joint convention unchanged: q_model = q_encoder + zero is built into the joint origins, so real joint angles replay
  directly. Waist, lift and chassis are not calibrated (data taken at waist 0, lift fixed).
- Cameras: Isaac pinhole cameras cannot model lens distortion; use the K principal point via aperture offsets and
  compare against undistorted real frames. Wrist fx is valid for the 0.2-0.4 m autofocus range; the real focal length
  varies by session (scale 0.92-1.0), which a fixed sim camera cannot follow.
- Use the right eye from `camera_setup_ours.json` (stereo-calibrated); the sim asset's own `camera_contract_v5.json`
  still has the nominal right-eye mount.
