# MANIFEST：文件清单（2026-10-26 版）

每个文件一行。**状态**：核心 = 推荐流程要用；辅助 = 可选步骤、模板、可视化、样例；诊断 = 只读检查或排查假设用；已弃用 = 被取代或被否决（保留作记录，不要在正式流程里用）。
**运行位置**：机器人 = G1-D 本机（conda `tv`）；服务器 = GPU 服务器（`$ISAAC_ENV` 或 `/usr/bin/python3`）；服务器 2 = 装有同事 RoboDojo 环境的第二台 GPU 服务器；PC = Windows；— = 文档或数据。
**✎** = 打包时做过路径/主机名/提示文字替换（规则见 `docs/环境配置_zh.md` 开头），其余文件与工作区原样一致。所有 `.py`/`.sh` 为 LF 行尾、无 BOM，全部通过 `python -m py_compile`。

## 顶层与文档

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `README_zh.md` | 工具包说明、本版变化、目录、快速开始 | — | 核心 |
| `MANIFEST.md` | 本文件 | — | 核心 |
| `SHA256SUMS.txt` | 所有文件的 SHA-256（不含自身） | — | 核心 |
| `docs/使用手册_zh.md` | 完整流程第 0–12 节：命令、通过标准、典型数值、常见问题 | — | 核心 |
| `docs/安全规范_zh.md` | 安全规则：现场、路径、控制服务、控制权交接、两个写入者、kill、进程管理、端口 | — | 核心 |
| `docs/环境配置_zh.md` | 写死的主机/路径/端口、环境变量、PC 工作区布局、常见坑 | — | 核心 |
| `docs/项目记录_20261020-26.md` | 10-20 ~ 10-26 整理版记录（采用 / 否决 / 数字） | — | 辅助 |
| `docs/项目记录_20261015-23_原始记录.md` | 原始工作记录的脱敏副本（截至 10-23）✎ | — | 辅助 |
| `skills/g1d-robot-calibration/SKILL.md` | Cursor Agent Skill：安全铁律、新流程清单、监控、恢复、汇报 | — | 辅助 |
| `skills/g1d-robot-calibration/reference.md` | Skill 参考：服务协议、每步命令与典型值、交接流程、日志关键字 | — | 辅助 |
| `examples/README_zh.md` | 样例数据说明 | — | 辅助 |
| `extras/README_zh.md` | 附加脚本的来历和弃用原因 | — | 辅助 |

## robot/（机器人；部署到 `~/calib_sessions/`，服务部署到 `~/g1d_infra_calib/scripts/`）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `robot/calib_arm_server.py` | 双臂位置控制服务（启动时保持当前位姿；限位/单步/速度/跟踪误差/断流保护；`waist` 腰部指令） | 机器人 | 核心 |
| `robot/start_server.sh` | 启动服务（不运动），已有控制程序时拒绝 | 机器人 | 核心 |
| `robot/takeover2.sh` | 无缝更换服务实例（确认新实例在写状态后才结束旧实例） | 机器人 | 核心 |
| `robot/collect_robot.py` | 设置 B 采集器（检查过的路径、稳定判据、5 帧腕部 + 头部帧、板漂移 4 mm 监控） | 机器人 | 核心 |
| `robot/run_queue.sh` | 采集后台队列，`STOP` 文件在两臂之间生效 | 机器人 | 核心 |
| `robot/go_home.py` | 只在检查过的路径上回 home（`--via`、`--near`、`--dry`） | 机器人 | 核心 |
| `robot/recover.py` | ERROR 锁定后：reset 并立即把出错臂拉回姿态表位姿 | 机器人 | 核心 |
| `robot/peek_lowstate.py` | 只读：lowstate 频率、mode_machine、手臂关节角 | 机器人 | 核心 |
| `robot/robot_state_check.py` | 只读：1.5 s 内 rt/lowcmd 写入者、腰/臂/夹爪位置、手臂速度 | 机器人 | 核心 |
| `robot/passive_logger_cams.py` | 只读记录器：rt/lowstate + rt/lowcmd + 三路相机（55555 头部、55556 左腕、55557 右腕） | 机器人 | 核心 |
| `robot/locate_board_robot.py` | 机器人本机头部双目测板位姿（按 40 mm；平移需乘实测格长/40） | 机器人 | 核心 |
| `robot/head_intr_capture.py` | 头部内参重采：人举板，按 6×4 覆盖网格自动存帧，写 `status.txt` | 机器人 | 辅助 |
| `robot/head_intr_calib.py` | 由重采帧求头部内参与双目，按图像条带对比新旧内参 | 机器人 | 辅助 |
| `robot/auto_touch.py` | 视觉引导自动触碰（独立检验手臂内部几何） | 机器人 | 辅助 |
| `robot/touch_queue.sh` | 左臂触碰后台队列 | 机器人 | 辅助 |
| `robot/touch_queue_right.sh` | 右臂触碰后台队列（10-21） | 机器人 | 辅助 |
| `robot/contact_point.py` | 接触图单应性求板面点（触碰板面坐标按 40 mm） | 机器人 | 辅助 |
| `robot/stop_now.sh` | 结束触碰队列并给服务发 `stop` | 机器人 | 辅助 |
| `robot/kill_touch.sh` | 只结束触碰脚本，当前段走完 | 机器人 | 辅助 |
| `robot/check_env.py` | 检查 cv2 aruco / CharucoDetector、zmq、numpy | 机器人 | 辅助 |
| `robot/grab_one.py` | 从 ZMQ 端口抓一帧（`which_wrist_now.py` 调用） | 机器人 | 辅助 |
| `robot/crop_zoom.py` | 裁剪放大加像素刻度（读指尖像素） | 机器人 | 辅助 |
| `robot/calib_ready_pose.py` | 最早的低层控制程序（抬到 ready 位姿并保持） | 机器人 | 辅助 |
| `robot/det_test.py` | 接触图上 ChArUco 检测数量 | 机器人 | 诊断 |
| `robot/repeat_test.py` | 重复性实验：同一姿态 4 种到达方式 | 机器人 | 诊断 |
| `robot/repeat_analyze.py` | 重复性分析（缩放 / 平移旋转 / 残差） | 机器人 | 诊断 |
| `robot/run_repeat_analyze.sh` | 等 repeat_test 结束后分析 | 机器人 | 诊断 |
| `robot/check_lowcmd_free.py` | 检查 rt/lowcmd 是否已有写入者（`robot_state_check.py` 更全） | 机器人 | 诊断 |
| `robot/limit_probe.py` | 关节限位自动探测（单关节单方向，停滞判据，`--recover`） | 机器人 | 诊断 |
| `robot/dex1_state.py` | 只读：Dex1 夹爪状态 | 机器人 | 诊断 |

## pc/（Windows PC）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `pc/arm_client.py` | 经 `ssh unitree` 读写服务 cmd/status（3 次重试） | PC | 核心 |
| `pc/capture_intrinsics.py` | 内参采图（实时预览、合格帧自动保存；端口新映射） | PC | 核心 |
| `pc/calibrate_intrinsics.py` | 内参求解、留出验证、双目基线（`--square-mm`） | PC | 核心 |
| `pc/validate_intrinsics.py` | 内参三层验证 | PC | 核心 |
| `pc/locate_board.py` | 头部双目测板位姿（按 40 mm、名义右眼；平移需乘实测格长/40） | PC | 核心 |
| `pc/dircheck.py` | 方向检查：逐关节微动拍腕相机图 | PC | 核心 |
| `pc/raise_to_zero2.py` | 手臂下垂 → 全 0 位姿 | PC | 核心 |
| `pc/lower_arms.py` | 全 0 → 手臂下垂（让出头部下部视场） | PC | 核心 |
| `pc/lift_back_to_zero.py` | 下坠后恢复：先抬肘再回 0 | PC | 核心 |
| `pc/waist_to.py` | 腰部 yaw 转到目标角（服务 `waist` 指令） | PC | 核心 |
| `pc/which_wrist_now.py` | 微动右腕 yaw，判断今天哪个端口是右腕 ✎ | PC | 核心 |
| `pc/plan_board_view.py` | 规划双臂小幅腕部调整让腕相机看到桌面板 | PC | 核心 |
| `pc/capture_board_views.py` | 执行 plan_board_view 计划，存头部 + 两腕帧和关节角 → `captures.json` | PC | 核心 |
| `pc/plan_left_session.py` | 规划左臂看板姿态（0.28–0.42 m、≥ 48 角点） | PC | 核心 |
| `pc/capture_left_session.py` | 执行左臂计划 → `captures.json` | PC | 核心 |
| `pc/merge_calib_into_robodojo.py` | 把我们的关节原点写进 RoboDojo G1-D URDF ✎ | PC | 核心 |
| `pc/check_robodojo_merge.py` | RoboDojo + 我们标定的头部/腕部轮廓检查；`plan_*`、`analyze_board_views` 读取它 ✎ | PC | 辅助 |
| `pc/live_capture_view.py` | 头部内参重采的实时引导窗口（读机器人流和 `status.txt`） | PC | 辅助 |
| `pc/confirm_motion.py` | 确认片段动作（下垂 → 0、腰回正、前抬、回 0） | PC | 辅助 |
| `pc/pull_frames.py` | 三路相机各抓一帧并统计帧率 | PC | 辅助 |
| `pc/board_timeline.py` | 从会话头部帧重建板位置时间线 | PC | 辅助 |
| `pc/table_edge.py` | 头部相机测桌子近边 | PC | 辅助 |
| `pc/touch_plan.py` | 预测悬停姿态的指尖射线落点 | PC | 辅助 |
| `pc/find_tip_pixel.py` | 自动找闭合手指楔形顶点像素 | PC | 辅助 |
| `pc/check_wrist_view.py` | 当前位姿腕相机能否看到板 | PC | 辅助 |
| `pc/joint_head_calib.py` | 头部内参两套数据联合比较（标准差、交叉残差） | PC | 诊断 |
| `pc/head_lr_consistency.py` | 左眼 / 名义右眼 / 双目右眼测板位姿的一致性 ✎ | PC | 诊断 |
| `pc/analyze_board_views.py` | 10-22 腕部看板精度分析（他们的配置 vs 我们的） | PC | 诊断 |
| `pc/compare_robodojo_urdf.py` | RoboDojo URDF 手臂链与我们名义链的比较 | PC | 诊断 |
| `pc/compare_robodojo_cams.py` | RoboDojo 相机安装 vs 我们的相机合同 ✎ | PC | 诊断 |
| `pc/compare_models.py` | 畸变模型对比 | PC | 诊断 |
| `pc/sub_lowstate.py` | Windows 直连 DDS 订阅（需 unitree_sdk2_python） | PC | 诊断 |
| `pc/which_wrist_cam.py` | 旧版端口判断（标签按 10-16 映射） | PC | 已弃用 |

## server/tools/（GPU 服务器）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `server/tools/contour_fit.py` | 头部图像手臂轮廓对齐：`eval` / `fit ... mount` / `pose`；联合拟合也 import 它 | 服务器 | 核心 |
| `server/tools/compose_params.py` | 分步构建的标定 URDF → 相对名义 URDF 的单一参数文件（FK 校验）✎ | 服务器 / PC | 核心 |
| `server/tools/export_meas.py` | ChArUco 检测、多帧融合 → 测量文件（按 40 mm，之后用 scale_meas） | 服务器 | 核心 |
| `server/tools/gen_poses.py` | 按实测板位姿生成姿态表 | 服务器 | 核心 |
| `server/tools/inject_real_intrinsics_patch.py` | 生成注入真实内参的标定包副本 | 服务器 | 核心 |
| `server/tools/dircheck_analyze.py` | 方向检查分析 | 服务器 | 核心 |
| `server/tools/touch_identify_auto.py` | 触碰辨识与交叉验证 | 服务器 | 辅助 |
| `server/tools/regress_summary.py` | 标定资产与名义资产差异、校验失败项汇总 | 服务器 | 辅助 |
| `server/tools/limits_check.py` | 资产的关节限位与自碰撞设置 | 服务器 | 辅助 |
| `server/tools/overlay_projected.py` | 不用 IsaacSim 的头部叠图（网格 FK 投影） | 服务器 | 辅助 |
| `server/tools/montage_crops.py` | 渲染对比放大图拼图 | 服务器 | 辅助 |
| `server/tools/make_compare_video.py` | 名义 vs 标定 URDF 叠图视频 | 服务器 | 辅助 |
| `server/tools/render_isaaclab.py` | Isaac Lab 四路相机渲染、探针验证主点 | 服务器 | 辅助 |
| `server/tools/run_render_isaaclab.sh` | 上面脚本的运行包装 ✎ | 服务器 | 辅助 |
| `server/tools/overlay_isaaclab.py` | 真机｜仿真｜叠加三联图 | 服务器 | 辅助 |
| `server/tools/render_compare.py` | 多个 URDF 变体按会话关节角渲染 head_left | 服务器 | 辅助 |
| `server/tools/run_render_compare.sh` | 上面脚本的运行包装 ✎ | 服务器 | 辅助 |
| `server/tools/compare_overlay.py` | 真机头部帧 + 各变体手臂轮廓叠图 | 服务器 | 辅助 |
| `server/tools/plan_jog_signs.py` | 方向检查的微动方向 | 服务器 | 辅助 |
| `server/tools/find_dircheck_pose.py` | 搜索安全的方向检查姿态 | 服务器 | 辅助 |
| `server/tools/inspect_identify.py` | 打印辨识参数和标准差 | 服务器 | 辅助 |
| `server/tools/pose_clearance.py` | 姿态表 FK 离桌余量 | 服务器 | 辅助 |
| `server/tools/why_skip.py` | 姿态被标 skip 的原因 | 服务器 | 辅助 |
| `server/tools/zero_pose_height.py` | 全 0 位姿最低点离桌高度 | 服务器 | 辅助 |
| `server/tools/eval_layout.py` | 不同机器人距离下的位姿设计比较 | 服务器 | 辅助 |
| `server/tools/run_eval_layout.sh` | 上面脚本的运行包装 ✎ | 服务器 | 辅助 |
| `server/tools/dump_head_cam_T.py` | 头部左右目在躯干系的位姿（名义合同） | 服务器 | 辅助 |
| `server/tools/build_segments_left.py` | 板被推动时的分段文件模板 | 服务器 | 辅助 |
| `server/tools/check_overlay_fk.py` | 关节中心 FK 投影核对渲染叠图 | 服务器 | 诊断 |
| `server/tools/check_urdf_vs_params.py` | 标定 URDF 与"名义 + 参数"FK 是否一致 | 服务器 | 诊断 |
| `server/tools/project_mesh_masks.py` | 网格 FK 投影遮罩 vs IsaacSim 遮罩（IoU） | 服务器 | 诊断 |
| `server/tools/estimate_wrist_extrinsic.py` | 由样本反推腕相机安装 | 服务器 | 诊断 |
| `server/tools/repeat_diff.py` | 重复访问的图像变化能否由编码器解释 | 服务器 | 诊断 |
| `server/tools/server_check_assets.sh` | 名义 / 渲染资产哈希与网格引用 | 服务器 | 诊断 |
| `server/tools/body_overlay.py` | 点云渲染叠图（不用 IsaacSim） | 服务器 | 诊断 |
| `server/tools/make_urdf_variants.py` | 10-19 渲染对比的 URDF 变体 ✎ | 服务器 | 已弃用 |

## server/runs/（实际用过的服务器运行脚本，作为模板）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `server/runs/server_build_1023_sq382.sh` | 由 `params_final_sq382c` 构建资产 `assembled_calib_20261023_sq382`（构建模板；去掉了 BOM）✎ | 服务器 | 辅助 |
| `server/runs/server_dual_trans.sh` | 10-19 dual_trans 辨识（40 mm；现由 pipeline_sq.sh 带格长执行）✎ | 服务器 | 辅助 |
| `server/runs/gen_v2.sh` | 10-19 姿态表生成 ✎ | 服务器 | 辅助 |
| `server/runs/gen_1020.sh` | 10-20 布局姿态表 ✎ | 服务器 | 辅助 |
| `server/runs/gen_1021.sh` | 10-21 布局姿态表 ✎ | 服务器 | 辅助 |
| `server/runs/server_final_video.sh` | IsaacSim 验收渲染（留出 1209，名义 vs 轮廓）✎ | 服务器 | 辅助 |
| `server/runs/server_final_video_1021.sh` | 正式资产验收渲染（10-21 右臂）✎ | 服务器 | 辅助 |
| `server/runs/server_regress_1021.sh` | 文档 07 回归检查模板 ✎ | 服务器 | 辅助 |
| `server/runs/server_repeat_diff.sh` | 重复性数据分析 ✎ | 服务器 | 诊断 |
| `server/runs/server_joint_offsets.sh` | 名义 URDF + 关节读数偏移假设（逐图对齐）✎ | 服务器 | 诊断 |
| `server/runs/server_contour_urdf.sh` | 10-20 轮廓对齐 URDF + 叠图（40 mm 几何）✎ | 服务器 | 已弃用 |
| `server/runs/server_left_1019.sh` | 10-19 左臂导出 + 辨识 ✎ | 服务器 | 已弃用 |
| `server/runs/server_right_1019.sh` | 10-19 右臂导出 + 辨识 ✎ | 服务器 | 已弃用 |
| `server/runs/server_dual_1019.sh` | 10-19 双臂辨识（无关节平移）✎ | 服务器 | 已弃用 |

## server/g1d_calib_20261015/（标定包本体；`calib_model.py` 也部署到机器人）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `server/g1d_calib_20261015/calib_model.py` | 误差模型：URDF、带参数 FK、相机投影、残差；`G1D_CALIB_NOMINAL` | 服务器 / 机器人 / PC | 核心 |
| `server/g1d_calib_20261015/identify.py` | 辨识（预设参数集、鲁棒损失、先验、k 折留出） | 服务器 | 核心 |
| `server/g1d_calib_20261015/apply_calibration.py` | 参数 → 标定 URDF（只改关节 origin；`--nominal` 叠加在任意 URDF 上） | 服务器 / PC | 核心 |
| `server/g1d_calib_20261015/build_assembly.py` | 标定 URDF → USD / 物理合同 / 相机合同 / 校验 ✎ | 服务器 | 核心 |
| `server/g1d_calib_20261015/pose_design.py` | D 最优位姿设计 | 服务器 | 核心 |
| `server/g1d_calib_20261015/board_setups.py` | 名义场景、可行位姿采样 | 服务器 | 核心 |
| `server/g1d_calib_20261015/nominal/g1_d_upper_dex1_v4.urdf` | 名义上身 URDF（不含 meshes） | — | 核心 |
| `server/g1d_calib_20261015/nominal/g1_d_full_dex1_v4.urdf` | 名义全身 URDF（不含 meshes） | — | 核心 |
| `server/g1d_calib_20261015/nominal/camera_contract_v5.json` | 四路相机父 link 与名义外参（右眼为名义安装） | — | 核心 |
| `server/g1d_calib_20261015/nominal/physics_contract.json` | 名义物理设置 | — | 辅助 |
| `server/g1d_calib_20261015/compare_sim_real.py` | sim-vs-real 角点残差 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/test_apply_calibration.py` | 单元测试（6 项） | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tcp_effect.py` | 参数集对 TCP / 腕相机位姿的影响 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/export_replay.py` | 仿真 trace → 回放轨迹 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/synthetic_validation.py` | 合成数据验证 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/synthetic_validation_table.md` | 合成验证结果表 | — | 辅助 |
| `server/g1d_calib_20261015/README_zh.md` | 包说明 ✎ | — | 辅助 |
| `server/g1d_calib_20261015/PACKAGE_README_zh.md` | 打包说明（说明未附带网格）✎ | — | 辅助 |
| `server/g1d_calib_20261015/docs/00_overview_zh.md` | 方法文档：总览 | — | 辅助 |
| `server/g1d_calib_20261015/docs/01_camera_intrinsics_zh.md` | 方法文档：相机内参 | — | 辅助 |
| `server/g1d_calib_20261015/docs/02_data_collection_zh.md` | 方法文档：数据采集 | — | 辅助 |
| `server/g1d_calib_20261015/docs/03_board_detection_export_zh.md` | 方法文档：板检测与导出 ✎ | — | 辅助 |
| `server/g1d_calib_20261015/docs/04_sim_real_comparison_zh.md` | 方法文档：sim-vs-real 对比 | — | 辅助 |
| `server/g1d_calib_20261015/docs/05_dynamic_identification_zh.md` | 方法文档：动态辨识 | — | 辅助 |
| `server/g1d_calib_20261015/docs/06_replay_validation_zh.md` | 方法文档：回放验证 | — | 辅助 |
| `server/g1d_calib_20261015/docs/07_apply_parameters_zh.md` | 方法文档：写回参数与回归检查 ✎ | — | 辅助 |
| `server/g1d_calib_20261015/docs/error_model_zh.md` | 方法文档：误差模型 | — | 辅助 |
| `server/g1d_calib_20261015/tools/build_camera_contract_calib.py` | build_assembly 子步骤：相机合同 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/compare_usd_calib.py` | build_assembly 子步骤：USD 比较 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/convert_prepare_finalize_calib.py` | build_assembly 子步骤：资产转换 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/make_patched_copies.py` | build_assembly 子步骤：打补丁副本 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/patched_copies.json` | build_assembly 子步骤配置 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/validate_sources_calib.py` | build_assembly 子步骤：来源校验 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/tools/validate_usd_fk.py` | build_assembly 子步骤：USD-FK 校验 | 服务器 | 辅助 |
| `server/g1d_calib_20261015/examples/measurements_tiny_example.json` | 合成测量文件样例 | — | 辅助 |
| `server/g1d_calib_20261015/examples/measurements_example_A_stereo_left.json` | 合成测量文件样例（设置 A） | — | 辅助 |
| `server/g1d_calib_20261015/examples/measurements_example_B_wrist_left.json` | 合成测量文件样例（设置 B） | — | 辅助 |
| `server/g1d_calib_20261015/examples/replay_r2s_E009_right_a1.json` | 仿真验证过的倒水轨迹 | — | 辅助 |
| `server/g1d_calib_20261015/examples/replay_r2s_E036_left_a1.json` | 仿真验证过的倒水轨迹 | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/params_B_left.json` | 辨识演示：参数 | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/result_B_left.json` | 辨识演示：结果 | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/compare_sim_real_B_left.json` | 辨识演示：对比 | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/quick_roll_nominal_B_left.json` | 辨识演示：单参数估计 | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/urdf/g1_d_upper_dex1_v4.urdf` | 辨识演示：写回的上身 URDF | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/urdf/g1_d_full_dex1_v4.urdf` | 辨识演示：写回的全身 URDF | — | 辅助 |
| `server/g1d_calib_20261015/examples/identify_demo/urdf/calibration_provenance.json` | 辨识演示：写回溯源 | — | 辅助 |
| `server/g1d_calib_20261015/params_test_left_shoulder_roll_2p6.json` | 占位参数（只用于打通流程） | — | 已弃用 |

## robodojo_merge/（新方法；服务器脚本放到 `$W` / `$D` / `/dev/shm/isaac_work`，见使用手册 §0.3）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `robodojo_merge/scale_meas.py` | 测量文件改写为实测格长（`<in> <out> <square_mm>`） | 服务器 | 核心 |
| `robodojo_merge/pipeline_sq.sh` | 给定格长的完整重建：缩放 → identify → URDF → 轮廓二次拟合 → compose（`SQ=38.2`）✎ | 服务器 | 核心 |
| `robodojo_merge/make_camera_setup.py` | 我们的相机配置 `camera_setup_ours.json`（右眼 = 左眼 + 双目 R、T × 格长/40；`CALIB_PARAMS`、`BOARD_SQUARE_MM`）✎ | PC | 核心 |
| `robodojo_merge/refine_wrist_mount.py` | 腕相机 vs 头部定位的板：留一会话检验 / 修正（`BOARD_SQUARE_MM`、`CALIB_PKG`、`ARM_OFFSET`）；联合拟合的数据加载器 | 服务器 | 核心 |
| `robodojo_merge/joint_fit.py` | 联合拟合：头部轮廓 + 头部定位的腕部看板（4 种模型） | 服务器 | 核心 |
| `robodojo_merge/run_joint_fit.sh` | 联合拟合运行脚本（两臂、训练/留出会话）✎ | 服务器 | 核心 |
| `robodojo_merge/build_sq382j.sh` | 联合拟合结果 → 增量参数 → URDF → compose → 轮廓检查 → 构建资产 ✎ | 服务器 | 核心 |
| `robodojo_merge/contour_left_eye.py` | 只用左眼的头部轮廓评分 | 服务器 | 核心 |
| `robodojo_merge/smoke_calib.py` | 用同事的机器人配置加载标定资产：物理稳定、FK 一致、渲染（`SMOKE_DIR`） | 服务器 2 | 核心 |
| `robodojo_merge/run_smoke.sh` | 冒烟测试运行脚本 | 服务器 2 | 核心 |
| `robodojo_merge/run_dual_trans_scan.sh` | 多个格长并行跑 dual_trans 辨识 ✎ | 服务器 | 辅助 |
| `robodojo_merge/summarize_scan.py` | 格长扫描汇总（残差、留出、内参修正、安装平移） | 服务器 | 辅助 |
| `robodojo_merge/diff_scan_params.py` | 两个格长之间哪些参数变化 | 服务器 | 辅助 |
| `robodojo_merge/board_plane_1023.py` | 由头部看板会话求桌面平面（叠杯用） | 服务器 | 辅助 |
| `robodojo_merge/run_refine_1023.sh` | 腕部–头部检验模板（10-23 新数据）✎ | 服务器 | 辅助 |
| `robodojo_merge/render_check_ours.py` | 标定 RoboDojo G1-D 渲染四路相机、核对连杆位姿 | 服务器 | 辅助 |
| `robodojo_merge/run_render_check.sh` | 上面脚本的运行包装 ✎ | 服务器 | 辅助 |
| `robodojo_merge/render_confirm.py` | 确认片段渲染（真实外观材质） | 服务器 | 辅助 |
| `robodojo_merge/run_render_confirm.sh` | 上面脚本的运行包装 ✎ | 服务器 | 辅助 |
| `robodojo_merge/make_confirm_traj.py` | 确认片段的实测关节轨迹 | PC / 服务器 | 辅助 |
| `robodojo_merge/make_confirm_video.py` | 真机 vs 仿真确认视频 ✎ | PC | 辅助 |
| `robodojo_merge/confirm_metrics.py` | 确认片段头部轮廓指标 | 服务器 | 辅助 |
| `robodojo_merge/compare_render_real.py` | 真机｜渲染｜叠边三联图 ✎ | PC | 辅助 |
| `robodojo_merge/refine_arm_chain.py` | 手臂链假设检验：关节零位 / 连杆原点 / 重力柔性（均否决） | 服务器 | 诊断 |
| `robodojo_merge/refine_board_scale.py` | 板尺寸假设检验 | 服务器 | 诊断 |
| `robodojo_merge/board_los.py` | 整臂偏移分解为头部视线方向与垂直分量 | 服务器 | 诊断 |
| `robodojo_merge/head_contour_armoff.py` | 整臂刚体偏移与头部视角是否相容（否决） | 服务器 | 诊断 |
| `robodojo_merge/summarize_armoff.py` | 腕相机安装修正 vs 整臂偏移的留一比较 | 服务器 | 诊断 |
| `robodojo_merge/inspect_meas.py` | 打印测量文件 / 辨识结果结构 | 服务器 | 诊断 |
| `robodojo_merge/wrist_camera_geometry.py` | 腕相机在 dex1_base_link 中的位置（官方 vs RoboDojo 模块）✎ | PC | 诊断 |
| `robodojo_merge/run_arm_offset.sh` | 整臂偏移假设运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/run_arm_chain.sh` | 手臂链假设运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/run_arm_chain2.sh` | 连杆原点假设运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/run_arm_chain3.sh` | 重力柔性假设运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/show_chain2.sh` | 查看 chain2 进度 | 服务器 | 诊断 |
| `robodojo_merge/run_board_los.sh` | board_los 运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/run_board_scale.sh` | 板尺寸假设运行脚本 ✎ | 服务器 | 诊断 |
| `robodojo_merge/rebuild_sq385.sh` | 38.5 mm 版参数重建（格长量错）✎ | 服务器 | 已弃用 |
| `robodojo_merge/contour_sq385.sh` | 38.5 mm 版轮廓对齐（从零开始，右臂停在较差极小）✎ | 服务器 | 已弃用 |
| `robodojo_merge/contour_sq385c.sh` | 38.5 mm 版轮廓二次拟合 ✎ | 服务器 | 已弃用 |
| `robodojo_merge/run_square385.sh` | 38.5 mm 腕部检验 ✎ | 服务器 | 已弃用 |
| `robodojo_merge/run_pkg385.sh` | 38.5 mm 包腕部检验（作 §10.1 模板时改 `BOARD_SQUARE_MM`/`CALIB_PKG`）✎ | 服务器 | 已弃用 |
| `robodojo_merge/run_refine_wrist.sh` | 10-22 第一版腕相机安装修正（40 mm）✎ | 服务器 | 已弃用 |
| `robodojo_merge/run_refine_left2.sh` | 10-22 左臂加新会话 ✎ | 服务器 | 已弃用 |
| `robodojo_merge/run_refine_both_v2.sh` | 10-22 右眼修正后复查 ✎ | 服务器 | 已弃用 |

## replay_cups/（应用示例：双臂叠杯）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `replay_cups/plan2.py` | 叠杯任务几何与规划（`findm` / `plan [--seq]`） | PC / 服务器 | 核心 |
| `replay_cups/geom.py` | 共享运动学（标定 URDF，`REPLAY_URDF`） | PC / 服务器 | 核心 |
| `replay_cups/reach_diag.py` | 捏沿口抓取 / 放置的可达性 | PC / 服务器 | 核心 |
| `replay_cups/fit_cups.py` | 头部双目定位两只纸杯（`--board-c --board-n --stereo-scale --seed-uv`） | PC | 核心 |
| `replay_cups/measure_table_plane.py` | 头部看桌上的板求桌面平面（格长 38.2 mm） | PC | 核心 |
| `replay_cups/choose_m.py` | 从 `m_search.json` 选汇合点 | PC | 核心 |
| `replay_cups/stereo_extrinsics.py` | 头部双目 R、T（固定内参，5 折标准差）→ `out/head_stereo_extrinsics.json` | PC | 核心 |
| `replay_cups/out/head_stereo_extrinsics.json` | 双目 R、T（按 40 mm 板，T 需乘格长/40；`make_camera_setup.py` 读取） | — | 核心 |
| `replay_cups/table_plane_from_outline.py` | 由已知 1.2 × 0.6 m 桌面轮廓求桌面平面 | PC | 辅助 |
| `replay_cups/check_grasp_reach.py` | 抓取姿态可达性 | PC | 辅助 |
| `replay_cups/check_cup_spots.py` | 其他杯位的可达性 | PC | 辅助 |
| `replay_cups/draw_cup_targets.py` | 头部图上画当前杯位和目标杯位（打包时去掉了 UTF-8 BOM）✎ | PC | 辅助 |
| `replay_cups/arms_aside.py` | 双肩外展让出头部视野 / `back` 回 0 | PC | 辅助 |
| `replay_cups/make_sim_traj.py` | 真机实测关节 + 指令夹爪 → 仿真驱动轨迹 | PC | 辅助 |
| `replay_cups/make_plan_sim_traj.py` | 计划轨迹按真机时间对齐 → 仿真驱动轨迹 | PC | 辅助 |
| `replay_cups/make_cups_traj.py` | 实测关节轨迹 + 抓放事件 | PC | 辅助 |
| `replay_cups/make_cups_cmp_video.py` | 真机 vs 仿真三路对比视频 ✎ | PC | 辅助 |
| `replay_cups/frames_to_videos.py` | 记录器帧 → 每路一个视频 | PC | 辅助 |
| `replay_cups/server/plan_sim_ik.py` | 用 Isaac Lab DifferentialIKController 求解 plan2 的所有 IK（`--seq`） | 服务器 | 核心 |
| `replay_cups/server/run_plan_ik.sh` | 仿真 IK 规划运行脚本（sq382j 资产）✎ | 服务器 | 核心 |
| `replay_cups/server/sim_cups.py` | 叠杯物理仿真检查 | 服务器 | 核心 |
| `replay_cups/server/run_sim_1023.sh` | 物理仿真 + 视频运行脚本 ✎ | 服务器 | 核心 |
| `replay_cups/server/sim_cups_views.py` | 物理仿真 + 每帧渲染我们的三路相机 | 服务器 | 辅助 |
| `replay_cups/server/run_sim_views_1023.sh` | 真机轨迹驱动的三路渲染 ✎ | 服务器 | 辅助 |
| `replay_cups/server/run_sim_planviews_1023.sh` | 计划轨迹驱动的三路渲染（去掉了 BOM）✎ | 服务器 | 辅助 |
| `replay_cups/robot/real_run_v2.sh` | 真机回放编排：start / go / status / abort（三路记录） | 机器人 | 核心 |
| `replay_cups/robot/takeover_after_replay_v2.py` | 终态时启动我们的服务，server ready 后立即 kill -9 replay.py | 机器人 | 核心 |
| `replay_cups/robot/stop_server_for_replay.sh` | 确认 replay 在发布后 kill -9 我们的服务（交给 replay） | 机器人 | 核心 |
| `replay_cups/robot/run_cups_replay.sh` | 原样运行同事的 replay.py | 机器人 | 核心 |
| `replay_cups/robot/ready_pose_arm_q.json` | replay 的 ready 位姿（接管时 `--init-pose`） | 机器人 | 核心 |
| `replay_cups/robot/real_run.sh` | v1 编排（只录头部） | 机器人 | 已弃用 |
| `replay_cups/robot/takeover_after_replay.py` | v1 接管（两个写入者重叠约 20 s，末段抖动） | 机器人 | 已弃用 |
| `replay_cups/robot/passive_logger.py` | v1 记录器（只录头部；被 `robot/passive_logger_cams.py` 取代） | 机器人 | 已弃用 |

## examples/（这台机器人的小数据；详见 `examples/README_zh.md`）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `examples/robodojo_merge_sq382j/params_final_sq382j.json` | **正式标定参数**（相对名义 URDF，106 项） | — | 核心 |
| `examples/robodojo_merge_sq382j/camera_setup_ours.json` | **正式相机配置**（四路相机父 link、安装、K/畸变） | — | 核心 |
| `examples/robodojo_merge_sq382j/README.md` | sq382j RoboDojo 包说明（英文，含检验表） | — | 核心 |
| `examples/robodojo_merge_sq382j/params_joint_delta_sq382.json` | 联合拟合增量（叠加在 urdf_contour_sq382c 上） | — | 辅助 |
| `examples/robodojo_merge_sq382j/joint_left.json` | 左臂联合拟合结果（4 种模型） | — | 辅助 |
| `examples/robodojo_merge_sq382j/joint_right.json` | 右臂联合拟合结果（4 种模型） | — | 辅助 |
| `examples/params_20261023/params_dual_trans_sq382.json` | 38.2 mm 的 dual_trans 参数（compose 的相机/内参来源） | — | 核心 |
| `examples/params_20261023/params_contour_mount_1020.json` | 10-20 肩部安装增量（pipeline_sq.sh 的第一遍输入） | — | 辅助 |
| `examples/params_20261023/params_final_sq382c.json` | 38.2 mm + 只用轮廓定肩部安装（联合拟合的基础几何） | — | 已弃用 |
| `examples/params_20261023/params_final_1021.json` | 10-21 正式参数（40 mm） | — | 已弃用 |
| `examples/intrinsics/camera_intrinsics_head_left.json` | 头部左目内参（正式，10-16） | — | 核心 |
| `examples/intrinsics/camera_intrinsics_head_right.json` | 头部右目内参（正式，10-16） | — | 核心 |
| `examples/intrinsics/camera_intrinsics_left_wrist.json` | 左腕内参（`zmq_port` 字段为 10-16 映射） | — | 核心 |
| `examples/intrinsics/camera_intrinsics_right_wrist.json` | 右腕内参（`zmq_port` 字段为 10-16 映射） | — | 核心 |
| `examples/joint_mapping.json` | 关节映射（sign 全 +1）；相机端口为 10-16 映射 | — | 辅助 |
| `examples/head_cam_T.json` | 头部左右目在躯干系的位姿（名义合同） | — | 辅助 |
| `examples/dircheck_plan.json` | 方向检查计划 | — | 辅助 |
| `examples/board_check_20261022/board_pose.json` | 头部双目测得的板位姿（10-22） | — | 辅助 |
| `examples/board_check_20261022/board_view_plan.json` | 双臂看板计划 | — | 辅助 |
| `examples/board_check_20261022/left_session_plan.json` | 左臂看板计划 | — | 辅助 |
| `examples/board_check_20261022/captures.json` | 看板会话记录格式样例 | — | 辅助 |
| `examples/board_check_20261022/refine_left_1023.json` | 左腕留一检验结果样例 | — | 辅助 |
| `examples/board_check_20261022/refine_right_1023.json` | 右腕留一检验结果样例 | — | 辅助 |
| `examples/replay_cups_20261023/cups.json` | 10-23 杯子定位结果 | — | 辅助 |
| `examples/replay_cups_20261023/m_search.json` | 汇合点搜索结果 | — | 辅助 |
| `examples/replay_cups_20261023/plan2_1023s.json` | 10-23 真机执行的计划（`--seq`） | — | 辅助 |
| `examples/poses_20261019/poses_left.json` | 10-19 左臂姿态表 | — | 辅助 |
| `examples/poses_20261019/poses_right.json` | 10-19 右臂姿态表 | — | 辅助 |
| `examples/poses_20261019/scene_header_B.json` | 场景表头（导出用） | — | 辅助 |
| `examples/poses_20261019/board_pose_measured.json` | 10-19 板位姿 | — | 辅助 |
| `examples/poses_20261019/summary.json` | 姿态表统计 | — | 辅助 |
| `examples/touch_auto_left_20261019_1757/touches.jsonl` | 触碰记录样例 | — | 辅助 |
| `examples/touch_auto_left_20261019_1757/log.txt` | 触碰日志样例 | — | 辅助 |
| `examples/params_1019/params_left_1019.json` | 10-19 左臂辨识参数 | — | 已弃用 |
| `examples/params_1019/params_dual_1019.json` | 10-19 双臂辨识参数 | — | 已弃用 |
| `examples/params_1019/params_dual_trans_1019.json` | 10-19 dual_trans 参数（40 mm） | — | 已弃用 |

## extras/（详见 `extras/README_zh.md`）

| 文件 | 用途 | 运行位置 | 状态 |
|---|---|---|---|
| `extras/abandoned/server_heads_1020.sh` | 头部看板观测 + 两肩安装联合辨识（叠图差 20–30 px）✎ | 服务器 | 已弃用 |
| `extras/abandoned/server_overlay_1020.sh` | heads_1020 的 URDF 与叠图 ✎ | 服务器 | 已弃用 |
| `extras/abandoned/stereo_arm_mask.py` | 双目深度分割手臂（纹理不足） | 服务器 | 已弃用 |
| `extras/abandoned/make_gripper_board.py` | 夹爪小板（设置 A，被否决） | PC | 已弃用 |
| `extras/abandoned/af_lock_server.py` | 替代 teleimager 锁对焦（用户拒绝） | 机器人 | 已弃用 |
| `extras/abandoned/touch_teach.py` | 手动示教触碰 | 机器人 | 已弃用 |
| `extras/abandoned/touch_identify.py` | 手动示教数据辨识 | 服务器 | 已弃用 |
| `extras/abandoned/touch_targets_image.py` | 示教目标点图 | PC | 已弃用 |
| `extras/abandoned/af_correct.py` | 逐样本焦距补偿（误差变大） | 服务器 | 已弃用 |
| `extras/abandoned/per_sample_focal.py` | 逐样本焦距估计 | 服务器 | 已弃用 |
| `extras/abandoned/server_left_afc.sh` | 焦距补偿运行脚本 ✎ | 服务器 | 已弃用 |
| `extras/abandoned/render_sim.py` | IsaacSim 5.0 第一版渲染（未出图） | 服务器 | 已弃用 |
| `extras/abandoned/setup_isaac_env.sh` | IsaacSim 5.0 pip 安装 | 服务器 | 已弃用 |
| `extras/abandoned/analyze_misalign.py` | 自动边缘匹配判断错位（不可靠） | 服务器 | 已弃用 |
| `extras/superseded/server_build_1021.sh` | 10-21 正式资产构建（40 mm）✎ | 服务器 | 已弃用 |
| `extras/superseded/server_build_1023_sq385.sh` | 38.5 mm 资产构建 ✎ | 服务器 | 已弃用 |
| `extras/superseded/compare_assets_1023.py` | 10-21 vs sq385 资产比较 | 服务器 | 已弃用 |
| `extras/legacy/collect.py` | PC 驱动的采集（被 robot/collect_robot.py 取代） | PC | 已弃用 |
| `extras/legacy/go_home.py` | 旧版回 home | PC | 已弃用 |
| `extras/legacy/raise_to_zero.py` | 旧版抬到 0（被 raise_to_zero2.py 取代） | PC | 已弃用 |
| `extras/legacy/takeover.sh` | 无存活确认的交接（勿用） | 机器人 | 已弃用 |
| `extras/legacy/add_home_ok.py` | 给旧姿态表补字段 | 服务器 | 已弃用 |
| `extras/legacy/swap_wrist_intrinsics.py` | 10-16 一次性交换腕部内参文件名 | PC | 已弃用 |
| `extras/diagnostics/head_scale_check.py` | 双目三角测量尺度检查（无结论） | PC | 诊断 |
| `extras/diagnostics/contour_timing.py` | contour_fit 单视角耗时与网格大小 | 服务器 | 诊断 |
| `extras/diagnostics/diag_cameras.py` | 三路相机流只读诊断（注释为 10-21 前映射） | 机器人 | 诊断 |
| `extras/diagnostics/diag_cameras.sh` | 视频设备与相机序列号只读诊断 | 机器人 | 诊断 |
| `extras/diagnostics/inspect_teleimager.sh` | 只读查看 teleimager 启动方式 | 机器人 | 诊断 |
| `extras/diagnostics/inspect_teleimager2.sh` | 同上（`sudo -n true` 只检查不提权）✎ | 机器人 | 诊断 |
| `extras/diagnostics/grep_teleimager.sh` | 只读搜索 teleimager 配置 | 机器人 | 诊断 |
| `extras/diagnostics/list_cams.sh` | 列出视频设备 | 机器人 | 诊断 |
| `extras/diagnostics/usb_perm.sh` | USB 相机权限 | 机器人 | 诊断 |
| `extras/diagnostics/read_arm_q.py` | 读一次手臂关节角 | 机器人 | 诊断 |
| `extras/diagnostics/residual_vs_torque.py` | 残差与力矩相关性 | 服务器 | 诊断 |
| `extras/diagnostics/check_charuco_legacy.py` | 判断板的 legacy 设置 ✎ | PC | 诊断 |
| `extras/diagnostics/detect_charuco_dict.py` | 判断板的字典 ✎ | PC | 诊断 |
| `extras/diagnostics/compare_motors.py` | 35 个电机位置与会话开始对比 | PC | 诊断 |
| `extras/diagnostics/show_board.py` | 屏幕全屏显示 ChArUco | PC | 诊断 |
| `extras/diagnostics/test_detect_once.py` | 单次检测测试 | PC | 诊断 |

---

## 有意排除的内容

| 内容 | 原因 |
|---|---|
| 本机 SSH 密钥和 SSH 配置（GPU 服务器、机器人） | 安全原因；打包时未读取、未复制，文档不引用其内容 |
| 公网服务器地址、个人路径 | 替换为 `<GPU_SERVER>`、`<GPU_SERVER_2>`、`$ISAAC_ENV`、`G1D_WORKSPACE` 等 |
| 同事的仓库 `g1d_infra`、RoboDojo 代码与资产（含网格） | 不是我们的代码；只读复制使用 |
| 第三方 SDK 目录 `pc_tools/3rd/unitree_sdk2_python/` | 从 Unitree 官方获取 |
| `server/g1d_calib_20261015/nominal/meshes/`、各版仿真资产（USD）、标定 URDF | 体积大；URDF 可由参数重建（`apply_calibration.py`） |
| 图像、会话、视频、渲染（`pc_tools/sessions/`、`frames_test/`、`render_cmp_*`、`replay_cups/real_run_*`、`real_vs_sim_*`、`IsaacSim对比图/` 等） | 大数据，且与这台机器人绑定 |
| `pc_tools/robodojo_merge_sq382*/`、`_sq385/` 里的 URDF 与 yml | 由参数和脚本可重建；正式包只附参数、相机配置和说明 |
| `robodojo_merge/` 的 `check/`、`confirm_video/`、`confirm_traj.json`（约 600 KB）、`board_check_20261022/` 的其余 JSON | 中间结果；格式样例已在 `examples/board_check_20261022/` |
| `replay_cups/` 里 10-21 版和调试用脚本（`plan_cups.py`、`compare_run.py`、`reach_*.py`、`debug_*.py`、`sim_v*`、`calib_vs_nominal_20261021/` 等）和 `model/`、`out/` 的其余文件 | 被 `plan2.py` + `plan_sim_ik.py` 流程取代，或是一次性分析 |
| 工作区根目录的 `compose_params.py`（与服务器版代码相同） | 由 `server/tools/compose_params.py`（交付说明给出的服务器版，路径改为环境变量）代替 |
| `make_colored_urdf.py`、`check_colored_urdf.py` | 打包当天（10-26）还在开发中的上色 URDF 工具，未完成 |
| 10-15 DDS 排查（`robot_*.py/sh`）、服务器环境探测（`probe_*`、`check_*.sh` 等）、IsaacSim 5.0 调试、一次性出图脚本、被 10-19 版取代的运行脚本 | 同 10-19 版排除清单 |
| 原包 `MANIFEST_sha256.txt`、`synthetic_validation.json`、占位姿态表 | 同 10-19 版 |
| `.venv/`、`.git/`、`__pycache__/` | 本机环境 / 版本库 / 缓存 |
