# G1-D 标定版机器人 URDF（上色版，2026-10-26）

我们标定过的 G1-D 机器人：同事的 RoboDojo G1-D 模型（官方 G1-D URDF + 团队的 Dex1-1 夹爪与腕部相机模块、升降柱、腰部、底盘）＋ 我们的标定 `params_final_sq382j`（2026-10-23 正式版：标定板实测格长 38.2 mm，dual_trans 手臂内部几何 + 头部轮廓对齐 + 联合拟合）。按真机照片上色，并把四个标定后的相机作为固定连杆写进 URDF，可以直接用于仿真和可视化。

## 文件

| 文件 | 内容 |
|---|---|
| `g1d_calibrated_colored.urdf` | 桌面版：根连杆 `AGV_link`，轮子锁定 |
| `g1d_mobile_calibrated_colored.urdf` | 移动版：再加虚拟平面关节 `base_x / base_y / base_yaw`（根连杆 `base_world`） |
| `meshes/` | 全部网格（STL）。`*_elbow_link_body.STL` / `*_elbow_link_band.STL` 是把肘部连杆拆成铝色主体和前臂黑环 |
| `camera_setup_ours.json` | 四个相机的内参 K、畸变、分辨率、安装位姿（与 URDF 里的相机连杆一致） |
| `params_final_sq382j.json` | 标定参数（相对名义 v4 URDF 的 106 项） |
| `preview_*.png` | 软件渲染预览（全零关节角） |
| `make_colored_urdf.py` / `check_colored_urdf.py` | 生成脚本 / 校验与预览脚本 |

## 颜色（来自真机照片）

| 部件 | 材质名 | RGBA |
|---|---|---|
| 头壳 | `g1d_black_gloss` | 0.05 0.05 0.06 |
| 胸前标志 | `g1d_dark_logo` | 0.12 0.12 0.13 |
| 躯干、腰部外壳 | `g1d_shell_white` | 0.86 0.87 0.88 |
| 肩、上臂、肘、前臂、腕 | `g1d_aluminium` | 0.71 0.73 0.76 |
| 前臂黑环、Dex1 夹爪本体与腕部相机外壳、手指 | `g1d_black_matte` | 0.07 0.07 0.08 |
| 指尖垫 | `g1d_pad_grey` | 0.20 0.20 0.21 |
| 升降柱 | `g1d_column` | 0.76 0.78 0.81 |
| 底盘上盖 | `g1d_chassis` | 0.80 0.81 0.83 |
| 轮子 | `g1d_wheel` | 0.04 0.04 0.04 |

STL 不能逐面上色，颜色不同的区域拆成单独的网格。真机背后的计算单元盒、面部灯环、面罩不在官方网格里，未建模。

## 相机连杆

| 连杆 | 父连杆 | 约定 |
|---|---|---|
| `head_left_camera` / `head_right_camera` | `head_link` | +x 前、+y 左、+z 上（Isaac 相机 "world" 约定） |
| `left_wrist_camera` / `right_wrist_camera` | `left_dex1_base_link` / `right_dex1_base_link` | 同上 |
| `<相机>_camera_optical` | `<相机>_camera` | OpenCV 光学系：z 前、x 右、y 下 |

内参在 `camera_setup_ours.json`，也写在相机连杆的注释里。右眼安装 = 左眼安装 + 双目标定 R、T（T 按实测格长 38.2/40 缩放，间距 58.6 mm）。腕部焦距对应 0.2–0.4 m 的自动对焦状态。Isaac 针孔相机不能模拟畸变：用 K 的主点设置光圈偏移，与去畸变后的真机图像对比。

## 校验结果（`check_colored_urdf.py`）

- 原有关节（类型、原点、轴、限位、父子关系）全部与标定源文件一致；所有连杆的惯量和碰撞体一致。新增的只有视觉材质、肘部拆分网格和 8 个相机固定关节（4 个相机 × 普通/光学）。
- 网格无缺失，所有视觉元素都有颜色。
- 相机连杆位姿与 `camera_setup_ours.json` 一致（误差 4e-9 m）。
- 运动学来源：与 5090-2 上同事流程的冒烟测试一致（`sq382j` 包：25 个关节，仿真与标定 FK 差 0.000 mm）。

## 使用

- **Isaac Lab / Isaac Sim**：`UrdfConverter`（`fix_base=True`，`merge_fixed_joints=False` 以保留相机连杆）。开自碰撞时需要 RoboDojo 资产里的 `physics_contract.json`（自碰撞过滤对，5090 上 `robodojo_g1d_calib_sq382j_20261023/` 里有一份），本包未附带。URDF 的材质颜色会导入为显示颜色；需要金属质感可以按材质名绑定 PreviewSurface。
- **RViz / ROS**：直接用 `robot_description` 加载，网格路径是相对 URDF 的 `meshes/...`；若需要 `package://`，按你的包名替换。
- **关节约定**：URDF 关节值 = 编码器读数（标定零位已写入关节原点），真机关节角可以直接回放。腰、升降柱、底盘未标定（标定时腰 = 0、升降柱固定）。

## 精度与局限

- 手臂相对头部：头部画面中手臂轮廓误差约 1.5–2.9 px（中位数）。
- 腕部相机相对头部测得的板子：3–8 px rms（0.3–0.4 m 处约 4–9 mm），主要受腕部自动对焦、关节回差、软纸板平整度和头部测深误差限制。
- 2026-10-23 用这套标定和仿真 IK 规划的双臂叠杯，真机回放成功。
