# check_colored_urdf.py -- checks of the coloured URDF package against the calibrated source and preview renders:
#   1. every joint (type, origin, axis, limits, parent/child) and every link's inertial / collision identical to the source
#   2. every mesh file exists; every visual has a material colour
#   3. camera links: FK pose == parent FK @ T_parent_camera_world_convention of camera_setup_ours.json
#   4. software preview renders (flat Lambert shading, painter's algorithm) at the all-zero pose, front / side / back
# usage: check_colored_urdf.py <source package dir> <coloured package dir>
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

SRC, PKG = Path(sys.argv[1]), Path(sys.argv[2])


def canon(el):
    return ET.tostring(el, encoding="unicode").replace(" ", "").replace("\n", "")


def T_of(o):
    T = np.eye(4)
    if o is not None:
        T[:3, :3] = Rotation.from_euler("xyz", [float(v) for v in o.get("rpy", "0 0 0").split()]).as_matrix()
        T[:3, 3] = [float(v) for v in o.get("xyz", "0 0 0").split()]
    return T


def fk_all(root_el, q=None):
    q = q or {}
    joints = root_el.findall("joint")
    children = {j.find("child").get("link") for j in joints}
    root = next(l.get("name") for l in root_el.findall("link") if l.get("name") not in children)
    by_parent = {}
    for j in joints:
        by_parent.setdefault(j.find("parent").get("link"), []).append(j)
    out, stack = {root: np.eye(4)}, [root]
    while stack:
        p = stack.pop()
        for j in by_parent.get(p, []):
            M = out[p] @ T_of(j.find("origin"))
            v = q.get(j.get("name"), 0.0)
            ax = j.find("axis")
            a = np.array([float(x) for x in (ax.get("xyz") if ax is not None else "1 0 0").split()])
            if j.get("type") in ("revolute", "continuous") and v:
                R = np.eye(4); R[:3, :3] = Rotation.from_rotvec(a * v).as_matrix(); M = M @ R
            elif j.get("type") == "prismatic" and v:
                D = np.eye(4); D[:3, 3] = a * v; M = M @ D
            c = j.find("child").get("link")
            out[c] = M
            stack.append(c)
    return out


def read_stl(p):
    b = Path(p).read_bytes()
    n = int(np.frombuffer(b, np.uint32, 1, 80)[0])
    return np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84)["v"].astype(float)


cams = json.loads((PKG / "camera_setup_ours.json").read_text(encoding="utf-8"))["views"]
for src_name, name in (("g1d_dex1_calib.urdf", "g1d_calibrated_colored.urdf"),
                       ("g1d_mobile_dex1_calib.urdf", "g1d_mobile_calibrated_colored.urdf")):
    s, c = ET.parse(SRC / src_name).getroot(), ET.parse(PKG / name).getroot()
    sj = {j.get("name"): canon(j) for j in s.findall("joint")}
    cj = {j.get("name"): canon(j) for j in c.findall("joint")}
    bad_j = [n for n in sj if sj[n] != cj.get(n)]
    sl = {l.get("name"): l for l in s.findall("link")}
    bad_l = []
    for l in c.findall("link"):
        if l.get("name") in sl:
            o = sl[l.get("name")]
            for tag in ("inertial", "collision"):
                if [canon(e) for e in o.findall(tag)] != [canon(e) for e in l.findall(tag)]:
                    bad_l.append(f"{l.get('name')}/{tag}")
    missing, uncoloured = [], []
    for l in c.findall("link"):
        for v in l.findall("visual") + l.findall("collision"):
            m = v.find("geometry/mesh")
            if m is not None and not (PKG / m.get("filename")).exists():
                missing.append(m.get("filename"))
        for v in l.findall("visual"):
            if v.find("material/color") is None:
                uncoloured.append(l.get("name"))
    F = fk_all(c)
    cam_err = max(np.abs(F[f"{v}_camera"] - F[cc["parent"]] @ np.array(cc["T_parent_camera_world_convention"])).max()
                  for v, cc in cams.items())
    print(f"{name}: joints {len(cj)} (source {len(sj)}), changed source joints {bad_j}, changed inertial/collision {bad_l}, "
          f"missing meshes {sorted(set(missing))}, uncoloured visuals {uncoloured}, camera frame max error {cam_err:.1e}")

# ---- previews ----
root_el = ET.parse(PKG / "g1d_calibrated_colored.urdf").getroot()
F = fk_all(root_el)
tris, cols = [], []
for l in root_el.findall("link"):
    for v in l.findall("visual"):
        m = v.find("geometry/mesh")
        if m is None:
            continue
        T = F[l.get("name")] @ T_of(v.find("origin"))
        V = read_stl(PKG / m.get("filename")) * np.array([float(x) for x in m.get("scale", "1 1 1").split()])
        tris.append(V @ T[:3, :3].T + T[:3, 3])
        cols.append(np.tile([float(x) for x in v.find("material/color").get("rgba").split()[:3]], (len(V), 1)))
P, C = np.concatenate(tris), np.concatenate(cols)
lo, hi = P.reshape(-1, 3).min(0), P.reshape(-1, 3).max(0)
ctr = (lo + hi) / 2
Wd, Ht, SS = 720, 1000, 2


def render(azim_deg, elev_deg, path, center=None, zoom=1.0):
    az, el = np.radians(azim_deg), np.radians(elev_deg)
    d = np.array([np.cos(el) * np.cos(az), np.cos(el) * np.sin(az), np.sin(el)])     # camera position direction
    c0 = ctr if center is None else np.asarray(center, float)
    eye = c0 + d * 3.2
    fwd = (c0 - eye) / np.linalg.norm(c0 - eye)
    right = np.cross(fwd, [0, 0, 1]); right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    Rc = np.stack([right, -up, fwd])                      # world -> camera (x right, y down, z forward)
    pc = (P - eye) @ Rc.T
    f = 0.62 * Ht * SS / (hi[2] - lo[2]) * 3.2 * 1.45 * zoom
    uv = pc[..., :2] / pc[..., 2:3] * f + np.array([Wd * SS / 2, Ht * SS / 2])
    n = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0])
    n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    light = -fwd * 0.6 + up * 0.6 + right * 0.3; light /= np.linalg.norm(light)
    shade = 0.35 + 0.65 * np.abs(n @ light)
    rgb = np.clip(C * shade[:, None], 0, 1)
    order = np.argsort(-pc[..., 2].mean(1))
    img = np.full((Ht * SS, Wd * SS, 3), 245, np.uint8)
    for k in order:
        cv2.fillConvexPoly(img, np.round(uv[k] * 4).astype(np.int32), tuple(int(255 * x) for x in rgb[k][::-1]), cv2.LINE_8, 2)
    img = cv2.resize(img, (Wd, Ht), interpolation=cv2.INTER_AREA)
    cv2.imencode(".png", img)[1].tofile(str(path))


torso_c = F["torso_link"][:3, 3] + F["torso_link"][:3, :3] @ np.array([0.15, 0.0, 0.15])
views = {"front": (25, 10, None, 1.0), "side": (95, 8, None, 1.0), "upper_body": (35, 18, torso_c, 2.6)}
for nm, (az, el, cc, zm) in views.items():
    render(az, el, PKG / f"preview_{nm}.png", cc, zm)
cv2.imencode(".png", np.hstack([cv2.imdecode(np.fromfile(str(PKG / f"preview_{nm}.png"), np.uint8), 1) for nm in views]))[1].tofile(
    str(PKG / "preview_all.png"))
print("previews written:", [f"preview_{nm}.png" for nm in views], "+ preview_all.png;", len(P), "triangles")
