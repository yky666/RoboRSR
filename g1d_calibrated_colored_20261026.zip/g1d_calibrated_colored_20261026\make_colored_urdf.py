# make_colored_urdf.py -- a ready-to-use, coloured URDF package of OUR calibrated G1-D (RoboDojo G1-D asset +
# params_final_sq382j): finishes from photos of the real robot (black glossy head, light grey-white torso / waist
# shells, brushed-aluminium arms with a black band on the forearm, black Dex1 grippers and camera housings, aluminium
# lift column, silver chassis, black wheels), the forearm band as its own mesh (elbow link split at x = 0.075 m, the
# region used for the 2026-10-22 material renders), and our four calibrated cameras as fixed links
# (<view>_camera: +x forward / +y left / +z up; <view>_camera_optical: OpenCV z forward / x right / y down).
# Kinematics, inertias and collision geometry are copied unchanged.
# usage: make_colored_urdf.py <calibrated package dir> <mesh dir> <out dir>
import json
import re
import shutil
import struct
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

PKG, MESH_SRC, OUT = (Path(a) for a in sys.argv[1:4])
COLORS = {  # linear-ish sRGB from the photos
    "g1d_black_gloss": (0.05, 0.05, 0.06, 1.0),      # head shell
    "g1d_dark_logo": (0.12, 0.12, 0.13, 1.0),
    "g1d_shell_white": (0.86, 0.87, 0.88, 1.0),      # torso, waist shells
    "g1d_aluminium": (0.71, 0.73, 0.76, 1.0),        # arms, wrists
    "g1d_black_matte": (0.07, 0.07, 0.08, 1.0),      # forearm band, Dex1 body, camera housing, fingers
    "g1d_pad_grey": (0.20, 0.20, 0.21, 1.0),         # finger tip pads
    "g1d_column": (0.76, 0.78, 0.81, 1.0),           # lift column
    "g1d_chassis": (0.80, 0.81, 0.83, 1.0),          # base plate
    "g1d_wheel": (0.04, 0.04, 0.04, 1.0),
}
RULES = [  # (link regex, mesh regex or None, material)
    (r"head_link", None, "g1d_black_gloss"),
    (r"logo_link", None, "g1d_dark_logo"),
    (r"torso_link|Yaw_Link|Pitching_Link", None, "g1d_shell_white"),
    (r".*_(shoulder_(pitch|roll|yaw)|elbow|wrist_(roll|pitch|yaw))_link", None, "g1d_aluminium"),
    (r".*_dex1_finger_link_\d_tip", None, "g1d_pad_grey"),
    (r".*_dex1_.*", None, "g1d_black_matte"),
    (r"LZ_.*_Link", None, "g1d_column"),
    (r"AGV_link", None, "g1d_chassis"),
    (r".*_Wheel_Link", None, "g1d_wheel"),
]
RING_LINK, RING_X = r"(left|right)_elbow_link", (0.075, 0.2)
CAM_LINKS = {"head_left": "head_left", "head_right": "head_right", "left_wrist": "left_wrist", "right_wrist": "right_wrist"}
R_OPT = np.array([[0, 0, 1], [-1, 0, 0], [0, -1, 0]], float)   # optical axes expressed in the x-forward camera frame


def read_stl(p):
    b = Path(p).read_bytes()
    n = struct.unpack("<I", b[80:84])[0]
    return np.frombuffer(b, np.dtype([("n", "<f4", 3), ("v", "<f4", (3, 3)), ("a", "<u2")]), n, 84).copy()


def write_stl(p, rec):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "wb") as f:
        f.write(b"g1d coloured split mesh".ljust(80, b" "))
        f.write(struct.pack("<I", len(rec)))
        f.write(rec.tobytes())


def material(name):
    m = ET.Element("material", name=name)
    ET.SubElement(m, "color", rgba=" ".join(f"{c:.3f}" for c in COLORS[name]))
    return m


def mat_for(link):
    return next((m for pat, _, m in RULES if re.fullmatch(pat, link)), None)


def origin_el(T):
    rpy = Rotation.from_matrix(T[:3, :3]).as_euler("xyz")
    return ET.Element("origin", xyz=" ".join(f"{v:.9g}" for v in T[:3, 3]), rpy=" ".join(f"{v:.9g}" for v in rpy))


# ---- meshes: copy, then split the elbow links into body + black band ----
if OUT.exists():
    shutil.rmtree(OUT)
shutil.copytree(MESH_SRC, OUT / "meshes")
split = {}
for side in ("left", "right"):
    rec = read_stl(OUT / "meshes" / f"{side}_elbow_link.STL")
    cx = rec["v"][:, :, 0].mean(1)
    ring = (cx > RING_X[0]) & (cx < RING_X[1])
    write_stl(OUT / "meshes" / f"{side}_elbow_link_band.STL", rec[ring])
    write_stl(OUT / "meshes" / f"{side}_elbow_link_body.STL", rec[~ring])
    split[f"{side}_elbow_link"] = (int(ring.sum()), int((~ring).sum()))
print("elbow split (band, body triangles):", split)

cams = json.loads((PKG / "camera_setup_ours.json").read_text(encoding="utf-8"))
report = {}
for src_name, out_name in (("g1d_dex1_calib.urdf", "g1d_calibrated_colored.urdf"),
                           ("g1d_mobile_dex1_calib.urdf", "g1d_mobile_calibrated_colored.urdf")):
    tree = ET.parse(PKG / src_name)
    root = tree.getroot()
    root.set("name", root.get("name") + "_calibrated_colored")
    for old in root.findall("material"):
        root.remove(old)
    for i, name in enumerate(COLORS):
        root.insert(i, material(name))
    counts = {}
    for link in root.findall("link"):
        name = link.get("name")
        mat = mat_for(name)
        for vis in list(link.findall("visual")):
            for old in vis.findall("material"):
                vis.remove(old)
            mesh = vis.find("geometry/mesh")
            if re.fullmatch(RING_LINK, name) and mesh is not None:
                idx = list(link).index(vis)
                link.remove(vis)
                for part, m in (("body", "g1d_aluminium"), ("band", "g1d_black_matte")):
                    v2 = ET.fromstring(ET.tostring(vis))
                    v2.set("name", f"{name}_{part}")
                    v2.find("geometry/mesh").set("filename", f"meshes/{name}_{part}.STL")
                    v2.append(material(m))
                    link.insert(idx, v2); idx += 1
                    counts[m] = counts.get(m, 0) + 1
                continue
            if mat is None:
                raise SystemExit(f"no colour rule for link {name}")
            vis.append(material(mat))
            counts[mat] = counts.get(mat, 0) + 1
    # calibrated cameras as fixed frames
    for view, c in cams["views"].items():
        T = np.array(c["T_parent_camera_world_convention"], float)
        cam = ET.SubElement(root, "link", name=f"{view}_camera")
        opt = ET.SubElement(root, "link", name=f"{view}_camera_optical")
        j = ET.SubElement(root, "joint", name=f"{view}_camera_joint", type="fixed")
        j.append(origin_el(T)); ET.SubElement(j, "parent", link=c["parent"]); ET.SubElement(j, "child", link=f"{view}_camera")
        j2 = ET.SubElement(root, "joint", name=f"{view}_camera_optical_joint", type="fixed")
        T2 = np.eye(4); T2[:3, :3] = R_OPT
        j2.append(origin_el(T2)); ET.SubElement(j2, "parent", link=f"{view}_camera"); ET.SubElement(j2, "child", link=f"{view}_camera_optical")
        for el in (cam, opt):
            el.append(ET.Comment(f" calibrated {view}: K {c['K']}, dist {c['dist_k1k2p1p2k3']}, {c['resolution']} "))
    ET.indent(tree, space="  ")
    hdr = (f"<!-- {out_name}: OUR calibrated G1-D (RoboDojo G1-D asset + params_final_sq382j, 2026-10-23), coloured from "
           f"photos of the real robot, calibrated cameras as fixed links. Generated by make_colored_urdf.py. -->\n")
    xml = ET.tostring(root, encoding="unicode")
    (OUT / out_name).write_text('<?xml version="1.0"?>\n' + hdr + xml + "\n", encoding="utf-8")
    report[out_name] = counts
print(json.dumps(report, indent=1))
shutil.copy(PKG / "camera_setup_ours.json", OUT / "camera_setup_ours.json")
shutil.copy(PKG / "params_final_sq382j.json", OUT / "params_final_sq382j.json")
shutil.copy(PKG / "physics_contract.json", OUT / "physics_contract.json") if (PKG / "physics_contract.json").exists() else None
print("written", OUT)
